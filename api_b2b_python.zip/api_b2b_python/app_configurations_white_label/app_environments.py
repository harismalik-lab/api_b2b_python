import os
from datetime import timedelta

from Crypto.Cipher import AES
from kombu import Queue

from app_configurations_white_label.security_credentials import BASIC_AUTH_CREDENTIALS
from app_configurations_white_label.settings import (
    BACKUP_DB_CONFIG, CONSOLIDATION_DB_CONFIG, DB_CONFIG, INFORMATICA_DB_CONFIG, SQL_POOL_SIZE, authentication_header,
    mongo_db_uri, secret_key_default
)


class Config(object):

    LIMITER_EXEMPT_FLAG = True  # Flag to set or exempt rate limit on resources
    PROCESS_HTTPS_ONLY = False
    SECRET_KEY = secret_key_default
    DEBUG = False
    TESTING = False
    BASE_DIR_PATH = os.path.dirname(__file__)
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(days=30)
    JWT_AUTH_HEADER_PREFIX = authentication_header
    JWT_HEADER_TYPE = authentication_header
    JWT_SECRET_KEY = SECRET_KEY
    MONGODB_SETTINGS = {'host': mongo_db_uri}
    MONGODB_CONNECT = False
    CELERY_BROKER_URL = 'filesystem://'
    CELERY_BROKER_FOLDER = 'celery_management'
    CELERY_PARENT_BROKER_FOLDER = os.path.join(os.getcwd(), CELERY_BROKER_FOLDER)
    BROKER_TRANSPORT_OPTIONS = {
        "data_folder_in": "out",
        "data_folder_out": "out",
        "processed_folder": "processed",
        'store_processed': "stored"
    }

    CELERY_BACKUP_BROKER_URL = 'sqla+sqlite:///celery_backup_transport.sqlite'
    CELERY_BACKUP_DB = 'celery_backup.sqlite'
    CELERY_RESULT_BACKEND = 'db+sqlite:///results.sqlite'
    BROKER_POOL_LIMIT = None
    BROKER_CONNECTION_MAX_RETRIES = None
    BROKER_CONNECTION_TIMEOUT = 30
    CELERY_CREATE_MISSING_QUEUES = True
    CELERY_RESULT_PERSISTENT = True
    CELERY_IGNORE_RESULT = False
    CELERY_TASK_RESULT_EXPIRES = None
    CELERYD_TASK_SOFT_TIME_LIMIT = 10
    CELERY_TASK_SEND_SENT_EVENT = True
    CELERY_TRACK_STARTED = True
    CELERY_TASK_COMPRESSION = 'gzip'
    CELERY_MESSAGE_COMPRESSION = 'gzip'
    CELERY_QUEUES = (
        Queue('default', routing_key='task.#'),
        Queue('high_priority', routing_key='high_priority.#')
    )
    CELERY_ROUTES = {
        'web_api.redemption.background_task.sync_rackspace_from_amazon': {
            'queue': 'high_priority',
            'routing_key': 'high_priority.sync_rackspace_from_amazon'
        },
        'web_api.redemption.background_task.sync_amazon_from_rackspace': {
            'queue': 'high_priority',
            'routing_key': 'high_priority.sync_amazon_from_rackspace'
        },
        'web_api.redemption.background_task.process_records': {
            'queue': 'high_priority',
            'routing_key': 'high_priority.process_records'
        }
    }
    JOBS = [
        {
            'id': 'periodic_sync',
            'func': 'web_api.redemption.background_task:periodic_sync',
            'trigger': 'interval',
            'seconds': 300
        }
    ]
    SQL_BACKUP_DB_CONFIG = BACKUP_DB_CONFIG
    SQL_DB_CONFIG = DB_CONFIG
    SQL_CONSOLIDATION_DB_CONFIG = CONSOLIDATION_DB_CONFIG
    SQL_INFORMATICA_DB_CONFIG = INFORMATICA_DB_CONFIG
    SQL_POOL_SIZE = SQL_POOL_SIZE
    HOME_SCREEN_HAPPY_BIRTHDAY_MAX_ALLOWED_NAME_LENGHT = 7
    HOME_SCREEN_HAPPY_BIRTHDAY_IMAGE = "https://s3.amazonaws.com/app-home-tiles/extras/happy_birthday_03.jpg"
    IS_DEV = False
    IS_STAGING = False
    IS_PRODUCTION = False
    ELASTIC_SEARCH_MAX_SEC_FOR_TIMEOUT = 3
    ELASTIC_SEARCH_MIN_STRING_LENGTH_FOR_SEARCH = 3
    ENTERTAINER_GAMIFICATION_API_KEY = "YzZmY2QwMjUxZjM2MThlNTE0NDM3ZWQ3OWEyY2QxN2U"
    ENTERTAINER_GAMIFICATION_ACTION_EARN = "add_smile"
    ENTERTAINER_GAMIFICATION_ACTION_BURN = "burn_smile"
    ENTERTAINER_GAMIFICATION_ACTION_SMILES = "get_user_smiles"
    API_CONTROLLER_REDEMPTION = "redemptions"
    API_CONTROLLER_REDEMPTION_SYNC = "redemptions/sync"
    SMS_SERVICE_READ_DATA_URL = "https://http-1-uat.reach-interactive.com/If00.asmx/SendMessage"
    SMS_SERVICE_READ_DATA_URL_WITH_PARAMS = "https://http-1.reach-interactive.com/If00.asmx/SendMessage?username=entertainer&password=ente2835&originator=Entertainer&callbackurl=www.google.com"  # noqa: E501
    SMS_SERVICE_READ_DATA_USER = "entertainer"
    SMS_SERVICE_READ_DATA_PASSWORD = "ente2835"
    SMS_SERVICE_READ_DATA_ORIGINATOR = "Entertainer"
    TRIPADVISOR_WEB_URL = "https://www.tripadvisor.com/WidgetEmbed-selfserveprop?border=true&popIdx=true&iswide=true&display=true&rating=true&writereviewlink=true&display_version=2&uniq=157&lang=en_US&nreviews=5&locationId="   # noqa: E501
    BADGE_VILLE_API_URL = "https://sandbox.badgeville.com/cairo/public_api/b6744b42ce965a9a1ab9a19dc671fe43/sites/548d5b87d4ed0ebe510010db/"   # noqa: E501
    BADGE_VILLE_API_KEY = "b6744b42ce965a9a1ab9a19dc671fe43"
    BADGE_VILLE_API_ID = "548d5b87d4ed0ebe510010db"
    ANALYTICS_SAVINGS_V1_URL = "http://api.theentertainerme.com/api_analytics/web/public_api/users/"
    ANALYTICS_SAVINGS_V2_URL = "http://api.theentertainerme.com/api_analytics/web/v2/users/"
    PROFILE_IMAGE_DIRECTORY = "/home/webdeploy/EntertainerProfilePics/"
    PROFILE_IMAGE_SERVER = "https://resources.theentertainerme.com/"
    APPBOY_FEEDER_URL = "http://api.theentertainerme.com/appboy_feeder/Main/process_info"
    PYTHON_API_BASE = "http://0.0.0.0:8085/"
    APPBOY_END_EXTEND_NOTIFICATION_URL = "https://api.appboy.com/users/track"
    APPBOY_SEND_MESSAGE_ENDPOINT = "/campaigns/trigger/send"
    IS_HOT_SUMMER_NIGHTS_ON = True
    IS_OFFLINE = False
    IS_ANALYTICS = False
    IS_REWARDS = False
    JWT_TOKEN_ENABLED = False
    IS_DELIVERY_CASHLESS = False
    SEND_APPBOY_PUSH_NOTIFICATION = True
    AWS_SECRET_ACCESS_KEY = 'EFe0T50pRXqwBCmBBxoV/88dQdkB08fs6dkugdSi'
    AWS_ACCESS_KEY_ID = 'AKIAJ2CHVBBS5NUO6IKQ'
    AWS_DEFAULT_REGION = 'us-west-2'
    BASIC_AUTH_ENABLED = False
    APS_SCHEDULE = True
    CELERY_RETRY_TIME = 180  # celery retry time 3 minutes
    FEEDBACK_RECIPIENT_EMAIL = 'product@theentertainerme.com'
    ELASTIC_SEARCH_BASE_URL = 'http://134.213.138.183:9222'
    ELASTIC_SEARCH_INDEX_NAME = 'ent_en'
    CACHE_TYPE = 'simple'
    PARAM_ENCRYPTION_KEY = "18b8c9ef473e2126c3c56ab0cb2b71cb"
    PARAM_ENCRYPTION_SALT = "18b8c9ef473e2126"
    PARAM_ENCRYPTION_MODE = AES.MODE_CBC
    LOGS_PATH = 'logs'
    IS_SWAGGER_ON = False
    SWAGGER_DOCS_PATH = os.path.join(os.getcwd(), 'common/locales/swagger_doc')
    FIRE_BASE_API_KEY_ANDROID = 'AIzaSyCsu5iB3FW62MEDu3V0bcABWJcFz2yo47w'
    FIRE_BASE_API_KEY = 'AAAA2ltpcIQ:APA91bFoptG8UyTGJAQMGDmEzb_VOnQv3zz3Qppc-Kg_FCZbwrXo7riLDxNNtNdIMew2zQeWa7CvqUS8kn2kxBKHlvBzzDFlzY_eexGP85KDrcQ8CxneT3uY8K6uZAlSVj2roJfoV1H8'  # noqa: E501
    CLICK_ACTION_ORDER = "https://dm.theentertainerme.com/"
    CLICK_ACTION_ICON = "https://dm.theentertainerme.com/entertainer-icon.jpg"
    CORS_REGIONS = {
        r"/delivery_pos_api/*": {'origins': 'dm.theentertainerme.com'}
    }
    IS_CELERY_ON = False
    GAMIFICATION_CONFIG = {
        'user': 'creativity',
        'password': 'HwJnm5_QP29ww_v6F7W'
    }
    SMILES_API_TIMEOUT = 5
    ELASTIC_SEARCH_MAX_POOL_SIZE = 200
    GENERATE_ALL_APM_LOGS = False
    GENERATE_APM_ERROR_LOGS = False
    ELASTIC_APM = {
        'SERVICE_NAME': 'Entertainer',
        'SECRET_TOKEN': '',
        'SERVER_URL': '',
        'AUTO_LOG_STACKS': False,
        'SERVER_TIMEOUT': 1,
        'PROCESSORS': (
            'common.flask_elastic_apm.apm_jinja_span_filter_processor',
            'common.flask_elastic_apm.apm_status_code_processor',
            'elasticapm.processors.sanitize_stacktrace_locals',
            'elasticapm.processors.sanitize_http_request_cookies',
            'elasticapm.processors.sanitize_http_headers',
            'elasticapm.processors.sanitize_http_wsgi_env',
            'elasticapm.processors.sanitize_http_request_querystring',
            'elasticapm.processors.sanitize_http_request_body'
        )
    }
    D_CART_URL = "https://awesome.theentertainerme.com/delivery"
    CINEMA_URL = ''
    VISA_IFRAME_TOKEN_URL = ''
    VISA_GET_VALIDATION_URL = ''
    VISA_CERT_FILE_PATH = ''
    VISA_KEY_FILE_PATH = ''
    VISA_VENDOR_UNIQUE_ID = ''
    VISA_USERNAME = ''
    VISA_PASSWORD = ''
    EGO_VISA_PARAM_DECRYPTION_KEY = ''
    EGO_VISA_PARAM_DECRYPTION_SALT = ''
    BAT_URL = ""


class ProductionConfig(Config):
    SQLALCHEMY_DATABASE_URI = 'mysql://user@localhost/foo'


class DevelopmentConfig(Config):
    DEBUG = True
    NEW_CART_URL = "https://entqacart.etenvbiz.com/products2018?et=1&utm_source=app&utm_medium=cart-icon&utm_campaign=cart_icon_app_gbl"   # noqa: E501
    KALIGO_SIGN_IN_API_ENDPOINT = "https://entertainer.kaligo-staging.xyz/whitelabel/entertainer/sign_in"
    KALIGO_ENCRYPTION_KEY = "89d20b535d8afa50"
    GAMIFICATION_URL = "https://apistaging.theentertainerme.com/gamify/web/v2/"
    ELASTIC_SEARCH_URL = "http://192.168.59.26:9200/entertainer_en/data_en/_search"
    IS_DEV = True
    ELASTIC_SEARCH_IS_ON = False
    FLASK_PROFILER_IS_ON = False
    MONGO_ERROR_LOG_URL = "http://apistaging.theentertainerme.com/api_analytics/web/public_api/error/api/log"
    REFERRAL_URL = "https://entqacart.etenvbiz.com/site/connectreferralsignupnew/?_t=r&_i="
    CONNECT_URL = "https://entqacart.etenvbiz.com/site/connectreferral/?_t=c&_i="
    ENTERTAINER_GAMIFICATION_ENVIRONMENT = "Staging"
    REDEMPTION_ENDPOINT_V51 = "http://ent.local/api_consolidation/web/v51/redemptions"
    REDEMPTION_ENDPOINT_URL = 'http://0.0.0.0:5000/api_consolidation/web/v{version}/{end_point}'
    REDEMPTION_ENDPOINT_FOR_OFFLINE = REDEMPTION_ENDPOINT_URL.format(version='o59', end_point='redemptions')
    REDEMPTION_ENDPOINT_FOR_OFFLINE_V592 = REDEMPTION_ENDPOINT_URL.format(version='o592', end_point='redemptions')
    REDEMPTION_ENDPOINT_V22 = "http://ent.local/api_consolidation/web/v22/redemptions"
    REDEMPTION_ENDPOINT = "http://ent.local/api_consolidation/web/v20/redemptions"
    API_ENDPOINT = "http://0.0.0.0:5000/api_consolidation/web/{version}/{controller}"
    PASSWORD_RESET_URL = "https://0.0.0.0:5000/api_consolidation/web/v59/password?token="
    BUY_PAGE_URL = 'https://cart.theentertainerme.com/buy/checkout'
    FLASK_PROFILER = {
        "enabled": FLASK_PROFILER_IS_ON,
        "storage": {
            "engine": "mongodb",
            "COLLECTION": "flask_profiler_python_api"
        },
        "basicAuth": {
            "enabled": FLASK_PROFILER_IS_ON,
            "username": 'prototype',
            "password": 'prototype'
        },
        "ignore": [
            "^/static/.*"
        ]
    }
    BASIC_AUTH_CREDENTIALS = BASIC_AUTH_CREDENTIALS


class TestingConfig(DevelopmentConfig):
    TESTING = True
    APS_SCHEDULE = False
    PRESERVE_CONTEXT_ON_EXCEPTION = False
    CELERY_BROKER_URL = 'memory://'
    CELERY_BACKUP_BROKER_URL = CELERY_BROKER_URL


class AnalyticsConfig(TestingConfig):
    IS_ANALYTICS = True
    BASIC_AUTH_ENABLED = False
    MONGODB_SETTINGS = {
        'host': 'mongodb://mongostuser:edawoletYrI1M6QM1V@134.213.252.56:22222/entertainer'
    }


class DeliveryCashLessConfig(TestingConfig):
    IS_DELIVERY_CASHLESS = True
    BASIC_AUTH_ENABLED = False


class RewardsConfig(TestingConfig):
    IS_REWARDS = True


class OfflineConfig(TestingConfig):
    IS_OFFLINE = True
    BASIC_AUTH_ENABLED = False
    SQL_BACKUP_DB_CONFIG = DB_CONFIG
    SQL_DB_CONFIG = BACKUP_DB_CONFIG
