api_prefix = '/et_rs_prd/b2b_p/pl'
api_analytics_prefix = '/api_analytics/web'
default_db_name = 'entertainer_web'
backup_db_name = 'test_ent_web_amazon'
consolidation_db_name = 'consolidation'
informatica_db_name = 'informatica'
sql_user = 'gen_dv_api_rgc'
sql_password = 'F7xnPVIRJlip8VWnb3'
sql_host = 'te-dev-db.cluster-cs6ndhrqo5f6.eu-west-1.rds.amazonaws.com'


DB_CONFIG = {
    "database": default_db_name,
    "user": sql_user,
    "host": sql_host,
    "password": sql_password
}
BACKUP_DB_CONFIG = {
    "database": backup_db_name,
    "user": sql_user,
    "host": sql_host,
    "password": sql_password
}
CONSOLIDATION_DB_CONFIG = {
    "database": consolidation_db_name,
    "user": sql_user,
    "host": sql_host,
    "password": sql_password
}
INFORMATICA_DB_CONFIG = {
    "database": informatica_db_name,
    "user": sql_user,
    "host": sql_host,
    "password": sql_password
}
ONLINE_LOG_PATH = 'web_api_logs/'
ANALYTICS_LOG_PATH = 'analytics_logs/'
OFFLINE_LOG_PATH = 'offline_api_logs/'
DAL_LOGS_PATH = 'dal_logs/'
REWARDS_LOGS_PATH = 'rewards_api_logs/'
DELIVERY_LOGS_PATH = 'delivery_cashless_api_logs/'
WHITE_LABEL_LOG_PATH = 'white_label_logs_path/'

all_sub_logs_folders = ['white_label_logs_path']

DEBUG = True
authentication_header = 'Bearer'
secret_key_default = 's3cr3tk3ys3cr3tk3y'
SQL_POOL_SIZE = 1

testing_hostname = 'http://localhost'
testing_port = '7000'

rabbit_mq_broker_url = 'amqp://guest:guest@127.0.0.1:5672/'
redis_broker_url = 'redis://127.0.0.1:6379/0'
mongo_db_uri = 'mongodb://localhost/test_ent'
SMILES_ICON_URL = "https://s3.amazonaws.com/entertainer-app-assets/icons/smiles_icon.png"
FREEMIUM_DUMMY_IMAGE = 'https://s3.amazonaws.com/entertainer-app-assets/freemium_dummy_image.jpg'
SMILES_COLOR_CODE = "e2bb55"
COLOR_CODE_ALREADY_REDEEMED = "de595b"
