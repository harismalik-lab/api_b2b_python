BASIC_AUTH_CREDENTIALS = {
    '3rd_party_zomato': 'J2QYWMH64FKUQ3RXHJD45DDJ036',
    'api_ios': '182927592559a46d3dfab63',
    'api_android': '230097930559a46ce09a157',
    'api_windows': '253014570559a46bb27cf35',
    'FutureWorkshops': 'bHJuia7sh',
    'user_alpha': 'BDubfDQx',
    'user_beta': '4fkUQ3rx',
    'user_gamma': 'pt7z5DZA',
    'user_delta': 'j2QYwMh6',
    'user_epsilon': 'n57fxLNa',
    'user_zeta': 'TAHxWpQA',
    'entertainer': 'J2QdWMH64dsQ3RXyinD45DDssw036',
    'nfDlZWgVNJfOlofA': 'SF?e(3VdCMW%<t>&K+Jm!#b~Qj*}yA]P',
    'qlzfqghpkeiwhmzg': 'k$V}B*(6DK5ymTNbH?4<rj3uGF;[~t>q',
    'da6be6d0-f4d9-4c38': '8bc4124e-d87e-43ca-a874-fe8661fa8efc',
    'VqMU4vjHd7j4NT8f': 's$fKq(L&Sg?;rk*H2^wC@Y!9b[Nh%P74',
    'u5YBy8TvbXLpNZfN': 'YXD}d6$S{AvjRHzM%fr_48`TJaPe&B7b'  # credentials for vodafone app
}

PHP_BASIC_AUTH_CREDENTIALS = {
    'web_rtrewK435036': 'JHSF*(SHIHH*(#$DFGD7636d6$S{Av36',
    'prototype': 'prototype'
}

encryption_disable_key = '0af5d6f0-4dd9-498d-8d2c-acf8c80ad9ba'
