from flask import current_app

from routing.b2b_python_api_routing.v1.api_v1 import B2bPythonApiV1


def api_urls():
    B2bPythonApiV1(app=current_app, name=B2bPythonApiV1.__name__).map_urls()
