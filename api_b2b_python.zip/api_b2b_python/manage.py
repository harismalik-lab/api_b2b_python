import os
import sys
import urllib

from flask import url_for
from flask_apidoc.commands import GenerateApiDoc
from flask_migrate import Migrate, MigrateCommand
from flask_script import Manager

from app import create_app

app = None


def manager_app():
    global app
    _app = 'web_api'
    if '-a' in sys.argv:
        app_index = sys.argv.index("-a")
        try:
            _app = sys.argv[app_index + 1]
            del sys.argv[app_index + 1]
        except IndexError:
            pass
        try:
            del sys.argv[app_index]
        except IndexError:
            pass

    if _app == 'analytics':
        app = create_app(config_settings='app_configurations.app_environments.AnalyticsConfig')['app']
    elif _app == 'offline':
        app = create_app(config_settings='app_configurations.app_environments.OfflineConfig')['app']
    elif _app == 'rewards':
        app = create_app(config_settings='app_configurations.app_environments.RewardsConfig')['app']
    elif _app == 'delivery':
        app = create_app(config_settings='app_configurations.app_environments.DeliveryCashLessConfig')['app']
    else:
        app = create_app()['app']
    return app


manager = Manager(manager_app())
manager.add_command(
    'apidoc',
    GenerateApiDoc(input_path='{pwd}/white_labels_api/'.format(pwd=os.getcwd()))
)


@manager.command
def db_shell():
    app_info = create_app()
    app = app_info['app']
    db = app_info['db']
    Migrate(app, db)
    MigrateCommand()


@manager.option('-v', '--version', dest='version', default='all')
def routes(version='all'):
    output = []
    for rule in app.url_map.iter_rules():
        if version == 'all' or version in rule.endpoint:
            options = {}
            for arg in rule.arguments:
                options[arg] = "[{0}]".format(arg)
            methods = ','.join(rule.methods)
            try:
                url = url_for(rule.endpoint, **options)
            except Exception:
                # Case where options dict contains some key, value like 'merchant_id': '[mercahnt_id]'
                if options:
                    for key, value in options.items():
                        # Replaces string values with 0 so that url_for wont break
                        options[key] = 0
                    url = url_for(rule.endpoint, **options)
                    url = url.replace('0', ':id')  # Replacing out hardcoded 0 with :id
            line = urllib.parse.unquote("{:50s} {:20s} {}".format(rule.endpoint, methods, url))
            output.append(line)

    for line in sorted(output):
        print(line)


if __name__ == '__main__':
    manager.run()
