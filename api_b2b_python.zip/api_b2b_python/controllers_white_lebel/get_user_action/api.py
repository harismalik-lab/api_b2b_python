"""
Gets user action api white label
"""
from common.base_resource import BaseGetResource
from common.common_helpers import CommonHelpers
from user_authentication.authentication import get_current_customer

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH

__author__ = 'ali'


class GetUserApiWL(BaseGetResource):
    """
    Get user action api white label
    """
    required_token = True
    response = {}
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='get_user_api/get_user_api.log',
        ),
        'name': 'get_user_api'
    }

    def initialize_class_attributes(self):
        """
        Initialize class attributes for get user action api
        """
        self.messages_locale = CommonHelpers.get_locale(self.locale, location_id=0)
        self.customer = get_current_customer()
        self.customer_id = self.customer.get('customer_id')

    def validate_customer(self):
        """
        Validate customer
        """
        if str(self.customer_id) != str(self.user_id):
            self.send_response_flag = True
            self.status_code = 403
            self.response = {
                "message": self.message_repo_instance.get_message_by_code(
                    self.message_repo_instance.you_are_not_allowed_to_access_this_application,
                    self.messages_locale
                ),
                "success": False,
                "code": 50
            }
            return self.send_response(self.response, self.status_code)
