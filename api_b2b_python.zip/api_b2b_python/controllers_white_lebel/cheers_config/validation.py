"""
Validation for cheers config api
"""
from common.common_helpers import get_request_parser
from common.custom_fields_request_parser import language
from flask_restful.inputs import regex

configs_parser = get_request_parser()
configs_parser.add_argument(
    'language',
    type=language,
    location=['mobile', 'values', 'json'],
    required=False,
    default='en'
)
configs_parser.add_argument(
    'app_version',
    type=str,
    location=['mobile', 'values', 'json'],
    required=False
)
configs_parser.add_argument(
    'wl_company',
    type=str,
    required=True
)
configs_parser.add_argument(
    '__platform',
    type=regex('[a-zA-Z]'),
    required=False,
    location=['mobile', 'values'],
    default='True'
)
