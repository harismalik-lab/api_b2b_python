"""
Cheers Config API
"""
from common.common_helpers import CommonHelpers
from requests import codes
from web_api.configs.api import CheersConfigsApi
from web_api.configs.validation_configs import configs_parser as config_parser

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from repositories_white_label.cheers_config_repo import CheersConfigsRepositoryWL


class CheersConfigsApiWL(CheersConfigsApi):
    """
    Cheers configuration api that handles all the requests related to cheers config and perform
    all the related functions.
    """
    request_parser = config_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='cheers_configs_api/cheers_config_api.log',
        ),
        'name': 'cheers_configs_api'
    }

    def populate_request_arguments(self):
        """
        Add request arguments of cheers config api
        """
        super().populate_request_arguments()
        self.company = self.request_args.get('company')

    def initialize_class_attributes(self):
        """
        Initialize class attributes for cheers config api
        """
        self.locale = CommonHelpers.get_locale(self.locale, location_id=0)

    def generate_final_response(self):
        """
        Generates final response
        """
        cheers_configurations = CheersConfigsRepositoryWL.get_cheers_configuration(
            self.locale, self.company
        )
        self.send_response_flag = True
        self.response = {
            'data': {
                'cheers_rules': cheers_configurations
            },
            'success': True,
            'message': 'success'
        }
        self.status_code = codes.OK

    def process_request(self):
        """
        Handles the retrieval of configs related to cheers
        """
        self.initialize_class_attributes()
        self.generate_final_response()
