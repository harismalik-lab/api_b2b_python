"""
This module contains Merchant APi
"""

from requests import codes

from python_api.app_configurations.settings import ONLINE_LOG_PATH
from python_api.common.base_resource import BaseDynamicResource
from python_api.common.common_helpers import CommonHelpers, OfferManager, multi_key_sort
from python_api.repositories.categories_repo import CategoriesRepository
from python_api.repositories.exchange_rates_repo import ExchangeRatesRepository
from python_api.repositories.merchant_repo import MerchantRepository
from python_api.repositories.offer_ent_active_repo import OfferEntActiveRepository
from python_api.repositories.outlet_repo import OutletRepository
from python_api.repositories.product_ent_active_repo import ProductEntActiveRepository
from python_api.repositories.share_offer_repo import ShareOfferRepository
from python_api.repositories.smiles_repo import SmileRepository
from python_api.repositories.top_up_offer_repo import TopUpOffersRepository
from python_api.repositories.translation_repo import MessageRepository
from python_api.user_authentication.authentication import get_current_customer
from python_api.web_api.merchants.validation_merchant_by_id import merchant_parser as merchant_by_id_parser
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.delivery_menu_items_repo import DeliveryMenuItemsRepositoryWL
from repositories_white_label.location_repo import LocationRepositoryWhiteLabel
from repositories_white_label.merchant_repo import MerchantRepositoryWl
from repositories_white_label.product_repo import ProductRepoWL
from repositories_white_label.v_67.offer_wl_active_repo import OfferWlRepositoryV67
from repositories_white_label.wl_company_repo import WLCompany
from repositories_white_label.wl_product_repo import WLProductRepository
from repositories_white_label.wl_user_group_repo import WlUserGroup
from repositories_white_label.wl_validtion_repo import WlValidationRepository

__author__ = 'ali'


class MerchantApi(BaseDynamicResource):
    """
    This class contains endpoint for get merchant by id
    """
    required_token = True
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ONLINE_LOG_PATH,
            file_path='merchants_api/merchants_api.log',
        ),
        'name': 'merchants_api'
    }
    request_parser = merchant_by_id_parser
    connections_names = ['default', 'consolidation']

    def populate_request_arguments(self):
        """
        Add request arguments of merchant_api
        """
        self.redeemability = self.request_args.get('redeemability')
        self.company = self.request_args.get('company')
        self.category = self.request_args.get('category')
        self.locale = self.request_args.get('language')
        self.currency = self.request_args.get('currency')
        self.location_id = self.request_args.get('location_id')
        self.offer_id = self.request_args.get('offer_id')
        self.platform = self.request_args.get('__platform').lower()
        self.device_key = self.request_args.get('device_key')
        self.user_id = self.request_args.get('user_id')
        self.app_version = self.request_args.get('app_version')
        self.lattitude = self.request_args.get('lat')
        self.longitude = self.request_args.get('lng')
        self.message_locale = CommonHelpers.get_locale_for_messaging(self.locale)
        self.is_cuckoo = self.request_args.get('is_cuckoo')
        self.user_include_cheers = self.request_args.get('user_include_cheers')

    def initialize_changable_repos(self):
        """
        Initialize changeable repo's
        """
        self.merchant_repo = MerchantRepository()
        self.offer_repo = OfferEntActiveRepository()

    def initialize_repos(self):
        """
        This method initializes repository instances
        """
        self.customer_profile_white_label = CustomerProfileWhiteLabel()
        self.message_repo = MessageRepository()
        self.category_repo = CategoriesRepository()
        self.topup_offer_repo = TopUpOffersRepository()
        self.currency_converter = ExchangeRatesRepository()
        self.outlet_repo = OutletRepository()
        self.initialize_changable_repos()
        self.delivery_menu_items_repo = DeliveryMenuItemsRepositoryWL()
        self.share_offer_repo = ShareOfferRepository()
        self.smile_manager = SmileRepository(logger=self.logger)
        self.product_ent_active_repo = ProductEntActiveRepository()
        self.location_repo = LocationRepositoryWhiteLabel()
        self.wl_product_repo = WLProductRepository()
        self.offer_wl_active_repo = OfferWlRepositoryV67()
        self.wl_validation = WlValidationRepository()

    def initialize_local_variables(self):
        """
        Initialize local variables
        """
        self.message_locale = CommonHelpers.get_locale_for_messaging(
            self.request_args.get('language')
        )
        self.lat_long = "{},{}".format(self.lattitude, self.longitude)
        self.customer_info = {}
        self.outlet_ids_having_offers = []
        self.outlets_filtered = []
        self.outlet_ids = []
        self.offers_array = {}
        self.product_ids_exist = False
        self.purchasable_product_ids = []
        self.offer_categories = []
        self.offer_sub_categories = []
        self.show_point_based_offers = False
        self.redeemability_for_delivery = {}
        self.delivery_offers_count = 0

    def set_current_customer_data(self):
        """
        Set current customer data
        """
        self.customer = get_current_customer()
        self.user_group = WlUserGroup.DEFAULT_USER_GROUP
        if not self.customer.get('IS_USER_LOGGED_IN') and self.customer.get('IS_PREACTIVATED_APP'):
            self.customer['PRODUCT_IDS'] = self.wl_product_repo.get_configured_products(
                self.company,
                WlUserGroup.DEFAULT_USER_GROUP
            )
        if self.customer.get('IS_USER_LOGGED_IN'):
            self.user_group = WlValidationRepository.get_user_groups(self.company, self.user_id)

    def get_merchant(self, **kwargs):
        """
        Find merchant by supplied id
        """
        self.merchant = self.merchant_repo.find_by_id(
            kwargs.get('merchant_id'),
            self.message_locale
        )
        if not self.merchant:
            self.status_code = codes.INTERNAL_SERVER_ERROR
            self.set_response(
                {
                    'message': 'Merchant does not exist.'
                },
                codes.INTERNAL_SERVER_ERROR
            )

    # self.company param missing in get_merchant_attributes_by_merchant_id
    def get_merchant_attributes(self, **kwargs):
        """
        Get merchant attributes
        """
        if self.merchant.get('is_tutorial'):
            self.merchant['is_tutorial'] = self.merchant.get('is_tutorial') > 0
        self.merchant_attributes = self.merchant_repo.get_merchant_attributes_by_merchant_id(
            kwargs.get('merchant_id'),
            self.merchant.get('category'),
            self.message_locale
        )

    def get_delivery_menu_item(self, **kwargs):
        """
        Get delivery menu items
        """
        self.merchant_menu_items = self.delivery_menu_items_repo.get_menu_items(
            kwargs.get('merchant_id'),
            self.message_locale
        )
        if self.merchant_menu_items.get('delivery_tutorials_info')[3]:
            self.merchant_menu_items['delivery_tutorials_info'][3] = ''

    def get_active_outlets(self, **kwargs):
        """
        Grab active outlets for this merchant
        """
        self.outlets = self.outlet_repo.find_by_merchant(
            merchant_id=kwargs.get('merchant_id'),
            location_id=0,
            latlong=self.lat_long,
            locale=self.locale,
        )
        for outlet in self.outlets:
            if outlet['delivery_telephone'] == '':
                outlet['delivery_telephone'] = self.merchant.get('delivery_contact_no')
            self.outlet_ids.append(outlet.get('id'))

            if outlet.get('name') and 'Ritz-Carlton' not in outlet.get('name'):
                outlet_name_parts = outlet['name'].split('-')
                outlet['name'] = outlet_name_parts[-1].strip()

    def load_customer_object(self):
        """
        Get customer profile and populate the customer information
        """
        self.customer['IS_USER_LOGGED_IN'] = True
        if self.customer.get('IS_USER_LOGGED_IN'):
            self.customer_profile = self.customer_profile_white_label.\
                load_customer_profile_by_user_id(user_id=self.customer.get('customer_id'))
            if self.customer_profile:
                self.customer_info['user_id'] = self.customer.get('customer_id')
                self.customer_info['is_demographics_updated'] = self.customer_profile_white_label.\
                    is_demographics_updated(self.customer.get('customer_id'))

    def check_company(self):
        """
        Check white label company
        """
        if self.company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS and self.app_version > 1.3:
            self.show_point_based_offers = True

    # TODO: Testing remaining of those functions which include offer_wl_active_repo
    def get_all_active_offers(self):
        """
        Get the array of all active offers against this merchant
        """
        self.offers = self.offer_repo.find_by_outlets(
            self.outlet_ids,
            self.company,
            self.is_cuckoo,
            self.purchasable_product_ids,
            self.category,
            self.offer_categories,
            self.offer_sub_categories,
            self.locale,
            self.customer,
            self.user_include_cheers,
            self.show_point_based_offers
        )

        if self.offer_categories > 0:
            self.merchant['category'] = self.offer_categories
        else:
            self.merchant['category'] = ""
        self.merchant['categories'] = self.offer_categories
        self.merchant['merchant_categories'] = self.offer_categories
        self.merchant['categories_analytics'] = OfferManager.get_category_codes_for_analytics(
            self.offer_categories
        )
        self.merchant['offer_categories'] = self.offer_categories
        self.merchant['sub_categories'] = self.offer_sub_categories
        self.merchant['digital_section'] = ', '.join([str(i) for i in self.offer_sub_categories])

        if self.company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
            if self.merchant['category'] == self.category_repo.category_API_Name_Retail:
                self.merchant['category'] = self.category_repo.category_API_Name_Services

    def get_outlets_having_offers(self):
        """
        Outlet id having offers
        """
        for offer in self.offers:
            for id in offer.get('outlet_ids'):
                self.outlet_ids_having_offers.append(id)
                # self.outlet_ids_having_offers = id

    def get_outlets_present_in_offer_list(self):
        """
        Get the outlets present in offer list
        """
        outlet_ids_having_offers = set(self.outlet_ids_having_offers)
        for outlet in self.outlets:
            for outlet_ids_having_offer in outlet_ids_having_offers:
                if outlet.get('id') == outlet_ids_having_offer:
                    self.outlets_filtered.append(outlet)
        # self.outlet_ids_having_offer = ''

    def sort_offers_list(self):
        """
        Sort Offers list By the following parameters ($b - $a) means $b is greater than $a
        """
        self.offers = multi_key_sort(
            self.offers,
            columns=[
                '-is_purchased', '-is_ent',
                '-is_monthly', '-is_new', '-is_delivery',
                '-is_cheers', 'product_id'
            ]
        )

    def set_offer_currency(self):
        """
        Set currency and check whether product_name already exist in the offers array
        """
        for offer in self.offers:
            offer['savings_estimate_aed'] = offer.get('savings_estimate')
            if self.currency.lower() == offer['local_currency'].lower() and \
                    offer.get('savings_estimate_local_currency') and \
                    offer.get('savings_estimate_local_currency') > 0:

                offer['savings_estimate'] = offer['savings_estimate_local_currency']
            else:
                offer['savings_estimate'] = self.currency_converter.get_conversion_rate(
                    offer['savings_estimate'],
                    'AED',
                    self.currency
                )
            offer['show_smiles_earn_value'] = False
            offer['smiles_earn_value'] = 0
            offer['smiles_burn_value'] = 0

            if offer['is_delivery']:
                self.redeemability_for_delivery['total_offers'] = self.redeemability_for_delivery.get('total_offers', 0)
                self.redeemability_for_delivery['total_offers'] += offer['quantity_redeemable']
                self.redeemability_for_delivery['total_offers'] += offer['quantity_redeemed']
                self.redeemability_for_delivery['total_offers'] += offer['quantity_not_redeemable']
                self.redeemability_for_delivery['total_offers'] -= offer['quantity_redeemed']
                self.delivery_offers_count += 1
            product_id_exists = False
            for key, value in self.offers_array.items():
                if key == 'product_id':
                    if value == offer.get('product_id'):
                        product_id_exists = True
            if not self.offers_array or not product_id_exists:
                self.offers_array = {'product_id': offer.get('product_id')}

    # Need to test all functions which include offers_array
    def get_location_categories(self):
        """
        Get location categories
        """
        if self.offers_array:
            self.categories = self.location_repo.get_location_categories(
                self.company, self.location_id, self.user_group, self.locale
            )
            replace_241_type_with_141 = False
            if(
                self.company.lower() == WLCompany.COMPANY_CODE_ENTERTAINER_CHANGI_REWARDS_ENTERTAINER and
                self.location_id == 11
            ):
                replace_241_type_with_141 = True
            self.offers_array = self.merchant_repo.formulate_offer_details_array(
                self.offers, self.offers_array, self.message_locale,
                not self.customer.get('IS_USER_LOGGED_IN'),
                self.categories, self.company, replace_241_type_with_141
            )

    def prepare_merchant_object(self):
        """
        Prepare merchant object for final response data
        """
        if self.delivery_offers_count > 0:
            self.merchant['has_delivery_offers'] = True
        else:
            self.merchant['has_delivery_offers'] = False

        self.merchant_menu_items['offers_remaining'] = "{total_offers} {messsage}".format(
            total_offers=int(self.redeemability_for_delivery.get('total_offers', 0)),
            messsage=self.message_repo.get_message_by_code(
                self.message_repo.delivery_offers_remaining,
                self.message_locale
            )
        )
        if not self.customer_info:
            self.customer_info['user_id'] = 0
            self.customer_info['is_demographics_updated'] = False
        # self.merchant['merchant_attributes'] = self.merchant_attributes
        self.merchant['outlets'] = self.outlets_filtered
        self.merchant['offers'] = self.offers_array
        self.merchant['delivery_section'] = self.merchant_menu_items
        self.merchant['customer'] = self.customer_info

    def prepare_response(self):
        """
        Set final response for merchant api
        :return:
        """
        self.response = {
            'success': True,
            'message': 'success',
            'data': self.merchant,
            'code': 0
        }
        self.send_response_flag = True
        self.status_code = codes.OK

    def process_request(self, *args, **kwargs):
        """
        Control the flow of merchant api
        """
        self.initialize_repos()
        self.initialize_local_variables()
        self.set_current_customer_data()
        self.get_merchant(**kwargs)
        # self.get_merchant_attributes(**kwargs)
        self.get_delivery_menu_item(**kwargs)
        self.get_active_outlets(**kwargs)
        self.load_customer_object()
        self.check_company()
        # self.get_all_active_offers()
        # self.get_outlets_having_offers()
        self.get_outlets_present_in_offer_list()
        # self.sort_offers_list()
        # self.set_offer_currency()
        self.get_location_categories()
        # missing self.merchant_attributes
        self.prepare_merchant_object()
        self.prepare_response()


class MerchantsApiAction(BaseDynamicResource):
    """
    This class contains merchant API endpoints
    """
    required_token = True
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ONLINE_LOG_PATH,
            file_path='merchants_api/merchants_api.log',
        ),
        'name': 'merchants_api'
    }
    request_parser = merchant_by_id_parser
    connections_names = ['default', 'consolidation']

    def populate_request_arguments(self):
        """
        Add request arguments for merchant_api_action
        """
        self.company = self.request_args.get('company')
        self.product_sku = self.request_args.get('product_sku')
        self.locale = self.request_args.get('language')
        self.currency = self.request_args.get('currency')
        self.platform = self.request_args.get('__platform').lower()
        self.offset = self.request_args.get('offset')
        self.limit = self.request_args.get('limit')
        self.active = self.request_args.get('active')
        self.product_sf_id = self.request_args.get('sf_id')

    def initialize_repos(self):
        """
        Initialize repo's
        """
        self.merchant_repo = MerchantRepositoryWl()
        self.exchanges_rates_repo = ExchangeRatesRepository()
        self.product_ent_active_repo = ProductEntActiveRepository()
        self.wl_product_repo = WLProductRepository()
        self.product_repo = ProductRepoWL()

    def initialze_local_variables(self):
        """
        Initialize local variables
        """
        self.bundled_product_skus = []

    def set_current_customer(self):
        """
        Get the bundled skus against the purchasable product
        """
        self.customer = get_current_customer()
        # Need to test after the implimentaion of get_configured_products
        # if not self.customer.get('IS_USER_LOGGED_IN'):
        #     self.customer['product_ids'] = self.wl_product_repo.get_configured_products(
        #         self.company,
        #         WlUserGroup.DEFAULT_USER_GROUP
        #     )
        bundled_result = self.merchant_repo.get_bundled_product(self.product_sku)
        if bundled_result:
            bundled_result = bundled_result[0]
            self.bundled_product_skus = bundled_result.get('bundled_product_sku').split('-')
        self.bundled_product_skus.append(self.product_sku)
        self.merchants = self.merchant_repo.get_bundled_offers(
            self.active,
            self.locale,
            self.product_sf_id,
            self.bundled_product_skus
        )

    def set_merchants(self):
        """
        Set merchants data
        """
        for merchant in self.merchants:
            merchant['outlet_ids'] = map(int, merchant.get('outlet_ids').split(','))
            merchant['offer_types_included'] = {}
            merchant['is_new'] = False
            if merchant['is_member']:
                merchant['is_monthly'] = True
                merchant['offer_types_included'].append("monthly")
            elif merchant['is_cheers']:
                merchant['is_cheers'] = True
                merchant['offer_types_included'].append("cheers")
            elif merchant['is_delivery']:
                merchant['is_delivery'] = True
                merchant['offer_types_included'].append("delivery")
            elif merchant['is_more_sa']:
                merchant['is_more_sa'] = True
                merchant['offer_types_included'].append("is_more_sa")

        exchange_rates = self.exchanges_rates_repo.get_exchange_rates()
        self.product_price_details = self.product_repo.get_product_price_details(
            self.company,
            self.product_sku,
            self.locale,
            exchange_rates,
            self.platform,
            self.currency,
            self.request_args
        )

    def prepare_response(self):
        """
        Set final response for MerchantApiAction api
        """
        self.response = {
            'success': True,
            'message': 'success',
            'data': {
                'merchants': self.merchants[self.offset: None if self.limit <= 0 else self.limit],
                'payment_info': self.product_price_details
            },
            'code': 0
        }
        self.send_response_flag = True
        self.status_code = codes.OK

    def process_request(self):
        """
        Controls the flow of merchant_api_action
        """
        self.initialize_repos()
        self.populate_request_arguments()
        self.initialze_local_variables()
        self.set_current_customer()
        self.set_merchants()
        self.prepare_response()


class GetMerchantsNameAction(BaseDynamicResource):
    """
    This class contains endpoint for merchant
    """
    required_token = True
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ONLINE_LOG_PATH,
            file_path='merchants_api/merchants_api.log',
        ),
        'name': 'merchants_api'
    }
    request_parser = merchant_by_id_parser
    connections_names = ['default', 'consolidation']

    def populate_request_arguments(self):
        """
        Add request arguments for merchant_name_action api
        """
        self.offer_id = self.request_args.get('offer_id')
        self.merchant_id = self.request_args.get('merchant_id')

    def initialize_repos(self):
        """
        Initialize all the repo's
        """
        self.merchant_repo_wl = MerchantRepositoryWl()
        self.offer_wl_active_repo = OfferWlRepositoryV67()

    def set_merchant_and_offer_name(self):
        """
        Set merchant name and offer name
        """
        self.merchant_name = self.merchant_repo_wl.find_name_by_id(self.merchant_id)
        self.offer_name = self.offer_wl_active_repo.find_name_by_id(self.offer_id)

    def prepare_response(self):
        """
        Set final response for merchant_name_action api
        """
        self.response = {
            'success': True,
            'message': 'success',
            'data': {
                'merchant_name': self.merchant_name,
                'offer_name': self.offer_name
            },
            'code': 0
        }
        self.send_response_flag = True
        self.status_code = codes.OK

    def process_request(self):
        """
        Controls the flow of merchant_name_action api
        """
        self.initialize_repos()
        self.populate_request_arguments()
        self.set_merchant_and_offer_name()
        self.prepare_response()
