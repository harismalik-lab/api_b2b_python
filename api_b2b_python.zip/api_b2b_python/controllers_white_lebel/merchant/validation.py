"""
This module contains param validator for /merchants/<id>[GET]
"""
from flask_restful.inputs import regex, boolean
from flask_restful.reqparse import RequestParser

from python_api.common.custom_fields_request_parser import currency, language

merchant_parser = RequestParser(bundle_errors=True)

merchant_parser.add_argument('lat', type=float, default=0, location=['mobile', 'values'])
merchant_parser.add_argument('lng', type=float, default=0, location=['mobile', 'values'])
merchant_parser.add_argument('redeemability', type=regex('[a-zA-Z]*[_]*'), default='redeemable',
                             location=['mobile', 'values'])
merchant_parser.add_argument('currency', type=currency, default='USD', location=['mobile', 'values'])
merchant_parser.add_argument('location_id', type=int, default=0, location=['mobile', 'values'])
merchant_parser.add_argument('language', type=language, default='en', location=['mobile', 'values'])
merchant_parser.add_argument('offer_id', type=int, required=False, location=['mobile', 'values'], default=0)
merchant_parser.add_argument('app_version', type=regex('[0-9][0-9]*[.]*'), required=False, location=['mobile', 'values'], default="0")
merchant_parser.add_argument('__platform', type=regex('[a-zA-Z]'), required=False, location=['mobile', 'values'], default='')
merchant_parser.add_argument('device_key', type=regex('[a-zA-Z0-9]*[-]*[.]*'), location=['mobile', 'values'])
merchant_parser.add_argument('user_id', type=int, default=-1, location=['mobile', 'values'])
merchant_parser.add_argument('company', type=str, default=True, location=['mobile', 'values'])
merchant_parser.add_argument('category', type=str, default="", location=['mobile', 'values'])
merchant_parser.add_argument('is_cuckoo', type=boolean, default=False, location=['mobile', 'values'])
merchant_parser.add_argument('user_include_cheers', type=boolean, default=False, location=['mobile', 'values'])
merchant_parser.add_argument('product_sku', type=regex('[a-z]*[0-9]*'), default=False,
                             location=['mobile', 'values', 'json'])
merchant_parser.add_argument('active', type=boolean, required=True, location=['mobile', 'json', 'values'])

