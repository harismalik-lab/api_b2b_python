"""
Validation for Sign in api
"""
from common.common_helpers import get_request_parser
from common.custom_fields_request_parser import language, validate_email_string
from flask_restful.inputs import regex

user_sign_in_parser = get_request_parser()

user_sign_in_parser.add_argument(
    '__platform',
    type=regex('[a-z]'),
    required=True,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'app_version',
    type=regex('[0-9][0-9]*[.]*'),
    required=True,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'language',
    type=language,
    default='en',
    location=['mobile', 'json', 'values']
)

user_sign_in_parser.add_argument(
    'email',
    type=validate_email_string,
    required=True,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'password',
    type=str,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument('device_model',
                                 type=str,
                                 required=True,
                                 location=['mobile', 'json', 'values']
                                 )
user_sign_in_parser.add_argument(
    'device_install_token',
    type=str,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'device_uid',
    type=str,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'mobile_phone',
    type=str,
    default='',
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'device_key',
    type=str,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'key',
    type=str,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'using_branch_activation',
    type=str,
    location=['mobile', 'json', 'values']
)

user_sign_in_parser.add_argument(
    'invoice_number',
    type=str,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'is_user_agreement_accepted',
    type=str,
    default=False,
    required=False,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'is_privacy_policy_accepted',
    type=bool,
    default=False,
    required=False,
    location=['mobile', 'json', 'values']
)
