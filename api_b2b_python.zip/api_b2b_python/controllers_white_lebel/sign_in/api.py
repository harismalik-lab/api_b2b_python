"""
Sign in API for white label.
"""
from app_configurations.settings import ONLINE_LOG_PATH
from repositories.quick_translation_repo import QuickTranslationRepository
from requests import codes
from web_api.api_v65.sign_in.api import LoginUserApiV65

from common_white_label.common_helpers import WLCommonHelpers, get_invoice_validation_message, is_lookup_based_company
from common_white_label.constants import GlobalConstants
from repositories_white_label.customer_device_repo import CustomerDeviceRepositoryWl
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.session_repo import SessionRepositoryWhiteLabel
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.wl_company_repo import WLCompany
from repositories_white_label.wl_crg_lookup_repo import WlCrgLookupRepository
from repositories_white_label.wl_dxb_ent_lookup_repo import WlDxbEntRepository
from repositories_white_label.wl_gem_lookup_repo import WlGemLookupRepository
from repositories_white_label.wl_gem_points_repo import WlGemPointsRepository
from repositories_white_label.wl_invoice_headers_repo import WlInvoiceHeadersRepository
from repositories_white_label.wl_naama_lookup_repo import WlNaamaLookupRepository
from repositories_white_label.wl_send_email_repository import WlSendEmailsRepository
from repositories_white_label.wl_templates_repo import WLTemplatesRepository
from repositories_white_label.wl_user_custom_info_repo import WLUserCustomInfoRepository
from repositories_white_label.wl_user_group_repo import WlUserGroup
from repositories_white_label.wl_validtion_repo import WlValidationRepository

from .validation import user_sign_in_parser


class SignInWLApi(LoginUserApiV65):
    """
    Sign-in application controller
    """
    backup_request_args_for_exception = False
    request_parser = user_sign_in_parser
    response = {}
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ONLINE_LOG_PATH,
            file_path='login_api/login_api.log',
        ),
        'name': 'login_api'
    }
    logger = None
    status_code = 200
    connections_names = ['default', 'consolidation']

    def process_request(self):
        self.populate_request_arguments()
        self.initialize_repos()
        self.local_variables()
        self.post_sessions_action()

    def populate_request_arguments(self):
        self.wl_company = self.request_args.get('wlcompany')
        self.platform = self.request_args.get('__platform')
        self.app_version = self.request_args.get('app_version')
        self.locale = self.request_args.get('language')
        self.email = self.request_args.get('email')
        self.password = self.request_args.get('password')
        self.device_model = self.request_args.get('device_model')
        self.device_install_token = self.request_args.get('device_install_token')
        self.device_id = self.request_args.get('device_uid')
        self.mobile_phone = self.request_args.get('mobile_phone')
        self.device_key = self.request_args.get('device_key')
        self.wl_key = self.request_args.get('key')
        self.using_branch_activation = self.request_args.get('using_branch_activation')
        self.invoice_number = self.request_args.get('invoice_number')
        self.is_user_agreement_accepted = self.request_args.get('is_user_agreement_accepted')
        self.is_privacy_policy_accepted = self.request_args.get('is_privacy_policy_accepted')

    def initialize_repos(self):
        self.wl_company_repo = WLCompany()
        self.wl_validation_repo = WlValidationRepository()
        self.wl_session_repo = SessionRepositoryWhiteLabel()
        self.customer_repo = CustomerProfileWhiteLabel()
        self.wl_customer_custom_info_repo = WLUserCustomInfoRepository()
        self.customer_device_repo = CustomerDeviceRepositoryWl()
        self.wl_templates_repo = WLTemplatesRepository()
        self.wl_invoice_repo = WlInvoiceHeadersRepository()
        self.wl_gem_lookup_repo = WlGemLookupRepository()
        self.wl_gem_points_repo = WlGemPointsRepository()
        self.wl_crg_lookup_repo = WlCrgLookupRepository()
        self.wl_dxb_ent_lookup_repo = WlDxbEntRepository()
        self.wl_naama_lookup_reo = WlNaamaLookupRepository()
        self.translation_manager = TranslationManager()
        self.wl_user_group = WlUserGroup()
        self.wl_email_send_repo = WlSendEmailsRepository()
        self.transaltion_repo_instance = QuickTranslationRepository()

    def local_variables(self):
        self.session_id = 0
        self.user_group = 0
        self.user_group_code = ""
        self.user_group_logo = ""
        self.number_of_offers = 0
        self.number_of_valid_keys = 0
        self.is_new_key_added = False
        self.message_locale = WLCommonHelpers.get_locale(self.locale)

    def return_response(self, status_code=0, internal_code=0, message='', success='', data={}, custom_message=''):
        """
        Return reponse helper
        :return:
        """
        self.status_code = status_code
        self.send_response_flag = True
        self.response = {}
        if message:
            self.response['message'] = self.translation_manager.get_translation(message, locale=self.locale)
        if custom_message:
            self.response['message'] = custom_message
        if internal_code:
            self.response['code'] = internal_code

        if isinstance(success, bool):
            self.response['success'] = success
        if data:
            self.response['data'] = data
        return self.send_response(self.response, self.status_code)

    def post_sessions_action(self):
        """
        Sign-in User function
        :return:
        """
        if self.invoice_number or self.wl_company.lower() == self.wl_company_repo.COMPANY_CODE_ENTERTAINER_EMAX:
            return self.post_session_invoice_based()

        islookup_based_company = is_lookup_based_company(self.wl_company)
        if islookup_based_company:
            return self.post_session_gem_crg_action()

        if self.using_branch_activation:
            return self.post_session_gem_branchiobased_action()

        if self.platform == GlobalConstants.PLATFORM_IOS and \
                self.wl_company != self.wl_company_repo.COMPANY_CODE_ENTERTAINER_HSBC:
            app_without_validation_screen = True
        else:
            app_without_validation_screen = False
        if not self.email:
            return self.return_response(
                status_code=codes.UNPROCESSABLE_ENTITY,
                internal_code=70,
                message=self.translation_manager.email_required
            )
        if not self.password or not app_without_validation_screen:
            return self.return_response(
                status_code=codes.UNPROCESSABLE_ENTITY,
                internal_code=70,
                message=self.translation_manager.email_password_required
            )
        if not self.device_key:
            self.device_id = self.device_key
        self.customer_by_email = self.customer_repo.load_customer_by_email(self.email, True)
        if not self.customer_by_email:
            if app_without_validation_screen:
                wl_company_name = self.wl_company_repo.get_company_name(self.wl_company)
                email_data = {}
                self.email_data_optional = {}
                if self.email:
                    self.email_data_optional["EMAIL"] = self.email
                if self.wl_company:
                    self.email_data_optional["WLCOMAPANY"] = self.wl_company
                if wl_company_name:
                    self.email_data_optional["WLCOMPANY_NAME"] = wl_company_name
                self.email_template_id = self.wl_templates_repo.get_template_by_company_and_type(
                    self.wl_company, self.wl_templates_repo.REGISTER_INSTRUCTIONS)
                self.customer_repo.send_email(email_type_id=self.email_template_id, email_data=email_data,
                                              email=self.email,
                                              language=self.locale, priority=self.wl_email_send_repo.Priority_Medium,
                                              dump=False, optional_data=self.email_data_optional)
                return self.return_response(
                    status_code=codes.UNPROCESSABLE_ENTITY,
                    internal_code=73,
                    message=self.translation_manager.email_not_linked_message
                )
            return self.return_response(
                status_code=codes.UNPROCESSABLE_ENTITY,
                internal_code=70,
                message=self.translation_manager.you_are_not_allowed_to_access_this_application
            )
        self.number_of_valid_keys = self.wl_validation_repo.get_number_of_valid_keys(self.wl_company, self.email)
        if self.number_of_valid_keys < 1 and self.wl_company != self.wl_company_repo.company_code_Du:
            if self.wl_key:
                wl_validation_status = self.wl_validation_repo.validate_key(self.wl_key, self.wl_company, self.email)
                if wl_validation_status == self.wl_validation_repo.INVALID_KEY:
                    return self.return_response(
                        status_code=codes.UNPROCESSABLE_ENTITY,
                        internal_code=70,
                        message=self.translation_manager.invalid_wl_key
                    )
                if wl_validation_status == self.wl_validation_repo.UNUSED_VALID_KEY:
                    self.wl_validation_repo.assign_key_to_customer(
                        self.wl_key, self.wl_company, self.email, True, self.customer_by_email["id"]
                    )
            else:
                if app_without_validation_screen:
                    wl_company_name = self.wl_company_repo.get_company_name(self.wl_company)
                    email_data = {}
                    self.optional_data = {}
                    if self.email:
                        self.optional_data["EMAIL"] = self.email
                    if self.wl_company:
                        self.optional_data["WLCOMAPANY"] = self.wl_company
                    if wl_company_name:
                        self.optional_data["WLCOMPANY_NAME"] = wl_company_name
                    self.email_template_id = self.wl_templates_repo.get_template_by_company_and_type(
                        self.wl_company, self.wl_templates_repo.REGISTER_INSTRUCTIONS)
                    self.customer_repo.send_email(
                        email_type_id=self.email_template_id, email_data=email_data,
                        email=self.email,
                        language=self.locale,
                        priority=self.wl_email_send_repo.Priority_Medium,
                        dump=False, optional_data=self.optional_data
                    )
                    return self.return_response(
                        status_code=codes.UNPROCESSABLE_ENTITY,
                        internal_code=73,
                        message=self.translation_manager.email_not_linked_message
                    )
                else:
                    return self.return_response(
                        status_code=codes.UNPROCESSABLE_ENTITY,
                        internal_code=70,
                        message=self.translation_manager.you_are_not_allowed_to_access_this_application
                    )
        password_hashed = self.customer_repo.get_password_hash(email=self.email)
        if password_hashed:
            self.customer = self.customer_repo.login_customer(self.email, self.password, password_hashed)
            if not self.customer:
                return self.return_response(
                    status_code=codes.UNPROCESSABLE_ENTITY,
                    internal_code=70,
                    message=self.translation_manager.invalid_password
                )
        else:
            return self.return_response(
                status_code=codes.UNPROCESSABLE_ENTITY,
                internal_code=70,
                message=self.translation_manager.invalid_password
            )
        self.customer_id = self.customer.get("id")
        self.wl_validation_repo.update_customer_validation(self.wl_company, self.email, self.customer_id)
        self.customer_profile = self.customer_repo.load_customer_profile_by_id(self.customer_id)
        product_ids = self.customer_repo.get_customer_products(user_id=self.customer_id, company=self.wl_company)
        session_token = self.wl_session_repo.generate_session(
            customer_id=self.customer_id, product_ids=product_ids, company=self.wl_company,
            platform=self.platform, device_model=self.device_model, device_id=self.device_id,
            app_version=self.app_version
        )
        self.session = self.wl_session_repo.find_by_token(company=self.wl_company, session_token=session_token)
        if self.session:
            self.session_id = self.session.get("id", None)
        device_info = self.customer_device_repo.find_one_by_device_id_and_customer_id(
            customer_id=self.customer_id, device_id=self.device_id, company=self.wl_company
        )
        if not device_info:
            device_num = self.customer_device_repo.count_devices_by_customer_id(self.customer_id, self.wl_company)
            self.customer_device_repo.create_new_record(
                self.customer_id, self.device_install_token, self.platform,
                self.device_model, session_token, 1 if device_num else 0, self.device_id
            )
        self.customer_profile = self.customer_repo.put_customer_in_trial_membership_if_qualifies(
            customer_profile=self.customer_profile
        )
        if self.wl_company == self.wl_company_repo.COMPANY_CODE_ENTERTAINER_HUT and self.mobile_phone:
            self.customer_repo.update_mobile_phone_number(self.customer_id, self.mobile_phone)
        pop_up_screen_upon_successful_activation = ""
        if self.wl_company == self.wl_company_repo.COMPANY_CODE_ENTERTAINER_LIFE:
            self.user_group = self.wl_validation_repo.get_user_group(self.wl_company, self.customer_id)
            if self.user_group == 1 or self.user_group == 2:
                pop_up_screen_upon_successful_activation = self.translation_manager.get_translation(
                    self.translation_manager.elf_pop_up_screen_upon_successful_activation, locale=self.locale
                )
            elif self.user_group == 3 or self.user_group == 4:
                pop_up_screen_upon_successful_activation = self.translation_manager.get_translation(
                    self.translation_manager.elf_pop_up_screen_upon_successful_activation_30_june_2018,
                    locale=self.locale
                )
            elif self.user_group == 5 or self.user_group == 6:
                pop_up_screen_upon_successful_activation = self.translation_manager.get_translation(
                    self.translation_manager.elf_pop_up_screen_upon_successful_activation_30_dec_2018,
                    locale=self.locale
                )
        if self.wl_company == self.wl_company_repo.COMPANY_CODE_MASTER_CARDS:
            self.user_group = self.wl_validation_repo.get_user_group(self.wl_company, self.customer_id)
            user_group_info = self.wl_user_group.get_group_info(self.user_group, self.wl_company)
            if user_group_info:
                self.user_group_code = user_group_info.get("code")
                self.user_group_logo = user_group_info.get("logo", "")
                self.number_of_offers = user_group_info.get("numberOffers", 0)
        is_demographics_updated = self.customer_profile.get("is_demographics_updated")
        data = {
            'message': "",
            'user_id': self.customer_id,
            'session_token': session_token,
            'member_type': 3,  # FML
            'currency': self.customer_profile.get("currency"),
            'new_user': False,
            'device_install_token': self.device_install_token,
            'device_uid': self.device_id,
            'device_os': self.platform,
            'device_model': self.device_model,
            'pop_up_screen_upon_successful_activation': pop_up_screen_upon_successful_activation,
            "user_group": self.user_group,
            "user_group_code": self.user_group_code,
            "user_group_logo": self.user_group_logo,
            "number_of_offers": self.number_of_offers,
            'is_demographics_updated': is_demographics_updated,
            'validation_params': {
                '__i': self.customer_id,
                '__sid': self.session_id,
                'session_token': session_token
            },
        }

        return self.return_response(
            status_code=codes.OK,
            internal_code=0,
            message=self.translation_manager.success,
            data=data,
            success=True
        )

    def post_session_invoice_based(self):
        """
        Handler for session invoice based
        :return:
        """
        if not self.email or not self.password:
            return self.return_response(
                status_code=codes.UNPROCESSABLE_ENTITY,
                internal_code=70,
                message=self.translation_manager.email_password_required
            )
        if self.device_key:
            self.device_id = self.device_key
        customer_by_email = self.customer_repo.load_customer_by_email(self.email, single=True)
        if not customer_by_email:
            return self.return_response(
                status_code=codes.UNPROCESSABLE_ENTITY,
                internal_code=70,
                message=self.translation_manager.email_not_exist
            )
        self.customer_id = customer_by_email.get('id')
        if self.invoice_number:
            invoice_validation_status = self.wl_invoice_repo.validate_invoice_number(
                self.invoice_number,
                self.wl_company,
                True,
                self.customer_id
            )
            if invoice_validation_status != self.wl_invoice_repo.VALID_STATUS:
                self.message = get_invoice_validation_message(
                    invoice_validation_status,
                    self.locale
                )
                return self.return_response(
                    status_code=codes.BAD_REQUEST, custom_message=self.message,
                    data={"validation_status": False}, success=True
                )
            if self.number_of_valid_keys < 1:
                self.is_new_key_added = True
        else:
            invoice_lookup = self.wl_invoice_repo.get_user_invoice(self.customer_id)
            if not invoice_lookup:
                self.message = get_invoice_validation_message(
                    self.wl_invoice_repo.Invoice_Status_Invalid_Transaction_Type,
                    self.locale
                )
                return self.return_response(
                    status_code=codes.BAD_REQUEST, custom_message=self.message,
                    data={"validation_status": False}, internal_code=70, success=True
                )
        password_hashed = self.customer_repo.get_password_hash(self.email)
        if password_hashed:
            customer = self.customer_repo.login_customer(self.email, self.password, password_hashed)
            if not customer:
                return self.return_response(
                    status_code=codes.unprocessable_entity, message=self.translation_manager.invalid_password,
                    internal_code=70, success=True
                )
        else:
            return self.return_response(
                status_code=codes.unprocessable_entity, message=self.translation_manager.invalid_password,
                internal_code=70, success=True
            )
        customer_profile = self.customer_repo.get_user_profile_by_user_id(self.customer_id)
        product_ids = self.customer_repo.get_customer_products(user_id=self.customer_id, company=self.wl_company)
        session_token = self.wl_session_repo.generate_session(
            self.customer_id, product_ids, self.wl_company,
            self.platform, self.device_model, self.device_id,
            self.app_version
        )
        session = self.wl_session_repo.find_by_token(self.wl_company, session_token)
        if session:
            self.session_id = session.get("id", None)
        device_info = self.customer_device_repo.find_one_by_device_id_and_customer_id(
            customer_id=self.customer_id, device_id=self.device_id, company=self.wl_company
        )
        if not device_info:
            device_num = self.customer_device_repo.count_devices_by_customer_id(self.customer_id, self.wl_company)
            self.customer_device_repo.create_new_record(
                self.customer_id, self.device_install_token, self.plaform,
                self.device_model, session, 1 if device_num else 0, self.device_id
            )
        customer_profile = self.customer_repo.put_customer_in_trial_membership_if_qualifies(customer_profile)
        if self.is_new_key_added:
            self.user_group = self.wl_validation_repo.get_user_group(self.wl_company, self.customer_id)
            email_template_id = self.wl_templates_repo.get_template_by_company_and_type(
                self.wl_company, self.wl_templates_repo.ACTIVATION_OF_TRAIL, self.user_group
            )
            email_data = {"user_id": self.customer_id}
            optional_data = {"{FIRST_NAME}": self.customer_profile["firstName"]}
            self.customer_repo.send_email(
                email_type_id=email_template_id,
                email_data=email_data,
                email=self.email,
                language=self.locale,
                priority=self.wl_email_send_repo.Priority_Medium,
                dump=False,
                optional_data=optional_data
            )
        is_demographics_updated = customer_profile.get("is_demographics_updated")
        data = {
            'message': "",
            'user_id': self.customer_id,
            'session_token': session_token,
            'member_type': 1,  # FML
            'currency': self.customer_repo.CURRENCY,
            'new_user': False,
            'device_install_token': self.device_install_token,
            'device_uid': self.device_id,
            'device_os': self.platform,
            'device_model': self.device_model,
            "user_group": self.user_group,
            "user_group_code": self.user_group_code,
            "user_group_logo": self.user_group_logo,
            "number_of_offers": self.number_of_offers,
            'is_demographics_updated': is_demographics_updated,
            'validation_params': {
                '__i': self.customer_id,
                '__sid': self.session_id,
                'session_token': session_token
            },
        }
        return self.return_response(
            status_code=codes.OK, message=self.translation_manager.success, success=True, data=data
        )

    def post_session_gem_crg_action(self):
        """
        Handler for session based gem crg action
        :return:
        """
        if not self.email or not self.password:
            if self.wl_company == self.wl_company_repo.COMPANY_CODE_ENTERTAINER_GEMS:
                message = self.translation_manager.get_translation(
                    self.translation_manager.gems_user_id_and_password_is_required, self.message_locale
                )
            else:
                message = self.translation_manager.get_translation(
                    self.translation_manager.email_password_required, self.message_locale
                )
            return self.return_response(
                status_code=codes.unprocessable_entity, custom_message=message, success=False, internal_code=70
            )
        lookup_data = {}
        if self.wl_company == self.wl_company_repo.COMPANY_CODE_ENTERTAINER_GEMS:
            lookup_data = self.wl_gem_lookup_repo.find_gem(self.email)
        elif self.wl_company == self.wl_company_repo.COMPANY_CODE_ENTERTAINER_CRG:
            lookup_data = self.wl_crg_lookup_repo.find_crg(self.email)
        elif self.wl_company == self.wl_company_repo.COMPANY_CODE_ENTERTAINER_NAAMA:
            lookup_data = self.wl_naama_lookup_repo.find_naama(self.email)
        elif self.wl_company == self.wl_company_repo.COMPANY_CODE_DUBAI_ENTERTAINMENTS:
            customer_by_email = self.customer_repo.load_customer_by_email(self.email, True)
            if not customer_by_email:
                return self.return_response(
                    status_code=codes.OK, message=self.translation_manager.success,
                    data={"registration_required": True}, success=True
                )
            customer_id = customer_by_email["id"]
            if customer_id > 0:
                lookup_data = self.wl_dxb_ent_lookup_repo.find_customer(self.customer_id)
        if not lookup_data:
            translation_message_identifier = self.translation_manager.get_translation(
                self.translation_manager.you_are_not_allowed_to_access_this_application
            )
            company_message_var = 'access_restricted_to_application_{}'.format(self.wl_company.lower())
            if self.translation_manager.get_translation(company_message_var):
                translation_message_identifier = self.translation_manager.get_translation(company_message_var)
            return self.return_response(
                status_code=codes.UNPROCESSABLE_ENTITY, message=translation_message_identifier, internal_code=70
            )
        if self.wl_company == self.wl_company_repo.COMPANY_CODE_DUBAI_ENTERTAINMENTS:
            self.email = lookup_data.get("email")
        self.user_group = lookup_data.get("user_group")
        customer_by_email = self.customer_repo.load_customer_by_email(self.email, True)
        password_hashed = self.customer_repo.get_password_hash(self.email)
        if not customer_by_email or not password_hashed:
            return self.return_response(
                status_code=codes.UNPROCESSABLE_ENTITY, message=self.translation_manager.success,
                data={"registration_required": True}, success=False
            )
        self.customer_id = self.customer_repo.load_customer_by_email(self.email, True).get("user_id")
        gems_password_info = self.wl_customer_custom_info_repo.get_user_custom_info(self.customer_id, self.wl_company)
        if not gems_password_info:
            return self.return_response(
                status_code=codes.OK, message=self.translation_manager.success, data={"registration_required": True},
                success=True
            )
        if self.device_key:
            self.device_id = self.device_key
        password_hashed = gems_password_info.get('password_hashed')
        if password_hashed:
            self.customer = self.customer_repo.login_customer(
                self.email, self.password, password_hashed, self.wl_company
            )
            if not self.customer:
                return self.return_response(
                    status_code=codes.UNPROCESSABLE_ENTITY, message=self.translation_manager.invalid_password,
                    success=False
                )
        else:
            return self.return_response(
                status_code=codes.UNPROCESSABLE_ENTITY, message=self.translation_manager.invalid_password, success=False
            )
        number_of_valid_keys = self.wl_validation_repo.get_number_of_valid_keys(self.wl_company, self.email)
        if not number_of_valid_keys:
            prefix = WLCommonHelpers.get_key_prefix_company(self.company)
            wl_key = WLCommonHelpers.generate_unique_id(prefix, 7)
            self.wl_validation_repo.add_new_key(wl_key, self.wl_company, self.customer_id, self.email, self.user_group,
                                                1)
            if self.wl_company == self.wl_company_repo.COMPANY_CODE_ENTERTAINER_GEMS:
                self.wl_gem_points_repo.update_for_gem(self.customer_id, self.email)
            email_template_id = self.wl_templates_repo.get_template_by_company_and_type(
                self.wl_company, self.wl_templates_repo.ACTIVATION_OF_TRAIL, self.user_group
            )
            email_data = {"user_id": self.customer_id}
            customer_profile = self.customer_repo.load_customer_profile_by_id(self.customer_id)
            optional_data = {}
            if customer_profile.get("FIST_NAME"):
                optional_data = {"FIRST_NAME": customer_profile.get("FIST_NAME")}
            self.customer_repo.send_email(
                email_type_id=email_template_id, email_data=email_data, email=self.email,
                language=self.locale, priority=self.wl_email_send_repo.Priority_Medium, dump=False,
                optional_data=optional_data
            )
            self.wl_validation_repo.update_customer_validation(self.wl_company, self.email, self.customer_id)
            product_ids = self.customer_repo.get_customer_products(self.customer_id, self.user_group)
            session_token = self.wl_session_repo.generate_session(self.customer_id, product_ids, self.wl_company,
                                                                  self.platform, self.device_model, self.device_id,
                                                                  self.app_version)
            session = self.wl_session_repo.find_by_token(self.wl_company, session_token)
            self.session_id = session.get("id", None)
            device_info = self.customer_device_repo.find_one_by_device_id_and_customer_id(
                customer_id=self.customer_id, device_id=self.device_id, company=self.wl_company
            )
            if not device_info:
                devices_num = self.customer_device_repo.count_devices_by_customer_id(self.customer_id, self.wl_company)
                if devices_num > 8:
                    return self.return_response(
                        status_code=codes.UNPROCESSABLE_ENTITY,
                        message=self.translation_manager.you_have_exceeded_your_devices_limit, success=False
                    )
                self.customer_device_repo.create_new_record(
                    self.customer_id, self.device_install_token, self.platform,
                    self.device_model, session, 1 if devices_num else 0, self.device_id
                )
            customer_profile = self.customer_repo.put_customer_in_trial_membership_if_qualifies(customer_profile)
            is_demographics_updated = customer_profile.get("is_demographics_updated")
            data = {
                'message': "",
                'user_id': self.customer_id,
                'session_token': session_token,
                'member_type': 1,  # FML
                'currency': self.customer_repo.CURRENCY,
                'new_user': False,
                'device_install_token': self.device_install_token,
                'device_uid': self.device_id,
                'device_os': self.platform,
                'device_model': self.device_model,
                'pop_up_screen_upon_successful_activation': "",
                'registration_required': False,
                "user_group": self.user_group,
                "user_group_code": self.user_group_code,
                "user_group_logo": self.user_group_logo,
                "number_of_offers": self.number_of_offers,
                'is_demographics_updated': is_demographics_updated,
                'validation_params': {
                    '__i': self.customer_id,
                    '__sid': self.session_id,
                    'session_token': session_token
                }
            }
            return self.return_response(
                status_code=codes.OK,
                message=self.translation_manager.success,
                success=True,
                data=data)

    def post_session_gem_branch_iobased_action(self):
        """
        Handler for session based io based action
        :return:
        """
        if not self.wl_key:
            self.number_of_valid_keys = self.wl_validation_repo.get_number_of_valid_keys(self.wl_company, self.email)
            if self.number_of_valid_keys < 1:
                return self.return_response(
                    status_code=codes.UNPROCESSABLE_ENTITY,
                    message=self.translation_manager.you_are_not_allowed_to_access_this_application,
                    success=True, internal_code=70
                )
        self.customer_profile = self.customer_repo.load_customer_by_email(self.email, True)
        if not self.customer_profile:
            return self.return_response(
                status_code=codes.UNPROCESSABLE_ENTITY, message=self.translation_manager.success, success=True,
                data={'registration_required': True}, internal_code=70
            )
        self.customer_id = self.customer_profile.get("id")
        if self.platform == GlobalConstants.PLATFORM_IOS and \
                self.wl_company != self.wl_company_repo.COMPANY_CODE_ENTERTAINER_HSBC:
            app_without_validation_screen = True
        else:
            app_without_validation_screen = False
        email_data = {"user_id": 0}
        self.email_data_optional = {}
        if not self.email:
            return self.return_response(
                status_code=codes.UNPROCESSABLE_ENTITY, message=self.translation_manager.email_required,
                internal_code=70
            )
        if not self.password and not app_without_validation_screen:
            return self.return_response(
                status_code=codes.UNPROCESSABLE_ENTITY, message=self.translation_manager.email_password_required,
                internal_code=70
            )
        password_hashed = self.customer_repo.get_password_hash(self.email)
        if password_hashed:
            if not self.password:
                return self.return_response(
                    status_code=codes.UNPROCESSABLE_ENTITY, message=self.translation_manager.invalid_password,
                    internal_code=70
                )
            self.customer = self.customer_repo.login_customer(self.email, self.password, password_hashed)
            if not self.customer:
                return self.return_response(
                    status_code=codes.UNPROCESSABLE_ENTITY, message=self.translation_manager.invalid_password,
                    internal_code=70
                )
        else:
            return self.return_response(
                status_code=codes.UNPROCESSABLE_ENTITY, message=self.translation_manager.invalid_password,
                internal_code=70
            )
        if not self.device_key:
            self.device_id = self.device_key
        assign_key_to_customer = False
        if self.wl_key:
            self.is_multiple_subscription_allowed = self.wl_company_repo.get_company_multiple_status_wl(self.wl_company)
            self.validation_response = self.wl_validation_repo.validate_key(self.wl_key, self.wl_company, self.email)
            self.number_of_valid_keys = self.wl_validation_repo.get_number_of_valid_keys(self.wl_company, self.email)
            if self.validation_response == self.wl_validation_repo.INVALID_KEY:
                return self.return_response(
                    status_code=codes.UNPROCESSABLE_ENTITY,
                    message=self.translation_manager.invalid_wl_key_with_branch,
                    internal_code=70
                )
            elif self.validation_response == self.wl_validation_repo.UNUSED_VALID_KEY:
                if not self.is_multiple_subscription_allowed and self.number_of_valid_keys > 0:
                    return self.return_response(
                        status_code=codes.UNPROCESSABLE_ENTITY,
                        message=self.translation_manager.you_have_already_activated_the_app_for_multiple_keys_not_allowed,
                        internal_code=70
                    )
                self.assign_key_to_customer = True
        self.customer_profile = self.customer_repo.load_customer_profile_by_id(self.customer_id)
        if assign_key_to_customer:
            self.wl_validation_repo.assign_key_to_customer(
                self.wl_key, self.wl_company, self.email, True, self.customer_id
            )
            self.user_group = self.wl_validation_repo.get_user_group_id_by_key(self.wl_key, self.wl_company)
            if self.wl_company.lower() == self.wl_company_repo.COMPANY_CODE_ENTERTAINER_HSBC:
                self.email_template_id = 550
                if self.user_group == 2:
                    self.email_template_id = 553
            else:
                self.email_template_id = self.wl_templates_repo.get_template_by_company_and_type(
                    self.wl_company, self.wl_templates_repo.ACTIVATION_OF_TRAIL, self.user_group
                )
            self.customer_repo.send_email(
                email_type_id=self.email_template_id, email_data=email_data, email=self.email,
                language=self.locale, priority=self.wl_email_send_repo.Priority_Medium,
                dump=False, optional_data=self.email_data_optional
            )
        products_ids = self.customer_repo.get_customer_products(self.customer_id, self.user_group)
        session_token = self.wl_session_repo.generate_session(self.customer_id, products_ids, self.wl_company,
                                                              self.platform, self.device_model, self.device_id,
                                                              self.app_version)
        self.session = self.wl_session_repo.find_by_token(self.wl_company, session_token)
        if self.session:
            self.session_id = self.session.get("id", None)
        device_info = self.customer_device_repo.find_one_by_device_id_and_customer_id(
            customer_id=self.customer_id, device_id=self.device_id, company=self.wl_company
        )
        if not device_info:
            device_num = self.customer_device_repo.count_devices_by_customer_id(self.customer_id, self.wl_company)
            self.customer_device_repo.create_new_record(
                self.customer_id, self.device_install_token, self.platform,
                self.device_model, self.session, 1 if device_num else 0, self.device_id
            )
        customer_profile = self.customer_repo.put_customer_in_trial_membership_if_qualifies(self.customer_profile)
        self.wl_validation_repo.update_customer_validation(self.wl_company, self.email, self.customer_id)
        is_demographics_updated = customer_profile.get("is_demographics_updated")
        data = {
            'message': "",
            'user_id': self.customer_id,
            'session_token': session_token,
            'member_type': 1,  # FML
            'currency': self.customer_repo.CURRENCY,
            'new_user': False,
            'device_install_token': self.device_install_token,
            'device_uid': self.device_id,
            'device_os': self.platform,
            'device_model': self.device_model,
            'pop_up_screen_upon_successful_activation': "",
            'registration_required': False,
            "user_group": self.user_group,
            "user_group_code": self.user_group_code,
            "user_group_logo": self.user_group_logo,
            "number_of_offers": self.number_of_offers,
            'is_demographics_updated': is_demographics_updated,
            'validation_params': {
                '__i': self.customer_id,
                '__sid': self.session_id,
                'session_token': session_token
            }
        }
        return self.return_response(
            status_code=codes.OK,
            message=self.translation_manager.you_have_already_activated_the_app_for_multiple_keys_not_allowed,
            internal_code=70, success=True, data=data
        )
