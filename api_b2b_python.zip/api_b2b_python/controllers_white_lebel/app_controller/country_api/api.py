"""
Module contains Country APi
"""
from common.base_resource import BaseGetResource
from repositories.global_ads_repo import GlobalAdsRepository
from repositories.session_repo import SessionRepository

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.common_helpers import WLCommonHelpers
from common_white_label.constants import GlobalConstants
from repositories_white_label.country_repo import CountryRepository
from repositories_white_label.wl_product_repo import WLProductRepository
from repositories_white_label.wl_user_group_repo import WlUserGroup
from user_authentication_white_label.authentication import get_company

from .validation import country_parser


class CountryApi(BaseGetResource):
    """
    Class that handles the country endpoint
    """
    request_parser = country_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='country_api/country_api.log',
        ),
        'name': 'country_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')
        self.is_travel = self.request_args.get('istravel')
        self.session_id = self.request_args.get('__sid')
        self.company = get_company()

    def check_validations(self):
        """
        Checks required arguments and sets all the responses as that of using in php.
        """
        # TODO: Improvement-> It should be handled at parser validation level and should show 400 error.
        # it is showing 500 error as it is done in php on required arguments.
        if not self.company:
            self.send_response_flag = True
            self.status_code = 500
            self.response = {
                'message': GlobalConstants().INTERNAL_SERVER_ERROR,
            }
            return self.send_response(self.response, self.status_code)

    def setting_variables(self):
        """
        Sets variables for api
        """
        self.locale = WLCommonHelpers().get_locale(self.locale)
        self.countries = []
        self.product_ids = []

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.country_repo = CountryRepository()
        self.global_ads_repo = GlobalAdsRepository()
        self.product_repo = WLProductRepository()
        self.session_repo = SessionRepository()

    def process_ids(self):
        """
        Gets validation status of device
        """
        if self.is_travel:
            if self.session_id:
                session = self.session_repo.find_by_id(self.session_id)
                if session:
                    self.product_ids = session.get_product_ids()
                    self.product_ids = self.product_ids.split(',')
            if not self.product_ids:
                user_groups = [{'user_group': WlUserGroup().DEFAULT_USER_GROUP}]
                self.product_ids = self.product_repo.get_configured_products(
                    self.company,
                    user_groups
                )
            self.countries = self.country_repo.get_country_by_region(
                self.company,
                self.product_ids,
                self.locale
            )
        else:
            self.countries = CountryRepository.get_country(self.locale)
        self.global_travel_ads = []  # $global_ads_repo->getGlobalAds($company);

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': {
                'countries': self.countries,
                'global_travel_ads': self.global_travel_ads
            },
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.populate_request_arguments()
        self.check_validations()
        if self.is_send_response_flag_on():
            return
        self.initialize_repos()
        self.setting_variables()
        self.process_ids()
        self.generate_final_response()
