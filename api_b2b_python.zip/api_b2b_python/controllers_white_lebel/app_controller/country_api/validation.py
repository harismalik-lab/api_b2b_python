"""
country validation parser
"""
from common.common_helpers import get_request_parser
from common.custom_fields_request_parser import boolean, language

country_parser = get_request_parser()

country_parser.add_argument(
    name="wlcompany",
    required=False,
    type=str
)
country_parser.add_argument(
    name="__i",
    required=False,
    type=int
)
country_parser.add_argument(
    name="session_token",
    required=False,
    type=str
)
country_parser.add_argument(
    name="__sid",
    required=False,
    type=int
)
country_parser.add_argument(
    name="language",
    default="en",
    type=language
)
country_parser.add_argument(
    name="istravel",
    default=False,
    location=['mobile', 'values', 'json'],
    required=False,
    type=boolean
)
