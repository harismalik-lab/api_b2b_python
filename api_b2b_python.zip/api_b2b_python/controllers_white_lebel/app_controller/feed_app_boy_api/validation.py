from common.common_helpers import get_request_parser
from common.custom_fields_request_parser import device_list, language

feed_appboy_parser = get_request_parser()

feed_appboy_parser.add_argument(
    name="user_id",
    required=True,
    type=int
)
feed_appboy_parser.add_argument(
    name="platform",
    required=False,
    type=device_list
)
feed_appboy_parser.add_argument(
    name="__platform",
    required=True,
    type=str
)
feed_appboy_parser.add_argument(
    name="language",
    default="en",
    type=language
)
feed_appboy_parser.add_argument(
    name="session_token",
    required=True,
    type=str
)
feed_appboy_parser.add_argument(
    name="wlcompany",
    required=False,
    type=str
)
