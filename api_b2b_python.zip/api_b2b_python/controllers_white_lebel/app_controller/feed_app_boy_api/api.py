"""
Module contains Feed App Boy APi
"""
import requests
from common.base_resource import BasePostResource
from flask import current_app

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from controllers_white_lebel.app_controller.feed_app_boy_api.validation import feed_appboy_parser


class FeedAppBoyApi(BasePostResource):
    """
    Class that handles the feed appboy endpoint
    """
    request_parser = feed_appboy_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='feed_app_boy_api/feed_app_boy_api.log',
        ),
        'name': 'feed_app_boy_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.company = self.request_manager.get('wlcompany')
        self.plat_form = self.request_manager.get('plat_form')
        self.user_id = self.request_manager.get('user_id')

    def send_curl(self):
        """
        Sends curl
        """
        self.app_boy_feeder_url = current_app.config.get("APP_BOY_FEEDER_URL")
        mycurl = requests.post(
            self.app_boy_feeder_url,
            data={
                "user_id": self.user_id,
                "platform": self.plat_form,
                "company": self.company
            },
        )
        if mycurl.status_code == requests.codes.ok:
            pass

    def generate_final_response(self):
        """
        Generates fianl response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': {
                'is_fed_successfully': True
            },
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.populate_request_arguments()
        self.send_curl()
        self.generate_final_response()
