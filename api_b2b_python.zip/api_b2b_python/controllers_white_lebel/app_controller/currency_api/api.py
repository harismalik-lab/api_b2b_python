"""
Module contains Currency APi
"""
from common.base_resource import BaseGetResource

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.common_helpers import WLCommonHelpers

from .validation import currencies_parser


class CurrenciesApi(BaseGetResource):
    """
    Class that handles the currencies endpoint
    """
    request_parser = currencies_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='currencies_api/currencies_api.log',
        ),
        'name': 'currencies_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')

    def setting_variables(self):
        """
        Sets variables for api
        """
        self.locale = WLCommonHelpers().get_locale(self.locale)

    def get_currencies(self):
        """
        Gets validation status of device
        """
        self.currencies = WLCommonHelpers().get_currencies(self.locale)

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': {
                'currencies': self.currencies
            },
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.populate_request_arguments()
        self.setting_variables()
        self.get_currencies()
        self.generate_final_response()
