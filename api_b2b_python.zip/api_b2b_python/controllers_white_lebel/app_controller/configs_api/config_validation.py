"""
configuration validation parser
"""
from common.common_helpers import get_request_parser
from common.custom_fields_request_parser import device_list, language

configs_parser = get_request_parser()

configs_parser.add_argument(
    name="wlcompany",
    required=False,
    type=str
)
configs_parser.add_argument(
    name="language",
    required=False,
    default="en",
    type=language
)
configs_parser.add_argument(
    name="__platform",
    required=False,
    type=device_list
)
configs_parser.add_argument(
    name="app_version",
    required=False,
    type=str
)
