"""
Module contains Configs APi
"""
from common.base_resource import BaseGetResource
from flask import current_app

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.common_helpers import WLCommonHelpers
from common_white_label.constants import GlobalConstants
from controllers_white_lebel.app_controller.configs_api.config_validation import configs_parser
from repositories_white_label.app_tutorial_repo import AppTutorialRepository
from repositories_white_label.translations_repo import TranslationManager
from user_authentication_white_label.authentication import get_company

class ConfigsApi(BaseGetResource):
    """
    Class that handles the configs endpoint
    """
    request_parser = configs_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='configs_api/configs_api.log',
        ),
        'name': 'configs_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.app_version = self.request_args.get('app_version', '')
        self.company = get_company()
        self.platform = self.request_args.get('__platform', '')
        self.locale = self.request_args.get('language')

    def check_validations(self):
        """
        Checks required arguments and sets all the responses as that of using in php.
        """
        # TODO: Improvement-> It should be handled at parser validation level and should show 400 error.
        # it is showing 500 error as it is done in php on required arguments.
        if not self.app_version:
            self.send_response_flag = True
            self.status_code = 500
            self.response = {
                'message': GlobalConstants().INTERNAL_SERVER_ERROR,
            }
            return self.send_response(self.response, self.status_code)

        if not self.company:
            self.send_response_flag = True
            self.status_code = 500
            self.response = {
                'message': GlobalConstants().INTERNAL_SERVER_ERROR,
            }
            return self.send_response(self.response, self.status_code)

        if not self.platform:
            self.send_response_flag = True
            self.status_code = 500
            self.response = {
                'message': GlobalConstants().INTERNAL_SERVER_ERROR,
            }
            return self.send_response(self.response, self.status_code)

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.translation_manager = TranslationManager()
        self.app_tutorial_repo = AppTutorialRepository()

    def setting_variables(self):
        """
        Sets variables for api
        """
        self.locale = WLCommonHelpers().get_locale(self.locale)
        self.location_version = WLCommonHelpers().get_location_version()

    def get_configs(self):
        """
        Gets configurations
        """
        self.cart_url = current_app.config.get('NEW_CART_URL')
        self.configs = {
            'key': 'locations',
            'value': self.location_version,
            'os': 'all'
        }
        self.is_analytics_enabled = WLCommonHelpers().is_analytics_enabled(self.company)
        if self.is_analytics_enabled:
            configs2 = {
                'key': 'log_analytics',
                'value': "true",
                'os': 'all'
            }
            self.configs = [self.configs, configs2]

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': {
                'cart_url': self.cart_url,
                'config': self.configs
            },
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.populate_request_arguments()
        self.check_validations()
        if self.is_send_response_flag_on():
            return
        self.initialize_repos()
        self.setting_variables()
        self.get_configs()
        self.generate_final_response()
