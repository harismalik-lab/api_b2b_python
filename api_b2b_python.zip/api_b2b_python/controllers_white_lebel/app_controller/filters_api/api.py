"""
Module contains Filters APi
"""
from common.base_resource import BaseGetResource
from repositories.merchant_repo import MerchantRepository

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.common_helpers import WLCommonHelpers
from common_white_label.constants import GlobalConstants
from user_authentication_white_label.authentication import get_company

from .validation import filters_parser


class FiltersApi(BaseGetResource):
    """
    Class that handles the filters endpoint
    """
    request_parser = filters_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='filters_api/filters_api.log',
        ),
        'name': 'filters_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')
        self.company = get_company()

    def check_validations(self):
        """
        Checks required arguments and sets all the responses as that of using in php.
        """
        # TODO: Improvement-> It should be handled at parser validation level and should show 400 error.
        # it is showing 500 error as it is done in php on required arguments.
        if not self.company:
            self.send_response_flag = True
            self.status_code = 500
            self.response = {
                'message': GlobalConstants().INTERNAL_SERVER_ERROR,
            }
            return self.send_response(self.response, self.status_code)

    def setting_variables(self):
        """
        Sets variables for api
        """
        self.locale = WLCommonHelpers().get_locale(self.locale)

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.merchant_repo = MerchantRepository()

    def get_filters(self):
        """
        Gets validation status of device
        """
        self.filters = self.merchant_repo.get_merchant_filters(self.locale)

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': self.filters,
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.populate_request_arguments()
        self.check_validations()
        if self.is_send_response_flag_on():
            return
        self.setting_variables()
        self.initialize_repos()
        self.get_filters()
        self.generate_final_response()
