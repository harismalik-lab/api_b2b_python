"""
Module contains Configurations Connectivity APi
"""
from common.base_resource import BaseGetResource

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from controllers_white_lebel.app_controller.configurations_connectivity_api.validation import configuration_parser


class ConfigurationsConnectivityApi(BaseGetResource):
    """
    Class that handles the configurations connectivity endpoint
    """
    request_parser = configuration_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='locations_api/locations_api.log',
        ),
        'name': 'locations_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.company = self.request_args.get('wlcompany')

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': [],
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.populate_request_arguments()
        self.generate_final_response()
