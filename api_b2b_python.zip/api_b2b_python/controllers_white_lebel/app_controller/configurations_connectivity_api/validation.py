from common.common_helpers import get_request_parser

configuration_parser = get_request_parser()

configuration_parser.add_argument(
    name="wlcompany",
    required=False,
    type=str
)
