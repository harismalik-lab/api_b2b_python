"""
verify model validation parser
"""
from common.common_helpers import get_request_parser
from common.custom_fields_request_parser import language

verify_model_parser = get_request_parser()

verify_model_parser.add_argument(
    name="model",
    type=str,
    required=False
)
verify_model_parser.add_argument(
    name="wlcompany",
    default="",
    type=str,
    required=False
)
verify_model_parser.add_argument(
    name="language",
    default="en",
    type=language,
    required=False
)
