from common.base_resource import BaseGetResource

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from controllers_white_lebel.app_controller.verify_model_api.verify_model_validation import verify_model_parser
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.validate_mobile_os_repo import ValidateMobileOsRepository


class VerifyModelApi(BaseGetResource):
    """
    Class that handles the verify model endpoint
    """
    required_token = True
    request_parser = verify_model_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='verify_model_api/verify_model_api.log',
        ),
        'name': 'verify_model_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.model = self.request_args.get('model')
        self.company = self.request_args.get('wlcompany')
        self.locale = self.request_args.get('language')

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.translation_manager = TranslationManager()
        self.validate_mobile_os = ValidateMobileOsRepository()

    def set_validation_status_and_response(self):
        """
        Gets validation status of device
        """
        self.validation_status = self.validate_mobile_os.validate_model(self.model, self.company)

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': self.validation_status,
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.populate_request_arguments()
        self.initialize_repos()
        self.set_validation_status_and_response()
        self.generate_final_response()
