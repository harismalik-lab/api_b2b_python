"""
Module contains App Tutorial APi
"""
from common.base_resource import BaseGetResource

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.common_helpers import WLCommonHelpers
from common_white_label.constants import GlobalConstants
from controllers_white_lebel.app_controller.app_tutorial_api.app_tutorial_validation import app_tutorial_parser
from repositories_white_label.app_tutorial_repo import AppTutorialRepository
from repositories_white_label.translations_repo import TranslationManager
from user_authentication_white_label.authentication import get_company


class AppTutorialApi(BaseGetResource):
    """
    App tutorial class handles the app tutorial endpoint
    """
    required_token = True
    request_parser = app_tutorial_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='app_tutorial_api/app_tutorial_api.log',
        ),
        'name': 'app_tutorial_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.app_version = self.request_args.get('app_version', '')
        self.company = get_company()
        self.locale = self.request_args.get('language')
        self.platform = self.request_args.get('__platform', '')

    def check_validations(self):
        """
        Checks required arguments and sets all the responses as that of using in php.
        """
        # TODO: Improvement-> It should be handled at parser validation level and should show 400 error.
        # it is showing 500 error as it is done in php on required arguments.
        if not self.app_version:
            self.send_response_flag = True
            self.status_code = 500
            self.response = {
                'message': GlobalConstants().INTERNAL_SERVER_ERROR,
            }
            return self.send_response(self.response, self.status_code)

        if not self.company:
            self.send_response_flag = True
            self.status_code = 500
            self.response = {
                'message': GlobalConstants().INTERNAL_SERVER_ERROR,
            }
            return self.send_response(self.response, self.status_code)

        if not self.platform:
            self.send_response_flag = True
            self.status_code = 500
            self.response = {
                'message': GlobalConstants().INTERNAL_SERVER_ERROR,
            }
            return self.send_response(self.response, self.status_code)

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.translation_manager = TranslationManager()

    def setting_variables(self):
        """
        Sets variables for api
        """
        self.locale = WLCommonHelpers().get_locale(self.locale)
        self.messages_locale = WLCommonHelpers().get_locale_for_messaging(
            self.locale
        )

    def get_app_tutorial(self):
        """
        Gets app tutorial
        """
        self.app_tutorials = AppTutorialRepository.get_app_tutorials(
            company=self.company,
            platform=self.platform,
            app_version=self.app_version,
            locale=self.messages_locale
        )

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': {
                'tutorial': {
                    'background_image': GlobalConstants.APP_TUTORIAL_BACKGROUND_IMAGE,
                    'app_tutorial': self.app_tutorials
                }
            },
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.populate_request_arguments()
        self.check_validations()
        if self.is_send_response_flag_on():
            return
        self.initialize_repos()
        self.setting_variables()
        self.get_app_tutorial()
        self.generate_final_response()
