"""
Module contains Locations APi
"""
from common.base_resource import BaseGetResource
from repositories.merchant_repo import MerchantRepository

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.common_helpers import WLCommonHelpers
from repositories_white_label.location_repo import LocationRepositoryWhiteLabel
from repositories_white_label.wl_company_repo import WLCompany

from .validation import locations_parser


class LocationsApi(BaseGetResource):
    """
    Class that handles the locations endpoint
    """
    request_parser = locations_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='locations_api/locations_api.log',
        ),
        'name': 'locations_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.company = self.request_args.get('wlcompany')
        self.app_version = self.request_args.get('app_version')
        self.plat_form = self.request_args.get('__platform')
        self.build_no = self.request_args.get('build_no')
        self.locale = self.request_args.get('language')

    def setting_variables(self):
        """
        Sets variables for api
        """
        self.locale = WLCommonHelpers().get_locale(self.locale)

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.merchant_repo = MerchantRepository()

    def get_locations(self):
        """
        Gets validation status of device
        """
        self.locations = LocationRepositoryWhiteLabel.get_locations(company=self.company, locale=self.locale)
        for location in self.locations:
            if (
                location['active'] == '1' or
                location['active'] == 1 or
                location['active'] == "True"
            ):
                location['active'] = True
            else:
                location['active'] = False
            location['is_show_category'] = False
            location['is_careem_enabled'] = int(location['is_careem_enabled'])
            # change location name from Riyadh & E. Prov to Riyadh
            if (
                self.company == WLCompany.COMPANY_CODE_ALBILAD and
                location['id'] == 10
            ):
                location['name'] = 'Riyadh'
        self.location_version = WLCommonHelpers().get_location_version()
        self.filters = self.merchant_repo.get_merchant_filters(self.locale, self.company)

    def generate_fina_response(self):
        """
        Generates fianl response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': {
                'locations': self.locations
            },
            'version': self.location_version,
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.populate_request_arguments()
        self.setting_variables()
        self.initialize_repos()
        self.get_locations()
        self.generate_fina_response()
