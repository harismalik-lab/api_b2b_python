"""
location validation parser
"""
from common.common_helpers import get_request_parser
from common.custom_fields_request_parser import device_list, language

locations_parser = get_request_parser()

locations_parser.add_argument(
    name="wlcompany",
    required=True,
    type=str
)
locations_parser.add_argument(
    name="language",
    required=True,
    default="en",
    type=language
)
locations_parser.add_argument(
    name="__platform",
    required=True,
    type=device_list
)
locations_parser.add_argument(
    name="app_version",
    required=True,
    type=str
)
locations_parser.add_argument(
    name="location_id",
    required=True,
    type=int
)
locations_parser.add_argument(
    name="build_no",
    required=True,
    type=int
)
