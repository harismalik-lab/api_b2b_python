"""
App key validation parser
"""
from common.common_helpers import get_request_parser
from common.custom_fields_request_parser import device_list

app_key_validation_parser = get_request_parser()

app_key_validation_parser.add_argument(
    name="wlcompany",
    required=False,
    type=str
)
app_key_validation_parser.add_argument(
    name="__platform",
    required=False,
    type=device_list
)
app_key_validation_parser.add_argument(
    name="app_version",
    required=False,
    type=str
)
app_key_validation_parser.add_argument(
    name="language",
    default="en",
    type=str,
    required=False
)
