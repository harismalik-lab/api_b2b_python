"""
Module contains App Key Validation Config APi
"""
from common.base_resource import BaseGetResource

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.common_helpers import WLCommonHelpers
from common_white_label.constants import GlobalConstants
from controllers_white_lebel.app_controller.app_key_validation_config_api.app_key_validation import (
    app_key_validation_parser
)
from repositories_white_label.appkey_validation_configuration_repo import AppKeyValidationConfigurationRepository
from repositories_white_label.translations_repo import TranslationManager


class AppKeyValidationConfigApi(BaseGetResource):
    """
    Class that handles the app key validations config endpoint
    """
    request_parser = app_key_validation_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='app_key_validation_config_api/app_key_validation_config_api.log',
        ),
        'name': 'app_key_validation_config_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.app_version = self.request_args.get('app_version')
        self.company = self.request_args.get('wlcompany')
        self.locale = self.request_args.get('language')
        self.platform = self.request_args.get('__platform')

    def check_validations(self):
        """
        Checks required arguments and sets all the responses as that of using in php.
        """
        # TODO: Improvement-> It should be handled at parser validation level and should show 400 error.
        # it is showing 500 error as it is done in php on required arguments.
        if not self.app_version:
            self.send_response_flag = True
            self.status_code = 500
            self.response = {
                'message': GlobalConstants().INTERNAL_SERVER_ERROR,
            }
            return self.send_response(self.response, self.status_code)

        if not self.company:
            self.send_response_flag = True
            self.status_code = 500
            self.response = {
                'message': GlobalConstants().INTERNAL_SERVER_ERROR,
            }
            return self.send_response(self.response, self.status_code)

        if not self.platform:
            self.send_response_flag = True
            self.status_code = 500
            self.response = {
                'message': GlobalConstants().INTERNAL_SERVER_ERROR,
            }
            return self.send_response(self.response, self.status_code)

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.translation_manager = TranslationManager()
        self.app_key_validation_configuration_repo = AppKeyValidationConfigurationRepository()

    def setting_variables(self):
        """
        Sets variables for api
        """
        self.locale = WLCommonHelpers().get_locale(self.locale)
        self.messages_locale = WLCommonHelpers().get_locale_for_messaging(
            self.locale
        )

    def get_app_key_validation_configuration(self):
        """
        Gets app key validation configuration
        """
        self.app_key_validation_configurations = self.app_key_validation_configuration_repo.\
            get_app_key_validation_configuration(self.company, self.platform, self.app_version, self.messages_locale)

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'configurations': self.app_key_validation_configurations,
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.populate_request_arguments()
        self.check_validations()
        if self.is_send_response_flag_on():
            return
        self.initialize_repos()
        self.setting_variables()
        self.get_app_key_validation_configuration()
        self.generate_final_response()
