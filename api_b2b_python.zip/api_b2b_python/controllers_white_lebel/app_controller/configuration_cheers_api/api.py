"""
Module contains Configuration Cheers APi
"""
from common.base_resource import BaseGetResource
from flask import current_app

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.common_helpers import WLCommonHelpers
from common_white_label.constants import GlobalConstants
from controllers_white_lebel.app_controller.configuration_cheers_api.config_cheers_validation import (
    config_cheers_parser
)
from repositories_white_label.app_tutorial_repo import AppTutorialRepository
from repositories_white_label.translations_repo import TranslationManager
from user_authentication_white_label.authentication import get_company



class ConfigurationsCheersApi(BaseGetResource):
    """
    Class that handles the configurations cheers endpoint
    """
    request_parser = config_cheers_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='config_cheers_api/config_cheers_api.log',
        ),
        'name': 'config_cheers_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """

        self.company = get_company()
        self.locale = self.request_args.get('language')

    def check_validations(self):
        """
        Checks required arguments and sets all the responses as that of using in php.
        """
        # TODO: Improvement-> It should be handled at parser validation level and should show 400 error.
        # it is showing 500 error as it is done in php on required arguments.
        if not self.company:
            self.send_response_flag = True
            self.status_code = 500
            self.response = {
                'message': GlobalConstants().INTERNAL_SERVER_ERROR,
            }
            return self.send_response(self.response, self.status_code)

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.translation_manager = TranslationManager()
        self.app_tutorial_repo = AppTutorialRepository()

    def setting_variables(self):
        """
        Sets variables for api
        """
        self.locale = WLCommonHelpers().get_locale(self.locale)

    def get_configurations_cheers(self):
        """
        Gets configurations cheers
        """
        self.configuration_cheers = WLCommonHelpers().get_cheers_configurations(
            locale=self.locale,
            company=self.company
        )
        self.cart_url = current_app.config.get('CART_URL')

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': {
                'cheers_rules': self.configuration_cheers
            },
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.populate_request_arguments()
        self.check_validations()
        if self.is_send_response_flag_on():
            return
        self.initialize_repos()
        self.setting_variables()
        self.get_configurations_cheers()
        self.generate_final_response()
