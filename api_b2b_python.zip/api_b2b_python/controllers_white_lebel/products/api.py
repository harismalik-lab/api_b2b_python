"""
Module handles the product controllers
"""
from common.base_resource import BaseGetResource
from common.common_helpers import CommonHelpers
from repositories.quick_translation_repo import QuickTranslationRepository

from repositories_white_label.exchange_rates_repo import ExchangeRatesRepositoryWL
from repositories_white_label.product_repo import ProductRepositoryWhiteLabel
from repositories_white_label.product_supplement_repo import ProductSupplimentaryRepositoryWl
# from repositories_white_label.v_67.product_top_merchants_repo import ProductTopMerchantsRepositoryWhiteLabelV67

from .validation import product_controller_parser, product_details_controller_parser

# from repositories_white_label.product_top_merchants_repo import ProductTopMerchantsRepositoryWhiteLabelV67


class ProductsApi(BaseGetResource):
    """
    Class handles the products related endpoint
    """
    request_parser = product_controller_parser

    def populate_request_arguments(self):
        """
        Reading request data
        """
        self.company = self.request_args.get('wlcompany')
        self.user_id = self.request_args.get('__i')
        self.location_id = int(self.request_args.get('location_id'))
        self.currency = self.request_args.get('currency')
        self.locale = self.request_args.get('language')
        self.is_cuckoo = self.request_args.get('is_cuckoo')

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.product_repo = ProductRepositoryWhiteLabel()
        self.exchange_rate_class_instance = ExchangeRatesRepositoryWL()

    def initialize_variables(self):
        """
        Initializes all instance based variables
        """
        self.products_info = []
        self.locale = CommonHelpers.get_locale(self.locale, self.location_id)

    def read_products(self):
        """
        Reads the products from database
        """
        product_tabs = self.product_repo.get_product_ids(self.company)
        exchange_rate = self.exchange_rate_class_instance.get_exchange_rates()
        for product_tab in product_tabs:
            product_info = {}
            product_info["section_title"] = product_tab.get("section_name", "")
            products = self.product_repo.get_products_by_id(
                self.company,
                self.locale,
                self.location_id,
                product_tab.get("product_ids", "").split(",")
            )
            products = self.product_repo.calculate_product_price(products, exchange_rate)
            product_info['products'] = products if products else {}
            for product in product_info.get("products", []):
                product['valid_to'] = str(product.get("valid_to", ""))
            self.products_info.append(product_info)

    def generate_final_response(self):
        """
        Final Api response generator
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'products_info': self.products_info,
            'success': True,
            'message': 'success'
        }

    def process_request(self):
        """
        Processes the api request
        """
        self.initialize_repos()
        self.initialize_variables()
        self.read_products()
        self.generate_final_response()


class ProductsDetailsApi(BaseGetResource):
    """
    Class handles the product details endpoint
    """
    request_parser = product_details_controller_parser

    def populate_request_arguments(self):
        """
        Reading request data
        """
        self.company = self.request_args.get('wlcompany')
        self.user_id = self.request_args.get('__i')
        self.platform = self.request_args.get('__platform')
        self.locale = self.request_args.get('language')
        self.location_id = self.request_args.get('location_id')
        self.product_id = self.request_args.get('product_id')
        self.currency = self.request_args.get('currency')

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.product_repo = ProductRepositoryWhiteLabel()
        self.transaltion_repo_instance = QuickTranslationRepository()
        self.exchange_rate_class_instance = ExchangeRatesRepositoryWL()
        # self.wl_top_merchant_repo = ProductTopMerchantsRepositoryWhiteLabelV67()
        self.wl_product_supplimentary_repo = ProductSupplimentaryRepositoryWl()

    def initialize_variables(self):
        """
        Initializes all instance based variables
        """
        self.products_info = []
        self.product_details = {}
        self.product_top_merchants_repo = []
        self.product_supplement_repo = []
        self.payment_info = {}
        self.top_merchants_info = {}
        self.product_supplements_info = {}
        self.locale = CommonHelpers.get_locale(self.locale, self.location_id)
        self.messages_locale = CommonHelpers.get_locale_for_messaging(self.locale)

    def get_products_detail(self):
        """
        Read information regarding products
        """
        exchange_rate = self.exchange_rate_class_instance.get_exchange_rates()
        product_summary = self.product_repo.get_product_details(
            self.company, self.product_id, self.locale, exchange_rate
        )
        buy_page = self.product_repo.get_buy_page_message_url(self.locale, self.request_args, self.platform)

        self.payment_info['buy_page_title'] = buy_page.get("buy_page_title", "")
        self.payment_info['buy_page_url'] = buy_page.get("buy_page_url", "")

        top_merchants = self.wl_top_merchant_repo.get_top_merchants(self.product_id, self.locale)
        product_supplements = self.wl_product_supplimentary_repo.get_product_supplement_details_wl(
            self.product_id, self.locale
        )
        self.product_details['product_info_section'] = product_summary if product_summary else {}
        self.top_merchants_info['merchant_section_title'] = self.transaltion_repo_instance.get_translation(
            "product_buy_screen_merchant_section_title", self.messages_locale
        )

        self.top_merchants_info['merchants'] = top_merchants if top_merchants else {}
        self.product_details['merchant_info_section'] = self.top_merchants_info

        self.product_supplements_info[
            'product_supplements_section_title'] = self.transaltion_repo_instance.get_translation(
            "product_buy_screen_product_supplement_title", self.messages_locale
        )

        self.product_supplements_info['product_supplements_section_tiles'] = \
            product_supplements if product_supplements else {}
        self.product_details['product_supplements'] = self.product_supplements_info

    def generate_final_response(self):
        """
        Final Api response generator
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'product_details': self.product_details,
            'payment_info': self.payment_info,
            'success': True,
            'message': self.transaltion_repo_instance.get_translation('success', self.messages_locale)
        }

    def process_request(self):
        """
        Processes the api request
        """
        self.initialize_repos()
        self.initialize_variables()
        self.get_products_detail()
        self.generate_final_response()
