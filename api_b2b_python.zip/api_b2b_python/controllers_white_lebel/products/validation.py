from common.common_helpers import get_request_parser
from common.custom_fields_request_parser import boolean, currency, device_list, language

product_controller_parser = get_request_parser()
product_controller_parser.add_argument(
    "wlcompany",
    type=str,
    required=True,
    location=['mobile', 'json', 'values']
)
product_controller_parser.add_argument(
    "__i",
    type=int,
    required=True,
    location=['mobile', 'json', 'values']
)
product_controller_parser.add_argument(
    "location_id",
    type=int,
    required=True,
    location=['mobile', 'json', 'values']
)
product_controller_parser.add_argument(
    "currency",
    default="USD",
    type=currency,
    required=False,
    location=['mobile', 'json', 'values']
)
product_controller_parser.add_argument(
    "language",
    type=language,
    required=False,
    default="en",
    location=['mobile', 'json', 'values']
)
product_controller_parser.add_argument(
    "is_cuckoo",
    default=False,
    type=boolean,
    location=['mobile', 'json', 'values'],
    required=True
)
product_details_controller_parser = get_request_parser()
product_details_controller_parser.add_argument(
    "wlcompany",
    type=str,
    location=['mobile', 'json', 'values'],
    required=True
)
product_details_controller_parser.add_argument(
    "__i",
    type=id,
    location=['mobile', 'json', 'values'],
    required=True
)
product_details_controller_parser.add_argument(
    "__platform",
    default="",
    type=device_list,
    location=['mobile', 'json', 'values'],
    required=True
)
product_details_controller_parser.add_argument(
    "language",
    default="en",
    type=language,
    location=['mobile', 'json', 'values'],
    required=False
)
product_details_controller_parser.add_argument(
    "location_id",
    type=int,
    location=['mobile', 'json', 'values'],
    required=True
)
product_details_controller_parser.add_argument(
    "product_id",
    default=0,
    type=int,
    location=['mobile', 'json', 'values'],
    required=False
)
product_details_controller_parser.add_argument(
    "currency",
    default="USD",
    type=currency,
    location=['mobile', 'json', 'values'],
    required=False
)
