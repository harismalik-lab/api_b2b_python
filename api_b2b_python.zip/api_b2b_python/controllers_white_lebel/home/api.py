import base64
import datetime
import json
import os
import urllib
from urllib.parse import urlencode

from Crypto.Cipher import AES
from flask import current_app
from requests import codes

from app_configurations_white_label.settings import ONLINE_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from common_white_label.common_helpers import CommonHelpers
from common_white_label.constants import GlobalConstants
from controllers_white_lebel.home.validation import home_wl_api_parser
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.exchange_rates_repo import ExchangeRatesRepositoryWL
from repositories_white_label.home_screen_configurations_repo import HomeScreenRepositoryWL
from repositories_white_label.product_repo import ProductRepositoryWhiteLabel
from repositories_white_label.session_repo import SessionRepositoryWhiteLabel
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.v_67.product_wl_active_repo import ProductWlActiveRepository
from repositories_white_label.wl_company_repo import WLCompany
from repositories_white_label.wl_gem_lookup_repo import WlGemLookupRepository
from repositories_white_label.wl_gem_points_repo import WlGemPointsRepository
from repositories_white_label.wl_validtion_repo import WlValidationRepository
from user_authentication_white_label.authentication import get_current_customer

__author__ = 'zaheer'


class HomeWlApi(BaseGetResource):
    """
    This class contains /home[GET] endpoint
    """
    api_version = 'v67'
    method = 'get'
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ONLINE_LOG_PATH,
            file_path='home_api/home_api.log',
        ),
        'name': 'home_api'
    }
    logger = None
    request_parser = home_wl_api_parser
    required_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.company = self.request_args.get('wlcompany')
        self.user_id = self.request_args.get('user_id')
        self.location_id = self.request_args.get('location_id')
        self.currency = self.request_args.get('currency')
        self.app_version = self.request_args.get('app_version')
        self.locale = self.request_args.get('locale')
        self.platform = self.request_args.get('platform')
        self.build_no = self.request_args.get('build_no')
        self.session_id = self.request_args.get('session_id')
        self.session_token = self.request_args.get('session_token')
        self.validation_params = {}
        self.synsodyne_code = ''

    def parse_request_args(self):
        self.locale = CommonHelpers.get_locale_for_messaging(self.locale)
        self.savings_messages = []
        self.message_to_append_with_this_year_savings = self.trasnlation_repo.get_translation(
            translation_key=self.trasnlation_repo.SAVED_THIS_YEAR_LABEL, locale=self.locale)
        self.user_yearly_savings = self.customer_repo.get_user_yearly_savings(
            user_id=self.user_id,
            currency=self.currency,
            locale=self.locale,
            message_to_append_with_this_year_savings=self.message_to_append_with_this_year_savings,
            company=self.company
        )
        self.user_yearly_savings['smiles_earned'] = 0
        self.user_points = 0
        self.user_points_earned = 0
        self.user_points_burned = 0
        self.user_points_available = 0

    def initialize_repose(self):
        self.home_screen_config_repo = HomeScreenRepositoryWL()
        self.customer_repo = CustomerProfileWhiteLabel()
        self.product_repo = ProductRepositoryWhiteLabel()
        self.gems_points_repo = WlGemPointsRepository()
        self.session_repo = SessionRepositoryWhiteLabel()
        self.product_wl_active_repo = ProductWlActiveRepository()
        self.exchange_rate_repo = ExchangeRatesRepositoryWL()
        self.wl_validation_repo = WlValidationRepository()
        self.trasnlation_repo = TranslationManager()
        self.wl_gem_lookup_repo = WlGemLookupRepository()

    def get_customer_from_session(self):
        '''
        Gets customer from session
        '''
        self.customer = get_current_customer()
        if (
            self.session_token and
            self.customer and
            not self.session_id
        ):

            session = self.session_repo.find_by_token(self.company, self.session_token)
            if session:
                session_id = session.get('id', '')
                user_id = session.get('customer_id', '')
                company = session.get('company', '')
                session_data = self.customer_repo.get_customer_products(user_id, company)
                GlobalConstants.SERVICE_Session_Helper_DEFAULT.setSessionData(
                    company,
                    user_id,
                    session_data
                )
                self.validation_params = {
                    '__i': user_id,
                    '__sid': session_id,
                    'session_token': self.session_token
                }

                # Get Customer from Session
                self.customer = get_current_customer()

    def get_users_points(self):
        """
        Gets users points
        """
        if self.company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
            user_points_result = self.gems_points_repo.get_user_points_stats(self.user_id)
            if user_points_result:
                self.user_points_earned = user_points_result.get('points_earned', '')
                self.user_points_burned = user_points_result.get('points_burned', '')
                self.user_points_available = user_points_result.get('points_available', '')
            self.user_points = (self.user_yearly_savings.get('total_points') if self.user_yearly_savings.get(
                'total_points'
            ) else 0)
            self.user_yearly_savings['smiles_earned'] = self.user_points_earned
        else:
            self.external_savings = self.user_yearly_savings.get('total_points') if \
                self.user_yearly_savings.get('total_points') else 0
            self.user_yearly_savings['external_savings'] = self.external_savings
            if self.user_yearly_savings.get('gems_savings'):
                del self.user_yearly_savings['gems_savings']
            if self.user_yearly_savings.get('total_points'):
                del self.user_yearly_savings['total_points']

    def show_aag_message(self):
        user_profile = self.customer_repo.load_customer_by_id(self.user_id)
        user_name = ''
        if user_profile:
            user_name = user_profile.get('first_name', '')
        if self.company == WLCompany.COMPANY_CODE_AAG:
            self.savings_messages.append("{} you've saved {} {} so far".format(
                user_name,
                self.currency,
                self.user_yearly_savings)
            )

            self.savings_messages.append(self.home_screen_config_repo.get_saving_messages(
                (self.user_yearly_savings['savings_this_year_aed'] if self.user_yearly_savings['savings_this_year_aed']
                 else 0, self.locale)))

            for message in self.savings_messages:
                message = message.replace("__UserName__", user_name)
                message = message.replace("__SAVINGS_VALUE__", '{} {}'.format(
                    self.currency,
                    self.user_yearly_savings['savings_this_year']
                ))
                message = message.replace("__CURRENCY__", self.currency)

            if self.company == WLCompany.COMPANY_CODE_ENTERTAINER_SENSODYNE:
                synsodyne_code = "CHSAU/CHSENO/0094/17a"
                self.savings_messages.append("Enjoy your free offers without worry of sensitivity \n\n {}".format(
                    synsodyne_code)
                )
        self.all_links = self.home_screen_config_repo.get_all(self.locale, self.location_id, self.company)
        self.home_sections = []
        self.location_version = WLCompany().get_location_version()
        self.app_configuration_version = 1
        self.purchasable_products = []
        self.purchased_product_ids = []
        self.purchasable_product_ids = []
        self.purchasable_product_detail = {"id": 0}
        self.show_upgrade_button = False
        self.show_cart_button = False
        '''
        if self.customer[GlobalConstants.IS_USER_LOGGED_IN]:
            purchased_product_ids = self.customer['purchased_product_ids']
            purchasable_products = self.product_wl_active_repo.get_purchasable_products(self.company, self.location_id)
            purchasable_product_ids = purchasable_products['purchasable_products_this_location']

            if len(purchasable_product_ids) > 0:
                products = self.product_repo.get_products_by_id(
                    self.company,
                    purchasable_product_ids[0],
                    self.locale,
                    self.location_id
                )
                if len(products) > 0:
                    exchangeRates = self.exchange_rate_repo.get_exchange_rates()
                    products = self.product_repo.calculate_product_price(products, exchangeRates)

                    if len(products) > 0:
                        purchasable_product_detail = products[0]

            if len(purchasable_products['purchasable_products_all']) > 0:
                if len(purchased_product_ids) > 0:
                    show_cart_button = True
                    show_upgrade_button = False
                else:
                    show_cart_button = False
                    show_upgrade_button = True
        '''

        self.main_cover = {
            'identifier': 'main_cover',
            'section_identifier': 'main_cover',
            'title': '',
            'tiles': []
        }
        if self.customer:
            self.is_user_logged_in = True

    def set_categories(self):
        self.categories = {
            'identifier': 'categories',
            'section_identifier': 'categories',
            'title': '',
            'tiles': HomeScreenRepositoryWL.get_categories(
                is_user_logged_in=self.is_user_logged_in,
                company=self.company,
                user_id=self.user_id,
                location_id=self.location_id,
                purchased_product_ids=self.purchased_product_ids,
                purchasable_product_ids=self.purchasable_product_ids,
                locale=self.locale
            )
        }

    def is_user_hsbc_black_card_holder(self):
        self.hsbc_black_card_holder = False
        if (
            self.customer and
            self.company.lower() == WLCompany.COMPANY_CODE_ENTERTAINER_HSBC
        ):
            user_group = self.wl_validation_repo.get_user_group(self.company, self.user_id)
            if user_group == 2:
                self.hsbc_black_card_holder = True
        if self.company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
            self.more_to_enjoy = self.trasnlation_repo.get_translation(
                self.trasnlation_repo.gems_more_to_enjoy,
                self.locale
            )
        elif self.company.lower() == WLCompany.COMPANY_CODE_ENTERTAINER_HSBC:
            self.more_to_enjoy = self.trasnlation_repo.get_translation(
                self.trasnlation_repo.hsbc_more_to_enjoy,
                self.locale
            )
        elif self.company == WLCompany.COMPANY_CODE_ENTERTAINER_QGIRCO:
            self.more_to_enjoy = self.trasnlation_repo.get_translation(
                self.trasnlation_repo.qgi_more_to_enjoy,
                self.locale
            )
        else:
            self.more_to_enjoy = self.home_screen_config_repo.get_heading('extra', self.locale)

    def add_ambassador_program_link(self):
        if (
            self.customer and
            self.company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS
        ):
            try:
                gems_encryption_key = self.gems_encryption_key  # this->container needs to define here
                if gems_encryption_key:
                    gem_lookup_data = self.wl_gem_lookup_repo.find_profile_by_id(self.user_id)
                    if gem_lookup_data:
                        parent_id = gem_lookup_data.get('parent_id', '')
                        SBU = gem_lookup_data.get('school', '')
                        for link in self.all_links:
                            if (
                                    link['link_type'] == self.home_screen_config_repo.type_extra and
                                    link['id'] in (1165, 1193)
                            ):  # Ambassador program
                                link['link_type'] = "trash"    # temporarily remove it
                            if link['link_type'] == self.home_screen_config_repo.type_gems_referral:
                                gems_referral_url = self.home_screen_config_repo.get_gems_ambassador_program_url(
                                    link['deep_link'],
                                    gems_encryption_key,
                                    parent_id,
                                    SBU
                                )
                                link['deep_link'] = gems_referral_url
                                if gems_referral_url:
                                    link['link_type'] = self.home_screen_config_repo.type_extra
            except:
                pass

    def check_user_black_card_holder(self):
        if self.hsbc_black_card_holder:
            self.link_type = '{}_group2'.format(self.home_screen_config_repo.type_extra)
        else:
            self.link_type = self.home_screen_config_repo.type_extra
        self.extras = {
            'identifier': 'featured_sections',
            'section_identifier': 'more_to_enjoy',
            'title': self.more_to_enjoy,   # 'Extras',
            'tiles': self.home_screen_config_repo.get_sub_section(self.all_links, self.link_type, self.locale)
        }
        self.for_the_weekend = {
            'identifier': 'featured_sections',
            'section_identifier': 'for_the_weekend',
            'title': self.home_screen_config_repo.get_heading('for_the_weekend', self.locale),  # 'For the weekend',
            'tiles': self.home_screen_config_repo.get_sub_section(
                self.all_links,
                self.home_screen_config_repo.type_for_the_weekend,
                self.locale
            )
        }
        if self.hsbc_black_card_holder:
            self.link_type = '{}_group2'.format(self.home_screen_config_repo.type_featured)
        else:
            self.link_type = self.home_screen_config_repo.type_featured

    def set_featured_section(self):
        self.feature_section = self.home_screen_config_repo.get_sub_section(
            self.all_links,
            self.link_type,
            self.locale
        )
        if self.company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
            self.featured_heading = self.trasnlation_repo.get_translation(
                self.trasnlation_repo.gems_featured_heading,
                self.locale
            )
        elif self.company.lower() == WLCompany.COMPANY_CODE_ENTERTAINER_HSBC:
            if self.hsbc_black_card_holder:
                self.featured_heading = self.trasnlation_repo.get_translation(
                    self.trasnlation_repo.hsbc_more_to_enjoy_group2,
                    self.locale
                )
            else:
                self.featured_heading = self.trasnlation_repo.get_translation(
                    self.trasnlation_repo.hsbc_more_to_enjoy,
                    self.locale
                )
        elif self.company == WLCompany.COMPANY_CODE_DUBAI_ENTERTAINMENTS:
            self.featured_heading = "What’s New"
        self.featured = {
            'identifier': 'featured_sections',
            'section_identifier': 'featured',
            'title': self.featured_heading,   # 'Featured',
            'tiles': self.feature_section
        }
        self.birthday = {
            'identifier': 'featured_sections',
            'section_identifier': 'Birthday Offer',
            'title': self.home_screen_config_repo.get_heading(
                'birthday',
                self.locale
            ),
            'tiles': []
        }

    def set_branding_attributes(self):
        self.savings_messages.append(self.customer if self.savings_messages else
                                     self.trasnlation_repo.get_translation(
                                         self.trasnlation_repo.savings_message_welcome_guest,
                                         self.locale
                                     ))
        self.branding_attributes = []
        if self.company.lower() == WLCompany.COMPANY_CODE_ENTERTAINER_HSBC:
            if self.hsbc_black_card_holder:
                self.branding_attributes = {
                    'main_top_image': 'https://s3.amazonaws.com/app-home-tiles/more-from-hsbc/Black_hs.jpg',
                    'main_top_color': 'aa000000',
                    'main_top_text_color': "FFFFFF"
                }
            else:
                self.branding_attributes = {
                    'main_top_image': 'https://s3.amazonaws.com/entertainer-app-assets/Generic-ios-Visual.jpg',
                    'main_top_color': 'aae63a2a',
                    'main_top_text_color': "FFFFFF"
                }
        elif self.company == WLCompany.COMPANY_CODE_AAG:
            self.branding_attributes = {
                'main_top_image': '',
                'main_top_color': 'aaff5c5c',
                'main_top_text_color': "252525"
            }
        else:
            self.branding_attributes = {
                'main_top_image': '',
                'main_top_color': '99ffffff',
                'main_top_text_color': "252525"
            }

    def set_main_cover_title(self):
        self.main_cover['tiles'].append({
            'identifier': 'messaging_tile',
            'image': '',
            'synsodyne_code': self.synsodyne_code,
            'messages': self.savings_messages,   # {("You have saved 10,000 AED this year so far!") //$savings_messages
            'main_top_image': self.branding_attributes['main_top_image'],
            'main_top_color': self.branding_attributes['main_top_color'],
            'main_top_text_color': self.branding_attributes['main_top_text_color']
        })
        self.main_cover['tiles'].append({
            'identifier': 'savings_tile',
            'image': '',
            'savings': self.user_yearly_savings
        })
        if self.company.lower() == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS and self.app_version > str(1.3):
            self.is_show_grey_view = True
            if self.user_points_available >= 5550:
                self.is_show_grey_view = False
            self.main_cover['tiles'].append({
                'identifier': 'points_section',
                'image': "",
                'detail': {
                    'points_available_image': "https://s3.amazonaws.com/entertainer-app-assets/icons/ic_home_points.png",
                    'points_used_image': "https://s3.amazonaws.com/entertainer-app-assets/icons/ic_home_points.png",
                    'points_available': self.user_points_available,
                    'points_used': self.user_points_burned,
                    'points_available_title': "GEMS POINTS AVAILABLE",
                    'points_used_title': "GEMS POINTS USED",
                    'bottom_message': "Use your GEMS Points toward school fees! Minimum number of GEMS Points required: 5,550",  # noqa:E501
                    'is_show_grey_view': self.is_show_grey_view
                }
            })
        self.home_sections.append(self.main_cover)
        self.home_sections.append(self.categories)

    def generate_kaligo_login_string(self, company, customer_id, customer_profile_info, locale):
        email = customer_profile_info["email"]
        first_name = customer_profile_info["firstname"]
        # user_name = first_name.lower().capitalize()
        # member_group = customer_profile_info["customerGroup"]
        membership_status_text = 'member'
        # customer_cc_details = self.customer_repo.get_customer_credit_card_details(customer_id)
        params_to_encode = {
            'user_id': customer_id,
            'email': email,
            'first_name': first_name,
            'user_level': '',
            'c_id': '',
            'c_4': '',
            'c_type': '',
            'language': locale == 'cn' if locale == 'zh' else locale,  # send kaligo zh instead of cn
            'membership_status': membership_status_text,
            'referrer': 19
        }
        plaintext = json.dumps(params_to_encode)
        self.kaligo_encryption_key = current_app.config.get('KALIGO_ENCRYPTION_KEY', '')
        iv = os.urandom(16)
        aes = AES.new(self.kaligo_encryption_key, mode=AES.MODE_CBC, IV=iv)
        ciphertext = (
            base64.encodebytes(
                iv + aes.encrypt(
                    CommonHelpers.pkcs5_padding(
                        plaintext,
                        16
                    )
                )
            )
        ).decode()
        self.kaligo_encrypted_string = urlencode(
            {
                'login': '{encrypted_data}'.format(encrypted_data=ciphertext)
            }
        )
        return self.kaligo_encrypted_string

    def check_is_kaligo_travel_enabled(self):
        self.is_kaligo_travel_enable = False
        self.kaligo_encrypted_string = ""
        self.kaligo_sign_in_api_endpoint = 'kaligo_sign_in_api_endpoint'   # this->container missing
        required_kaligo = False
        if self.build_no >= 70:
            required_kaligo = True
        if (
            self.customer and
            self.company.lower() == WLCompany.COMPANY_CODE_ENTERTAINER_HSBC and
            required_kaligo
        ):
            user_group = self.wl_validation_repo.get_user_group(self.company, self.user_id)
            if user_group == 2:
                self.hsbc_black_card_holder = True
            # kaligo stuff start
            self.user_profile = self.customer_repo.load_customer_profile_by_user_id(self.user_id)
            self.is_kaligo_travel_enable = True
            self.kaligo_encrypted_string = self.generate_kaligo_login_string(
                self.company,
                self.user_id,
                self.user_profile,
                self.locale
            )
            self.kaligo_section_final = []
            # & checkInDate=04 % 2F14 % 2F2018 & checkOutDate=04 % 2F16 % 2F2018
            section_heading = self.trasnlation_repo.get_translation(
                self.trasnlation_repo.Home_Screen_Getaway_Section_Heading,
                self.locale
            )
            if user_group == self.customer_repo.MEMBERSTATUS_MEMBER:
                section_heading = self.trasnlation_repo.get_translation(
                    self.trasnlation_repo.Home_Screen_Getaway_Section_Heading_member,
                    self.locale
                )
            self.kaligo_section = self.home_screen_config_repo.get_sub_section(
                self.all_links,
                'kaligo',
                self.locale
            )
            today_date = datetime.datetime.now()
            checkInDate = today_date + datetime.timedelta(days=10)
            checkOutDate = checkInDate + datetime.timedelta(days=2)
            if self.kaligo_section:
                for section in self.kaligo_section:
                    section['is_external_link'] = False
                    parts = urllib.parse.urlparse(section.get('deep_link'))
                    query = dict(urllib.parse.parse_qsl(parts.query))
                    query['currency'] = self.currency
                    query['checkInDate'] = checkInDate
                    query['checkOutDate'] = checkOutDate
                    section['deep_link'] = '{}://{}{}?{}'.format(
                        parts.get('scheme'),
                        parts.get('host'),
                        parts.get('path'),
                        urllib.parse.urlencode(query)
                    )
                    redirect = urlencode(section['deep_link'])
                    section['deep_link'] = '{}?{}&redirect={}'.format(
                        self.kaligo_sign_in_api_endpoint,
                        self.kaligo_encrypted_string,
                        redirect
                    )
                    section['internal_webview_title'] = "ENTERTAINER getaways"
                    section['on_close_webview_message'] = 'Are you sure you want to navigate away from ENTERTAINER getaways?'  # noqa:E501
                    self.kaligo_section_final.append(section)
            self.home_sections.append({
                'identifier': 'featured_sections',
                'section_identifier': 'featured',
                'title': section_heading,
                'tiles': self.kaligo_section_final
            })
            # kaligo stuff end

    def set_home_section(self):
        if len(self.birthday['tiles']) > 0:
            self.home_sections.append(self.birthday)
        if len(self.extras['tiles']) > 0:
            self.home_sections.append(self.extras)
        if len(self.for_the_weekend['tiles']) > 0:
            self.home_sections.append(self.for_the_weekend)
        if len(self.featured['tiles']) > 0:
            self.home_sections.append(self.featured)

    def generate_final_response(self):
        data = {
            'purchasable_product_ids': self.purchasable_product_ids,
            'purchasable_product_detail': self.purchasable_product_detail,
            'show_upgrade_button': self.show_upgrade_button,
            'show_cart_button': self.show_cart_button,
            'location_version': self.location_version,
            'app_configuration_version': self.app_configuration_version,
            'is_kaligo_travel_enable': self.is_kaligo_travel_enable,
            'kaligo_encrypted_string': self.kaligo_encrypted_string,
            'kaligo_sign_in_api_endpoint': self.kaligo_sign_in_api_endpoint,
            'home_sections': self.home_sections
        }
        if self.validation_params:
            data['validation_params'] = self.validation_params
        self.send_response_flag = True
        self.response = {
            'data': data,
            'success': True,
            'message': 'success'
        }
        self.status_code = codes.OK

    def process_request(self):
        self.populate_request_arguments()
        self.initialize_repose()
        self.parse_request_args()
        self.get_customer_from_session()
        self.get_users_points()
        self.show_aag_message()
        self.set_categories()
        self.is_user_hsbc_black_card_holder()
        self.add_ambassador_program_link()
        self.check_user_black_card_holder()
        self.set_featured_section()
        self.set_branding_attributes()
        self.set_main_cover_title()
        self.check_is_kaligo_travel_enabled()
        self.set_home_section()
        self.generate_final_response()
