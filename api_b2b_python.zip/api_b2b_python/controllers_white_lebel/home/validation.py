from common.common_helpers import get_request_parser
from common.custom_fields_request_parser import currency, language
from flask_restful.inputs import regex

home_wl_api_parser = get_request_parser()

home_wl_api_parser.add_argument(
    "wlcompany",
    required=True,
    location=['mobile', 'json', 'values'],
    type=str
)
home_wl_api_parser.add_argument(
    "user_id",
    required=False,
    location=['mobile', 'json', 'values'],
    type=int
)
home_wl_api_parser.add_argument(
    name="session_token",
    required=True,
    location=['mobile', 'json', 'values'],
    type=str
)
home_wl_api_parser.add_argument(
    name="__sid",
    required=False,
    type=int,
    location=['mobile', 'json', 'values']
)
home_wl_api_parser.add_argument(
    name="__platform",
    required=True,
    location=['mobile', 'json', 'values'],
    type=regex('[a-z]')
)
home_wl_api_parser.add_argument(
    name="location_id",
    required=False,
    type=int,
    location=['mobile', 'json', 'values']
)
home_wl_api_parser.add_argument(
    name="language",
    required=True,
    default="en",
    type=language,
    location=['mobile', 'json', 'values']
)
home_wl_api_parser.add_argument(
    name="app_version",
    required=True,
    type=regex('[0-9][0-9]*[.]*'),
    location=['mobile', 'json', 'values']
)
home_wl_api_parser.add_argument(
    name="currency",
    type=currency,
    default="USD",
    location=['mobile', 'json', 'values']
)
home_wl_api_parser.add_argument(
    name="build_no",
    required=True,
    type=int,
    location=['mobile', 'json', 'values']
)
