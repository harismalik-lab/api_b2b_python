"""
Validation arguments for redemption
"""
from web_api.redemption.validation import redemption_parser

redemption_parser_wl = redemption_parser

redemption_parser_wl.add_argument(
    'wl_company',
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
redemption_parser_wl.add_argument(
    'is_barcode_enabled',
    required=False,
    default=0,
    location=['mobile', 'values', 'json']
)
redemption_parser_wl.add_argument(
    'key',
    required=False,
    location=['mobile', 'values', 'json']
)
