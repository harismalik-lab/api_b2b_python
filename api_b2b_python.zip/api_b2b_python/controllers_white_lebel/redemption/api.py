"""
Redemption controller white label
"""
from common.common_helpers import CommonHelpers, get_current_date_time
from repositories.informatica_mobile_redemption_repo import InformaticaMobileRedemptionRepository
from repositories.v_592.offer_ent_active_repo_v592 import OfferEntActiveRepositoryV592
from user_authentication.authentication import get_current_customer
from web_api.api_v65.redemption.api import RedemptionProcessV65, RedemptionsSyncApiV65

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.common_helpers import WLCommonHelpers
from controllers_white_lebel.redemption.validation import redemption_parser_wl
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.offer_wl_active_repo import OfferRepositoryWl
from repositories_white_label.product_repo import ProductRepositoryWhiteLabel
from repositories_white_label.redemption_repo import RedemptionRepositoryWhiteLabel
from repositories_white_label.user_savings_repo import UserSavingsRepositoryWhiteLabel
from repositories_white_label.v_67.offer_wl_active_repo import OfferWlRepositoryV67
from repositories_white_label.v_67.outlet_repo import OutletRepositoryWhiteLabelV67
from repositories_white_label.wl_company_repo import WLCompany
from repositories_white_label.wl_gem_lookup_repo import WlGemLookUP


class RedemptionProcessV65WL(RedemptionProcessV65):
    """
    Implementation: Validate the existence of the offers, the user, the outlet, and whether the offers are
    redeemable by this user at this outlet. From the outlet, merchant information can be retrieved
    and the PIN can then be verified. If all is OK, create a new record in the redemption table and
    calculate the redemption_code.
    """
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='white_label_redemption_api/white_label_redemption_api.log',
        ),
        'name': 'white_label_redemption_api'
    }
    request_parser = redemption_parser_wl

    def populate_request_arguments(self):
        """
        Request arguments for redemption api white label
        """
        super().populate_request_arguments()
        self.company = self.request_args.get('wl_company')
        self.is_reattempt = self.request_args.get('is_reattempt')
        self.quantity = self.request_args.get('quantity')

    def initialize_class_attributes(self):
        """
        Initialize class attributes
        """
        super().initialize_class_attributes()
        self.message_locale = WLCommonHelpers.get_locale(self.locale, location_id=0)
        self.customer = get_current_customer()
        self.offer_wl_active_repo = OfferWlRepositoryV67()
        self.offer_ent_active_class_instance = OfferEntActiveRepositoryV592()
        self.outlet_repo = OutletRepositoryWhiteLabelV67()
        self.product_repo = ProductRepositoryWhiteLabel()
        self.user_savings_repo = UserSavingsRepositoryWhiteLabel()
        self.redemption_repo = RedemptionRepositoryWhiteLabel()
        self.offer_wl_active_repo = OfferRepositoryWl()
        self.customer_repo = CustomerProfileWhiteLabel()
        self.wl_gem_lookup_repo = WlGemLookUP()
        self.purchased_through_connect = False
        self.purchased_product_ids = []

    def verify_customer(self):
        """
        Sets current customer data
        """
        if not self.customer.get('customer_id'):
            self.message = self.quick_transaltion_repo.get_translation(
                self.quick_transaltion_repo.NOT_AUTHORIZE_TO_ACCESS_USER,
                self.message_locale
            )
            self.status_code = 422
            self.response = {
                "message": self.message,
                "httpResponse": self.status_code,
                "code": 50
            }
            return self.send_response(self.response, self.status_code)

    def verify_reattempt_code_and_transaction(self):
        """
        Verify reattempt code and transactions
        """
        if self.is_reattempt and self.transaction_id:
            reattempt_code = self.redemption_repo.get_code(
                self.transaction_id,
                self.customer.get('customer_id')
            )
            if reattempt_code:
                self.redemption_response = {'redemption_code': reattempt_code}
                self.message = self.quick_transaltion_repo.get_translation(
                    self.quick_transaltion_repo.SUCCESS,
                    self.message_locale
                )
                self.response = {
                    'data': {"referenceNo": self.redemption_response},
                    'message': self.message,
                    'success': True
                }
                self.status_code = 201
                return self.send_response(self.response, self.status_code)
        for purchased_product_id in self.purchased_product_ids:
            if purchased_product_id == self.product_id:
                self.purchased_through_connect = True

    def initialize_offers_data(self):
        """
        Get offer_instance from db and check if its exist at given outlet.
        """
        self.offer = self.offer_wl_active_repo.find_by_id(self.offer_id, self.product_id)

    def verify_offer_redeem_limit(self):
        """
        Verify offer redeem limit
        """
        if not self.is_app_tutorial:
            self.redeemed_offer_count_in_last_x_hours = \
                self.redemption_repo.get_redemptions_in_last_xhours_for_offer_for_customer(
                    self.customer['customer_id'],
                    self.offer_id,
                    self.offer['hours_to_consider_for_redemption_cap'],
                    self.company
                )
            if self.redeemed_offer_count_in_last_x_hours >= self.offer['redemptions_limit_in_x_hours']:
                self.send_response_flag = True
                monthly_limit_messages = self.quick_transaltion_repo.get_translation(
                    self.quick_transaltion_repo.MONTHLY_LIMIT_MESSAGE,
                    locale=self.message_locale
                )
                self.response = monthly_limit_messages
                self.response = self.response.format(
                    MONTHLY_LIMIT=self.offer['redemptions_limit_in_x_hours'],
                    MONTHLY_HOURS=self.offer['hours_to_consider_for_redemption_cap']
                )
                self.logger.info(self.response)

    def get_merchant_information(self):
        """
        Gets merchant information
        """
        merchant_info = self.merchant_class_instance.get_merchant_info(self.offer.get('merchant_id'))
        self.merchant_pin = merchant_info.get('pin') if merchant_info else ''
        self.merchant_sf_id = merchant_info.get('sf_id') if merchant_info else ''

    def verify_offer_redeemability(self):
        """
        Calculates offer redeemability
        """
        is_redeemable = self.offer_wl_active_repo.calculate_offer_redeemability_for_redemption_controller(
            company=self.company,
            customer=self.customer,
            offer_id=self.offer_id,
            offer_valid_from_date=self.offer.get('valid_from'),
            offer_expiration_date=self.offer.get('valid_to'),
            offer_type=self.offer.get('type'),
            offer_quantity=self.offer.get('quantity'),
            product_id=self.product_id
        )
        if not is_redeemable:
            self.send_response_flag = True
            self.status_code = 422
            self.response = {
                "message": self.quick_transaltion_repo.get_translation(
                    self.quick_transaltion_repo.NOT_ALLOWED,
                    locale=self.message_locale
                ),
                "success": False,
                "code": 422
            }
            return self.send_response(self.response, self.status_code)

    def get_outlet_information(self):
        """
        Provides outlet information against given outlet id
        """
        self.outlet_info = self.outlet_repo.get_outlet_info(self.outlet_id)
        self.root_code = self.redemption_repo.get_root_code(self.product_id, self.offer_id)
        self.savings_estimates = self.offer.get('savings_estimate')
        self.is_points_based_offer = False
        self.points = 0
        if (
            self.company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS and
            self.offer.get('is_point_based_offer')
        ):
            self.savings_estimates = 0
            self.is_points_based_offer = True
            self.points = self.offer.get('gems_points')

    def redemption_data(self):
        """
        Initialize redemption_data
        """
        self.redemption_instance = dict()
        self.redemption_instance['date_created'] = get_current_date_time()
        self.redemption_instance['customer_id'] = self.customer['customer_id']
        self.redemption_instance['offer_id'] = self.offer_id
        self.redemption_instance['outlet_id'] = self.outlet_id
        self.redemption_instance['quantity'] = 1
        self.redemption_instance['code'] = ''
        self.redemption_instance['session_token'] = self.session_token
        self.redemption_instance['savings_estimate'] = self.savings_estimates
        self.redemption_instance['transaction_id'] = self.transaction_id
        self.redemption_instance['product_id'] = self.product_id
        self.redemption_instance['company'] = self.company
        self.redemption_instance['root_code'] = self.root_code
        self.redemption_instance['device_os'] = self.platform
        self.redemption_instance['device_model'] = self.device_model
        self.redemption_instance['device_language'] = self.message_locale
        self.redemption_instance['purchased_through_connect'] = self.purchased_through_connect

        self.redemption_repo.insert_redemption_instance_data(data=self.redemption_instance)

    def set_redemption_code(self):
        """
        Sets redemption code.
        """
        code = self.redemption_repo.generate_redemption_code(
            self.redemption_instance.get('id'),
            self.redemption_type
        )
        self.redemption_instance['code'] = code
        self.coupon = ''

    def update_user_savings(self):
        """
        Update user savings
        """
        self.user_savings_repo.add_redemption_savings(
            self.customer_id,
            self.savings_estimates,
            self.company,
            0
        )

    def insert_informatica_table_entry(self):
        """
        Insert an db entry to informatica table for newly redemption.
        """
        self.informatica_data = {
            'id': self.redemption_instance.get('id'),
            'customer_id': self.redemption_instance['customer_id'],
            'session_token': self.session_token,
            'membership_code': self.customer.get('membership_code'),
            'quantity': self.redemption_instance['quantity'],
            'code': self.redemption_instance['code'],
            'date_created': self.redemption_instance['date_created'],
            'offer_sf_id': self.offer.get('sf_id'),
            'outlet_sf_id': self.outlet_info.get('sf_id'),
            'merchant_sf_id': self.merchant_instance['sf_id'],
            'root_code': self.redemption_instance['root_code'],
            'processed': False,
            'company': self.company
        }
        InformaticaMobileRedemptionRepository().insert_mobile_redemption(self.informatica_data)

    def check_customer_profile(self):
        """
        Check customer profile against given customer id
        """
        if self.is_points_based_offer:
            customer_profile = self.customer_repo.load_customer_profile_by_id(
                self.customer.get('customer_id')
            )
            if not customer_profile:
                email = customer_profile.get('email')
                # lookup_data = self.wl_gem_lookup_repo.find_one_by(
                #     {
                #         'email': email,
                #         'is_active': True
                #     }
                # )
                wl_gems_points = {
                    'user_id': self.redemption_instance.get('customer_id'),
                    # 'gems_persistent_id': lookup_data.get('gems_persistent_id'),
                    'email': email,
                    'gems_points': self.points,
                    'savings': 0,
                    'redemption_id': self.redemption_instance.get('id')
                }
                self.wl_gem_lookup_repo.insert_gems_points(data=wl_gems_points)

    def build_redemption_response(self):
        self.redemption_response = {
            'redemption_code': self.redemption_instance.get('code'),
            'is_redemption_already_made': False,
            'smiles_earned': 0,
            'redemption_id': self.redemption_instance.get('id')
        }
        self.set_response({
            'data': {
                "referenceNo": self.redemption_response
            },
            'message': 'success',
            'success': True,
            'code': 0
        })
        self.status_code = 200

    def process_request(self):
        """
        Redeem an offer for a user.
        """
        if self.offers_provided():
            self.offer_id = self.offers[0]
            self.initialize_class_attributes()
            self.verify_customer()
            self.verify_reattempt_code_and_transaction()
            self.initialize_offers_data()
            self.is_offer_exist()
            if self.is_send_response_flag_on():
                return

            self.verify_app_tutorial()
            self.verify_offer_redeem_limit()
            if self.is_send_response_flag_on():
                return

            self.get_merchant_information()
            self.set_merchant_ids()
            self.verify_merchant_pin()
            if self.is_send_response_flag_on():
                return

            self.verify_offer_redeemability()
            self.get_outlet_information()

            self.redemption_data()
            self.get_product_info()
            self.set_redemption_type()
            self.set_redemption_code()
            self.update_user_savings()
            self.insert_informatica_table_entry()
            self.check_customer_profile()
            self.build_redemption_response()
        else:
            self.send_response_flag = True
            self.status_code = 422
            self.response = {
                "message": self.message_class_instance.get_message_by_id(30, self.message_locale),
                "success": False,
                "code": 422
            }
            return self.send_response(self.response, self.status_code)


class RedemptionsSyncApiWL(RedemptionsSyncApiV65):
    """
    Redemption sync api white label
    """

    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='redemption_api/redemption_post_sync_api_wl.log',
        ),
        'name': 'offline_redemption_post_sync_api_wl'
    }

    def populate_request_arguments(self):
        """
        Request arguments for redemption sync api white label
        """
        super().populate_request_arguments()
        self.user_id = self.request_args.get('user_id')
        self.messages_locale = self.request_args.get('language', '')
        self.company = self.request_args.get('wlcompany')

    def initialize_repos(self):
        """
        Initialize repo's
        """
        super().initialize_repos()
        self.redemption_repo = RedemptionRepositoryWhiteLabel()
        self.user_savings_repo = UserSavingsRepositoryWhiteLabel()
        self.offer_wl_active_repo = OfferRepositoryWl()
        self.outlet_repo = OutletRepositoryWhiteLabelV67()

    def initialize_class_attributes(self):
        """
        Initialize class attributes
        """
        super().initialize_class_attributes()
        self.messages_locale = CommonHelpers.get_locale(self.messages_locale, location_id=0)
        self.purchased_through_connects = False
        self.purchased_product_ids = {}
        self.redemptions_to_sync = len(self.offers)

    def redemption_offers_log(self):
        """
        Gets redemption counter and offer logs
        """
        self.redemption_counter = -1
        self.offers_logs = {}

    def initialize_redemption_data(self):
        """
        Initialize redemption_data
        """
        self.redemption_instance = dict()
        self.redemption_instance['date_created'] = get_current_date_time()
        self.redemption_instance['customer_id'] = self.customer['customer_id']
        self.redemption_instance['offer_id'] = self.offer_entity_instance.get('id')
        self.redemption_instance['outlet_id'] = self.outlet_instance.get('id')
        self.redemption_instance['quantity'] = 1
        self.redemption_instance['code'] = self.redemption_code
        self.redemption_instance['session_token'] = self.session_token
        self.redemption_instance['savings_estimate'] = self.offer_entity_instance.get('savings_estimate', 0)
        self.redemption_instance['is_shared'] = self.is_shared_offer or False
        self.redemption_instance['transaction_id'] = self.transaction_id
        self.redemption_instance['product_id'] = self.product_id
        self.redemption_instance['company'] = self.company
        self.redemption_instance['root_code'] = self.root_code
        self.redemption_instance['device_os'] = self.platform
        self.redemption_instance['device_model'] = self.device_model
        self.redemption_instance['device_language'] = self.language
        self.redemption_instance['purchased_through_connect'] = self.purchased_through_connect

        self.redemption_repo.insert_redemption_instance_data(data=self.redemption_instance)

    def setting_shared_offer_values(self):
        """
        Shared offered values status
        """
        self.shared_offer_status = list(map(int, self.shared_offer_status))

    def setting_offer_outlets(self):
        offers_ids_list = self.offers
        offer_with_outlets = self.offer_wl_active_repo.get_outlet_ids_for_offer(offers_ids_list)
        for offer_outlet in offer_with_outlets:
            self.offer_with_outlet_arr[str(offer_outlet['offer_ids'])] = offer_outlet['outlet_ids']

    def setting_data_for_redemption(self, offer_id, outlet_id):
        """
        Sets data for redemption
        :param: offer_id
        :param: outlet_id
        """
        self.redemption_date = get_current_date_time()
        self.initialize_redemption_data()
        self.redemption = self.redemption_class_instance.insert_redemption(redemption_data=self.redemption_instance)
        self.redemptions_synced += 1
        self.redemption_savings_instance.add_redemption_savings(
            self.customer_id,
            self.offer_entity_instance.get('savings_estimate'),
            self.company
        )
        self.is_app_tutorial = self.merchants_repo_instance.is_app_tutorial(outlet_id)

    def setting_offer_ids_and_logs(self):
        """
        Setting offer ids and logs
        """
        for redemption_counter, offer_id in enumerate(self.offers):
            merchant_id = self.merchants[redemption_counter]
            outlet_id = self.outlets[redemption_counter]
            self.redemption_code = self.redemption_codes[redemption_counter]
            lng = self.longitudes[redemption_counter]
            lat = self.latitudes[redemption_counter]
            self.is_shared_offer = self.shared_offer_status[redemption_counter]
            self.transaction_id = self.transaction_ids[redemption_counter]
            self.product_id = self.product_ids[redemption_counter]
            self.purchased_through_connect = False

            for purchased_product_id in self.purchased_product_ids:
                if purchased_product_id == self.product_id:
                    self.purchased_through_connect = True

            if self.offer_with_outlet_arr.get(offer_id, False):
                offer_outlets = self.offer_with_outlet_arr[offer_id].split(',')
                if outlet_id not in offer_outlets:
                    outlet_id = offer_outlets[0]
                    self.number_of_redemptions_having_wrong_outlet += 1

                if self.transaction_id:
                    self.reattempt_code = self.redemption_repo.get_code_for_offline_redemption(
                        self.transaction_id,
                        self.redemption_code
                    )
                    if self.reattempt_code or self.redemption_code in self.reattempt_codes_already_synced:
                        self.redemptions_already_synced += 1
                    else:
                        # Find Outlet Entity for persistence
                        self.root_code = self.redemption_repo.get_root_code(self.product_id, offer_id)
                        self.offer_entity_instance = self.offer_wl_active_repo.find_by_id(offer_id, self.product_id)
                        merchant_entity = self.merchants_repo_instance.get_merchant_info(merchant_id)
                        self.outlet_instance = self.outlet_repo.get_outlet_info(outlet_id)

                        # Redeem Offer
                        self.setting_data_for_redemption(offer_id, outlet_id)
                        self.setting_offer_logs_array(offer_id, outlet_id, lat, lng, merchant_entity)
            else:
                self.number_of_redemptions_having_no_outlet += 1

    def process_request(self):
        """
        Redeem an offer for a user.
        """
        self.initialize_class_attributes()
        self.initialize_repos()
        self.redemption_offers_log()
        self.validate_sync_redemption()
        if self.is_send_response_flag_on():
            return

        self.sync_offline_redemption()
        self.setting_shared_offer_values()
        self.validate_user()
        if self.is_send_response_flag_on():
            return

        self.setting_offer_outlets()
        self.setting_reattempt_code_existance()
        self.setting_offer_ids_and_logs()
        self.setting_logs_and_details()
        self.generate_final_response()
