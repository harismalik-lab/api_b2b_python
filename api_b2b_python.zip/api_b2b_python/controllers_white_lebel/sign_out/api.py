from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from web_api.sign_out.api import LogoutUserApi


class WlLogoutUserApi(LogoutUserApi):

    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='white_label_logout_api/white_label_logout_api.log',
        ),
        'name': 'white_label_logout_api'
    }
