"""
Customer session refresh api.
"""
from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.translations_repo import TranslationManager
from user_authentication_white_label.authentication import get_company
from white_labels_api.v1.user_session_refresh_api.validation import user_session_refresh_parser


class WlUserSessionRefreshApi(BaseGetResource):
    """
    @api {get} /v1/user/session/refresh refresh user session
    @apiSampleRequest /v1/user/session/refresh
    @apiVersion 1.0.0
    @apiName UserSessionRefresh
    @apiGroup Users
    @apiParam {Integer}         user_id            Current User Id
    """
    request_parser = user_session_refresh_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='user_session_refresh_api/user_session_refresh_api.log',
        ),
        'name': 'user_session_refresh_api'
    }
    strict_token = True
    required_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.user_id = self.request_args.get('customer_id')

    def initilize_local_variables(self):
        """
        Sets local variables
        """
        self.company = get_company()

    def initialize_repos(self):
        """
        Initializes repositories
        """
        self.customer_repo = CustomerProfileWhiteLabel()
        self.translation_repo = TranslationManager()

    def refresh_session(self):
        """
        Refreshes user session
        """
        self.customer_repo.refresh_customer_sessions(customer_id=self.user_id, company=self.company)

    def prepare_response(self):
        """
        Sets final response of user language api
        :rtype: dict
        """
        self.send_response_flag = True
        self.response = {
            'success': True,
            'message': self.translation_repo.get_translation(
                self.translation_repo.success,
                'en'
            ),
            'data': []
        }
        self.status_code = 200
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of user language api
        """
        self.initilize_local_variables()
        self.initialize_repos()
        self.refresh_session()
        self.prepare_response()
