from common_white_label.common_helpers import get_request_parser

user_session_refresh_parser = get_request_parser()

user_session_refresh_parser.add_argument(
    'customer_id',
    type=int,
    required=False,
    location=['mobile', 'values', 'json']
)
user_session_refresh_parser.add_argument(
    'session_token',
    type=str,
    required=False,
    location=['mobile', 'values', 'json']
)
