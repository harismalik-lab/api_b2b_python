"""
Validation for user post profile api
"""
from flask_restful.inputs import regex

from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import device_list, language

post_user_profile_in_parser = get_request_parser()

post_user_profile_in_parser.add_argument(
    '__platform',
    type=device_list,
    required=True,
    location=['mobile', 'values', 'json']
)
post_user_profile_in_parser.add_argument(
    'app_version',
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
post_user_profile_in_parser.add_argument(
    'language',
    type=language,
    required=False,
    location=['mobile', 'values', 'json'],
    default='en'
)
post_user_profile_in_parser.add_argument(
    'location_id',
    type=str,
    required=False,
    location=['mobile', 'values', 'json'],
    default='0'
)
post_user_profile_in_parser.add_argument(
    'user_id',
    type=int,
    required=False,
    location=['mobile', 'values', 'json']
)
post_user_profile_in_parser.add_argument(
    'country',
    type=str,
    required=False,
    location=['mobile', 'values', 'json'],
    default=""
)
post_user_profile_in_parser.add_argument(
    'about_me',
    type=str,
    required=False,
    location=['mobile', 'values', 'json'],
    default=""
)
post_user_profile_in_parser.add_argument(
    'profile_image',
    type=str,
    required=False,
    location=['mobile', 'values', 'json'],
    default=""
)
post_user_profile_in_parser.add_argument(
    'session_token',
    type=regex('[0-9a-zA-Z]*[-]*'),
    location=['mobile', 'values', 'json'],
    required=False
)
