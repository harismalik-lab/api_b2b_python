"""
Update User Profile API
"""
import datetime

from flask import request

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BasePostResource
from common_white_label.common_helpers import AwsS3Manager, CommonHelpers
from common_white_label.db import CONSOLIDATION, DEFAULT
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from user_authentication_white_label.authentication import get_company, get_current_customer
from white_labels_api.v1.user_profile_post_api.validation import post_user_profile_in_parser


class PostUserProfileApi(BasePostResource):
    """
    @api {post} /v1/user/profile Update User Profile
    @apiSampleRequest /v1/user/profile
    @apiVersion 1.0.0
    @apiName PostUserProfile
    @apiGroup User
    @apiParam {String="ios","android","web"}        __platform          All supported platform
    @apiParam {String}                              app_version         Mobile App Version
    @apiParam {Integer}                             user_id             User id
    @apiParam {Integer}                             location_id         Id of location to filter outlets by
    @apiParam {String}                              [country]           Country name
    @apiParam {String}                              [about_me]          About me
    @apiParam {String}                              [profile_image]     Profile image location
    @apiParam {String="en", "ar", "cn", "el","zh"}  [language]          Response Language
    """

    strict_token = True
    required_token = True
    backup_request_args_for_exception = False
    request_parser = post_user_profile_in_parser
    response = {}
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='post_user_profile_api/post_user_profile_api.log',
        ),
        'name': 'post_user_profile_api'
    }
    logger = None
    status_code = 200
    connections_names = [DEFAULT, CONSOLIDATION]

    def populate_request_arguments(self):
        """
        Setting the arguments
        """
        # self.user_id = self.request_args.get('user_id','')
        self.locale = self.request_args.get('language')
        self.country = self.request_args.get('country')
        self.about_me = self.request_args.get('about_me')

    def initialize_repos(self):
        """
        Initializing the repos
        """
        self.customer_repo_instance = CustomerProfileWhiteLabel(logger=self.logger)

    def initialize_attributes(self):
        self.locale = CommonHelpers.get_locale(self.locale, 0)
        self.profile_image_name = ""
        self.customer = get_current_customer()
        self.customer_id = self.customer.get('customer_id')
        self.wlcompany = get_company()

    def set_profile_image_name(self):
        if hasattr(request, 'files') and request.files.get('profile_image'):
            response_message = self.customer_repo_instance.upload_profile_image(
                request.files.get('profile_image'),
                self.customer_id
            )
            if response_message.get("code", 0) == AwsS3Manager.RESPONSE_CODE_BAD_REQUEST:
                self.send_response_flag = True
                self.status_code = 400
                self.response = {
                    "message": response_message.get("message", ''),
                    "data": {'status': False},
                    "success": False,
                    "code": 400
                }
                return self.send_response(self.response, self.status_code)
            self.profile_image_name = response_message.get("url", '')

    def update_profile_status(self):
        self.profile_update_status = self.customer_repo_instance.save_user_profile(
            self.customer_id,
            self.about_me,
            self.profile_image_name,
            country=self.country
        )

    def generate_response(self):
        if not self.profile_update_status:
            self.send_response_flag = True
            self.status_code = 420
            self.response = {
                "message": "Profile not updated",
                "data": {'status': self.profile_update_status},
                "success": False,
                "code": 420
            }
            return self.send_response(self.response, self.status_code)
        else:
            user_profile = self.customer_repo_instance.get_user_profile_by_user_id(
                user_id=self.customer_id,
                company=self.wlcompany
            )
            if isinstance(user_profile.get('user_creation_date'), datetime.datetime):
                user_profile['user_creation_date'] = str(user_profile.get('user_creation_date'))
            self.send_response_flag = True
            self.status_code = 200
            self.response = {
                "message": "success",
                "data": user_profile,
                "success": True,
                "code": 200
            }
            return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Process the request
        :return: Response
        """
        if self.is_send_response_flag_on():
            return

        self.initialize_attributes()
        self.initialize_repos()
        self.set_profile_image_name()
        if self.is_send_response_flag_on():
            return

        self.update_profile_status()
        self.generate_response()
