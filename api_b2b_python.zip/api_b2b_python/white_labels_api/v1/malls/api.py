"""
Malls screen api white labels
"""
from requests import codes

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from common_white_label.common_helpers import CommonHelpers
from repositories_white_label.outlet_repo import OutletRepositoryWl
from user_authentication_white_label.authentication import get_company
from white_labels_api.v1.malls.validation import malls_api_parser


class MallsApi(BaseGetResource):
    """
    @api {get} /v1/malls
    @apiSampleRequest /v1/malls
    @apiVersion 1.0.0
    @apiName Malls
    @apiGroup Malls
    @apiParam {String}                                      app_version      Mobile App Version.
    @apiParam {String="android", "ios", "web"}              __platform       Mobile Platform.
    @apiParam {String='de', 'en', 'ar', 'cn', 'el', 'zh'}   [language]       Response Language.
    @apiParam {Integer}                                     [location_id]    User Location Id.
    """
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='malls_api/malls_api.log',
        ),
        'name': 'malls_api'
    }
    logger = None
    request_parser = malls_api_parser
    required_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.location_id = self.request_args.get('location_id')
        self.locale = self.request_args.get('locale')
        self.category = self.request_args.get('category')

    def setting_variables(self):
        """
        Sets variables for api
        """
        self.locale = CommonHelpers.get_locale(self.locale, location_id=self.location_id)
        self.company = get_company()

    def get_malls(self):
        """
        Gets categories
        """
        self.malls = OutletRepositoryWl.get_outlet_attribute_values(
            company=self.company,
            attribute='mall',
            location_id=self.location_id,
            locale=self.locale,
            category=self.category
        )

    def generate_final_response(self):
        """
        Generates final response
        """
        data = {
            'malls': self.malls
        }
        self.send_response_flag = True
        self.response = {
            'data': data,
            'success': True,
            'message': 'success'
        }
        self.status_code = codes.OK

    def process_request(self):
        self.setting_variables()
        self.get_malls()
        self.generate_final_response()
