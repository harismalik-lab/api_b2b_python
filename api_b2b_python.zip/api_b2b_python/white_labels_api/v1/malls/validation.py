"""
Validation params of malls api
"""
from flask_restful.inputs import regex

from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import device_list, language

malls_api_parser = get_request_parser()

malls_api_parser.add_argument(
    name="__platform",
    type=device_list,
    required=True,
    location=['mobile', 'json', 'values']
)
malls_api_parser.add_argument(
    name="location_id",
    required=False,
    type=int,
    location=['mobile', 'json', 'values']
)
malls_api_parser.add_argument(
    name="language",
    required=True,
    default="en",
    type=language,
    location=['mobile', 'json', 'values']
)
malls_api_parser.add_argument(
    name="app_version",
    required=True,
    type=regex('[0-9][0-9]*[.]*'),
    location=['mobile', 'json', 'values']
)
malls_api_parser.add_argument(
    name="build_no",
    required=True,
    type=str,
    location=['mobile', 'json', 'values']
)
malls_api_parser.add_argument(
    'category',
    type=str,
    required=False,
    default='',
    location=['mobile', 'values', 'json']
)
