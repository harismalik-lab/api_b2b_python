"""
Reset Password API
"""
# pylint: disable=import-error
# pylint: disable=unused-import
from flask import current_app
from phpserialize import dumps as php_json_dumps
# pylint: disable=fixme
# pylint: disable=attribute-defined-outside-init
from validate_email import validate_email

from app_configurations_white_label.settings import ONLINE_LOG_PATH
from common_white_label import translations_constants
from common_white_label.base_resource import BasePostResource
from common_white_label.common_helpers import CommonHelpers
from common_white_label.db import CONSOLIDATION, DEFAULT
from common_white_label.security import Security
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.send_email_repo import SendEmailsRepository
from repositories_white_label.wl_company_repo import WLCompany
from repositories_white_label.wl_templates_repo import WLTemplatesRepository
from repositories_white_label.wl_validtion_repo import WlValidationRepository
from user_authentication_white_label.authentication import get_company
from white_labels_api.v1.passwords_api.validation import user_password_reset_in_parser


class UserPasswordResetApi(BasePostResource):
    """
    @api {post} /v1/passwords Forgot Password
    @apiSampleRequest /v1/passwords
    @apiVersion 1.0.0
    @apiName UserPasswordResetApi
    @apiGroup Users
    @apiParam {String}                                         email           Email of user
    @apiParam {String='de', 'en', 'ar', 'cn', 'el', 'zh'}      [language]      Response language
    """
    backup_request_args_for_exception = False
    request_parser = user_password_reset_in_parser
    response = {}
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ONLINE_LOG_PATH,
            file_path='password_reset_api/password_reset_api.log',
        ),
        'name': 'password_reset_api'
    }
    logger = None
    status_code = 200
    connections_names = [DEFAULT, CONSOLIDATION]

    def populate_request_arguments(self):
        """
        Setting the arguments
        """
        self.email = self.request_args.get('email')
        self.locale = self.request_args.get('language')

    def initialize_local_veriables(self):
        """
        Sets variables for api
        """
        self.company = get_company()

    def initialize_repos(self):
        """
        Initializing the repos
        """
        self.customer_repo_instance = CustomerProfileWhiteLabel(logger=self.logger)
        self.security_repo_instance = Security()
        self.wl_template_repo = WLTemplatesRepository()
        self.wl_validation_repo = WlValidationRepository()
        self.wl_company_repo = WLCompany()

    def check_email(self):
        if not self.email and self.email == "":
            self.generate_response_on_no_valid_customer()
        else:
            if not validate_email(self.email):
                self.status_code = 422
                self.send_response_flag = True
                self.response = {
                    "message": '{} is not a valid email'.format(self.email),
                    "data": {
                        "message": '{} is not a valid email'.format(self.email)
                    }
                }

    def initialize_attributes(self):
        self.locale = CommonHelpers.get_locale(self.locale, 0)

    def validate_customer(self):
        self.customer = self.customer_repo_instance.load_customer_by_email(self.email)

    def setting_language_and_message(self):
        self.message = "Password reset link sent to your email address."
        if self.locale == 'cn':
            self.message = translations_constants.LOCALE_CN_RESET_PASSWORD
        if self.locale == 'ar':
            self.message = translations_constants.LOCALE_AR_RESET_PASSWORD

    def generate_response(self):
        data = {
            'is_sent': True,
            'message': self.message
        }
        self.status_code = 201
        self.send_response_flag = True
        self.response = {
            "message": 'success',
            'data': data,
            "success": True
        }
        return self.send_response(self.response, self.status_code)

    def generate_response_on_no_valid_customer(self):
        code = 55
        self.status_code = 422
        self.send_response_flag = True
        self.response = {
            "message": 'Email address not found.',
            'code': code,
            "data": [],
            "success": False
        }
        return self.send_response(self.response, self.status_code)

    def sending_email_to_customer(self):
        if self.customer:
            password_reset_token = self.security_repo_instance.generate_random_string(length=20)
            self.customer_repo_instance.update_password_reset_token(
                self.customer['id'],
                password_reset_token
            )

            password_reset_url = current_app.config.get('PASSWORD_RESET_URL')
            is_lookup_based_company = self.wl_company_repo.is_lookup_based_company(self.company)
            if is_lookup_based_company:
                password_reset_url.replace('company', self.company)

            password_reset_url = '{password_reset_url}{password_reset_token}'.format(
                password_reset_url=password_reset_url,
                password_reset_token=password_reset_token
            )

            user_group = self.wl_validation_repo.get_user_group(self.company, self.customer.get('id'))
            email_template_id = self.wl_template_repo.get_template_by_company_and_type(
                self.company,
                self.wl_template_repo.FORGOT_PASSWORD,
                user_group
            )

            email_data = php_json_dumps({
                "user_id": self.customer['id'],
                "{PASSWORD_RESET_URL}": password_reset_url
            })
            self.customer_repo_instance.send_email(
                email_type_id=email_template_id,
                email_data=email_data.decode(errors='ignore'),
                email=self.email,
                language=self.locale,
                priority=SendEmailsRepository.Priority_High,
                dump=False,
                optional_data=None
            )
            self.setting_language_and_message()
            self.generate_response()
        else:
            self.generate_response_on_no_valid_customer()

    def process_request(self):
        """
        Process the request
        :return: Response
        """
        self.check_email()
        if self.is_send_response_flag_on():
            return

        self.initialize_repos()
        self.initialize_local_veriables()
        self.initialize_attributes()
        self.validate_customer()
        self.sending_email_to_customer()
