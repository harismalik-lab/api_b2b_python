"""
Passwords reset api request parser.
"""
from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import language, validate_email_string

user_password_reset_in_parser = get_request_parser()

user_password_reset_in_parser.add_argument(
    'language',
    required=False,
    default="en",
    type=language,
    location=['values', 'json', 'mobile']
)
user_password_reset_in_parser.add_argument(
    'email',
    type=validate_email_string,
    required=False,
    location=['values', 'json', 'mobile']
)
