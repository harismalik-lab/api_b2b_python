"""
Home screen api white labels
"""
import datetime
from requests import codes

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from common_white_label.common_helpers import CommonHelpers, multi_key_sort
from repositories_white_label.home_screen_configurations_repo import HomeScreenRepositoryWL
from repositories_white_label.outlet_repo import OutletRepositoryWl
from user_authentication_white_label.authentication import get_current_customer
from white_labels_api.v1.express_home_api.validation import express_home_api_parser


class ExpressHomeApi(BaseGetResource):
    """
    @api {get} /v1/home Get home screen
    @apiSampleRequest /v1/home
    @apiVersion 1.0.0
    @apiName UserGemsPointsSummaryApiWL
    @apiGroup Users
    @apiParam {String}                                      app_version      Mobile App Version.
    @apiParam {String="android", "ios", "web"}              __platform       Mobile Platform.
    @apiParam {String='de', 'en', 'ar', 'cn', 'el', 'zh'}   [language]       Response Language.
    @apiParam {Integer}                                     [location_id]    User Location Id.
    @apiParam {String="BHD", "EGP", "EUR", "GBP", "HKD", "JOD", "KWD", "LBP", "MYR", "OMR", "QAR", "SAR", "SGD", "USD", "ZAR", "AED"}    [currency]  Currency   # noqa:E501
    @apiParam {Float}                                     [__lat]    Latitude
    @apiParam {Float}                                     [__lng]   Longitude
    """
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='home_api/home_api.log',
        ),
        'name': 'home_api'
    }
    logger = None
    request_parser = express_home_api_parser
    required_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.location_id = self.request_args.get('location_id')
        self.currency = self.request_args.get('currency')
        self.app_version = self.request_args.get('app_version')
        self.locale = self.request_args.get('locale')
        self.platform = self.request_args.get('__platform')
        self.build_no = self.request_args.get('build_no')
        self.latitude = self.request_args.get('__lat')
        self.longitude = self.request_args.get('__lng')
        self.session_token = ''
        self.user_id = 0
        self.is_user_logged_in = False

    def initialize_local_variables(self):
        """
        Sets variables for home api
        """
        self.customer = get_current_customer()
        self.home_sections = []
        self.outlet_offers_redeemable_array = []

    def initialize_repose(self):
        """
        Initializes the different repos
        """
        self.home_screen_config_repo = HomeScreenRepositoryWL()
        self.outlet_repo = OutletRepositoryWl()

    def parse_request_args(self):
        """
        Parses request args
        """
        self.customer = get_current_customer()
        if self.customer:
            self.is_user_logged_in = True
            self.user_id = self.customer.get('customer_id')
            self.session_token = self.customer.get('session_token')
        self.locale = CommonHelpers.get_locale_for_messaging(self.locale)

    def get_offers_and_outlets_deals_section(self):
        """
        Get offers and outlets for deals section
        :return:
        """
        self.outlets, self.hashed_outlets = self.outlet_repo.get_outlet_array(self.location_id)
        self.offers = self.outlet_repo.get_offer_array(self.location_id,
                                                       section=self.home_screen_config_repo.DEALS_SECTION)

    def get_offers_nearby_section(self):
        """
        Get offers for nearby section
        """
        self.outlet_offers_redeemable_array = []
        self.offers = self.outlet_repo.get_offer_array(self.location_id)

    def process_offers_and_outlets(self):
        """
        Process offers and outlets
        """
        self.is_location_enabled = True
        self.outlet_offer_info = {}
        self.flag_details = {}
        for offer in self.offers:
            self.set_redeemability(offer)
            if isinstance(offer.get('outlet_ids'), list):
                outlet_ids = offer['outlet_ids']
            elif isinstance(offer.get('outlet_ids'), str):
                outlet_ids = list(set(map(int, filter(None, offer.get('outlet_ids').split(',')))))
            else:
                outlet_ids = []
            for outlet_id in outlet_ids:
                if self.hashed_outlets.get(outlet_id):
                    if not self.outlet_offer_info.get(outlet_id):
                        self.outlet_offer_info[outlet_id] = self.hashed_outlets[outlet_id]
                        changes = self.get_outlet_offer_info_changes(offer)
                        self.outlet_offer_info[outlet_id].update(changes)
                        if self.latitude and self.longitude:
                            self.outlet_offer_info[outlet_id]['distance'] = CommonHelpers.calculate_distance(
                                float(self.latitude),
                                float(self.longitude),
                                self.outlet_offer_info[outlet_id]['lat'] or 0.0,
                                self.outlet_offer_info[outlet_id]['lng'] or 0.0
                            )
                        else:
                            self.is_location_enabled = False
                    else:
                        self.update_outlet_offer_info(offer, outlet_id)
                    if self.outlet_offer_info[outlet_id]['is_redeemable']:
                        self.outlet_offers_redeemable_array.append(self.outlet_offer_info[outlet_id])

    def set_redeemability(self, offer):
        """
        Set redeemability of offer
        :param offer: offer
        """
        redeemability = self.calculate_offer_redeemability_for_offer(offer)
        offer['is_redeemable'] = redeemability.get('is_redeemable', 0)
        offer['redeemability'] = redeemability['redeemability']

    def calculate_offer_redeemability_for_offer(self, offer):
        """
        Calculate offer redeemability for offer
        :param offer: offer
        """
        redeemability_value = self.home_screen_config_repo.NOT_REDEEMABLE
        is_within_validity_period = False
        if isinstance(offer['valid_from_date'], str):
            now = datetime.datetime.now().strftime('%Y-%m-%dT%H:%M:%S')
        else:
            now = datetime.datetime.now()

        if offer['valid_from_date'] > now:
            return {
                'redeemability': redeemability_value
            }

        if offer['valid_from_date'] <= now and offer['expiration_date'] >= now:
            is_within_validity_period = True

        if is_within_validity_period:
            if offer['type'] in [self.home_screen_config_repo.TYPE_DEFAULT, self.home_screen_config_repo.TYPE_NEW_OFFER]:
                redeemability_value = self.home_screen_config_repo.REDEEMABLE
        else:
            redeemability_value = self.home_screen_config_repo.NOT_REDEEMABLE
        if redeemability_value == self.home_screen_config_repo.REDEEMABLE:
            return {
                'is_redeemable': 1,
                'redeemability': redeemability_value
            }
        else:
            return {
                'is_redeemable': 0,
                'redeemability': redeemability_value
            }

    def get_outlet_offer_info_changes(self, offer):
        """
        Changes outlet offer info
        :param offer: offer
        :return: dict
        """
        return {
            'offer_ids': [offer['id']],
            'offer_title': offer['title'],
            'offer_validity': str(offer['valid_to']),
            'is_redeemable': bool(offer['is_redeemable']),
            'redeemability': offer.get('redeemability', 0),
        }

    def update_outlet_offer_info(self, offer, outlet_id):
        """
        Update outlet offer info
        :param offer: offer
        :param outlet_id: offer id
        """
        if not offer['id'] in self.outlet_offer_info[outlet_id]['offer_ids']:
            self.outlet_offer_info[outlet_id]['offer_ids'].append(offer['id'])
        if offer.get('is_redeemable'):
            self.outlet_offer_info[outlet_id]['is_redeemable'] = True
        if offer.get('redeemability', 0) > self.outlet_offer_info[outlet_id]['redeemability']:
            self.outlet_offer_info[outlet_id]['redeemability'] = offer['redeemability']

    def set_nearby_outlets(self):
        """
        set nearby outlets
        """
        self.nearby_outlets = []
        nearby_outlet_data = {}
        final_outlets = []

        if self.outlet_offers_redeemable_array:
            if self.is_location_enabled:
                final_outlets = multi_key_sort(
                    self.outlet_offers_redeemable_array,
                    ['distance']
                )
            else:
                final_outlets = multi_key_sort(
                    self.outlet_offers_redeemable_array,
                    ['merchant_name']
                )
        if final_outlets:
            if len(final_outlets) > self.home_screen_config_repo.OUTLETS_LIMIT:
                final_outlets_count = self.home_screen_config_repo.OUTLETS_LIMIT
            else:
                final_outlets_count = len(final_outlets)
            for outlet in final_outlets[:final_outlets_count]:
                nearby_outlet_data['image_url'] = outlet['merchant']['photo_url']
                nearby_outlet_data['merchant_logo'] = outlet['merchant']['logo_url']
                nearby_outlet_data['merchant_title'] = outlet['merchant']['name']
                nearby_outlet_data['merchant_address'] = outlet['merchant_address']
                nearby_outlet_data['distance'] = outlet['distance']
                nearby_outlet_data['offer_title'] = outlet['offer_title']
                nearby_outlet_data['offer_validity'] = outlet['offer_validity']
                nearby_outlet_data['api_params'] = {
                    'merchant_id': outlet['merchant']['id'],
                    'outlet_id': outlet['id'],
                    'type': ''
                }
                self.nearby_outlets.append(nearby_outlet_data)
                nearby_outlet_data = {}

    def nearby_section_response(self):
        """
        Generate nearby section response
        """
        nearby_outlets_section = {
            'section_identifier': self.home_screen_config_repo.NEARBY_SECTION_IDENTIFIER,
            'section_title': self.home_screen_config_repo.NEARBY_SECTION_NAME,
            'button_text': self.home_screen_config_repo.SEE_ALL_BUTTON_TEXT,
            'button_text_color': self.home_screen_config_repo.SEE_ALL_BUTTON_TEXT_COLOR,
            'button_background_color': '',
            'api_params': {
                'type': self.home_screen_config_repo.NEARBY_SECTION_NAME.lower()
            },
            'section_list': self.nearby_outlets
        }
        self.home_sections.append(nearby_outlets_section)

    def deals_section_response(self):
        """
        Generate deals section response
        """
        nearby_outlets_section = {
            'section_identifier': self.home_screen_config_repo.DEALS_SECTION_IDENTIFIER,
            'section_title': self.home_screen_config_repo.DEALS_SECTION_NAME,
            'button_text': self.home_screen_config_repo.SEE_ALL_BUTTON_TEXT,
            'button_text_color': self.home_screen_config_repo.SEE_ALL_BUTTON_TEXT_COLOR,
            'button_background_color': '',
            'api_params': {
                'type': self.home_screen_config_repo.DEALS_SECTION_NAME.lower()
            },
            'section_list': self.nearby_outlets
        }
        self.home_sections.append(nearby_outlets_section)

    def generate_final_response(self):
        """
        Generate final response
        """
        data = {
            'home_sections': self.home_sections
        }
        self.send_response_flag = True
        self.response = {
            'data': data,
            'success': True,
            'message': 'success'
        }
        self.status_code = codes.OK

    def process_request(self):
        self.initialize_local_variables()
        self.initialize_repose()
        self.parse_request_args()
        self.get_offers_and_outlets_deals_section()
        self.process_offers_and_outlets()
        self.set_nearby_outlets()
        self.deals_section_response()
        self.get_offers_nearby_section()
        self.process_offers_and_outlets()
        self.set_nearby_outlets()
        self.nearby_section_response()
        self.generate_final_response()
