"""
Validation params of home api
"""
from flask_restful.inputs import regex

from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import currency, device_list, language

express_home_api_parser = get_request_parser()

express_home_api_parser.add_argument(
    name="__platform",
    type=device_list,
    required=True,
    location=['mobile', 'json', 'values']
)
express_home_api_parser.add_argument(
    name="location_id",
    required=False,
    type=int,
    location=['mobile', 'json', 'values']
)
express_home_api_parser.add_argument(
    name="language",
    required=True,
    default="en",
    type=language,
    location=['mobile', 'json', 'values']
)
express_home_api_parser.add_argument(
    name="app_version",
    required=True,
    type=regex('[0-9][0-9]*[.]*'),
    location=['mobile', 'json', 'values']
)
express_home_api_parser.add_argument(
    name="currency",
    type=currency,
    default="USD",
    location=['mobile', 'json', 'values']
)
express_home_api_parser.add_argument(
    name="build_no",
    required=True,
    type=str,
    location=['mobile', 'json', 'values']
)
express_home_api_parser.add_argument(
    name="__lat",
    required=False,
    type=float,
    location=['mobile', 'json', 'values']
)
express_home_api_parser.add_argument(
    name="__lng",
    required=False,
    type=float,
    location=['mobile', 'json', 'values']
)
