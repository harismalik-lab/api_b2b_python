"""
Feed App Boy APi
"""
import datetime

from requests import codes

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BasePostResource
from repositories_white_label.feed_repo import FeedRepository
from user_authentication_white_label.authentication import get_company
from white_labels_api.v1.feed_app_boy_api.validation import feed_appboy_parser


class FeedAppBoyApi(BasePostResource):
    """
    @api {post} /v1/feed/appboy Post Feed Appboy Api
    @apiSampleRequest /v1/feed/appboy
    @apiVersion 1.0.0
    @apiName FeedAppBoyApi
    @apiGroup Configurations
    @apiParam {Integer}                               user_id            User ID
    @apiParam {String="ios, android", "web"}          [__platform]       Mobile Platform
    """
    request_parser = feed_appboy_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='feed_app_boy_api/feed_app_boy_api.log',
        ),
        'name': 'feed_app_boy_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.platform = self.request_args.get('__platform')
        self.user_id = self.request_args.get('user_id')

    def initialize_local_variables(self):
        """
        Sets variables for emax card number api
        """
        self.company = get_company()

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.repo_feed = FeedRepository()

    def process_request(self):
        """
        This method processes the request
        :return: response containing a boolean flag 'is_fed_successfully'
        """
        self.initialize_repos()
        created_at = datetime.datetime.now()
        feed_boy_post_data = {
            'company': self.company,
            'user_id': self.user_id,
            'platform': self.platform,
            'created_at': created_at
        }
        post_response = self.repo_feed.add_appboy_feed(data=feed_boy_post_data)
        response_data = {
            'is_fed_successfully': post_response
        }

        self.send_response_flag = True
        self.response = {
            'data': response_data,
            'success': True,
            'message': 'success',
            'code': '200'
        }
        self.status_code = codes.OK
