"""
Location Categories screen api white labels
"""
from requests import codes

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from common_white_label.common_helpers import CommonHelpers
from repositories_white_label.home_screen_configurations_repo import HomeScreenRepositoryWL
from user_authentication_white_label.authentication import get_company, get_current_customer
from white_labels_api.v1.location_categories.validation import location_categories_api_parser


class LocationCategoriesApi(BaseGetResource):
    """
    @api {get} /v1/location categories
    @apiSampleRequest /v1/location/categories
    @apiVersion 1.0.0
    @apiName LocationCategories
    @apiGroup LocationCategories
    @apiParam {String}                                      app_version      Mobile App Version.
    @apiParam {String="android", "ios", "web"}              __platform       Mobile Platform.
    @apiParam {String='de', 'en', 'ar', 'cn', 'el', 'zh'}   [language]       Response Language.
    @apiParam {Integer}                                     [location_id]    User Location Id.
    """
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='location_categories_api/location_categories_api.log',
        ),
        'name': 'location_categories_api'
    }
    logger = None
    request_parser = location_categories_api_parser
    required_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.location_id = self.request_args.get('location_id')
        self.app_version = self.request_args.get('app_version')
        self.locale = self.request_args.get('locale')

    def setting_variables(self):
        """
        Sets variables for api
        """
        customer = get_current_customer()
        self.user_id = customer.get('customer_id')
        self.locale = CommonHelpers.get_locale(self.locale, self.location_id)
        self.company = get_company()
        self.customer = get_current_customer()
        self.is_user_logged_in = self.customer.get('is_user_logged_in')
        self.user_id = self.customer.get('customer_id')

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.home_screen_config_repo = HomeScreenRepositoryWL()

    def get_categories(self):
        """
        Gets categories
        """
        self.categories = HomeScreenRepositoryWL.get_categories(
            is_user_logged_in=self.is_user_logged_in,
            company=self.company,
            user_id=self.user_id,
            location_id=self.location_id,
            locale=self.locale
        )

    def generate_final_response(self):
        """
        Generates final response
        """
        data = {
            'location_categories': self.categories
        }
        self.send_response_flag = True
        self.response = {
            'data': data,
            'success': True,
            'message': 'success'
        }
        self.status_code = codes.OK

    def process_request(self):
        self.setting_variables()
        self.get_categories()
        self.generate_final_response()
