"""
Country api white label
"""
from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from common_white_label.common_helpers import CommonHelpers
from repositories_white_label.country_repo import CountryRepository
from repositories_white_label.global_ads_repo import GlobalAdsRepositoryWl
from repositories_white_label.session_repo import SessionRepositoryWhiteLabel
from repositories_white_label.wl_product_repo import WLProductRepository
from repositories_white_label.wl_user_group_repo import WlUserGroup
from user_authentication_white_label.authentication import get_company, get_current_customer
from white_labels_api.v1.country.validation import country_parser


class CountryApiWl(BaseGetResource):
    """
    @api {get} /v1/country Get Country
    @apiSampleRequest /v1/country
    @apiVersion 1.0.0
    @apiName CountryApi
    @apiGroup Configurations
    @apiParam {Boolean}                                       [istravel]          Filter by travel
    @apiParam {String="en", "ar", "cn", "el", "de", "zh"}     [language]          Response language
    """
    request_parser = country_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='country_api/country_api.log',
        ),
        'name': 'country_api'
    }

    def populate_request_arguments(self):
        """
        Add request arguments of country api
        """
        self.locale = self.request_args.get('language')
        self.is_travel = self.request_args.get('istravel')
        # self.session_token = self.request_args.get('session_token')

    def setting_variables(self):
        """
        Sets variables for country api
        """
        self.locale = CommonHelpers.get_locale(self.locale)
        self.company = get_company()
        try:
            self.session_token = get_current_customer().get('session_token')
        except Exception:
            self.session_token = ''
        self.countries = []
        self.product_ids = []

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.country_repo = CountryRepository()
        self.global_ads_repo = GlobalAdsRepositoryWl()
        self.product_repo = WLProductRepository()
        self.session_repo = SessionRepositoryWhiteLabel()

    def get_countries(self):
        """
        Gets validation status of device
        """
        if self.is_travel:
            if self.session_token:
                session = self.session_repo.find_by_token(company=self.company, session_token=self.session_token)
                if session:
                    self.product_ids = session.get('product_ids')
                    self.product_ids = self.product_ids.split(',')
            if not self.product_ids:
                user_groups = [WlUserGroup.DEFAULT_USER_GROUP]
                self.product_ids = self.product_repo.get_configured_products(company=self.company, user_groups=user_groups)
            self.countries = self.country_repo.get_country_by_region(self.company, self.product_ids, self.locale)
        else:
            self.countries = CountryRepository.get_country(self.locale)
        self.global_travel_ads = []  # $global_ads_repo->getGlobalAds($company);

    def generate_final_response(self):
        """
        Sets final response of country api
        :rtype: dict
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': {
                'countries': self.countries,
                'global_travel_ads': self.global_travel_ads
            },
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.initialize_repos()
        self.setting_variables()
        self.get_countries()
        self.generate_final_response()
