"""
Validation params of country api
"""
from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import boolean, language

country_parser = get_request_parser()

country_parser.add_argument(
    name="session_token",
    type=str,
    required=False,
    location=['mobile', 'values', 'json']
)
country_parser.add_argument(
    name="istravel",
    default=False,
    type=boolean,
    required=False,
    location=['mobile', 'values', 'json']
)
country_parser.add_argument(
    name="language",
    type=language,
    default="en",
    required=False,
    location=['mobile', 'values', 'json']
)
