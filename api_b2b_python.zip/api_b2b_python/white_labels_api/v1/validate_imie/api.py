"""
Validate imie api white label
"""

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BasePostResource
from common_white_label.common_helpers import CommonHelpers
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.wl_company_repo import WLCompany
from repositories_white_label.wl_validtion_repo import WlValidationRepository
from user_authentication_white_label.authentication import get_company
from white_labels_api.v1.validate_imie.validation import validate_imie_parser


class ValidateImieApiWl(BasePostResource):
    """
    @api {post} /v1/validate/imie Post Validate IMIE Number
    @apiSampleRequest /v1/validate/imie
    @apiVersion 1.0.0
    @apiName ValidateImie
    @apiGroup Validate Key
    @apiParam {String}                                  key              White label key
    @apiParam {String="en", "ar", "cn", "el","zh"}      [language]       Response Language
    """
    request_parser = validate_imie_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='validate_imie_api/validate_imie_api.log',
        ),
        'name': 'validate_imie_api'
    }

    def populate_request_arguments(self):
        """
        Add request arguments of validate imie api
        """
        self.locale = self.request_args.get('language')
        self.key = self.request_args.get('key')

    def initialize_repos(self):
        """
        Initialize repos for validate imie api
        """
        self.wl_company = WLCompany()
        self.wl_validation_repo = WlValidationRepository()
        self.translation_manager = TranslationManager()

    def initialize_class_attributes(self):
        """
        Initialize class attributes of validate imie api
        """
        self.locale = CommonHelpers.get_locale(self.locale, location_id=0)
        self.is_key_validated = False
        self.company = get_company()

    def validate_key(self):
        """
        Key validation for validate imie api
        :rtype: dict
        """
        if not self.key:
            self.send_response_flag = True
            self.status_code = 422
            self.response = {
                'success': 'false',
                'message': self.translation_manager.get_translation(
                    self.translation_manager.key_required,
                    self.locale
                ),
                'code': 70,
                'data': []
            }
            return self.send_response(self.response, self.status_code)

    def valiade_key_status(self):
        """
        Validates the key status of validate imie api
        """
        validation_status = self.wl_validation_repo.validate_key_pre_activated(self.key, self.company)

        if validation_status == WlValidationRepository.VALID_KEY:
            self.is_key_validated = True

    def prepare_response(self):
        """
        Sets final response of validate imie api
        :rtype: dict
        """
        allowed_key_validation = False
        if self.company != self.wl_company.COMPANY_CODE_ENTERTAINER_MOTO:
            allowed_key_validation = True
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': {
                'validation_status': self.is_key_validated,
                'session_token': 'privileged',
                'allowed_key_validation': allowed_key_validation
            },
            'success': self.is_key_validated
        }
        if self.is_key_validated:
            self.response['message'] = ""
        else:
            self.response['message'] = self.translation_manager.get_translation(
                self.translation_manager.invalid_wl_key,
                self.locale
            )
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of validate imie api
        """
        self.initialize_repos()
        self.initialize_class_attributes()
        self.validate_key()
        if self.is_send_response_flag_on():
            return
        self.valiade_key_status()
        self.prepare_response()
