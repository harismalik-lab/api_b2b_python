"""
Validation for validate imie api
"""
from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import language

validate_imie_parser = get_request_parser()

validate_imie_parser.add_argument(
    'key',
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
validate_imie_parser.add_argument(
    'language',
    type=language,
    default='en',
    required=False,
    location=['mobile', 'values', 'json']
)
