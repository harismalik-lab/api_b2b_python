"""
User Savings api white label
"""
import datetime

from requests import codes

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from common_white_label.common_helpers import CommonHelpers
# from common_white_label.constants import GlobalConstants
from repositories_white_label.exchange_rates_repo import ExchangeRatesRepositoryWL
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.user_savings_repo import UserSavingsRepositoryWhiteLabel
from user_authentication_white_label.authentication import get_company, get_current_customer
from white_labels_api.v1.user_savings_api.validation import user_savings_parser


class UserSavingsApi(BaseGetResource):
    """
    @api {get} /v1/user/savings Get User Savings
    @apiSampleRequest /v1/user/savings
    @apiVersion 1.0.0
    @apiName UserSavings
    @apiGroup Users
    @apiParam {String}                              app_version        Mobile App Version
    @apiParam {String="ios","android","web"}        __platform         All supported platform
    @apiParam {String="en", "ar", "cn", "el","zh"}  [language]         Response Language
    """
    request_parser = user_savings_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='user_savings_api/user_savings_api.log',
        ),
        'name': 'user_savings_api'
    }
    required_token = True
    strict_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')
        self.currency = self.request_args.get('currency')

    def initialize_class_attributes(self, *args, **kwargs):
        """
        Sets variables for api
        """
        current_date = datetime.datetime.now()
        self.current_year = current_date.year
        self.start_date = current_date.replace(month=1, day=1).strftime("%Y-%m-%d")
        self.end_date = current_date.replace(month=12, day=31).strftime("%Y-%m-%d")
        self.messages_locale = CommonHelpers.get_locale(self.locale)
        self.customer = get_current_customer()
        self.user_id = self.customer.get('customer_id')
        self.company = get_company()

    def initialize_repos(self):
        """
        Initializes repositories
        """
        self.exchange_rates_repo = ExchangeRatesRepositoryWL()
        self.translation_repo = TranslationManager()
        self.user_savings_repo = UserSavingsRepositoryWhiteLabel()

    def get_user_savings(self):
        # if self.customer.get(GlobalConstants.CUSTOMER_ID, 0) != self.user_id:
        if not self.user_id:
            self.send_response_flag = True
            self.status_code = codes.FORBIDDEN
            self.response = {
                'data': [],
                'message': self.translation_repo.get_translation(
                    self.translation_repo.you_are_not_allowed_to_access_this_application,
                    self.messages_locale
                ),
                'success': False
            }
            return self.send_response(self.response, self.status_code)
        savings = self.user_savings_repo.get_user_savings(self.user_id, self.company)
        self.savings = ExchangeRatesRepositoryWL().get_conversion_rate(
            savings.get('current_year_savings', 0), 'AED', self.currency if self.currency else 'AED'
        )
        yearly_savings = self.user_savings_repo.get_yearly_saving(
            self.user_id, self.start_date, self.end_date, self.company
        )
        self.yearly_savings = ExchangeRatesRepositoryWL().get_conversion_rate(
            round(yearly_savings.get('savings', 0)), 'AED', self.currency if self.currency else 'AED'
        )

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': {
                'current_year': str(self.current_year),
                'savings': round(self.savings),
                'yearly_savings': round(self.yearly_savings)
            },
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Handles the process of api
        """
        self.initialize_class_attributes()
        self.initialize_repos()
        self.get_user_savings()
        if self.is_send_response_flag_on():
            return
        self.generate_final_response()
