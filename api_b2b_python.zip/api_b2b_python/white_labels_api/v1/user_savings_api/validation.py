from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import device_list, language

user_savings_parser = get_request_parser()

user_savings_parser.add_argument(
    'language',
    type=language,
    required=False,
    default='en',
    location=['mobile', 'values', 'json'],
)
user_savings_parser.add_argument(
    '__platform',
    type=device_list,
    default='',
    required=True,
    location=['mobile', 'values', 'json']
)
user_savings_parser.add_argument(
    'app_version',
    type=str,
    required=True,
    default='',
    location=['mobile', 'values', 'json']
)
user_savings_parser.add_argument(
    'session_token',
    required=False,
    type=str,
    location=['mobile', 'values', 'json']
)

user_savings_parser.add_argument(
    'currency',
    type=str,
    required=False,
    location=['mobile', 'values', 'json']
)
