"""
Merchant name api white label
"""
from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from repositories_white_label.merchant_repo import MerchantRepositoryWl
from repositories_white_label.offer_wl_active_repo import OfferWlRepository
from repositories_white_label.translations_repo import TranslationManager
from white_labels_api.v1.merchant_name.validation import merchant_name_parser


class MerchantNameApiWl(BaseGetResource):
    """
    @api {get} /v1/merchant/name Get merchant name
    @apiSampleRequest /v1/merchants/name
    @apiVersion 1.0.0
    @apiName MerchantName
    @apiGroup Merchants
    @apiParam {Integer}                                     offer_id           Offer id
    @apiParam {Integer}                                     merchant_id        Merchant id
    @apiParam {Integer}                                     location_id        ID of location to filter outlets by
    @apiParam {String="android", "ios", "web"}              __platform         All supported platform
    @apiParam {String}                                      app_version        App_version
    @apiParam {String='de', 'en', 'ar', 'cn', 'el', 'zh'}   [language]         Response language
    """
    request_parser = merchant_name_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='merchant_name/merchant_name.log',
        ),
        'name': 'merchant_name'
    }
    strict_token = True
    required_token = True

    def populate_request_arguments(self):
        """
        Add request arguments of merchant name api
        """
        self.merchant_id = self.request_args.get('merchant_id')
        self.offer_id = self.request_args.get('offer_id')
        self.locale = self.request_args.get('language')

    def initialize_class_attributes(self):
        """
        Initialize class attributes of merchant name api
        """
        self.merchant_repo = MerchantRepositoryWl()
        self.offer_wl_active_repo = OfferWlRepository()
        self.translation_manager = TranslationManager()

    def find_merchant_and_offer_name(self):
        """
        Find merchant and offer name against merchant_id and offer_id
        """
        self.merchant_name = self.merchant_repo.find_name_by_id(self.merchant_id)
        self.offer_name = self.offer_wl_active_repo.find_offer_type_by_id(self.offer_id)

    def prepare_response(self):
        """
        Sets final response of merchant name api
        :rtype: dict
        """
        self.send_response_flag = True
        self.response = {
            'data': {'merchant_name': self.merchant_name, 'offer_name': self.offer_name},
            'success': True,
            'message': self.translation_manager.get_translation(
                self.translation_manager.success,
                self.locale
            )
        }
        self.status_code = 200
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of merchant name api
        """
        self.initialize_class_attributes()
        self.find_merchant_and_offer_name()
        self.prepare_response()
