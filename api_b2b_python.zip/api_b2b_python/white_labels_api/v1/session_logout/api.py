"""
Session Logout Api
"""
from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BasePostResource
from common_white_label.common_helpers import CommonHelpers
from repositories_white_label.session_repo import SessionRepositoryWhiteLabel
from repositories_white_label.translations_repo import TranslationManager
from user_authentication_white_label.authentication import get_company, get_current_customer
from white_labels_api.v1.session_logout.validation import session_logout_parser


class LogoutApi(BasePostResource):
    """
    @api {post} /v1session/logout  Logout the user and remove the session.
    @apiSampleRequest /v1/session/logout
    @apiVersion 1.0.0
    @apiName SessionLogoutApi
    @apiGroup Users
    @apiParam {String='de', 'en', 'ar', 'cn', 'el', 'zh'}       [language]      Response language
    """
    request_parser = session_logout_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='session_logout_api/session_logout_api.log',
        ),
        'name': 'session_logout_api'
    }
    strict_token = True
    required_token = True

    def populate_request_arguments(self):
        """
        Adds request arguments of session logout api.
        """
        self.locale = self.request_args.get('language')
        # self.session_token = self.request_args.get('session_token')

    def setting_variables(self):
        """
        Sets variables for session logout api
        """
        self.locale = CommonHelpers.get_locale(self.locale)
        self.company = get_company()

    def initialize_repo(self):
        """
        Initializes the different repos
        """
        self.session_repo = SessionRepositoryWhiteLabel()
        self.transaltion_repo = TranslationManager()

    def get_current_user_info(self):
        """
        Gets current user info
        """
        self.customer = get_current_customer()
        self.user_id = self.customer.get('customer_id')
        self.session_id = self.customer.get('id')
        self.session_token = self.customer.get('session_token')

    def generate_final_response(self):
        """
        Sets final response of session logout api
        :rtype: dict
        """
        session = self.session_repo.find_by_id(company=self.company, session_id=self.session_id)
        self.send_response_flag = True
        self.status_code = 200
        if session:
            self.session_repo.remove_session(self.session_id)
            response_message = self.transaltion_repo.get_translation(
                self.transaltion_repo.success,
                self.locale
            )
            response_success = True
        else:
            response_message = self.transaltion_repo.get_translation(
                self.transaltion_repo.wrong_session_token,
                self.locale
            )
            response_success = False

        self.response = {
            "message": response_message,
            "success": response_success,
            "data": [],
            "code": 0
        }
        return self.send_response(self.response, status_code=self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.initialize_repo()
        self.setting_variables()
        self.get_current_user_info()
        self.generate_final_response()
