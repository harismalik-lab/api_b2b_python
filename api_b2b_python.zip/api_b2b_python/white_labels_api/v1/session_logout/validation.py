"""
Validation params of session logout api
"""
from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import language

session_logout_parser = get_request_parser()
session_logout_parser.add_argument(
    name="language",
    type=language,
    default="en",
    required=False,
    location=['mobile', 'values', 'json']
)
session_logout_parser.add_argument(
    name="app_version",
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
session_logout_parser.add_argument(
    name="session_token",
    type=str,
    required=False,
    location=['mobile', 'values', 'json']
)
