"""
Implementation: Validate the existence of the offers, the user, the outlet, and whether the offers are redeemable
by this user at this outlet. From the outlet, merchant information can be retrieved and the PIN can then be
verified. If all is OK, create a new record in the redemption table and calculate the redemption_code.
"""
from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BasePostResource
from common_white_label.common_helpers import CommonHelpers, get_current_date_time
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.informatica_mobile_redemption_repo import InformaticaMobileRedemptionRepository
from repositories_white_label.merchant_repo import MerchantRepositoryWl
from repositories_white_label.offer_wl_active_repo import OfferWlRepository
from repositories_white_label.outlet_repo import OutletRepositoryWl
from repositories_white_label.product_repo import ProductRepositoryWhiteLabel
from repositories_white_label.redemption_repo import RedemptionRepositoryWhiteLabel
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.user_savings_repo import UserSavingsRepositoryWhiteLabel
from repositories_white_label.wl_company_repo import WLCompany
from repositories_white_label.wl_gem_lookup_repo import WlGemLookupRepository
from user_authentication_white_label.authentication import get_company, get_current_customer
from white_labels_api.v1.redemption.validation import redemption_parser_wl


class RedemptionProcessWL(BasePostResource):
    """
    @api {post} /v1/redemptions Post Redeem the offer
    @apiSampleRequest /v1/redemptions
    @apiVersion 1.0.0
    @apiName RedemptionProcessWL
    @apiGroup Redemptions
    @apiParam {Integer}                                     offer_id                Offer id
    @apiParam {Integer}                                     outlet_id               Outlet id
    @apiParam {Integer}                                     merchant_pin            Merchant pin
    @apiParam {Integer}                                     location_id             Id of location to filter outlets by
    @apiParam {String="ios","android","web"}                __platform              All supported platform
    @apiParam {String}                                      app_version             app version of app
    @apiParam {Float}                                       lat                     Latitude
    @apiParam {Float}                                       lng                     Longitude
    @apiParam {Integer}                                     transaction_id          Transaction id
    @apiParam {Integer}                                     product_id              Product_id
    @apiParam {String}                                      device_model            Model of device
    @apiParam {Boolean}                                     [is_delivery]           Check delivery
    @apiParam {Boolean}                                     [is_barcode_enabled]    Check Bar code enabled
    @apiParam {Boolean}                                     [is_shared]             Is shared flag
    @apiParam {String="en", "ar", "cn", "el","zh"}          [language]              Response Language
    """

    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='redemption_api_wl/redemption_api_wl.log',
        ),
        'name': 'redemption_api_wl'
    }
    request_parser = redemption_parser_wl
    strict_token = True
    required_token = True

    def populate_request_arguments(self):
        """
        Request arguments for redemption api white label
        """
        self.offer_id = self.request_args.get('offer_id', 0)
        self.outlet_id = self.request_args.get('outlet_id')
        self.provided_merchant_pin = self.request_args.get('merchant_pin', '')
        self.transaction_id = self.request_args.get('transaction_id', '')
        self.product_id = self.request_args.get('product_id')
        self.locale = self.request_args.get('locale', '')
        self.device_model = self.request_args.get('device_model', '')
        self.platform = self.request_args.get('__platform', '')
        self.is_reattempt = self.request_args.get('is_reattempt')

    def initialize_local_veriables(self):
        """
        Sets variables for api
        """
        self.customer = get_current_customer()
        self.company = get_company()
        self.session_token = get_current_customer().get('session_token')

    def initialize_repos(self):
        """
        Initializes repos for redemption api
        """
        self.merchant_repo = MerchantRepositoryWl()
        self.redemption_repo = RedemptionRepositoryWhiteLabel()
        self.offer_wl_active_repo = OfferWlRepository()
        self.translation_manager = TranslationManager()
        self.outlet_repo = OutletRepositoryWl()
        self.product_repo = ProductRepositoryWhiteLabel()
        self.user_savings_repo = UserSavingsRepositoryWhiteLabel()
        self.customer_repo = CustomerProfileWhiteLabel()
        self.wl_gem_lookup_repo = WlGemLookupRepository()

    def initialize_class_attributes(self):
        """
        Initializes class attributes for redemption api
        """
        self.redemption_instance = None
        self.purchased_product_ids = []
        self.messages_locale = CommonHelpers.get_locale_for_messaging(self.locale)
        self.customer_id = self.customer.get('customer_id', 0)

    def verify_customer(self):
        """
        Validates customer
        """
        if not self.customer_id:
            self.message = self.translation_manager.get_translation(
                self.translation_manager.NOT_AUTHORIZE_TO_ACCESS_USER,
                self.messages_locale
            )
            self.status_code = 422
            self.response = {
                "message": self.message,
                "code": 50
            }
            return self.send_response(self.response, self.status_code)

    def verify_reattempt_code_and_transaction(self):
        """
        Verify reattempt redemption code and transactions
        """
        if self.is_reattempt and self.transaction_id:
            reattempt_code = self.redemption_repo.get_code(
                transaction_id=self.transaction_id,
                customer_id=self.customer_id
            )
            if reattempt_code:
                self.redemption_response = {'redemption_code': reattempt_code}
                self.message = self.translation_manager.get_translation(
                    self.translation_manager.SUCCESS,
                    self.messages_locale
                )
                self.response = {
                    'data': {"referenceNo": self.redemption_response},
                    'message': self.message,
                    'success': True
                }
                self.status_code = 201
                return self.send_response(self.response, self.status_code)
        self.purchased_through_connect = False
        for purchased_product_id in self.purchased_product_ids:
            if purchased_product_id == self.product_id:
                self.purchased_through_connect = True

    def initialize_offers_data(self):
        """
        Checks offers against provided offer id and product id
        """
        self.offer = self.offer_wl_active_repo.find_by_id(
            offer_id=self.offer_id,
            product_id=self.product_id
        )

    def is_offer_exist(self):
        """
        Checks if offer exist or not
        """
        if not self.offer:
            self.send_response_flag = True
            self.status_code = 422
            self.response["message"] = self.translation_manager.get_translation(
                self.translation_manager.offer_does_not_exist_or_inactive,
                self.messages_locale
            )
            self.response["message"] = self.response["message"].replace('XXX1', self.offer_id)
            self.response["code"] = 31
            self.response["success"] = False
            self.response["data"] = []
            self.logger.info(self.response)

    def verify_app_tutorial(self):
        """
        Verify app tutorial
        """
        self.is_app_tutorial = self.merchant_repo.is_app_tutorial_by_merchant_id(
            merchant_id=self.offer.get('merchant_id')
        )

    def verify_offer_redeem_limit(self):
        """
        Verify offer redeem limit
        """
        if not self.is_app_tutorial:
            self.redeemed_offer_count_in_last_x_hours = self.redemption_repo.get_redemptions_in_last_xhours_for_offer_for_customer(  # noqa: E501
                    customer_id=self.customer_id,
                    offer_id=self.offer_id,
                    number_of_hours=self.offer['hours_to_consider_for_redemption_cap'],
                    company=self.company
                )
            if self.redeemed_offer_count_in_last_x_hours >= self.offer.get('redemptions_limit_in_x_hours'):
                self.send_response_flag = True
                monthly_limit_messages = self.translation_manager.get_translation(
                    self.translation_manager.MONTHLY_LIMIT_MESSAGE,
                    locale=self.messages_locale
                )
                self.status_code = 422
                self.response["success"] = False
                self.response["code"] = 422
                self.response["data"] = []
                self.response["message"] = monthly_limit_messages
                self.response["message"] = self.response["message"].format(
                    MONTHLY_LIMIT=self.offer.get('redemptions_limit_in_x_hours'),
                    MONTHLY_HOURS=self.offer.get('hours_to_consider_for_redemption_cap')
                )
                self.logger.info(self.response)

    def get_merchant_information(self):
        """
        Gets merchant information
        """
        merchant_info = self.merchant_repo.get_merchant_info(self.offer.get('merchant_id'))
        self.merchant_pin = merchant_info.get('pin') if merchant_info else ''
        self.merchant_sf_id = merchant_info.get('sf_id') if merchant_info else ''

    def verify_merchant_pin(self):
        """
        Verify merchant-pin with user-pin
        """
        if int(self.merchant_pin) != int(self.provided_merchant_pin):
            self.send_response_flag = True
            self.response["message"] = self.translation_manager.get_translation(
                self.translation_manager.invalid_merchant_pin,
                self.messages_locale
            )
            self.status_code = 422
            self.response["code"] = 30
            self.response["success"] = False
            self.response["data"] = []
            self.logger.info(self.response)

    def verify_offer_redeemability(self):
        """
        Calculates offer redeemability
        """
        is_redeemable = self.offer_wl_active_repo.calculate_offer_redeemability_for_redemption_controller(
            company=self.company,
            customer=self.customer,
            offer_id=self.offer_id,
            offer_valid_from_date=self.offer.get('valid_from'),
            offer_expiration_date=self.offer.get('valid_to'),
            offer_type=self.offer.get('type'),
            offer_quantity=self.offer.get('quantity'),
            product_id=self.product_id
        )
        if not is_redeemable:
            self.send_response_flag = True
            self.status_code = 422
            self.response = {
                "message": self.translation_manager.get_translation(
                    self.translation_manager.NOT_ALLOWED,
                    locale=self.messages_locale
                ),
                "success": False,
                "code": 422
            }
            return self.send_response(self.response, self.status_code)

    def get_outlet_information(self):
        """
        Provides outlet information against given outlet id
        """
        self.outlet_info = self.outlet_repo.get_outlet_info(self.outlet_id)
        self.root_code = self.redemption_repo.get_root_code(self.product_id, self.offer_id)
        self.savings_estimates = self.offer.get('savings_estimate_local_currency')
        self.is_points_based_offer = False
        self.points = 0
        if (
            self.company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS and
            self.offer.get('is_point_based_offer')
        ):
            self.savings_estimates = 0
            self.is_points_based_offer = True
            self.points = self.offer.get('gems_points')

    def redemption_data(self):
        """
        Initializes redemption_data
        """
        self.redemption_instance = dict()
        self.redemption_instance['customer_id'] = self.customer.get('customer_id')
        self.redemption_instance['date_created'] = get_current_date_time()
        self.redemption_instance['offer_id'] = self.offer_id[0] if isinstance(self.offer_id, list) else self.offer_id
        self.redemption_instance['outlet_id'] = self.outlet_id
        self.redemption_instance['quantity'] = 1
        self.redemption_instance['code'] = ''
        self.redemption_instance['session_token'] = self.session_token
        self.redemption_instance['savings_estimate'] = self.savings_estimates
        self.redemption_instance['transaction_id'] = self.transaction_id
        self.redemption_instance['product_id'] = self.product_id
        self.redemption_instance['company'] = self.company
        self.redemption_instance['root_code'] = self.root_code
        self.redemption_instance['device_os'] = self.platform
        self.redemption_instance['device_model'] = self.device_model
        self.redemption_instance['device_language'] = self.messages_locale
        self.redemption_instance['purchased_through_connect'] = self.purchased_through_connect

        self.redemption_instance['id'] = self.redemption_repo.insert_redemption_instance_data(
            data=self.redemption_instance
        )

    def set_redemption_code(self):
        """
        Sets redemption code
        """
        self.product_info = self.product_repo.find_by_id(self.product_id)
        self.redemption_type = self.redemption_repo.TYPE_DEFAULT

        if self.product_info.get('delivery_enabled'):
            self.redemption_type = self.redemption_repo.TYPE_DELIVERY

        self.code = self.redemption_repo.generate_redemption_code(
            self.redemption_instance.get('id'),
            self.redemption_type
        )
        self.redemption_instance['code'] = self.code
        self.coupon = ''
        redemption_update = {'code': self.code}
        self.redemption_repo.update_redemption_code(
            redemption_id=self.redemption_instance.get('id'),
            redemption_changes=redemption_update
        )

    def update_user_savings(self):
        """
        Updates user savings
        """
        self.user_savings_repo.add_redemption_savings(
            user_id=self.customer_id,
            savings=self.savings_estimates,
            company=self.company,
            points=0
        )

    def insert_informatica_table_entry(self):
        """
        Insert an entry into db in the mobile_redemption table
        """
        self.informatica_data = {
            'id': self.redemption_instance.get('id'),
            'customer_id': self.redemption_instance.get('customer_id'),
            'membership_code': self.customer.get('membership_code', ''),
            'quantity': self.redemption_instance.get('quantity'),
            'code': self.redemption_instance.get('code'),
            'date_created': self.redemption_instance.get('date_created'),
            'offer_sf_id': self.offer.get('sf_id'),
            'outlet_sf_id': self.outlet_info.get('sf_id'),
            'merchant_sf_id': self.merchant_sf_id,
            'root_code': self.redemption_instance.get('root_code'),
            'company': self.company
        }
        InformaticaMobileRedemptionRepository().insert_mobile_redemption(self.informatica_data)

    def check_customer_profile(self):
        """
        Checks customer profile against given customer id
        """
        if self.is_points_based_offer:
            customer_profile = self.customer_repo.load_customer_profile_by_id(self.customer_id)
            if not customer_profile:
                email = customer_profile.get('email')
                lookup_data = self.wl_gem_lookup_repo.find_gem_data_by_id({
                    'email': email,
                    'is_active': True
                })
                wl_gems_points = {
                    'user_id': self.redemption_instance.get('customer_id'),
                    'gems_persistent_id': lookup_data.get('gems_persistent_id'),
                    'email': email,
                    'gems_points': self.points,
                    'savings': 0,
                    'redemption_id': self.redemption_instance.get('id')
                }
                self.wl_gem_lookup_repo.insert_gems_points(data=wl_gems_points)

    def build_redemption_response(self):
        """
        Builds redemption response
        """
        self.redemption_response = {
            'redemption_code': self.code,
            'smiles_earned': 0,
            'coupon': self.coupon
        }

    def generates_final_response(self):
        """
        Sets final response
        :rtype: dict
        """
        self.send_response_flag = True
        self.response = {
            'success': True,
            'message': self.translation_manager.get_translation(
                self.translation_manager.success,
                self.messages_locale
            ),
            'data': {"referenceNo": self.redemption_response}
        }
        self.status_code = 200
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Redeem an offer for a user
        """
        self.initialize_local_veriables()
        self.initialize_class_attributes()
        self.initialize_repos()
        if self.is_send_response_flag_on():
            return

        self.verify_customer()
        if self.is_send_response_flag_on():
            return
        self.verify_reattempt_code_and_transaction()
        self.initialize_offers_data()
        self.is_offer_exist()
        if self.is_send_response_flag_on():
            return

        self.verify_app_tutorial()
        self.verify_offer_redeem_limit()
        if self.is_send_response_flag_on():
            return

        self.get_merchant_information()
        self.verify_merchant_pin()
        if self.is_send_response_flag_on():
            return

        self.verify_offer_redeemability()
        if self.is_send_response_flag_on():
            return
        self.get_outlet_information()

        self.redemption_data()
        self.set_redemption_code()
        self.update_user_savings()
        self.insert_informatica_table_entry()
        self.check_customer_profile()
        self.build_redemption_response()
        self.generates_final_response()
