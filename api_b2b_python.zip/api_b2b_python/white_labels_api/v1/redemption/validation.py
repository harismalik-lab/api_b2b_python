"""
Validation arguments for redemption
"""
from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import boolean, device_list, language

redemption_parser_wl = get_request_parser()

redemption_parser_wl.add_argument(
    'is_barcode_enabled',
    type=boolean,
    required=False,
    default=0,
    location=['mobile', 'values', 'json']
)
redemption_parser_wl.add_argument(
    'key',
    type=str,
    required=False,
    location=['mobile', 'values', 'json']
)
redemption_parser_wl.add_argument(
    'session_token',
    type=str,
    required=False,
    location=['mobile', 'values', 'json']
)
redemption_parser_wl.add_argument(
    'offer_id',
    type=int,
    required=True,
    action='append',
    location=['mobile', 'values', 'json'],
)
redemption_parser_wl.add_argument(
    'is_shared',
    type=boolean,
    required=False,
    location=['mobile', 'values', 'json']
)
redemption_parser_wl.add_argument(
    'outlet_id',
    type=int,
    required=True,
    location=['mobile', 'values', 'json'],
)
redemption_parser_wl.add_argument(
    'merchant_pin',
    type=int,
    required=True,
    location=['mobile', 'values', 'json'],
)
redemption_parser_wl.add_argument(
    'currency',
    type=str,
    required=False,
    location=['mobile', 'values', 'json']
)
redemption_parser_wl.add_argument(
    'lng',
    type=str,
    required=False,
    location=['mobile', 'values', 'json']
)
redemption_parser_wl.add_argument(
    'lat',
    type=str,
    required=False,
    location=['mobile', 'values', 'json']
)
redemption_parser_wl.add_argument(
    'is_reattempt',
    type=boolean,
    required=False,
    location=['mobile', 'values', 'json']
)
redemption_parser_wl.add_argument(
    'transaction_id',
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
redemption_parser_wl.add_argument(
    'product_id',
    type=str,
    required=True,
    location=['mobile', 'values', 'json'],
)
redemption_parser_wl.add_argument(
    'location_id',
    type=int,
    location=['mobile', 'values', 'json']
)
redemption_parser_wl.add_argument(
    'language',
    type=language,
    required=False,
    default='en',
    location=['mobile', 'values', 'json'],
)
redemption_parser_wl.add_argument(
    'is_delivery',
    type=boolean,
    required=False,
    location=['mobile', 'values', 'json']
)
redemption_parser_wl.add_argument(
    'device_model',
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
redemption_parser_wl.add_argument(
    '__platform',
    type=device_list,
    required=True,
    location=['mobile', 'values', 'json']
)
redemption_parser_wl.add_argument(
    'app_version',
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
