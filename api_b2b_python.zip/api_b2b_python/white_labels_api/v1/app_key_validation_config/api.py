"""
Module contains App Key Validation Config APi
"""
from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from common_white_label.common_helpers import CommonHelpers
from repositories_white_label.appkey_validation_configuration_repo import AppKeyValidationConfigurationRepository
from repositories_white_label.translations_repo import TranslationManager
from user_authentication_white_label.authentication import get_company
from white_labels_api.v1.app_key_validation_config.validation import app_key_validation_parser


class AppKeyValidationConfigApi(BaseGetResource):
    """
    @api {get} /v1/app/key/validation/config App Key Validation Configuration
    @apiSampleRequest /v1/app/key/validation/config
    @apiVersion 1.0.0
    @apiName appKeyValidationConfigurations
    @apiGroup Configurations
    @apiParam {String="ios","android", "web|}                __platform        Mobile Platform
    @apiParam {String}                                       app_version       Mobile app version
    @apiParam {String="en", "ar", "cn", "el, "de", "zh"}     [language]        Response language
    """
    request_parser = app_key_validation_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='app_key_validation_config_api/app_key_validation_config_api.log',
        ),
        'name': 'app_key_validation_config_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.app_version = self.request_args.get('app_version')
        self.locale = self.request_args.get('language')
        self.platform = self.request_args.get('__platform')

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.translation_manager = TranslationManager()
        self.app_key_validation_configuration_repo = AppKeyValidationConfigurationRepository()

    def setting_variables(self):
        """
        Sets variables for api
        """
        self.locale = CommonHelpers.get_locale(self.locale)
        self.messages_locale = CommonHelpers.get_locale_for_messaging(self.locale)
        self.company = get_company()

    def get_app_key_validation_configuration(self):
        """
        Gets app key validation configuration
        """
        self.app_key_validation_configurations = self.app_key_validation_configuration_repo.\
            get_app_key_validation_configuration(self.company, self.platform, self.app_version, self.messages_locale)

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'configurations': self.app_key_validation_configurations,
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.initialize_repos()
        self.setting_variables()
        self.get_app_key_validation_configuration()
        self.generate_final_response()
