"""
App key validation parser
"""
from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import device_list

app_key_validation_parser = get_request_parser()

app_key_validation_parser.add_argument(
    name="__platform",
    type=device_list,
    required=True,
    location=['mobile', 'values', 'json']
)
app_key_validation_parser.add_argument(
    name="app_version",
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
app_key_validation_parser.add_argument(
    name="language",
    type=str,
    default="en",
    required=False,
    location=['mobile', 'values', 'json']
)
