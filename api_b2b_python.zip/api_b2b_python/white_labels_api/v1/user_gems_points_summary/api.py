"""
User gem points summary api white label
"""
import datetime

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from common_white_label.common_helpers import CommonHelpers
from common_white_label.constants import GlobalConstants
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.wl_gem_points_repo import WlGemPointsRepository
from user_authentication_white_label.authentication import get_company, get_current_customer
from white_labels_api.v1.user_gems_points_summary.validation import user_gems_points_summary_parser


class UserGemsPointsSummaryApiWL(BaseGetResource):
    """
    @api {get} /v1/user/gemspoints/summary Get User Gems Points Summary
    @apiSampleRequest /v1/user/gemspoints/summary
    @apiVersion 1.0.0
    @apiName UserGemsPointsSummaryApiWL
    @apiGroup Users
    @apiParam {String}      app_version      Mobile App Version.
    @apiParam {String}      __platform       Mobile Platform.
    @apiParam {String}      [language]       Response Language.
    @apiParam {String}      [location_id]    User Location Id.
    @apiParam {String}      [currency]       Currency.
    @apiParam {String}      [summary_type]   Summary Type.
    """
    request_parser = user_gems_points_summary_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='user_gems_points_summary_api/user_gems_points_summary_api.log',
        ),
        'name': 'user_gems_points_summary_api'
    }
    required_token = True
    strict_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')
        self.__platform = self.request_args.get('__platform')
        self.app_version = self.request_args.get('app_version')
        self.currency = self.request_args.get('currency')
        self.summary_type = self.request_args.get('summary_type')

    def setting_variables(self):
        """
        Sets variables for user gems points api
        """
        self.locale = CommonHelpers.get_locale(self.locale)
        self.company = get_company()

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.wl_gem_points_repo = WlGemPointsRepository()
        self.translation_manager = TranslationManager()

    def initialize_class_attributes(self):
        """
        Sets variables for api
        """
        self.customer = get_current_customer()
        self.customer_id = self.customer.get('customer_id')
        self.session_token = self.customer.get('session_token')
        self.user_id = None
        today_date = datetime.datetime.now()
        self.current_year = today_date.year
        self.current_month = today_date.month
        self.lifetime_savings = 0
        self.current_month_savings = 0
        self.first_day_of_current_year = datetime.datetime.now().replace(month=1, day=1)
        self.first_day_of_current_month = datetime.datetime.now().replace(
            month=self.current_month,
            day=1,
            year=self.current_year
        )
        self.month_names = self.translation_manager.get_translation(
            self.translation_manager.MOMTHS_NAME_LIST,
            self.locale
        )
        self.total_valid_months = self.month_names[: self.current_month]
        self.graph_data = []
        self.years_months_having_redemptions = []
        self.months_having_redemptions = []
        self.years_having_redemptions = []
        self.year_month_wise_redemptions = []
        self.redemptions_response = []
        self.total_redemptions = 0
        self.total_savings = 0
        self.month_index = 1
        self.graph_data = []
        self.accumulative_sum = 0
        self.by_year = GlobalConstants.summary_type_by_year
        self.by_month = GlobalConstants.summary_type_by_month

    def validate_customer(self):
        """
        Throws an Error if user_id do not match with customer_id stored in session data
        :rtype: dict
        """
        if str(self.customer_id) != str(self.user_id):
            self.send_response_flag = True
            self.status_code = 403
            self.response = {
                "message": self.translation_manager.get_translation(
                    self.translation_manager.you_are_not_allowed_to_access_this_application,
                    self.locale
                ),
                "success": False,
                "code": 90
            }
            return self.send_response(self.response, self.status_code)

    def get_user_gems_points_summary(self):
        """
        Gets user gems points summary
        """
        self.validate_customer()
        self.redemption_summary = {
            'current_year': self.current_year,
            'current_month': self.month_names[self.current_month - 1].lower().title(),
            'current_month_saving': 0,
            'currency': '',
            'life_time_saving': 0,
            'graph_data': [],
            'progress_data': [],
        }
        if self.summary_type == self.by_month:
            for index, month in enumerate(self.total_valid_months):
                self.year_month_wise_redemptions.append({
                    'index': index + 1,
                    'name': "{current_year} {month}".format(current_year=self.current_year, month=month),
                    'redemption_count': 0,
                    'total_redemptions': 0,
                    'savings': 0,
                    'total_savings': 0,
                    'currency': '',
                    'redemptions': []
                })
        self.all_points = self.wl_gem_points_repo.find_points(user_id=self.customer_id)
        for point in self.all_points:
            self.lifetime_savings += point.get('gems_points')
            if point.get('created_date') >= self.first_day_of_current_month:
                self.current_month_savings += point.get('gems_points')
            if self.summary_type == self.by_month:
                self.total_redemptions += 1
                self.savings = point.get('gems_points')
                self.total_savings += self.savings
                index = point.get('created_date').month - 1
                if self.year_month_wise_redemptions[index]:
                    self.year_month_wise_redemptions[index]['redemption_count'] += 1
                    self.year_month_wise_redemptions[index]['savings'] += self.savings
                    self.year_month_wise_redemptions[index]['redemptions'].append({
                        'id': point.get('id'),
                        'date_created': str(
                            point.get('created_date').replace(tzinfo=datetime.timezone.utc).isoformat()),
                        'savings': self.savings
                    })
            if self.summary_type == self.by_year:
                self.total_redemptions += 1
                self.savings = point.get('gems_points')
                self.total_savings += self.savings
                self.year_index = -1

                for year_month_wise_redemption in range(len(self.year_month_wise_redemptions)):
                    if self.year_month_wise_redemptions[year_month_wise_redemption]['name'] == point.get('created_date').year:  # noqa:E501
                        self.year_index = year_month_wise_redemption
                if self.year_index == -1:
                    self.existing_years_count = len(self.year_month_wise_redemptions)
                    self.year_month_wise_redemptions.append({
                        'index': self.existing_years_count + 1,
                        'name': str(point.get('created_date').year),
                        'redemption_count': 0,
                        'total_redemptions': 0,
                        'savings': 0,
                        'total_savings': 0,
                        'currency': ''
                    })
                    self.year_index = len(self.year_month_wise_redemptions) - 1
                self.year_month_wise_redemptions[self.year_index]['redemption_count'] += 1
                self.year_month_wise_redemptions[self.year_index]['total_redemptions'] = self.total_redemptions
                self.year_month_wise_redemptions[self.year_index]['savings'] += self.savings
                self.year_month_wise_redemptions[self.year_index]['total_savings'] += self.total_savings
        if self.summary_type == self.by_month:
            for monthly_redemption in self.year_month_wise_redemptions:
                monthly_redemption['total_redemptions'] = self.total_redemptions
                monthly_redemption['total_savings'] = self.total_savings
                if monthly_redemption.get('redemption_count') > 0:
                    self.months_having_redemptions.append(monthly_redemption)
            if (
                self.months_having_redemptions and
                self.months_having_redemptions[len(self.months_having_redemptions) - 1]['index'] == self.current_month
            ):
                for redemption in self.months_having_redemptions[len(self.months_having_redemptions) - 1]['redemptions']:
                    self.day_index = -1
                    for graph_len in range(len(self.graph_data)):
                        if self.graph_data[graph_len]['index'] == redemption['date_created'].day:
                            self.day_index = graph_len
                    if self.day_index >= 0:
                        self.graph_data[self.day_index]['value'] += redemption.get('savings', 0)
                    else:
                        self.graph_data.append({
                            'index': redemption.get('date_created').day,
                            'value': redemption.get('savings'),
                            'currency': ''
                        })
                for monthly_summary in self.months_having_redemptions:
                    monthly_summary['redemptions'] = ''
            self.months_having_redemptions.reverse()
            self.years_months_having_redemptions = self.months_having_redemptions
        if self.summary_type == self.by_year:
            for yearly_data in self.year_month_wise_redemptions:
                yearly_data['total_savings'] = self.total_savings
                yearly_data['total_redemptions'] = self.total_redemptions
                self.accumulative_sum += yearly_data['savings']
                self.graph_data.append({'value': self.accumulative_sum, 'currency': ''})
            self.year_month_wise_redemptions.reverse()
            self.years_months_having_redemptions = self.year_month_wise_redemptions
        self.redemption_summary['life_time_saving'] = self.lifetime_savings
        self.redemption_summary['current_month_saving'] = self.current_month_savings
        self.redemption_summary['graph_data'] = self.graph_data
        self.redemption_summary['progress_data'] = self.years_months_having_redemptions

    def generate_final_response(self):
        """
        Generates final response
        :rtype: dict
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': self.redemption_summary,
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.initialize_repos()
        self.initialize_class_attributes()
        self.get_user_gems_points_summary()
        self.generate_final_response()
