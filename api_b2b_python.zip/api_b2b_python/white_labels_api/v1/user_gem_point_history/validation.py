"""
Validation params of user gems points history api
"""
from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import language

user_gems_points_history_parser = get_request_parser()

user_gems_points_history_parser.add_argument(
    name="__platform",
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
user_gems_points_history_parser.add_argument(
    name="language",
    type=language,
    default="en",
    required=True,
    location=['mobile', 'values', 'json']
)
user_gems_points_history_parser.add_argument(
    name="location_id",
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
user_gems_points_history_parser.add_argument(
    name="app_version",
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
user_gems_points_history_parser.add_argument(
    name="currency",
    type=str,
    required=False,
    location=['mobile', 'values', 'json']
)
