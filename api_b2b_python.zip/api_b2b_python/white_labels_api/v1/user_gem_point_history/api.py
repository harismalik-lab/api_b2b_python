"""
User Gem Points History api white label
"""
import datetime

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from common_white_label.common_helpers import CommonHelpers
from common_white_label.constants import GlobalConstants
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.wl_gem_points_repo import WlGemPointsRepository
from user_authentication_white_label.authentication import get_company, get_current_customer
from white_labels_api.v1.user_gem_point_history.validation import user_gems_points_history_parser


class UserGemsPointsHistoryApiWL(BaseGetResource):
    """
    @api {get} /v1/user/gemspoints/history Get User Gems Points History
    @apiSampleRequest /v1/user/gemspoints/history
    @apiVersion 1.0.0
    @apiName UserGemsPointsHistoryApiWL
    @apiGroup Users
    @apiParam {String}      app_version       Mobile app version.
    @apiParam {String}      __platform        Mobile platform
    @apiParam {String}      [language]        Response language.
    @apiParam {Integer}     [location_id]     Location id of user.
    @apiParam {String}      [currency]        Currency.
    """
    request_parser = user_gems_points_history_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='user_gems_points_history_api/user_gems_points_history_api.log',
        ),
        'name': 'user_gems_points_history_api'
    }
    required_token = True
    strict_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')
        self.__platform = self.request_args.get('__platform')
        self.location_id = self.request_args.get('location_id')
        self.app_version = self.request_args.get('app_version')
        self.currency = self.request_args.get('currency')

    def setting_variables(self):
        """
        Sets variables for kaligo deeplink api
        """
        self.company = get_company()
        self.locale = CommonHelpers.get_locale(self.locale)

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.wl_gem_points_repo = WlGemPointsRepository()
        self.translation_manager = TranslationManager()

    def initialize_class_attributes(self):
        """
        Sets variables for api
        """
        self.customer = get_current_customer()
        self.customer_id = self.customer.get('customer_id')
        self.session_token = self.customer.get('session_token')
        self.user_id = None
        today_date = datetime.datetime.now()
        self.current_year = today_date.year
        self.current_month = today_date.month
        self.lifetime_savings = 0
        self.current_month_savings = 0
        self.first_day_of_current_year = datetime.datetime.now().replace(month=1, day=1)
        self.first_day_of_current_month = datetime.datetime.now().replace(
            month=self.current_month,
            day=1,
            year=self.current_year
        )
        self.month_names = self.translation_manager.get_translation(
            self.translation_manager.MOMTHS_NAME_LIST,
            self.locale
        )
        self.code_redemption = ''
        self.merchant = ''
        self.graph_data = []
        self.years_months_having_redemptions = []
        self.months_having_redemptions = []
        self.years_having_redemptions = []
        self.year_month_wise_redemptions = []
        self.total_redemptions = 0
        self.total_savings = 0
        self.total_valid_months = self.month_names[0: int(self.current_month)]
        self.month_index = 1

    def validate_customer(self):
        """
        Throw an Error if user_id do not match with customer_id stored in session data
        :rtype: dict
        """
        if not self.customer_id:
            self.send_response_flag = True
            self.status_code = 403
            self.response = {
                "message": self.translation_manager.get_translation(
                    self.translation_manager.you_are_not_allowed_to_access_this_application,
                    self.locale
                ),
                "success": False,
                "code": 90
            }
            return self.send_response(self.response, self.status_code)

    def get_user_gems_points_history(self):
        """
        Gets user gems points
        """
        self.validate_customer()
        self.redemption_summary = {
            'current_year': self.current_year,
            'total_redemptions': 0,
            'month_wise_redemmptions': {}
        }

        self.all_points = self.wl_gem_points_repo.find_points(self.locale, self.customer_id)
        for index, month in enumerate(self.total_valid_months):
            self.year_month_wise_redemptions.append({
                'index': index + 1,
                'month': '{current_year} {month}'.format(current_year=self.current_year, month=month),
                'redemption_count': 0,
                'redemptions': []
            })
        for point in self.all_points:
            self.lifetime_savings += point.get('gems_points')
            if point.get('created_date') >= self.first_day_of_current_month:
                self.current_month_savings += point.get('gems_points')
            self.total_redemptions += 1
            self.savings = point.get('gems_points')
            self.total_savings += self.savings
            self.gems_logo = ""
            index_date = point.get('created_date').month
            index = index_date - 1
            if self.year_month_wise_redemptions[index]:
                self.year_month_wise_redemptions[index]['redemption_count'] += 1
                if point['source'] == GlobalConstants.NBAD_PAY:
                    self.gems_logo = GlobalConstants.NBAD_PAY_GEMS_LOGO
                elif point['source'] == GlobalConstants.ENBD:
                    self.gems_logo = GlobalConstants.ENBD_GEMS_LOGO
                elif point['redemption_id'] and point['merchant_logo_url']:
                    self.gems_logo = point.get('merchant_logo_url')
                else:
                    self.gems_logo = GlobalConstants.GEMS_LOGO

                if point.get('redemption_id'):
                    if point.get('redemption_id') > 0:
                        self.code_redemption = point.get('redemption_id')
                        self.merchant = point.get('redemption_id')
                else:
                    self.code_redemption = point.get('source')
                    self.merchant = point.get('source')
                self.year_month_wise_redemptions[index]['redemptions'].append({
                    'id': point['id'],
                    'date': str(point.get('created_date').replace(tzinfo=datetime.timezone.utc).isoformat()),
                    'code': self.code_redemption,
                    'savings': self.savings,
                    'offer': '',
                    'outlet_id': 0,
                    'outlet': point.get('created_date').strftime('%d/%m/%Y'),
                    'merchant_id': 0,
                    'merchant': self.merchant,
                    'category': '',
                    'logo_url': self.gems_logo,
                    'icon_url': self.gems_logo
                })
        self.redemption_summary['total_redemptions'] = self.total_savings
        for monthly_redemptions in self.year_month_wise_redemptions:
            if monthly_redemptions['redemption_count'] > 0:
                self.months_having_redemptions.append(monthly_redemptions)
        self.months_having_redemptions.reverse()
        self.years_months_having_redemptions = self.months_having_redemptions
        self.redemption_summary['month_wise_redemmptions'] = self.years_months_having_redemptions

    def generate_final_response(self):
        """
        Generates final response
        :rtype: dict
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': self.redemption_summary,
            'message': '',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.setting_variables()
        self.initialize_repos()
        self.initialize_class_attributes()
        self.get_user_gems_points_history()
        self.generate_final_response()
