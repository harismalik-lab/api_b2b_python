"""
Sign up API for white label.
"""
import datetime
import uuid

from dateutil.parser import parse
from flask import current_app
from phpserialize import dumps as php_json_dumps

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BasePostResource
from common_white_label.common_helpers import CommonHelpers, get_current_date_time
from common_white_label.db import CONSOLIDATION, DEFAULT
from repositories_white_label.customer_device_repo import CustomerDeviceRepositoryWl
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.send_email_repo import SendEmailsRepository
from repositories_white_label.session_repo import SessionRepositoryWhiteLabel
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.wl_company_repo import WLCompany
from repositories_white_label.wl_crg_lookup_repo import WlCrgLookupRepository
from repositories_white_label.wl_gem_lookup_repo import WlGemLookupRepository
from repositories_white_label.wl_templates_repo import WLTemplatesRepository
from repositories_white_label.wl_user_group_repo import WlUserGroup
from repositories_white_label.wl_validtion_repo import WlValidationRepository
from white_labels_api.v1.sign_up_api.validation import user_sign_up_in_parser_white_label

__author__ = "Saqib"


class SignUpWLApi(BasePostResource):
    """
    @api {post} /v1/users Post Create new User
    @apiSampleRequest /v1/users
    @apiVersion 1.0.0
    @apiName SignUpWLApi
    @apiGroup Users
    @apiParam {String}                                      app_version                       Mobile app version
    @apiParam {String="ios","android", "web"}               __platform                        Mobile Platform
    @apiParam {String}                                      email                             Email address
    @apiParam {String}                                      password                          Customer password
    @apiParam {String}                                      confirm_password                  Confirm customer password
    @apiParam {String}                                      [device_model]                    Customer device model
    @apiParam {String}                                      [terms_acceptance]                User terms acceptance
    @apiParam {Boolean}                                     [using_branch_activation]         Using branch activation
    @apiParam {String}                                      [invoice_number]                  Emax invoice number
    @apiParam {String}                                      [device_key]                      Customer device key
    @apiParam {String}                                      [key]                             SMG provided key
    @apiParam {String}                                      [mobile_phone]                    Mobile phone number
    @apiParam {String}                                      [device_install_token]            Customer device install token
    @apiParam {String}                                      [device_uid]                      Device uid
    @apiParam {Boolean}                                     [is_privacy_policy_accepted]      Is privacy policy accepted
    @apiParam {Boolean}                                     [is_user_agreement_accepted]      Is user agreement accepted
    @apiParam {String}                                      [firstname]                       First name of the user
    @apiParam {String}                                      [lastname]                        Last name of the user
    @apiParam {String}                                      [country_of_residence]            User's country of residence
    @apiParam {String}                                      [gender]                          User's gender
    @apiParam {String}                                      [nationality]                     User's nationality
    @apiParam {String}                                      [date_of_birth]                   User's date of birth
    @apiParam {String}                                      [parent_id]                       Parent id
    @apiParam {String="en", "ar", "cn", "el", "de", "zh"}   [language]                        Response language
    """

    backup_request_args_for_exception = False
    request_parser = user_sign_up_in_parser_white_label
    response = {}
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='sign_up_api_white_label/sign_up_api_white_label.log',
        ),
        'name': 'sign_up_api_white_label'
    }
    logger = None
    status_code = 200
    connections_names = [DEFAULT, CONSOLIDATION]

    def populate_request_arguments(self):
        """
        Populates the request arguments
        """
        self.locale = self.request_args.get('language')  # language of the user
        self.is_social = self.request_args.get('social_registration')  # user is
        self.facebook_id = self.request_args.get('facebook')  # facebook id
        self.email = self.request_args.get('email')
        self.password = self.request_args.get('password')
        self.device_os = self.request_args.get('device_os')  # required (device_os)
        self.device_model = self.request_args.get('device_model')
        self.device_install_token = self.request_args.get('device_install_token')  # provided by app
        self.device_id = self.request_args.get('device_uid')  # unique id of the device
        self.app_version = self.request_args.get('app_version')
        self.nationality = self.request_args.get('nationality')
        self.date_of_birth = self.request_args.get('date_of_birth')
        self.device_key = self.request_args.get('device_key')
        self.affiliate_code = self.request_args.get('affiliate_code')
        self.location_id = self.request_args.get('location_id')
        self.first_name = self.request_args.get('firstname')
        self.last_name = self.request_args.get('lastname')
        self.country_of_residence = self.request_args.get('country_of_residence')
        self.confirm_password = self.request_args.get('confirm_password')
        self.gender = self.request_args.get('gender')
        self.mobile_phone = self.request_args.get('mobile_phone')
        self.using_branch_activation = self.request_args.get('using_branch_activation')
        self.wl_key = self.request_args.get('key')
        self.lat = self.request_args.get('lat')
        self.lng = self.request_args.get('lng')
        self.invoice_number = self.request_args.get('invoice_number')
        self.is_eula_agreed = self.request_args.get('is_eula_agreed')
        self.is_gdpr_agreed = self.request_args.get('is_gdpr_agreed')
        self.parent_id = self.request_args.get('parent_id')
        self.messages_locale = CommonHelpers.get_locale(self.locale, 0)
        self.company = self.request_args.get('wl_company')

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.customer_repo = CustomerProfileWhiteLabel()
        self.session_repo = SessionRepositoryWhiteLabel()
        self.wl_validation_repo = WlValidationRepository()
        self.wl_templates_repo = WLTemplatesRepository()
        self.wl_company_repo = WLCompany()
        # self.wl_invoice_headers_repo = WlInvoiceHeadersRepository()
        self.translation_manager = TranslationManager()
        self.customer_device_repo_instance = CustomerDeviceRepositoryWl()

    def initialize_repos_for_ip_activation(self):
        """
        Initializes the repos only for io base activation
        """
        self.wl_gem_lookup_repo = WlGemLookupRepository()
        self.wl_crg_lookup_repo = WlCrgLookupRepository()

    def setting_language_and_variables(self):
        """
        Sets the variables
        """
        # self.company = get_company()
        self.user_group = 1
        self.user_group_code = None
        self.user_group_logo = None
        self.number_of_offers = 0
        self.session_id = 0
        self.user_already_exist = False
        self.wl_key_already_validated = False

    def create_new_customer(self):
        """
        Creates the new customer
        """
        self.customer_id = self.customer_repo.create_new_customer(
            password=self.request_args.get('password'),
            email=self.request_args.get('email').lower(),
            firstname=self.request_args.get('firstname'),
            lastname=self.request_args.get('lastname'),
            country_of_residence=self.request_args.get('country_of_residence'),
            currency=self.request_args.get('currency'),
            default_currency=self.request_args.get('default_currency'),
            language=self.request_args.get('language'),
            gender=self.request_args.get('gender'),
            mobile_phone=self.request_args.get('mobile_phone'),
            nationality=self.request_args.get('nationality'),
            affiliate_code=self.request_args.get('affiliate_code'),
            date_of_birth=self.request_args.get('date_of_birth'),
            terms_acceptance=self.request_args.get('terms_acceptance'),
            do_not_email=self.request_args.get('do_not_email'),
            is_using_trial=False,
            is_social=self.is_social,
            company=self.company
        )

    def setting_language_and_variables_io_activation(self):
        """
        Sets the variables for IO Based
        """
        self.setting_language_and_variables()
        self.user_group = 0
        faqs_url = current_app.config.get('FAQS_WEB_URL')
        self.faqs_url = faqs_url.replace('{company}', self.company)
        self.is_valid_date_of_birth = True

    def check_for_company(self):
        """
        Checks the company express or student
        """
        if all([
            self.company.lower() == WLCompany.COMPANY_CODE_EXPRESS,
            not self.invoice_number
        ]):
            self.status_code = 422
            self.send_response_flag = True
            self.response = {
                "message": self.translation_manager.get_translation(
                    self.translation_manager.invoice_validation_invalid_code_message,
                    self.messages_locale
                ),
                "code": 70,
                "success": False
            }
            return self.send_response(self.response, self.status_code)

    def validate_customer_already_exist(self):
        """
        Validates the customer exists in the db or not
        """
        customer_exist = self.customer_repo.load_customer_by_email(self.email)
        if customer_exist:
            self.send_response_flag = True
            self.status_code = 422
            self.response = {
                "message": self.translation_manager.get_translation(
                    self.translation_manager.customer_with_this_email_address_already_exists,
                    self.messages_locale
                ),
                "success": False,
                "code": 90,
                "data": []
            }
            return self.send_response(self.response, self.status_code)
        else:
            invoice_validation_status = self.wl_invoice_headers_repo.validate_invoice_number(
                invoice_number=int(self.invoice_number),
                company=self.company,
                user_id=0,
                is_for_sign_up_or_sign_in=True
            )

            if invoice_validation_status != self.wl_invoice_headers_repo.VALID_STATUS:
                self.send_response_flag = True
                self.status_code = 400
                self.response = {
                    "message": self.wl_company_repo.get_invoice_validation_message(
                        invoice_validation_status,
                        self.locale
                    ),
                    "success": True,
                    "code": 90,
                    "data": {'validation_status': False}
                }
                return self.send_response(self.response, self.status_code)

    def validate_customer_created(self):
        """
        Validates if the customer already exists or not.
        """
        if not self.customer_id:
            self.send_response_flag = True
            self.status_code = 422
            self.response = {
                "message": self.translation_manager.get_translation(
                    self.translation_manager.user_creation_failed,
                    self.messages_locale
                ),
                "success": False,
                "code": 90
            }
            return self.send_response(self.response, self.status_code)

    def setting_invoice_and_customer_profile_and_products(self):
        """
        Sets the invoice number and the customer profile of the user.
        """
        self.invoice_lookup = self.wl_invoice_headers_repo.add_invoice_to_user(
            invoice_number=self.invoice_number,
            company=self.company,
            user_id=self.customer_id,
            email=self.email
        )
        self.customer_profile = self.customer_repo.load_customer_profile_by_user_id(self.customer_id)
        self.customer_profile = self.customer_repo.put_customer_in_trial_membership_if_qualifies(
            self.customer_profile
        )
        self.product_ids = self.customer_repo.get_customer_products(
            user_id=self.customer_id,
            company=self.company
        )

    def add_new_device(self, primary):
        """
        Adds new device
        """
        self.customer_device_repo_instance.create_new_record(
            customer_id=self.customer_id,
            device_install_token=self.device_install_token,
            device_os=self.device_os,
            device_model=self.device_model,
            session=self.session,
            primary=primary,
            device_id=self.device_id
        )

    def setting_device_related_data(self):
        """
        Sets the device related data.
        """
        devices_num = self.customer_device_repo_instance.count_devices_by_customer_id(
            self.customer_id, self.company
        )
        primary = 0 if devices_num else 1
        self.add_new_device(primary=primary)

    def returning_response(self):
        """
        Generating response and returning to main function
        """
        is_demographics_updated = self.customer_repo.is_demographics_updated(self.customer_id)
        self.status_code = 200
        self.send_response_flag = True
        data = {
            'message': "",
            'user_id': self.customer_id,
            'session_token': self.session_token,
            'member_type': self.customer_profile['new_member_group'],
            'currency': self.customer_profile['currency'],
            'new_user': False,
            'device_uid': self.device_id,
            'device_os': self.device_os,
            'device_model': self.device_model,
            'is_demographics_updated': is_demographics_updated,
            'user_group': self.user_group,
            'user_group_code': self.user_group_code,
            'user_group_logo': self.user_group_logo,
            'number_of_offers': self.number_of_offers,
            'user_already_exist': False
        }
        self.response = {
            "message": self.translation_manager.get_translation(
                self.translation_manager.success, self.locale
            ),
            'data': data,
            'success': True,
            "code": 0
        }
        return self.send_response(self.response, self.status_code)

    def post_invoice_based_users(self):
        """
        Process the request flow for IO base user.
        """
        self.check_email_password()
        if self.is_send_response_flag_on():
            return

        # check of valid email address is mase in request parser
        self.validate_customer_already_exist()
        if self.is_send_response_flag_on():
            return
        self.create_new_customer()
        self.validate_customer_created()
        if self.is_send_response_flag_on():
            return

        self.setting_invoice_and_customer_profile_and_products()
        self.setting_session_related_data()
        self.send_email_to_user()
        self.setting_device_related_data()
        self.returning_response()

    def set_customer_data_io_activation(self):
        """
        Sets the customer related data for io activation
        """
        self.customer_profile = self.customer_repo.load_customer_by_email(self.email)
        user_already_exist = True if self.customer_profile else False
        self.customer_id = self.customer_profile.get('id', 0)

        if user_already_exist:
            self.status_code = 200
            self.send_response_flag = True
            data = {
                'message': "",
                'user_id': self.customer_id,
                'user_already_exist_message': self.translation_manager.get_translation(
                    self.translation_manager.customer_with_this_email_address_already_exists,
                    self.messages_locale
                ),
                'user_already_exist': user_already_exist
            }
            self.response = {
                "message": self.translation_manager.get_translation(
                    self.translation_manager.success, self.locale
                ),
                'data': data,
                'success': True,
                "code": 0
            }
            return self.send_response(self.response, self.status_code)

    def check_look_up_based_company(self):
        """
        Checks the look up based company and then take action accordingly
        """
        if self.is_lookup_based_company:
            if self.company in [
                WLCompany.COMPANY_CODE_ENTERTAINER_GEMS,
                WLCompany.COMPANY_CODE_DUBAI_ENTERTAINMENTS,
                WLCompany.COMPANY_CODE_DHL
            ]:
                if not self.parent_id:
                    self.status_code = 422
                    self.send_response_flag = True
                    if self.company == WLCompany.COMPANY_CODE_DUBAI_ENTERTAINMENTS:
                        message = self.translation_manager.get_translation(
                            self.translation_manager.please_enter_valid_user_id_message,
                            self.messages_locale
                        )
                    else:
                        message = self.translation_manager.get_translation(
                            self.translation_manager.parent_id_is_required,
                            self.messages_locale
                        )
                    self.response = {
                        "message": message,
                        "code": 70,
                        "success": False
                    }
                    return self.send_response(self.response, self.status_code)

            self.look_up_data = None
            if self.company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
                self.look_up_data = self.wl_gem_lookup_repo.find_on_by_email(self.email, gems=True)
            elif self.company == WLCompany.COMPANY_CODE_ENTERTAINER_CRG:
                self.look_up_data = self.wl_gem_lookup_repo.find_on_by_email(self.email, crg=True)
            elif self.company == WLCompany.COMPANY_CODE_ENTERTAINER_NAAMA:
                self.look_up_data = self.wl_gem_lookup_repo.find_on_by_email(self.email, nama=True)
            elif self.company == WLCompany.COMPANY_CODE_DUBAI_ENTERTAINMENTS:
                self.look_up_data = self.wl_gem_lookup_repo.find_on_by_email(
                    self.email, dubai_ent=True, parent_id=self.parent_id, is_active=True
                )

            if not self.look_up_data:
                translation_message_identifier = \
                    self.translation_manager.you_are_not_allowed_to_access_this_application

                company_message_var = 'access_restricted_to_application_{}'.format(self.company.lower())
                if hasattr(self.translation_manager, company_message_var):
                    translation_message_identifier = getattr(self.translation_manager, company_message_var)
                self.status_code = 422
                self.send_response_flag = True
                self.response = {
                    "message": self.translation_manager.get_translation(
                        translation_message_identifier,
                        self.messages_locale
                    ),
                    "code": 70,
                    "success": False
                }
                return self.send_response(self.response, self.status_code)

            if self.company in [
                WLCompany.COMPANY_CODE_ENTERTAINER_GEMS,
                WLCompany.COMPANY_CODE_DUBAI_ENTERTAINMENTS
            ]:
                if any([
                    str(self.look_up_data.get('emp_code')).lower() != str(self.parent_id).lower(),
                    (self.company == WLCompany.COMPANY_CODE_DUBAI_ENTERTAINMENTS and
                     self.look_up_data.get('user_id') > 0)
                ]):
                    if self.company == WLCompany.COMPANY_CODE_DUBAI_ENTERTAINMENTS:
                        message = self.translation_manager.get_translation(
                            self.translation_manager.please_enter_valid_user_id_message,
                            self.messages_locale
                        )
                    else:
                        message = self.translation_manager.get_translation(
                            self.translation_manager.access_restricted_to_application_gem,
                            self.messages_locale
                        )
                    self.status_code = 422
                    self.send_response_flag = True
                    self.response = {
                        "message": message,
                        "code": 70,
                        "success": False
                    }
                    return self.send_response(self.response, self.status_code)

            try:
                date_of_birth_verify = datetime.datetime.strftime(self.date_of_birth, '%Y-%m-%d')
                look_up_data_dob = datetime.datetime.strftime(self.look_up_data.get('dob'), '%Y-%m-%d')
            except Exception:
                date_of_birth_verify = self.date_of_birth
                look_up_data_dob = self.look_up_data.get('dob')

            if (
                self.company == WLCompany.COMPANY_CODE_DUBAI_ENTERTAINMENTS and
                any([
                    not self.date_of_birth,
                    not self.look_up_data.get('dob'),
                    date_of_birth_verify != look_up_data_dob
                ])
            ):
                self.status_code = 422
                self.send_response_flag = True
                self.response = {
                    "message": "Please enter a valid Date of Birth",
                    "code": 70,
                    "success": False
                }
                return self.send_response(self.response, self.status_code)

            if self.look_up_data.get('user_group'):
                self.user_group = self.look_up_data.get('user_group')
            else:
                self.user_group = WlUserGroup.DEFAULT_USER_GROUP
        elif self.wl_company_repo.get_pre_activated_apps(self.company):
            self.wl_validation_status = self.wl_validation_repo.validate_key(
                self.wl_key,
                self.company,
                self.email
            )
            if self.wl_validation_status == self.wl_validation_repo.INVALID_KEY:
                self.status_code = 422
                self.send_response_flag = True
                self.response = {
                    "message": self.translation_manager.get_translation(
                        self.translation_manager.imie_number_not_valid,
                        self.messages_locale
                    ),
                    "code": 70,
                    "success": False
                }
                return self.send_response(self.response, self.status_code)
        elif self.company != WLCompany.COMPANY_CODE_DU:
            number_of_valid_keys = self.wl_validation_repo.get_number_of_valid_keys(self.company, self.email)
            if number_of_valid_keys < 1:
                self.status_code = 422
                self.send_response_flag = True
                self.response = {
                    "message": self.translation_manager.get_translation(
                        self.translation_manager.you_are_not_allowed_to_access_this_application,
                        self.messages_locale
                    ),
                    "code": 70,
                    "success": False
                }
                return self.send_response(self.response, self.status_code)

    def setting_email_template_id(self):
        """
        Sets the email template id of the email to be send to user.
        """
        if self.company.lower() == WLCompany.COMPANY_CODE_ENTERTAINER_HSBC:
            self.email_template_id = 550
            if self.user_group == 2:
                self.email_template_id = 553
        else:
            # Get Email Template Based on the Company and User Group
            self.email_template_id = self.wl_templates_repo.get_template_by_company_and_type(
                self.company,
                self.wl_templates_repo.ACTIVATION_OF_TRAIL,
                self.user_group
            )

    def set_look_up_data(self):
        """
        Sets the customer lookup data
        """
        if self.look_up_data:
            self.look_up_data['user_id'] = self.customer_id
            if self.company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
                self.wl_gem_lookup_repo.update_user_data(self.customer_id, gems=True)
            elif self.company == WLCompany.COMPANY_CODE_ENTERTAINER_CRG:
                self.wl_gem_lookup_repo.update_user_data(self.customer_id, crg=True)
            elif self.company == WLCompany.COMPANY_CODE_ENTERTAINER_NAAMA:
                self.wl_gem_lookup_repo.update_user_data(self.customer_id, nama=True)
            elif self.company == WLCompany.COMPANY_CODE_DUBAI_ENTERTAINMENTS:
                self.wl_gem_lookup_repo.update_user_data(self.customer_id, dubai_ent=True)
                self.wl_gem_lookup_repo.update_user_data(self.customer_id, gems=True)
            elif self.company == WLCompany.COMPANY_CODE_ENTERTAINER_CRG:
                self.wl_gem_lookup_repo.update_user_data(self.customer_id, crg=True)
            elif self.company == WLCompany.COMPANY_CODE_ENTERTAINER_NAAMA:
                self.wl_gem_lookup_repo.update_user_data(self.customer_id, nama=True)
            elif self.company == WLCompany.COMPANY_CODE_DUBAI_ENTERTAINMENTS:
                self.wl_gem_lookup_repo.update_user_data(self.customer_id, dubai_ent=True)
            if self.company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
                self.wl_gem_lookup_repo.update_gem_points(
                    customer_id=self.customer_id,
                    email=self.email
                )

    def assign_key_to_customer_normal_flow(self):
        """
        Assigns key to customer
        """
        prefix = self.wl_company_repo.get_key_prefix_by_company(self.company)
        self.wl_key = self.wl_company_repo.generate_unique_id(prefix, 7)
        if self.wl_key:
            self.wl_validation_repo.assign_key_to_customer(
                self.wl_key,
                self.company,
                self.email,
                self.user_already_exist,
                self.customer_id
            )

    def assign_key_to_customer_io_based(self):
        """
        Assigns a key to the customer
        """
        self.assign_key_to_customer = False
        is_multiple_subscription_allowed = self.wl_company_repo.get_company_multiple_status(self.company)

        validation_response = self.wl_validation_repo.validate_key(
            self.wl_key, self.company, self.email
        )
        number_of_keys = self.wl_validation_repo.get_number_of_valid_keys(self.company, self.email)

        # Key is not Active or Assigned to Other Customer
        if validation_response == self.wl_validation_repo.INVALID_KEY:
            self.status_code = 422
            self.send_response_flag = True
            self.response = {
                "message": self.translation_manager.get_translation(
                    self.translation_manager.invalid_wl_key_with_branch,
                    self.messages_locale
                ),
                "code": 70,
                "success": False
            }
            return self.send_response(self.response, self.status_code)

        # Key is Active and Assigned to this Customer
        if validation_response == self.wl_validation_repo.ALREADY_ACTIVATED_VALID_KEY:
            pass

        # Key is Active and Not Assigned to anyone
        if validation_response == self.wl_validation_repo.UNUSED_VALID_KEY:
            if not is_multiple_subscription_allowed and number_of_keys > 0:
                self.status_code = 422
                self.send_response_flag = True
                self.response = {
                    "message": self.translation_manager.get_translation(
                        self.translation_manager.you_have_already_activated_the_app_for_multiple_keys_not_allowed,
                        self.messages_locale
                    ),
                    "code": 70,
                    "success": False
                }
                return self.send_response(self.response, self.status_code)
            self.assign_key_to_customer = True

    def setting_customer_data_io_based_user(self):
        """
        Sets the customer related data of the user based on io
        """
        if not self.customer_id:
            self.status_code = 422
            self.send_response_flag = True
            self.response = {
                "message": self.translation_manager.get_translation(
                    self.translation_manager.user_creation_failed,
                    self.messages_locale
                ),
                "code": 90,
                "success": False
            }
            return self.send_response(self.response, self.status_code)
        self.customer_profile = self.customer_repo.load_customer_profile_by_user_id(self.customer_id)
        self.customer_profile = \
            self.customer_repo.put_customer_in_trial_membership_if_qualifies(customer_profile=self.customer_profile)

    def assigning_key_and_send_email(self):
        """
        Assigns a key and then sends the email to user.
        """
        if self.assign_key_to_customer:
            self.wl_validation_repo.assign_key_to_customer(
                wl_key=self.wl_key,
                company=self.company,
                email=self.email,
                is_customer_exists=True,
                customer_id=self.customer_id
            )
            # Get User_Group Id
            self.user_group = self.wl_validation_repo.get_user_group_id_by_key(self.wl_key, self.company)
            self.email_template_id = 0
            self.setting_email_template_id()
            optional_data = php_json_dumps({})
            email_data = php_json_dumps({'user_id': self.customer_id})
            self.customer_repo.send_email(
                email_type_id=self.email_template_id,
                email_data=email_data.decode(errors='ignore'),
                email=self.email,
                language=self.locale,
                dump=False,
                priority=SendEmailsRepository.Priority_High,
                optional_data=optional_data.decode(errors='ignore')
            )
        self.wl_validation_repo.update_customer_validation(
            self.company,
            self.email,
            self.customer_id
        )

    def generate_final_response_io_based_user(self):
        """
        Generates the response on the based of the user.
        """
        is_demographics_updated = self.customer_repo.is_demographics_updated(self.customer_id)
        self.status_code = 200
        self.send_response_flag = True
        data = {
            'message': "",
            'user_id': self.customer_id,
            'session_token': self.session_token,
            'member_type': self.customer_profile['new_member_group'],
            'currency': self.customer_profile['currency'],
            'new_user': False,
            'device_uid': self.device_id,
            'device_os': self.device_os,
            'device_model': self.device_model,
            'is_demographics_updated': is_demographics_updated,
            'pop_up_screen_upon_successful_activation': "",
            'user_group': self.user_group,
            'user_group_code': self.user_group_code,
            'user_group_logo': self.user_group_logo,
            'number_of_offers': self.number_of_offers,
            'user_already_exist': False,
            'user_already_exist_message': ""
        }
        self.response = {
            "message": self.translation_manager.get_translation(
                self.translation_manager.success, self.locale
            ),
            'data': data,
            'success': True,
            "code": 0
        }
        return self.send_response(self.response, self.status_code)

    def post_users_branch_io_based_activations(self):
        """
        IO based activation implementation.
        """
        self.initialize_repos_for_ip_activation()
        self.set_customer_data_io_activation()
        if self.is_send_response_flag_on():
            return

        self.setting_language_and_variables_io_activation()
        self.check_date_of_birth()
        if self.is_send_response_flag_on():
            return

        self.check_email_password()
        # valid email address already checked at the request parser level.

        self.assign_key_to_customer_io_based()
        self.create_new_customer()
        self.validate_customer_created()
        self.setting_customer_data_io_based_user()
        self.assigning_key_and_send_email()

        self.product_ids = self.customer_repo.get_customer_products(
            user_id=self.customer_id, company=self.company
        )
        self.setting_session_related_data()
        self.add_new_device(primary=1)
        self.generate_final_response_io_based_user()

    def setting_mobile_phone_of_user(self):
        """
        Setting the mobile phone of the user.
        """
        # Insert mobile number for Hutson
        if self.company == WLCompany.COMPANY_CODE_ENTERTAINER_HUT and self.mobile_phone:
            data = {'mobile_phone': self.mobile_phone}
            self.customer_repo.update_customer_profile_by_id(self.customer_id, data=data)

    def setting_pop_up_screen_message(self):
        """
        Sets the screen pop up message.
        """
        # Entertainer Life
        self.pop_up_screen_upon_successful_activation = ""
        if self.company == WLCompany.COMPANY_CODE_ENTERTAINER_LIFE:
            if self.user_group == 1 or self.user_group == 2:
                self.pop_up_screen_upon_successful_activation = self.translation_manager.get_translation(
                    self.translation_manager.elf_pop_up_screen_upon_successful_activation,
                    self.messages_locale
                )
            elif self.user_group == 3 or self.user_group == 4:
                self.pop_up_screen_upon_successful_activation = self.translation_manager.get_translation(
                    self.translation_manager.elf_pop_up_screen_upon_successful_activation_30_june_2018,
                    self.messages_locale
                )
            elif self.user_group == 5 or self.user_group == 6:
                self.pop_up_screen_upon_successful_activation = self.translation_manager.get_translation(
                    self.translation_manager.elf_pop_up_screen_upon_successful_activation_30_dec_2018,
                    self.messages_locale
                )

    def setting_user_exist_message(self):
        """
        Sets the user exist message
        """
        self.user_already_exist_message = ""
        if self.user_already_exist:
            self.user_already_exist_message = self.translation_manager.get_translation(
                self.translation_manager.user_already_registered_gems_message,
                self.messages_locale
            )

    def initialize_repos_for_normal_flow(self):
        """
        Initializing the repos for normal flow of sign up.
        """
        # self.wl_gem_lookup_repo = WlGemLookupRepository()
        # self.wl_crg_lookup_repo = WlCrgLookupRepository()
        # self.wl_user_custom_info_repo = WLUserCustomInfoRepository()

    def setting_language_and_variables_normal_flow(self):
        """
        Sets the variables for normal flow
        """
        self.setting_language_and_variables()
        self.user_group = 1
        self.messages_locale = CommonHelpers.get_locale(self.locale, 0)
        self.number_of_valid_keys = 0
        self.look_up_data = {}
        self.wl_validation_status = self.wl_validation_repo.INVALID_KEY
        if self.date_of_birth:
            self.date_of_birth = parse(self.date_of_birth)
        self.is_valid_date_of_birth = True
        self.user_already_exist = False
        self.wl_key_already_validated = False
        # self.is_lookup_based_company = self.wl_company_repo.is_lookup_based_company(self.company)
        # self.is_required_to_pick_fname_lname_from_lookup = self.wl_company_repo.is_required_to_pick_name_from_lookup(self.company)  # noqa
        if self.device_key:
            self.device_id = self.device_key
        self.session = {}

    def check_date_of_birth(self):
        """
        Checks the date of birth of the user
        """
        try:
            if self.date_of_birth and isinstance(self.date_of_birth, datetime.datetime):
                if self.date_of_birth > parse(get_current_date_time()):
                    self.is_valid_date_of_birth = False
        except Exception:
            self.is_valid_date_of_birth = False

        if not self.is_valid_date_of_birth:
            self.status_code = 422
            self.send_response_flag = True
            self.response = {
                "message": self.message_repo_instance.get_message_by_code(
                    self.message_repo_instance.invalid_dob, self.messages_locale),
                "code": 90,
                "success": False
            }
            return self.send_response(self.response, self.status_code)

    def check_email_password(self):
        """
        Checks email and the password of user
        """
        if not self.email:
            self.status_code = 422
            self.send_response_flag = True
            self.response = {
                "message": self.translation_manager.get_translation(
                    self.translation_manager.email_password_required,
                    self.messages_locale
                ),
                "code": 70,
                "success": False
            }
            return self.send_response(self.response, self.status_code)

    def load_customer_related_data_normal_flow(self):
        """
        Loads the customer and then login the user.
        """
        custom_express_info = False
        customer_profile_info = False
        self.customer = self.customer_repo.load_customer_by_email(self.email)
        if self.customer:
            customer_profile_info = True
            # Checks the user info in user_custom table
            custom_express_info = self.customer_repo.get_user_from_custom_table(
                user_id=self.customer.get('id'),
                company=self.company
            )
            # if info exist in user custom table
            if custom_express_info:
                self.user_already_exist = True
                self.status_code = 422
                self.send_response_flag = True
                self.response = {
                    "message": self.translation_manager.get_translation(
                        self.translation_manager.customer_with_this_email_address_already_exists,
                        self.messages_locale
                    ),
                    "code": 90,
                    "success": False
                }
                return self.send_response(self.response, self.status_code)
        profile_customer_id = 0
        if self.customer:
            # getting the customer id from customer profile if the profile exists
            profile_customer_id = self.customer.get('id')
        if not custom_express_info:
            self.customer_id = self.customer_repo.create_new_customer(
                password=self.password,
                email=self.email,
                status=10,
                is_customer=1,
                firstname=self.first_name,
                lastname=self.last_name,
                country_of_residence=self.country_of_residence,
                company=self.company,
                customer_profile_info=customer_profile_info,
                profile_customer_id=profile_customer_id
            )
            self.validate_customer_created()

    def setting_customer_data_normal_flow(self):
        """
        Sets the customer related data of the user in normal flow
        """
        self.customer_profile = self.customer_repo.load_customer_profile_by_id(self.customer_id)
        self.product_ids = self.customer_repo.get_customer_products(user_id=self.customer_id, company=self.company)

    def send_email_to_user(self):
        """
        User is created send email to user
        """
        self.user_group = self.wl_validation_repo.get_user_group(self.company, self.customer_id)
        if self.user_group and isinstance(self.user_group, dict):
            self.user_group = self.user_group.get('user_group')
        self.setting_email_template_id()
        optional_data = php_json_dumps({'{FIRST_NAME}': self.first_name})
        email_data = php_json_dumps({'user_id': self.customer_id})
        self.customer_repo.send_email(
            email_type_id=self.email_template_id,
            email_data=email_data.decode(errors='ignore'),
            email=self.email,
            language=self.locale,
            priority=SendEmailsRepository.Priority_Medium,
            dump=False,
            optional_data=optional_data.decode(errors='ignore')
        )

    def setting_session_related_data(self):
        """
        Sets the session related data of the user.
        """
        session_token = self.session_repo.generate_session(
            customer_id=self.customer_id,
            product_ids=self.product_ids,
            app_version=self.app_version,
            company=self.company,
            last_row=True
        )
        self.session = self.session_repo.find_by_token(session_token=session_token, company=self.company)
        if self.session:
            self.session_id = self.session.get('id')
            self.session_token = self.session.get('session_token')

        self.session_repo.adding_entry_in_session_addendum_table(
            session_id=self.session_id, user_id=self.customer_id,
            device_key=self.device_key, device_os=self.device_os,
            device_model=self.device_model, device_language=self.locale,
            lat=self.lat, lng=self.lng, company=self.company
        )

    def set_device_related_info_normal_flow(self):
        """
        Sets the device information
        """
        if not self.wl_key_already_validated:
            device_info = self.customer_device_repo_instance.find_one_by_device_id_and_customer_id(
                customer_id=self.customer_id,
                device_id=self.device_id,
                company=self.company
            )
            if not device_info:
                self.setting_device_related_data()
        else:
            self.add_new_device(primary=1)

    def setting_user_group_info(self):
        """
        Sets the user group related information
        """
        if self.company == WLCompany.COMPANY_CODE_EXPRESS:
            self.user_group_info = WlUserGroup().get_group_info(self.user_group, self.company)
            if self.user_group_info:
                self.user_group_code = self.user_group_info["code"]
                self.user_group_logo = self.user_group_info["logo"] if self.user_group_info.get("logo") else ""
                if self.user_group_info.get('number_of_offers'):
                    self.number_of_offers = self.user_group_info["number_of_offers"]
                else:
                    self.number_of_offers = 0
            # self.user_group = self.user_group_code

    def set_wl_validation_data(self):
        """
        Sets the data on the basis of the white label validation.
        """
        prefix = self.wl_company_repo.get_key_prefix_by_company(self.company)
        unique_string = str(uuid.uuid4())
        self.wl_key = '{prefix}-{time_string}'.format(prefix=prefix, time_string=unique_string[:16])
        wl_validation_data = {
            'wl_key': self.wl_key,
            'wl_company': self.company,
            'email': self.email,
            'isused': True,
            'activation_date': datetime.datetime.now(),
            'active': True,
            'user_group': self.user_group,
            'existing': True,
            'customer_id': self.customer_id
        }
        self.wl_validation_repo.new_wl_validation_record(changes=wl_validation_data)

    def generating_final_response(self):
        """
        Generating the final response in normal flow case.
        """
        self.status_code = 200
        self.send_response_flag = True
        self.pop_up_screen_upon_successful_activation = ''
        data = {
            "resend_invite_section": {
                "title": "Thank you for registering",
                "message": self.translation_manager.get_translation(
                    self.translation_manager.EMAIL_VERIFICATION_ON_REGISTER,
                    self.messages_locale
                ),
                "button_text": "OK",
                "show_success_popup": 1,
                'show_continue_button': False,
                'user_id': self.customer_id,
                'email': self.email
            }
        }
        self.response = {
            "message": 'success',
            'data': data,
            'success': True,
            "code": 0
        }
        return self.send_response(self.response, self.status_code)

    def normal_flow_of_sign_up(self):
        """
        Normal flow of user's sign up
        """
        self.initialize_repos_for_normal_flow()
        self.setting_language_and_variables_normal_flow()
        self.check_date_of_birth()
        self.check_email_password()
        self.load_customer_related_data_normal_flow()
        if self.is_send_response_flag_on():
            return
        self.set_wl_validation_data()
        self.setting_customer_data_normal_flow()
        self.send_email_to_user()
        # self.setting_session_related_data()
        self.set_device_related_info_normal_flow()
        self.setting_user_group_info()
        self.generating_final_response()

    def process_request(self):
        self.initialize_repos()
        self.setting_language_and_variables()
        # self.check_for_company()
        if self.is_send_response_flag_on():
            return

        # self.setting_device_id()
        # Flow of invoice number based apps sign up
        # if self.invoice_number:
        #     self.post_invoice_based_users()
        #     if self.is_send_response_flag_on():
        #         return
        #
        # # Flow of IO based sign up
        # if all([
        #     self.using_branch_activation,
        #     self.wl_key
        # ]):
        #     self.post_users_branch_io_based_activations()
        #     if self.is_send_response_flag_on():
        #         return

        # Flow for normal sign up
        self.normal_flow_of_sign_up()
