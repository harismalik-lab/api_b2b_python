"""
validation params of configurations connectivity
"""
from common_white_label.common_helpers import get_request_parser

config_connectivity_parser = get_request_parser()

