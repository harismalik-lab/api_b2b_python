"""
Configurations connectivity api white label
"""
from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from repositories_white_label.translations_repo import TranslationManager
from white_labels_api.v1.config_connectivity.validation import config_connectivity_parser


class ConfigConnectivityApiWL(BaseGetResource):
    """
    @api {get} /v1/configurations/connectivity Get Configurations Connectivity
    @apiSampleRequest /v1/configurations/connectivity
    @apiVersion 1.0.0
    @apiName ConfigConnectivity
    @apiGroup Configurations
    """
    request_parser = config_connectivity_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='config_connectivity_api/config_connectivity_api.log',
        ),
        'name': 'config_connectivity_api'
    }

    def initialize_class_attributes(self):
        """
        Initialize class attributes of config api
        """
        self.translation_manager = TranslationManager()

    def prepare_response(self):
        """
        Sets final response of config connectivity
        :rtype: dict
        """
        try:
            self.send_response_flag = True
            self.response = {
                'success': True,
                'message': 'success',
                'data': []
            }
            self.status_code = 200
            return self.send_response(self.response, self.status_code)
        except Exception:
            self.send_response_flag = True
            self.status_code = 500
            self.response = {"msg": "Internal Server Error"}

    def process_request(self):
        """
        Handle response for config connectivity
        """
        self.initialize_class_attributes()
        self.prepare_response()
