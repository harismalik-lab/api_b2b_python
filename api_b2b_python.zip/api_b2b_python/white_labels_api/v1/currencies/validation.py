"""
Validation params of currency api
"""

from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import device_list, language

currencies_parser = get_request_parser()

currencies_parser.add_argument(
    'language',
    type=language,
    required=False,
    default='en',
    location=['mobile', 'values', 'json'],
)
currencies_parser.add_argument(
    '__platform',
    type=device_list,
    default='',
    required=True,
    location=['mobile', 'values', 'json']
)
currencies_parser.add_argument(
    'app_version',
    type=str,
    required=True,
    default='',
    location=['mobile', 'values', 'json'],
)
