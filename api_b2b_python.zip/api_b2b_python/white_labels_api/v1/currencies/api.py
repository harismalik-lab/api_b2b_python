"""
Currency api white label
"""
from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from common_white_label.common_helpers import CommonHelpers
from repositories_white_label.wl_company_repo import WLCompany
from white_labels_api.v1.currencies.validation import currencies_parser


class CurrenciesApi(BaseGetResource):
    """
    @api {get} /v1/currencies Get Currencies
    @apiSampleRequest /v1/currencies
    @apiVersion 1.0.0
    @apiName currencies
    @apiGroup Configurations
    @apiParam {String}                                        app_version             Mobile app version
    @apiParam {String="ios","android", "web"}                 __platform              Mobile Platform
    @apiParam {String="en", "ar", "cn", "el", "de", "zh"}     [language]              Response language
    """
    request_parser = currencies_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='currencies_api/currencies_api.log',
        ),
        'name': 'currencies_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')

    def initialize_class_attributes(self):
        """
        Sets variables for api
        """
        self.locale = CommonHelpers.get_locale(self.locale)
        self.wl_company_repo = WLCompany()

    def get_currencies(self):
        """
        Gets validation status of device
        """
        self.currencies = self.wl_company_repo.get_currencies(self.locale)

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': {'currencies': self.currencies},
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.initialize_class_attributes()
        self.get_currencies()
        self.generate_final_response()
