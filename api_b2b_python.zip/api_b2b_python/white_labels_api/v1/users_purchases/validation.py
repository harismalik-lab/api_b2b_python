"""
Validation for user purchases api
"""
from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import currency, device_list, language

user_purchases_parser = get_request_parser()

user_purchases_parser.add_argument(
    name="session_token",
    type=str,
    required=False,
    location=['mobile', 'values', 'json']
)
user_purchases_parser.add_argument(
    'app_version',
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
user_purchases_parser.add_argument(
    'location_id',
    type=int,
    required=False,
    location=['mobile', 'values', 'json']
)
user_purchases_parser.add_argument(
    'offset',
    type=int,
    default=0,
    required=False,
    location=['mobile', 'values', 'json']
)

user_purchases_parser.add_argument(
    'limit',
    type=int,
    default=0,
    required=False,
    location=['mobile', 'values', 'json']
)
user_purchases_parser.add_argument(
    'currency',
    required=False,
    type=currency,
    default='USD',
    location=['mobile', 'values', 'json']
)
user_purchases_parser.add_argument(
    '__platform',
    type=device_list,
    required=True,
    location=['mobile', 'values', 'json']
)
user_purchases_parser.add_argument(
    'language',
    type=language,
    default='en',
    required=False,
    location=['mobile', 'values', 'json']
)
