"""
User purchases api
"""

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from common_white_label.common_helpers import CommonHelpers, get_formated_date
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.translations_repo import TranslationManager
from user_authentication_white_label.authentication import get_company, get_current_customer
from white_labels_api.v1.users_purchases.validation import user_purchases_parser


class GetUserPurchasesWl(BaseGetResource):
    """
    @api {get} /v1/users/purchases Get User purchases history
    @apiSampleRequest /v1/users/{user_id}/purchases
    @apiVersion 1.0.0
    @apiName GetUserPurchasesWl
    @apiGroup Users
    @apiParam {String}                              currency            Currency
    @apiParam {String="ios","android","web"}        __platform          All supported platform
    @apiParam {String}                              app_version         Mobile App Version
    @apiParam {Integer}                             [limit]             Limit
    @apiParam {Integer}                             [offset]            Offset
    @apiParam {String="en", "ar", "cn", "el","zh"}  [language]          Response Language
    """
    request_parser = user_purchases_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='get_user_purchases_api/get_user_purchases_api.log',
        ),
        'name': 'get_user_purchases_api'
    }
    strict_token = True
    required_token = True

    def populate_request_arguments(self):
        """
        Setting the arguments
        """
        self.locale = self.request_args.get('language')
        self.currency = self.request_args.get('currency')
        self.limit = self.request_args.get('limit')
        self.offset = self.request_args.get('offset')

    def initialize_repos(self):
        """
        Initializing the repos
        """
        self.customer_repo = CustomerProfileWhiteLabel()
        self.translation_manager = TranslationManager()

    def initialize_class_attributes(self):
        """
        Initialize class attributes
        """
        self.customer = get_current_customer()
        self.customer_id = self.customer.get('customer_id')
        self.messages_locale = CommonHelpers.get_locale(self.locale, location_id=0)
        self.company = get_company()

    def validate_customer(self):
        """
        Validates customer against providing user_id
        :rtype: dict
        """
        # if str(self.customer_id) != str(self.user_id):
        if not self.customer_id:
            self.send_response_flag = True
            self.status_code = 403
            self.response = {
                "message": self.translation_manager.get_translation(
                    self.translation_manager.you_are_not_allowed_to_access_this_application,
                    self.messages_locale
                ),
                "success": False,
                "code": 90
            }
            return self.send_response(self.response, self.status_code)

    def get_customer_purchases(self):
        """
        Gets customer purchases
        """
        self.purchases = self.customer_repo.get_customer_digital_orders_purchase_history(
            user_id=self.customer_id,
            locale=self.locale,
            currency=self.currency,
            company=self.company
        )

    def generate_response_on_no_purchases_available(self):
        """
        Generates response on no purchases available
        :rtype: dict
        """
        if not self.purchases:
            self.send_response_flag = True
            self.status_code = 200
            self.response = {
                "message": self.translation_manager.get_translation(
                    self.translation_manager.no_data_available,
                    self.messages_locale
                ),
                "success": False,
                "data": []
            }
            return self.send_response(self.response, self.status_code)

    def setting_purchases_and_data(self):
        """
        Setting purchases and data
        """
        self.purchases.reverse()
        if self.limit <= 0:
            self.limit = len(self.purchases)
        else:
            self.limit = self.limit + self.offset
        self.data = self.purchases[self.offset: self.limit]
        for date in self.data:
            date['date'] = get_formated_date(date['date'])
            date['date'] = str(date['date'])

    def generate_final_response(self):
        """
        Generates final response
        :rtype: dict
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            "message": 'success',
            "data": self.data,
            "success": True
        }

    def process_request(self, *args, **kwargs):
        """
        Process the request
        """
        self.initialize_repos()
        self.initialize_class_attributes()
        # self.user_id = kwargs.get('user_id')
        self.validate_customer()
        if self.is_send_response_flag_on():
            return
        self.get_customer_purchases()
        self.generate_response_on_no_purchases_available()
        if self.is_send_response_flag_on():
            return

        self.setting_purchases_and_data()
        self.generate_final_response()
