"""
Validates Api
"""
import datetime

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BasePostResource
from common_white_label.common_helpers import CommonHelpers
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.session_repo import SessionRepositoryWhiteLabel
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.wl_company_repo import WLCompany
from repositories_white_label.wl_custom_product_repo import WLCustomProductRepository
from repositories_white_label.wl_send_email_repository import WlSendEmailsRepository
from repositories_white_label.wl_templates_repo import WLTemplatesRepository
from repositories_white_label.wl_user_group_repo import WlUserGroup
from repositories_white_label.wl_validtion_repo import WlValidationRepository
from user_authentication_white_label.authentication import get_company
from white_labels_api.v1.validates_api.validation import validates_parser


class PostValidatesActionApi(BasePostResource):
    """
    @api {post} /v1/validates Post Validates.
    @apiSampleRequest /v1/validates
    @apiVersion 1.0.0
    @apiName Validates
    @apiGroup Validate Key
    @apiParam {String}                                  email                       User Email
    @apiParam {String}                                  key                         Validation Key
    @apiParam {Boolean}                                 is_secondary_key            Check Secondary Key
    @apiParam {Boolean}                                 afterlogin                  Afterlogin Check
    @apiParam {String="en", "ar", "cn", "el","zh"}      [language]                  Response Language
    @apiParam {Boolean}                                 [using_branch_activation]   Using Branch Activation
    """
    request_parser = validates_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='validates_api/validates_api.log',
        ),
        'name': 'validates_api'
    }

    def populate_request_arguments(self):
        """
        Add request arguments of config api
        """
        self.locale = self.request_args.get('language')
        self.email = self.request_args.get('email')
        self.key = self.request_args.get('key')
        self.is_secondary_key = self.request_args.get('is_secondary_key')
        self.after_login = self.request_args.get('afterlogin')
        self.using_branch_activation = self.request_args.get('using_branch_activation')

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.wl_validation_repo = WlValidationRepository()
        self.customer_repo = CustomerProfileWhiteLabel()
        self.company_repo = WLCompany()
        self.wl_templates_repo = WLTemplatesRepository()
        self.session_repo = SessionRepositoryWhiteLabel()
        self.translation_repo = TranslationManager()
        self.user_group_repo = WlUserGroup()
        self.wl_custom_product_repo = WLCustomProductRepository()

    def setting_variables(self):
        """
        Sets variables for api
        """
        self.company = get_company()
        self.locale = CommonHelpers.get_locale(self.locale)
        self.is_key_validated = False
        self.is_customer_exists = False
        self.message = self.translation_repo.get_translation(self.translation_repo.invalid_wl_key, self.locale)
        self.customer_id = 0
        self.existing_user_id = 0
        self.product_to_purchase = False
        self.email_data = {'user_id': 0}
        self.email_data_optional = {}
        self.insert_new_key = False
        self.update_existing_key = False
        self.user_group = False
        self.user_group_code = ""
        self.user_group_logo = ""
        self.number_of_offers = 0
        self.is_bin_code_valid = False

        if self.company.lower() == WLCompany.COMPANY_CODE_DU:
            self.email_data_optional = {'custom_message': ''}

        if self.is_secondary_key or self.after_login:
            self.is_secondary_key = True

    def validate_master_card_key(self, key, email, locale='en'):
        bin = key[0:6]
        company = WLCompany.COMPANY_CODE_MASTER_CARDS
        email_data = {'user_id': 0}
        email_data_optional = {}
        number_of_offers = 0
        user_group_logo = ''
        user_group_code = ''
        message = ''
        user_group = self.wl_validation_repo.get_user_group_mce(_bin=bin)
        if user_group:
            self.is_bin_code_valid = True
        validation_response = self.wl_validation_repo.validate_key_mce(wl_key=key, email=email)
        if validation_response == self.wl_validation_repo.ALREADY_ACTIVATED_VALID_KEY:
            if self.is_bin_code_valid:
                self.update_existing_key = True
                self.is_key_validated = True
                message = self.translation_repo.get_translation(
                    self.translation_repo.you_have_successfully_activated_the_key,
                    locale
                )
            else:
                self.is_key_validated = True
                message = self.translation_repo.get_translation(
                    self.translation_repo.you_have_successfully_activated_the_key,
                    locale
                )
        if validation_response == self.wl_validation_repo.KEY_NOT_EXISTS:
            if self.is_bin_code_valid:
                self.number_of_keys = self.wl_validation_repo.get_number_of_valid_keys_mce(email)
                if self.number_of_keys > 0:
                    self.update_existing_key = True
                    self.is_key_validated = True
                    message = self.translation_repo.get_translation(
                        self.translation_repo.you_have_successfully_activated_the_key,
                        locale
                    )

                self.insert_new_key = True
                self.is_key_validated = True
                message = self.translation_repo.get_translation(
                    self.translation_repo.you_have_successfully_activated_the_key,
                    locale
                )
            else:
                self.is_key_validated = False
                message = self.translation_repo.get_translation(
                    self.translation_repo.bin_key_is_not_valid,
                    locale
                )
        if self.is_key_validated:
            customer = self.customer_repo.load_customer_by_email(email)
            if customer:
                customer_id = customer.get('id', 0)
                self.is_customer_exists = True
                email_data['user_id'] = customer.get('id', 0)
            if not user_group:
                user_group = self.wl_validation_repo.get_user_group_id_by_key(key, company)
            user_group_info = self.user_group_repo.get_group_info(user_group, company)
            if user_group_info:
                user_group_code = user_group_info.get('code', '')
                if user_group_info.get('logo', ''):
                    user_group_logo = user_group_info.get('logo')
                if user_group_info.get('numberOffers', ''):
                    number_of_offers = user_group_info.get('numberOffers')
            if self.insert_new_key or self.update_existing_key:
                if self.update_existing_key:
                    wl_validation = self.wl_validation_repo.get_validation_object_mce(email)
                else:
                    wl_validation = {
                        'invalid_key_customer_does_not_exists': "00",
                        'invalid_key_customer_exists': "01",
                        'valid_key_customer_does_not_exists': "10",
                        'valid_key_customer_exists': "11",
                        'INACTIVE_KEY': -1,
                        'INVALID_KEY': 0,
                        'UNUSED_VALID_KEY': 1,
                        'ALREADY_ACTIVATED_VALID_KEY': 2,
                        'KEY_NOT_EXISTS': 3,
                        'VALID_KEY': 4
                    }

                wl_validation['wl_key'] = key
                wl_validation['wl_Company'] = company
                wl_validation['email'] = email
                wl_validation['is_used'] = True
                wl_validation['activation_date'] = datetime.datetime.now()
                wl_validation['active'] = True
                if user_group:
                    wl_validation['user_group'] = user_group
                else:
                    wl_validation['user_group'] = 1
                wl_validation['existing'] = self.is_customer_exists
                if self.is_customer_exists:
                    wl_validation['customer_id'] = customer_id
                else:
                    wl_validation['customer_id'] = None
                if self.is_customer_exists:
                    email_template_id = self.wl_templates_repo.get_template_by_company_and_type(
                        company,
                        self.wl_templates_repo.ACTIVATION_OF_TRAIL,
                        user_group
                    )
                    self.customer_repo.send_email(
                        email_type_id=email_template_id,
                        email_data=email_data,
                        email=email,
                        language=locale,
                        priority=WlSendEmailsRepository.Priority_High,
                        optional_data=email_data_optional
                    )
        self.send_response_flag = True
        data = {
            'validation_status': self.is_key_validated,
            'is_customer_exists': self.is_customer_exists,
            'user_group_id': user_group,
            'user_group_code': user_group_code,
            'user_group_logo': user_group_logo,
            'number_of_offers': number_of_offers,
            'message': message
        }
        return data

    def check_master_card_company_email_and_key(self):
        if not self.email or not self.key:
            self.send_response_flag = True
            self.status_code = 422
            self.response = {
                'data': {},
                'message': self.translation_repo.get_translation(
                    self.translation_repo.email_and_key_required,
                    self.locale
                )
            }
            return self.send_response(self.response, self.status_code)
        if self.company.lower() == WLCompany.COMPANY_CODE_MASTER_CARDS:
            data = self.validate_master_card_key(self.email, self.key, self.locale)
            self.status_code = 200
            self.response = {
                'data': {
                    'validation_status': data['validation_status'],
                    'is_customer_exists': data['is_customer_exists'],
                    'user_group_id': data['user_group_id'],
                    'user_group_code': data['user_group_code'],
                    'user_group_logo': data['user_group_logo'],
                    'number_of_offers': data['number_of_offers']
                },
                'message': data['message'],
                'success': True
            }
            return self.send_response(self.response, self.status_code)

    def get_customer_info(self):
        self.customer = self.customer_repo.load_customer_by_email(self.email)
        if self.customer:
            self.is_customer_exists = True
            self.customer_id = self.customer.get('id', 0)
            self.email_data['user_id'] = self.customer_id

    def get_url_from_config_and_change_company(self):
        faqs_url = self.wl_validation_repo.FAQS_WEB_URL.format(company=self.company)  # noqa: F841
        is_multiple_subscription_allowed = self.company_repo.get_company_multiple_status(self.company)
        is_required_deactive_old_group_keys = False
        if (
            not is_multiple_subscription_allowed and
            self.is_secondary_key and
            self.company != WLCompany.COMPANY_CODE_DU
        ):
            self.is_key_validated = False
            if self.using_branch_activation:
                validation_response = self.wl_validation_repo.validate_key(self.key, self.company, self.email)
                if validation_response == self.wl_validation_repo.ALREADY_ACTIVATED_VALID_KEY:
                    self.message = self.translation_repo.get_translation(
                        self.translation_repo.you_have_already_activated_the_app_for_multiple_keys_not_allowed,
                        self.locale
                    )
                else:
                    self.message = self.translation_repo.get_translation(
                        self.translation_repo.invalid_wl_key_with_branch,
                        self.locale
                    )
            else:
                self.message = self.translation_repo.get_translation(
                    self.translation_repo.you_are_not_allowed_to_subscribe_multiple_keys,
                    self.locale
                )
        else:
            validation_response = self.wl_validation_repo.validate_key(self.key, self.company, self.email)
            if validation_response == self.wl_validation_repo.INVALID_KEY:
                self.is_key_validated = False
                self.message = self.translation_repo.get_translation(
                    self.translation_repo.invalid_wl_key,
                    self.locale
                )
                if self.using_branch_activation:
                    self.message = self.translation_repo.get_translation(
                        self.translation_repo.invalid_wl_key_with_branch,
                        self.locale
                    )
            if validation_response == self.wl_validation_repo.ALREADY_ACTIVATED_VALID_KEY:
                if self.is_secondary_key:
                    self.is_key_validated = False
                    self.message = self.translation_repo.get_translation(
                        self.translation_repo.you_have_already_activated_this_key,
                        self.locale
                    )
                else:
                    self.is_key_validated = True
                    self.message = self.translation_repo.get_translation(
                        self.translation_repo.you_have_successfully_activated_the_key,
                        self.locale
                    )
                    if self.using_branch_activation:
                        self.message = self.translation_repo.get_translation(
                            self.translation_repo.you_have_successfully_activated_the_key_with_branch,
                            self.locale
                        )
            if validation_response == self.wl_validation_repo.UNUSED_VALID_KEY:
                if self.company.lower() == WLCompany.COMPANY_CODE_DU:
                    key_group = self.wl_validation_repo.get_user_group_id_by_key(self.key, self.company)
                    if key_group < 6:
                        self.send_response_flag = True
                        self.response = {
                            'data': {},
                            'success': True,
                            'message': self.translation_repo.get_translation(
                                self.translation_repo.invalid_wl_key_with_branch,
                                self.locale
                            )
                        }
                        self.status_code = 422
                        return self.send_response(self.response, self.status_code)
                    number_of_keys_old_groups = self.wl_validation_repo.get_number_of_valid_keys_old_user_groups_du(
                        self.company,
                        self.email
                    )
                    if number_of_keys_old_groups > 0:
                        is_required_deactive_old_group_keys = True
                if not is_multiple_subscription_allowed:
                    self.number_of_keys = self.wl_validation_repo.get_number_of_valid_keys(self.company, self.email)
                    if self.number_of_keys > 0 and not is_required_deactive_old_group_keys:
                        if self.company.lower() != WLCompany.COMPANY_CODE_ENTERTAINER_HSBC:
                            self.is_key_validated = False
                            self.message = self.translation_repo.get_translation(
                                self.translation_repo.you_have_already_activated_the_app_for_multiple_keys_not_allowed,
                                self.locale
                            )
                        return
                self.is_upgraded_to_black_card = False
                is_red_card_holder = 0
                if self.company.lower() == WLCompany.COMPANY_CODE_ENTERTAINER_HSBC and self.is_customer_exists:
                    self.number_of_keys = self.wl_validation_repo.get_number_of_valid_keys(self.company, self.email)
                    if self.number_of_keys > 0:
                        old_user_group = self.wl_validation_repo.get_user_group(self.company, self.customer_id)
                        if old_user_group == 1:
                            is_red_card_holder = True
                self.wl_validation_repo.assign_key_to_customer(
                    self.key,
                    self.company,
                    self.email,
                    self.is_customer_exists,
                    self.customer_id
                )
                if (
                    self.company.lower() == WLCompany.COMPANY_CODE_ENTERTAINER_HSBC or
                    (self.company.lower() == WLCompany.COMPANY_CODE_DU and is_required_deactive_old_group_keys)
                ):
                    if self.company.lower() == WLCompany.COMPANY_CODE_DU:
                        self.wl_validation_repo.update_user_group(self.key, self.company, self.email, 7)
                    self.wl_validation_repo.expire_old_keys(self.company, self.email, self.key)
                if self.is_customer_exists:
                    if (
                        self.company.lower() == WLCompany.COMPANY_CODE_ENTERTAINER_HSBC or
                        self.company.lower() == WLCompany.COMPANY_CODE_DU
                    ):
                        self.session_repo.mark_all_sessions_for_customer_date_cached(self.customer_id, self.company)
                    else:
                        self.product_ids = self.customer_repo.get_customer_products(
                            user_id=self.customer_id,
                            company=self.company
                        )
                        self.session_repo.update_all_sessions_for_customer(
                            self.customer_id,
                            self.product_ids,
                            self.company
                        )
                    # If customer already exists
                    # Get User_Group Id
                    user_group = self.wl_validation_repo.get_user_group_id_by_key(self.key, self.company)
                    if self.company.lower() == WLCompany.COMPANY_CODE_ENTERTAINER_HSBC:
                        email_template_id = 550
                        if user_group == 2:
                            if is_red_card_holder:
                                email_template_id = 556
                            else:
                                email_template_id = 553
                    else:
                        # Get Email Template Based on the Company and User Group
                        email_template_id = self.wl_templates_repo.get_template_by_company_and_type(
                            self.company,
                            self.wl_templates_repo.ACTIVATION_OF_TRAIL,
                            user_group
                        )
                    # Send Email to Customer
                    self.customer_repo.send_email(
                        email_template_id,
                        self.email_data,
                        self.email,
                        self.locale,
                        WlSendEmailsRepository.Priority_High,
                        self.email_data_optional
                    )
                self.is_key_validated = True
                self.message = self.translation_repo.get_translation(
                    self.translation_repo.you_have_successfully_activated_the_key,
                    self.locale
                )
                if self.using_branch_activation:
                    self.message = self.translation_repo.get_translation(
                        self.translation_repo.you_have_successfully_activated_the_key_with_branch,
                        self.locale
                    )
        if not self.is_key_validated:
            if self.company.lower() == WLCompany.COMPANY_CODE_DU:
                product_info = self.wl_custom_product_repo.get_custom_product_for_user_group(
                    self.company,
                    self.user_group_repo.GROUP_ID_DU_CUSTOMER,
                    self.locale
                )
                product_info['user_id'] = self.customer_id
                product_info['purchase_success_message'] = self.translation_repo.get_translation(
                    self.translation_repo.du_product_purchase_success_message,
                    self.locale
                )
                self.product_to_purchase = product_info

    def generate_final_response(self):
        self.send_response_flag = True
        self.response = {
            'data': {
                'validation_status': self.is_key_validated,
                'is_customer_exists': self.is_customer_exists
            },
            'success': True,
            'message': self.message
        }
        self.status_code = 200

    def process_request(self):
        self.initialize_repos()
        self.setting_variables()
        self.get_customer_info()
        self.check_master_card_company_email_and_key()
        if self.is_send_response_flag_on():
            return
        self.get_url_from_config_and_change_company()
        if self.is_send_response_flag_on():
            return
        self.generate_final_response()
        if self.is_send_response_flag_on():
            return
