"""
Validation params of validates api
"""

from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import boolean, language

validates_parser = get_request_parser()


validates_parser.add_argument(
    'language',
    type=language,
    required=False,
    default='en',
    location=['mobile', 'values', 'json']
)
validates_parser.add_argument(
    'email',
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
validates_parser.add_argument(
    'key',
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
validates_parser.add_argument(
    'is_secondary_key',
    type=boolean,
    required=False,
    default=False,
    location=['mobile', 'values', 'json']
)
validates_parser.add_argument(
    'afterlogin',
    type=boolean,
    required=False,
    default=False,
    location=['mobile', 'values', 'json']
)
validates_parser.add_argument(
    'using_branch_activation',
    type=boolean,
    required=False,
    default=False,
    location=['mobile', 'values', 'json']
)
