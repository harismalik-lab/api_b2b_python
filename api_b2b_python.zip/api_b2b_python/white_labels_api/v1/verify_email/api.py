"""
Email Verification API
"""
from validate_email import validate_email

from app_configurations_white_label.settings import ONLINE_LOG_PATH
from common_white_label.base_resource import BasePostResource
from common_white_label.db import CONSOLIDATION, DEFAULT
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.translations_repo import TranslationManager
from user_authentication_white_label.authentication import get_company
from white_labels_api.v1.verify_email.validation import verify_email_parser


class UserEmailVerificationApi(BasePostResource):
    """
    @api {post} /v1/email/verify Verify Email
    @apiSampleRequest /v1/email/verify
    @apiVersion 1.0.0
    @apiName UserEmailVerificationApi
    @apiGroup Users
    @apiParam {Bool}                                            email_verified flag for email verified
    @apiParam {Bool}                                            email_exist flag for email exist
    @apiParam {String}                                          email           Email of user
    @apiParam {String='de', 'en', 'ar', 'cn', 'el', 'zh'}       [language]      Response language
    """
    backup_request_args_for_exception = False
    request_parser = verify_email_parser
    response = {}
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ONLINE_LOG_PATH,
            file_path='verify_email_api/verify_email_api.log',
        ),
        'name': 'verify_email_api'
    }
    logger = None
    status_code = 200
    connections_names = [DEFAULT, CONSOLIDATION]

    def populate_request_arguments(self):
        """
        Setting the arguments
        """
        self.email = self.request_args.get('email')
        self.email_verified = self.request_args.get('email_verified')
        self.email_exist = self.request_args.get('email_exist')
        self.wl_company = self.request_args.get('wl_company')
        self.locale = self.request_args.get('language', 'en')

    def initialize_local_variables(self):
        """
        Sets variables for api
        """
        self.company = get_company()

    def initialize_repos(self):
        """
        Initializing the repos
        """
        self.customer_repo_instance = CustomerProfileWhiteLabel(logger=self.logger)
        self.translation_manager = TranslationManager()

    def check_email(self):
        """
        Checks the email of user.
        """
        if not self.email and self.email == "":
            self.generate_response_on_no_valid_customer()
        else:
            if not validate_email(self.email):
                self.status_code = 422
                self.send_response_flag = True
                self.response = {
                    "message": '{} is not a valid email'.format(self.email),
                    "data": {
                        "message": '{} is not a valid email'.format(self.email)
                    }
                }
                return self.send_response(self.response, self.status_code)

    def validate_customer(self):
        """
        Validates the email of user.
        """
        self.customer = self.customer_repo_instance.load_customer_by_email_and_custom_info(self.email, self.wl_company)

    def generate_response_on_no_valid_customer(self):
        code = 55
        self.status_code = 422
        self.send_response_flag = True
        data = {'message': self.customer_repo_instance.INVALID_EMAIL}
        self.response = {
            "message": self.customer_repo_instance.INVALID_EMAIL,
            'code': code,
            "data": data,
            "success": False
        }
        return self.send_response(self.response, self.status_code)

    def checking_customer_data(self):
        """
        Checks the customer data and responds accordingly.
        """
        if not self.customer:
            data = []
            self.response = {
                'message': self.translation_manager.get_translation(
                    self.translation_manager.invalid_email_address,
                    self.locale
                ),
                'data': data,
                "success": False
            }
            self.status_code = 422
            self.send_response_flag = True
            return self.send_response(self.response, self.status_code)
        else:
            if not self.customer.get('is_email_verified'):
                data = {
                    "resend_invite_section": {
                        "title": self.customer_repo_instance.VERIFY_YOUR_EMAIL,
                        "message": self.translation_manager.get_translation(
                            self.translation_manager.PENDING_VERIFICATION,
                            self.locale
                        ),
                        'email': self.email,
                        "alert_cancel_button_title": "Cancel",
                        "alert_resend_button_title": "Resend",
                    }
                }
                self.response = {
                    "code": self.status_code,
                    "success": True,
                    "data": data
                }
                self.status_code = 200
                self.send_response_flag = True
                return self.send_response(self.response, self.status_code)

    def generate_final_response(self):
        """
        Generates the final response with status code 200
        """
        data = {
            'message': self.customer_repo_instance.EMAIL_VERIFIED,
            "is_email_verified": True,
        }
        self.response = {
            'data': data,
            "success": True
        }
        self.status_code = 200
        self.send_response_flag = True
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Process the request
        :return: Response
        """
        self.check_email()
        if self.is_send_response_flag_on():
            return

        self.initialize_repos()
        self.initialize_local_variables()
        self.validate_customer()
        self.checking_customer_data()
        if self.is_send_response_flag_on():
            return

        self.generate_final_response()
