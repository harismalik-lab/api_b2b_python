"""
Validation for verify code api
"""
from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import language, validate_email_string

verify_email_parser = get_request_parser()

verify_email_parser.add_argument(
    'email',
    type=validate_email_string,
    required=True,
    location=['mobile', 'values', 'json']
)
verify_email_parser.add_argument(
    'language',
    type=language,
    default='en',
    required=False,
    location=['mobile', 'values', 'json']
)
verify_email_parser.add_argument(
    'wl_company',
    type=str,
    default=False,
    required=True,
    location=['mobile', 'values', 'json']
)
