"""
Validation for app tabs api
"""
from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import boolean, device_list, language

app_tabs_parser = get_request_parser()
app_tabs_parser.add_argument(
    'language',
    type=language,
    required=False,
    default='en',
    location=['mobile', 'values', 'json']
)
app_tabs_parser.add_argument(
    'app_version',
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
app_tabs_parser.add_argument(
    '__platform',
    type=device_list,
    required=True,
    location=['mobile', 'values', 'json']
)
app_tabs_parser.add_argument(
    'location_id',
    type=int,
    required=False,
    location=['mobile', 'values', 'json']
)
app_tabs_parser.add_argument(
    'is_cuckoo',
    type=boolean,
    required=False,
    default=False,
    location=['mobile', 'values', 'json']
)
app_tabs_parser.add_argument(
    'category',
    type=str,
    required=False,
    default='All',
    help='Name category to filter outlets by (string only)',
    location=['mobile', 'values', 'json']
)
app_tabs_parser.add_argument(
    'user_include_cheers',
    type=boolean,
    required=False,
    default=False,
    location=['mobile', 'values', 'json']
)
