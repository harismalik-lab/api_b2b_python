"""
App Tutorial Api
"""
from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from common_white_label.common_helpers import CommonHelpers
from common_white_label.constants import GlobalConstants
from repositories_white_label.app_tutorial_repo import AppTutorialRepository
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.wl_company_repo import WLCompany
from repositories_white_label.wl_product_repo import WLProductRepository
from repositories_white_label.wl_tabs_repo import WlTabsRepository
from repositories_white_label.wl_user_group_repo import WlUserGroup
from repositories_white_label.wl_validtion_repo import WlValidationRepository
from user_authentication_white_label.authentication import get_company, get_current_customer
from white_labels_api.v1.app_tabs.validation import app_tabs_parser


class AppTabsApi(BaseGetResource):
    """
    @api {get} /v1/app/tabs Get App Tabs
    @apiSampleRequest /v1/app/tabs
    @apiVersion 1.0.0
    @apiName AppTabsApi
    @apiGroup Configurations
    @apiParam {String}                                      app_version             Mobile app version
    @apiParam {String="ios","android"}                      __platform              Mobile Platform
    @apiParam {Boolean}                                     [is_cuckoo]             Is cuckoo
    @apiParam {String}                                      [category]              Name category to filter outlets by
    @apiParam {Boolean}                                     [user_include_cheers]   User include cheers
    @apiParam {String}                                      [location_id]           ID of location to filter outlets by
    @apiParam {String="en", "ar", "cn", "el", "de", "zh"}   [language]              Response language
    """
    required_token = True
    strict_token = True
    request_parser = app_tabs_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='app_tabs_api/app_tabs_api.log',
        ),
        'name': 'app_tabs_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.app_version = self.request_args.get('app_version', '')
        self.locale = self.request_args.get('language')
        self.platform = self.request_args.get('__platform', '')
        self.location_id = self.request_args.get('location_id', '')
        self.is_cuckoo = self.request_args.get('is_cuckoo', '')
        self.category = self.request_args.get('category', '')
        self.user_include_cheers = self.request_args.get('user_include_cheers', '')

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.translation_manager = TranslationManager()
        self.wl_tabs_repo = WlTabsRepository()
        self.product_repo = WLProductRepository()
        self.wl_validation_repo = WlValidationRepository()

    def initialize_local_variables(self):
        """
        Sets variables for api
        """
        self.company = get_company()
        self.locale = CommonHelpers.get_locale(self.locale)
        self.messages_locale = CommonHelpers.get_locale_for_messaging(self.locale)
        self.customer = get_current_customer()
        self.show_buy_more_tab = False
        self.hsbc_black_card_holder = False

    def get_app_tutorial(self):
        """
        Gets app tutorial
        """
        self.app_tutorials = AppTutorialRepository.get_app_tutorials(
            company=self.company,
            platform=self.platform,
            app_version=self.app_version,
            locale=self.messages_locale
        )

    def set_user_group_and_other_data(self):
        """
        Sets the user group and other variables
        """
        if not self.customer.get(GlobalConstants.IS_USER_LOGGED_IN):
            self.user_groups = [WlUserGroup.DEFAULT_USER_GROUP]
            self.customer[GlobalConstants.PRODUCT_IDS] = self.product_repo.get_configured_products(
                self.company, self.user_groups
            )

        if (
            self.customer.get(GlobalConstants.IS_USER_LOGGED_IN, False) and
            self.company == WLCompany.COMPANY_CODE_ENTERTAINER_HSBC
        ):
            self.user_group = self.wl_validation_repo.get_user_group(
                self.company, self.customer.get(GlobalConstants.CUSTOMER_ID, 0)
            )
            if self.user_group == 2:
                self.hsbc_black_card_holder = True

        self.tabs = self.wl_tabs_repo.get_outlet_tabs(
            self.company, self.category, self.is_cuckoo, self.messages_locale, self.location_id,
            self.customer[GlobalConstants.PRODUCT_IDS], self.show_buy_more_tab, self.hsbc_black_card_holder
        )

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': {
                'limit': CustomerProfileWhiteLabel.MAX_OUTLETS,
                'tabs': self.tabs
            },
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.initialize_repos()
        self.initialize_local_variables()
        self.set_user_group_and_other_data()
        self.generate_final_response()
