"""
Validation params for merchant
"""
from flask_restful.inputs import regex
from flask_restful.reqparse import RequestParser

from common_white_label.custom_fields_request_parser import boolean, currency, device_list, language

merchant_by_id_parser = RequestParser(bundle_errors=True)

merchant_by_id_parser.add_argument(
    name="session_token",
    type=str,
    required=False,
    location=['mobile', 'values', 'json']
)

merchant_by_id_parser.add_argument(
    'category',
    type=str,
    default="",
    location=['mobile', 'values', 'json']
)
merchant_by_id_parser.add_argument(
    '__platform',
    type=device_list,
    required=True,
    location=['mobile', 'values', 'json']
)
merchant_by_id_parser.add_argument(
    'location_id',
    type=int,
    required=False,
    default=0,
    location=['mobile', 'values', 'json']
)
merchant_by_id_parser.add_argument(
    'language',
    type=language,
    required=False,
    default='en',
    location=['mobile', 'values', 'json']
)
merchant_by_id_parser.add_argument(
    'app_version',
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
merchant_by_id_parser.add_argument(
    'lat',
    type=float,
    default=0,
    location=['mobile', 'values', 'json']
)
merchant_by_id_parser.add_argument(
    'lng',
    type=float,
    default=0,
    location=['mobile', 'values', 'json']
)
merchant_by_id_parser.add_argument(
    'currency',
    type=currency,
    default='USD',
    location=['mobile', 'values', 'json']
)
merchant_by_id_parser.add_argument(
    'is_cuckoo',
    type=boolean,
    default=False,
    location=['mobile', 'values', 'json']
)
merchant_by_id_parser.add_argument(
    'user_include_cheers',
    type=boolean,
    default=False,
    location=['mobile', 'values', 'json']
)
merchant_by_id_parser.add_argument(
    'redeemability',
    type=regex('[a-zA-Z]*[_]*'),
    default='redeemable',
    location=['mobile', 'values', 'json']
)
