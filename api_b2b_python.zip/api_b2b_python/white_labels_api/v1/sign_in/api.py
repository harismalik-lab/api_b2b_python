"""
Sign in API for public api white label.
"""
from flask import request
from phpserialize import dumps as php_json_dumps

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BasePostResource
from common_white_label.common_helpers import CommonHelpers
from common_white_label.constants import GlobalConstants
from repositories_white_label.customer_device_repo import CustomerDeviceRepositoryWl
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.session_repo import SessionRepositoryWhiteLabel
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.wl_company_repo import WLCompany
from repositories_white_label.wl_invoice_headers_repo import WlInvoiceHeadersRepository
from repositories_white_label.wl_send_email_repository import WlSendEmailsRepository
from repositories_white_label.wl_templates_repo import WLTemplatesRepository
from repositories_white_label.wl_user_group_repo import WlUserGroup
from repositories_white_label.wl_validtion_repo import WlValidationRepository
from user_authentication_white_label.authentication import get_current_customer

from .validation import user_sign_in_parser


class SignInWLApi(BasePostResource):
    """
    @api {post} /v1/sessions Post Sign-in User
    @apiSampleRequest /v1/sessions
    @apiVersion 1.0.0
    @apiName SignInWLApi
    @apiGroup Users
    @apiParam {String}                                    app_version                       Mobile app version
    @apiParam {String="ios","android", "web"}             __platform                        Mobile Platform
    @apiParam {String}                                    email                             Email address
    @apiParam {String}                                    password                          Customer password
    @apiParam {String}                                    device_model                      Customer device model
    @apiParam {Boolean}                                   [using_branch_activation]         Using branch activation
    @apiParam {String}                                    [invoice_number]                  Emax invoice number
    @apiParam {String}                                    [device_key]                      Customer device model
    @apiParam {String}                                    [key]                             SMG provided key
    @apiParam {String}                                    [mobile_phone]                    Mobile phone number
    @apiParam {String}                                    [device_install_token]            Customer device install token
    @apiParam {String}                                    [device_uid]                      Device uid
    @apiParam {Boolean}                                   [is_privacy_policy_accepted]      is_gdpr_agreed
    @apiParam {Boolean}                                   [is_user_agreement_accepted]      is_eula_agreed
    @apiParam {String="en", "ar", "cn", "el", "de", "zh"} [language]                        Response language
    """
    backup_request_args_for_exception = False
    request_parser = user_sign_in_parser
    response = {}
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='sign_in_api/sign_in_api.log',
        ),
        'name': 'sign_in_api'
    }
    logger = None
    status_code = 200

    def populate_request_arguments(self):
        """
        Add request arguments of sign in api
        """
        self.platform = self.request_args.get('__platform')
        self.app_version = self.request_args.get('app_version')
        self.locale = self.request_args.get('language')
        self.email = self.request_args.get('email')
        self.password = self.request_args.get('password')
        self.device_model = self.request_args.get('device_model')
        self.device_install_token = self.request_args.get('device_install_token')
        self.device_id = self.request_args.get('device_uid')
        self.mobile_phone = self.request_args.get('mobile_phone')
        self.device_key = self.request_args.get('device_key')
        self.wl_key = self.request_args.get('key')
        self.using_branch_activation = self.request_args.get('using_branch_activation')
        self.invoice_number = self.request_args.get('invoice_number')
        self.is_user_agreement_accepted = self.request_args.get('is_user_agreement_accepted')
        self.is_privacy_policy_accepted = self.request_args.get('is_privacy_policy_accepted')
        self.wl_company = self.request_args.get('wl_company')
        self.force_login = self.request_args.get('force_login')
        self.lat = self.request_args.get('__lat')
        self.lng = self.request_args.get('__lng')

    def initialize_repos(self):
        """
        Initialize repo's for sign in api
        """
        # self.wl_company_repo = WLCompany()
        self.wl_validation_repo = WlValidationRepository()
        self.wl_session_repo = SessionRepositoryWhiteLabel()
        self.customer_repo = CustomerProfileWhiteLabel()
        # self.wl_customer_custom_info_repo = WLUserCustomInfoRepository()
        self.customer_device_repo = CustomerDeviceRepositoryWl()
        self.wl_templates_repo = WLTemplatesRepository()
        self.wl_invoice_repo = WlInvoiceHeadersRepository()
        # self.wl_gem_lookup_repo = WlGemLookupRepository()
        # self.wl_gem_points_repo = WlGemPointsRepository()
        # self.wl_crg_lookup_repo = WlCrgLookupRepository()
        # self.wl_dxb_ent_lookup_repo = WlDxbEntRepository()
        # self.dhl_lookup_repo = WlDhlEntRepository()
        # self.wl_naama_lookup_repo = WlNaamaLookupRepository()
        self.translation_manager = TranslationManager()
        self.wl_user_group = WlUserGroup()
        self.wl_email_send_repo = WlSendEmailsRepository()
        # self.company_limit_repo = CompanyLimit()

    def local_variables(self):
        """
        Initialize local variables for sign in api
        """
        # self.wl_company = get_company()
        self.session_id = 0
        self.user_group = 0
        self.user_group_code = ""
        self.user_group_logo = ""
        self.number_of_offers = 0
        self.number_of_valid_keys = 0
        self.is_new_key_added = False
        self.messages_locale = CommonHelpers.get_locale(self.locale)
        self.customer = get_current_customer()
        self.customer_id = self.customer.get('id')

    def check_device_info_for_all(self):
        """
        Checks device info
        :return:
        """
        device_info = self.customer_device_repo.find_one_by_device_id_and_customer_id(
            customer_id=self.customer_id, device_id=self.device_id, company=self.wl_company
        )
        if not device_info:
            self.device_num = self.customer_device_repo.count_devices_by_customer_id(
                self.customer_id,
                self.wl_company
            )
            self.customer_device_repo.create_new_record(
                customer_id=self.customer_id,
                device_install_token=self.device_install_token,
                device_os=self.platform,
                device_model=self.device_model,
                session=self.session,
                primary=1 if self.device_num else 0,
                device_id=self.device_id
            )

    def check_invoiced_based_apps(self):
        """
        Check invoiced based apps
        :rtype: dict
        """
        if self.invoice_number or self.wl_company.lower() == self.wl_company_repo.COMPANY_CODE_ENTERTAINER_EMAX:
            return self.process_request_invoiced_based()

    def check_lookup_based_company(self):
        """
        Check lookup based company
        :rtype: dict
        """
        is_lookup_based_company = WLCompany().is_lookup_based_company(company=self.wl_company)
        if is_lookup_based_company:
            return self.post_session_lookup_based()

    def check_branch_io_activation(self):
        """
        Check branch activation
        :rtype: dict
        """
        if self.using_branch_activation:
            return self.post_session_gem_branch_io_based_action()

    def check_platform(self):
        """
        Checks platform
        """
        if (
            self.platform == GlobalConstants.PLATFORM_IOS and
            self.wl_company != self.wl_company_repo.COMPANY_CODE_ENTERTAINER_HSBC
        ):
            self.app_without_validation_screen = True
        else:
            self.app_without_validation_screen = False

    def check_email(self):
        """
        Check email
        :rtype: dict
        """
        if not self.email:
            self.send_response_flag = True
            self.status_code = 422
            self.response = {
                'success': False,
                'message': self.translation_manager.get_translation(
                    self.translation_manager.email_required,
                    self.locale
                ),
                'code': 70
            }
            return self.send_response(self.response, self.status_code)

    def check_password(self):
        """
        Checks password
        :rtype: dict
        """
        if not self.password and not self.app_without_validation_screen:
            self.send_response_flag = True
            self.status_code = 422
            self.response = {
                'success': False,
                'message': self.translation_manager.get_translation(
                    self.translation_manager.email_password_required,
                    self.locale
                ),
                'data': [],
                'code': 70
            }
            return self.send_response(self.response, self.status_code)

    def check_device_key(self):
        """
        Check device key
        """
        if not self.device_key:
            self.device_id = self.device_key

    def check_email_and_company(self, wl_company_name):
        """
        Checks email and company against given wl_company_name
        :param str wl_company_name: company name
        """
        if self.email:
            self.email_data_optional["EMAIL"] = self.email

        if self.wl_company:
            self.email_data_optional["WLCOMAPANY"] = self.wl_company

        if wl_company_name:
            self.email_data_optional["WLCOMPANY_NAME"] = wl_company_name

    def check_customer_email(self):
        """
        Check customer email
        :rtype: dict
        """
        self.customer_by_email = self.customer_repo.load_customer_by_email(self.email, True)
        if not self.customer_by_email:
            if self.app_without_validation_screen:
                wl_company_name = self.wl_company_repo.get_company_name(self.wl_company)
                email_data = {}
                self.email_data_optional = {}
                self.check_email_and_company(wl_company_name)
                self.email_template_id = self.wl_templates_repo.get_template_by_company_and_type(
                    self.wl_company,
                    self.wl_templates_repo.REGISTER_INSTRUCTIONS
                )
                self.customer_repo.send_email(
                    email_type_id=self.email_template_id,
                    email_data=email_data.decode(errors='ignore'),
                    email=self.email,
                    language=self.locale,
                    priority=self.wl_email_send_repo.Priority_Medium,
                    dump=False,
                    optional_data=self.email_data_optional
                )
                self.response = {
                    'message': self.translation_manager.get_translation(
                        self.translation_manager.email_not_linked_message,
                        self.locale
                    ),
                    'code': 73
                }
                self.status_code = 422
                self.send_response_flag = True
                return self.send_response(self.response, self.status_code)
            else:
                self.message = self.translation_manager.get_translation(
                    self.translation_manager.you_are_not_allowed_to_access_this_application,
                    self.locale
                )
                if self.wl_company == self.wl_company_repo.COMPANY_CODE_DU:
                    self.message = self.translation_manager.get_translation(
                        self.translation_manager.you_are_not_allowed_to_access_this_application_due,
                        self.locale
                    )
                self.response = {'message': self.message, 'code': 70}
                self.status_code = 422
                self.send_response_flag = True
                return self.send_response(self.response, self.status_code)

    def validate_key(self):
        """
        Validates key
        :rtype: dict
        """
        self.number_of_valid_keys = self.wl_validation_repo.get_number_of_valid_keys(
            company=self.wl_company,
            email=self.email
        )
        if self.number_of_valid_keys < 1:
            if self.wl_key:
                wl_validation_status = self.wl_validation_repo.validate_key(
                    wl_key=self.wl_key,
                    company=self.wl_company,
                    email=self.email
                )
                if wl_validation_status == self.wl_validation_repo.INVALID_KEY:
                    self.response = {
                        'message': self.translation_manager.get_translation(
                            self.translation_manager.invalid_wl_key,
                            self.messages_locale
                        ),
                        'code': 70
                    }
                    self.status_code = 422
                    self.send_response_flag = True
                    return self.send_response(self.response, self.status_code)

                if wl_validation_status == self.wl_validation_repo.UNUSED_VALID_KEY:
                    self.wl_validation_repo.assign_key_to_customer(
                        wl_key=self.wl_key,
                        company=self.wl_company,
                        email=self.email,
                        is_customer_exists=True,
                        customer_id=self.customer_by_email.get("id")
                    )
            else:
                if self.app_without_validation_screen:
                    wl_company_name = self.wl_company_repo.get_company_name(self.wl_company)
                    email_data = {}
                    self.email_data_optional = {}
                    self.check_email_and_company(wl_company_name)
                    self.email_template_id = self.wl_templates_repo.get_template_by_company_and_type(
                        self.wl_company,
                        self.wl_templates_repo.REGISTER_INSTRUCTIONS
                    )
                    self.customer_repo.send_email(
                        email_type_id=self.email_template_id,
                        email_data=email_data.decode(errors='ignore'),
                        email=self.email,
                        language=self.locale,
                        priority=self.wl_email_send_repo.Priority_Medium,
                        dump=False, optional_data=self.email_data_optional
                    )
                    self.response = {
                        'message': self.translation_manager.get_translation(
                            self.translation_manager.email_not_linked_message,
                            self.messages_locale
                        ),
                        'code': 70,
                    }
                    self.status_code = 422
                    self.send_response_flag = True
                    return self.send_response(self.response, self.status_code)

                else:
                    self.message = self.translation_manager.get_translation(
                        self.translation_manager.you_are_not_allowed_to_access_this_application,
                        self.locale
                    )
                    if self.wl_company == self.wl_company_repo.COMPANY_CODE_DU:
                        self.message = self.translation_manager.get_translation(
                            self.translation_manager.you_are_not_allowed_to_access_this_application_due,
                            self.locale
                        )
                    self.response = {'message': self.message, 'code': 70}
                    self.status_code = 422
                    self.send_response_flag = True
                    return self.send_response(self.response, self.status_code)

    def check_user_password(self):
        """
        Check user password
        :rtype: dict
        """
        self.password_hashed = self.customer_repo.get_password_hash(email=self.email)
        if self.password_hashed:
            if not self.password:
                self.response = {
                    'message': self.translation_manager.get_translation(
                        self.translation_manager.invalid_password,
                        self.messages_locale
                    ),
                    'code': 70
                }
                self.status_code = 422
                self.send_response_flag = True
                return self.send_response(self.response, self.status_code)
            self.customer = self.customer_repo.login_customer(self.email, self.password, self.password_hashed)
            if not self.customer:
                self.response = {
                    'message': self.translation_manager.get_translation(
                        self.translation_manager.invalid_password,
                        self.messages_locale
                    ),
                    'code': 70
                }
                self.status_code = 422
                self.send_response_flag = True
                return self.send_response(self.response, self.status_code)
        else:
            self.response = {
                'message': self.translation_manager.get_translation(
                    self.translation_manager.invalid_password,
                    self.messages_locale
                ),
                'code': 70
            }
            self.send_response_flag = True
            self.status_code = 422
            return self.send_response(self.response, self.status_code)

    def update_customer_validation_info(self):
        """
        Update customer validation information
        """
        self.customer_id = self.customer.get("id")
        self.wl_validation_repo.update_customer_validation(self.wl_company, self.email, self.customer_id)

    def check_device_info(self):
        """
        Check device information
        :rtype: dict
        """
        self.device_info = self.customer_device_repo.find_one_by_device_id_and_customer_id(
            customer_id=self.customer_id,
            device_id=self.device_id,
            company=self.wl_company
        )
        if not self.device_info:
            self.device_num = self.customer_device_repo.count_devices_by_customer_id(
                customer_id=self.customer_id,
                company=self.wl_company
            )
            self.is_device_limit_to_check = self.wl_company_repo.get_customer_device_limit_required_company(
                self.wl_company
            )
            if self.is_device_limit_to_check and self.device_num > self.is_device_limit_to_check:
                self.send_response_flag = True
                self.response = {
                    'success': False,
                    'message': self.translation_manager.get_translation(
                        self.translation_manager.you_have_exceeded_your_devices_limit,
                        self.locale
                    )
                }
                self.status_code = 422
                self.send_response_flag = True
                return self.send_response(self.response, self.status_code)

    def load_customer_profile(self):
        """
        Load customer profile by id
        """
        self.customer_profile = self.customer_repo.load_customer_profile_by_id(self.customer_id)

    def generate_session_token(self):
        """
        Generate session token
        """
        product_ids = self.customer_repo.get_customer_products(user_id=self.customer_id, company=self.wl_company)
        self.session_token = self.wl_session_repo.generate_session(
            customer_id=self.customer_id,
            product_ids=product_ids,
            company=self.wl_company,
            platform=self.platform,
            device_model=self.device_model,
            device_id=self.device_id,
            app_version=self.app_version
        )
        self.session = self.wl_session_repo.find_by_token(company=self.wl_company, session_token=self.session_token)
        if self.session:
            self.session_id = self.session.get("id", 0)

    def device_info_customer(self):
        """
        If not device info then create new record
        """
        if not self.device_info:
            self.customer_device_repo.create_new_record(
                customer_id=self.customer_id,
                device_install_token=self.device_install_token,
                device_os=self.platform,
                device_model=self.device_model,
                session=self.session,
                primary=1 if self.device_num else 0,
                device_id=self.device_id
            )

    def add_customer_in_trial(self):
        """
        If customer qualifies then put customer in trial membership
        """
        self.customer_profile = self.customer_repo.put_customer_in_trial_membership_if_qualifies(
            self.customer_profile
        )

    def update_phone_number(self):
        """
        Update mobile phone number
        """
        if self.wl_company == self.wl_company_repo.COMPANY_CODE_ENTERTAINER_HUT and self.mobile_phone:
            self.customer_repo.update_mobile_phone_number(self.customer_id, self.mobile_phone)

    def check_company_code_for_entertainer(self):
        """
        Check company code for entertainer
        """
        self.pop_up_screen_upon_successful_activation = ""
        if self.wl_company == self.wl_company_repo.COMPANY_CODE_ENTERTAINER_LIFE:
            self.user_group = self.wl_validation_repo.get_user_group(self.wl_company, self.customer_id)
            if self.user_group == 1 or self.user_group == 2:
                self.pop_up_screen_upon_successful_activation = self.translation_manager.get_translation(
                    self.translation_manager.elf_pop_up_screen_upon_successful_activation,
                    locale=self.locale
                )
            elif self.user_group == 3 or self.user_group == 4:
                self.pop_up_screen_upon_successful_activation = self.translation_manager.get_translation(
                    self.translation_manager.elf_pop_up_screen_upon_successful_activation_30_june_2018,
                    locale=self.locale
                )
            elif self.user_group == 5 or self.user_group == 6:
                self.pop_up_screen_upon_successful_activation = self.translation_manager.get_translation(
                    self.translation_manager.elf_pop_up_screen_upon_successful_activation_30_dec_2018,
                    locale=self.locale
                )

    def check_company_code_for_master_cards(self):
        """
        Check company code for master
        """
        if self.wl_company == self.wl_company_repo.COMPANY_CODE_MASTER_CARDS:
            self.user_group = self.wl_validation_repo.get_user_group(self.wl_company, self.customer_id)
            user_group_info = self.wl_user_group.get_group_info(self.user_group, self.wl_company)
            if user_group_info:
                self.user_group_code = user_group_info.get("code")
                self.user_group_logo = user_group_info.get("logo", "")
                self.number_of_offers = user_group_info.get("number_of_offers", 0)

    def set_final_response(self):
        """
        Sets final response
        :rtype: dict
        """
        is_demographics_updated = self.customer_repo.is_demographics_updated(self.customer.get('id'))
        data = {
            'message': "",
            'user_id': self.customer_id,
            'session_token': self.session_token,
            'member_type': 3,
            'currency': self.customer_profile.get("currency"),
            'new_user': False,
            'device_install_token': self.device_install_token,
            'device_uid': self.device_id,
            'device_os': self.platform,
            'device_model': self.device_model,
            'pop_up_screen_upon_successful_activation': self.pop_up_screen_upon_successful_activation,
            "user_group": self.user_group,
            "user_group_code": self.user_group_code,
            "user_group_logo": self.user_group_logo,
            "number_of_offers": self.number_of_offers,
            'is_demographics_updated': is_demographics_updated
        }
        self.send_response_flag = True
        self.response = {
            'data': data,
            'success': True,
            'message': self.translation_manager.get_translation(
                self.translation_manager.success,
                self.locale
            )
        }
        self.status_code = 200
        return self.send_response(self.response, self.status_code)

    def get_user_group_info_on_company_and_id(self):
        self.user_group = self.wl_validation_repo.get_user_group(self.wl_company, self.customer_id)
        if not self.user_group:
            self.send_response_flag = True
            self.response = {
                'success': False,
                'message': self.translation_manager.get_translation(
                    self.translation_manager.invalid_vip_key,
                    self.locale
                )
            }
            self.status_code = 422
            self.send_response_flag = True
            return self.send_response(self.response, self.status_code)
        user_group_info = self.wl_user_group.get_group_info(self.user_group, self.wl_company)
        if user_group_info:
            self.user_group_code = user_group_info.get("code")
            self.user_group_logo = user_group_info.get("logo", "")
            self.number_of_offers = user_group_info.get("number_of_offers", 0)

    def process_request(self):
        """
        Handles the process of sign in api
        :rtype: dict
        """
        # self.initialize_repos()
        # self.local_variables()
        # self.check_invoiced_based_apps()
        # if self.is_send_response_flag_on():
        #     return
        # self.check_lookup_based_company()
        # if self.is_send_response_flag_on():
        #     return
        # self.check_branch_io_activation()
        # if self.is_send_response_flag_on():
        #     return
        # self.check_platform()
        #
        # self.check_email_password_invoice_based()
        # if self.is_send_response_flag_on():
        #     return
        # self.check_customer_email_exist()
        # if self.is_send_response_flag_on():
        #     return
        #
        # self.check_email()
        # if self.is_send_response_flag_on():
        #     return
        #
        # self.check_password()
        # if self.is_send_response_flag_on():
        #     return
        #
        # self.check_device_key()
        # self.check_customer_email()
        # if self.is_send_response_flag_on():
        #     return
        #
        # self.validate_key()
        # if self.is_send_response_flag_on():
        #     return
        #
        # self.check_user_password()
        # if self.is_send_response_flag_on():
        #     return
        #
        # self.update_customer_validation_info()
        # self.check_device_info()
        # if self.is_send_response_flag_on():
        #     return
        #
        # self.load_customer_profile()
        # self.generate_session_token()
        # self.device_info_customer()
        # self.add_customer_in_trial()
        # self.update_phone_number()
        # self.check_company_code_for_entertainer()
        # self.check_company_code_for_master_cards()
        # self.set_final_response()

        self.initialize_repos()
        self.local_variables()
        self.check_email_password_invoice_based()
        if self.is_send_response_flag_on():
            return

        self.check_customer_email_exist()
        if self.is_send_response_flag_on():
            return

        self.check_password_hash_invoice_based()
        if self.is_send_response_flag_on():
            return

        self.check_email_verified()
        if self.is_send_response_flag_on():
            return

        self.check_black_listed_user()
        if self.is_send_response_flag_on():
            return

        self.check_device_black_listed()
        if self.is_send_response_flag_on():
            return

        self.check_customer_profile_invoice_based()
        self.check_session_invoice_based()
        if self.is_send_response_flag_on():
            return

        self.device_info_invoice_based()
        self.get_user_group_info_on_company_and_id()
        if self.is_send_response_flag_on():
            return
        self.set_final_response_invoice_based()

    def check_email_password_invoice_based(self):
        """
        Check email and password invoice based
        :rtype: dict
        """
        if not self.email or not self.password:
            self.response = {
                'message': self.translation_manager.get_translation(
                    self.translation_manager.email_password_required,
                    self.messages_locale
                ),
                'code': 70
            }
            self.status_code = 422
            self.send_response_flag = True
            return self.send_response(self.response, self.status_code)

    def check_customer_email_exist(self):
        """
        Check customer by email
        :rtype: dict
        """
        if self.device_key:
            self.device_id = self.device_key
        self.customer_by_email = self.customer_repo.load_customer_by_email(self.email, single=True)
        if not self.customer_by_email:
            self.response = {
                'success': True,
                'message': self.translation_manager.get_translation(
                    self.translation_manager.INVALID_EMAIL_OR_PASSWORD,
                    self.messages_locale
                ),
                'code': 70
            }
            self.status_code = 422
            self.send_response_flag = True
            return self.send_response(self.response, self.status_code)

    def check_customer_email_invoice_based(self):
        """
        Check customer by email
        :rtype: dict
        """
        if self.device_key:
            self.device_id = self.device_key
        self.customer_by_email = self.customer_repo.load_customer_by_email(self.email, single=True)
        if not self.customer_by_email:
            self.response = {
                'message': self.translation_manager.get_translation(
                    self.translation_manager.email_not_exist,
                    self.messages_locale
                ),
                'code': 70
            }
            self.status_code = 422
            self.send_response_flag = True
            return self.send_response(self.response, self.status_code)

    def check_invoice_number(self):
        """
        Check invoice number
        :rtype: dict
        """
        self.customer_id = self.customer_by_email.get('id')
        if self.invoice_number:
            invoice_validation_status = self.wl_invoice_repo.validate_invoice_number(
                invoice_number=self.invoice_number,
                company=self.wl_company,
                is_for_sign_up_or_sign_in=True,
                user_id=self.customer_id
            )
            if invoice_validation_status != self.wl_invoice_repo.VALID_STATUS:
                self.message = WlInvoiceHeadersRepository().get_invoice_validation_message(
                    invoice_validation_status,
                    self.locale
                )
                self.response = {
                    'success': True,
                    'message': self.message,
                    'data': {'validation_status': False},
                    'code': 0
                }
                self.status_code = 400
                self.send_response_flag = True
                return self.send_response(self.response, self.status_code)

            if self.number_of_valid_keys < 1:
                self.is_new_key_added = True
            invoice_lookup = self.wl_invoice_repo.add_invoice_to_user(
                invoice_number=self.invoice_number,
                company=self.wl_company,
                user_id=self.customer_id,
                email=self.email
            )
        else:
            invoice_lookup = self.wl_invoice_repo.get_user_invoice(self.customer_id)
            if not invoice_lookup:
                self.message = WlInvoiceHeadersRepository().get_invoice_validation_message(
                    self.wl_invoice_repo.Invoice_Status_Invalid_Transaction_Type,
                    self.locale
                )
                self.response = {
                    'success': True,
                    'message': self.message,
                    'data': {'validation_status': False},
                    'code': 70
                }
                self.status_code = 400
                self.send_response_flag = True
                return self.send_response(self.response, self.status_code)

    def check_password_hash_invoice_based(self):
        """
        Check password hash of invoice based
        :rtype: dict
        """
        self.password_hashed = self.customer_repo.get_password_hash(email=self.email)
        if self.password_hashed:
            self.customer = self.customer_repo.login_customer(
                self.email, self.password, self.password_hashed, company=self.wl_company
            )
            self.customer_id = self.customer.get('user_id')
            if not self.customer:
                self.response = {
                    'success': True,
                    'message': self.translation_manager.get_translation(
                        self.translation_manager.INVALID_EMAIL_OR_PASSWORD,
                        self.messages_locale
                    ),
                    'code': 70
                }
                self.status_code = 422
                self.send_response_flag = True
                return self.send_response(self.response, self.status_code)
        else:
            self.response = {
                'success': True,
                'message': self.translation_manager.get_translation(
                    self.translation_manager.INVALID_EMAIL_OR_PASSWORD,
                    self.messages_locale
                ),
                'code': 70
            }
            self.status_code = 422
            self.send_response_flag = True
            return self.send_response(self.response, self.status_code)

    def check_email_verified(self):
        """
        Checks that email is verified.
        """
        is_email_verified = self.customer.get('is_email_verified')
        if not is_email_verified:
            self.status_code = 200
            self.send_response_flag = True
            data = {
                "resend_invite_section": {
                    "title": "Verify your email",
                    "message": self.translation_manager.get_translation(
                        self.translation_manager.RESEND_EMAIL_VERIFY,
                        self.messages_locale
                    ),
                    'email': self.email,
                    "button_text": "RESEND",
                    "show_success_popup": 0,
                    'show_continue_button': True,
                    'continue_button_title': 'CANCEL'
                }
            }
            self.response = {
                "message": "success",
                "code": self.status_code,
                "success": False,
                "data": data
            }
            return self.send_response(self.response, self.status_code)

    def check_black_listed_user(self):
        """
        Checking the black listed user and device
        """
        if self.customer['status'] == self.customer_repo.STATUS_BLACKLISTED:
            self.status_code = 422
            self.send_response_flag = True
            self.response = {
                "message": self.message_repo_instance.user_blacklisted,
                "code": 70,
                "success": False
            }
            return self.send_response(self.response, self.status_code)

    def check_device_black_listed(self):
        """
        Checking the blacklisted device
        """
        if self.customer_device_repo.is_device_linked_to_blacklisted_user(self.device_id):
            self.status_code = 422
            self.send_response_flag = True
            self.response = {
                "message": self.message_repo_instance.device_blacklisted,
                "code": 70,
                "success": False
            }
            return self.send_response(self.response, self.status_code)

    def check_customer_profile_invoice_based(self):
        """
        Check customer profile invoice based
        """
        self.customer_profile = self.customer_repo.load_customer_profile_by_id(self.customer.get('id'))

    def check_session_invoice_based(self):
        """
        Check session token invoice based
        """
        product_ids = self.customer_repo.get_customer_products(user_id=self.customer_id, company=self.wl_company)
        api_version = self.wl_session_repo.get_api_version(request)
        all_sessions = self.wl_session_repo.get_all_user_sessions(self.customer_id)
        if all_sessions:
            #  Checks that if found any active session is available and device_id is same.
            #  Then logout the user session and creates the new one.
            if len(all_sessions) == 1:
                logged_in_session = all_sessions[0]
                logged_in_session_id = logged_in_session.get('id')
                device_info = self.customer_device_repo.find_one_by_customer_id_and_session_id(
                    customer_id=self.customer_id,
                    session_id=logged_in_session_id,
                    device_id=self.device_id
                )
                if device_info:
                    self.force_login = True
            if self.force_login:
                self.wl_session_repo.expire_all_current_user_sessions(self.customer_id)
            else:
                self.status_code = 200
                self.send_response_flag = True
                data = {
                    "user_already_logged_in_section": {
                        "title": "You'll be signed out elsewhere!",
                        "message": "By logging in, your account will be logged out of another device.",
                        "image": "https://s3.amazonaws.com/entertainer-app-assets/icons/family/lock_icon.png",
                        "yes_button_title": "LOGIN WITH THIS DEVICE",
                        "no_button_title": "I've changed my mind"
                    }
                }
                self.response = {
                    "message": self.translation_manager.get_translation(
                        self.translation_manager.YOU_WILL_BE_SIGNED_OUT,
                        self.locale
                    ),
                    "code": self.status_code,
                    "success": False,
                    "data": data
                }
                return self.send_response(self.response, self.status_code)

        self.session_token = self.wl_session_repo.generate_session(
            customer_id=self.customer_id, product_ids=product_ids,
            company=self.wl_company, app_version=self.app_version
        )
        self.session = self.wl_session_repo.find_by_token(company=self.wl_company, session_token=self.session_token)
        if self.session:
            self.session_id = self.session.get("id", 0)

        self.customer_repo.refresh_customer_sessions(customer_id=self.customer_id, company=self.wl_company)
        self.wl_session_repo.adding_entry_in_session_addendum_table(
            session_id=self.session_id, user_id=self.customer_id,
            device_key=self.device_key, device_os=self.platform,
            device_model=self.device_model, device_language=self.locale,
            lat=self.lat, lng=self.lng, company=api_version
        )

    def device_info_invoice_based(self):
        """
        Check device info
        """
        self.check_device_info_for_all()

    def customer_profile_trial_membership(self):
        """
        If customer qualifies then sets customer profile trial membership
        """
        self.customer_profile = self.customer_repo.put_customer_in_trial_membership_if_qualifies(
            self.customer_profile
        )

    def check_new_key_added(self):
        """
        New key added
        """
        if self.is_new_key_added:
            self.user_group = self.wl_validation_repo.get_user_group(self.wl_company, self.customer_id)
            email_template_id = self.wl_templates_repo.get_template_by_company_and_type(
                self.wl_company,
                self.wl_templates_repo.ACTIVATION_OF_TRAIL,
                self.user_group
            )

            email_data = php_json_dumps({'user_id': self.customer_id})
            optional_data = php_json_dumps({"{FIRST_NAME}": self.customer_profile.get("firstname")})

            self.customer_repo.send_email(
                email_type_id=email_template_id,
                email_data=email_data.decode(errors='ignore'),
                email=self.email,
                language=self.locale,
                priority=self.wl_email_send_repo.Priority_Medium,
                dump=False,
                optional_data=optional_data
            )

    def set_final_response_invoice_based(self):
        """
        Sets final response for invoice based
        :rtype: dict
        """
        is_demographics_updated = self.customer_repo.is_demographics_updated(self.customer.get('id'))
        data = {
            'message': "",
            'user_id': self.customer_id,
            'session_token': self.session_token,
            'member_type': 1,
            'currency': self.customer_profile.get("currency"),
            'new_user': False,
            'device_install_token': self.device_install_token,
            'device_uid': self.device_id,
            'device_os': self.platform,
            'device_model': self.device_model,
            "user_group": self.user_group,
            "user_group_code": self.user_group_code,
            "user_group_logo": self.user_group_logo,
            "number_of_offers": self.number_of_offers,
            'is_demographics_updated': is_demographics_updated
        }
        self.response = {
            'success': True,
            'message': self.translation_manager.get_translation(
                self.translation_manager.success,
                self.messages_locale
            ),
            'data': data,
            'code': 70
        }
        self.status_code = 200
        self.send_response_flag = True
        return self.send_response(self.response, self.status_code)

    def process_request_invoiced_based(self):
        """
        Handles the process of sign in post invoiced base session
        """
        self.initialize_repos()
        self.local_variables()
        self.check_email_password_invoice_based()
        if self.is_send_response_flag_on():
            return
        self.check_customer_email_invoice_based()
        if self.is_send_response_flag_on():
            return

        # self.check_invoice_number()
        # if self.is_send_response_flag_on():
        #     return
        #
        self.check_password_hash_invoice_based()
        if self.is_send_response_flag_on():
            return

        self.check_email_verified()
        if self.is_send_response_flag_on():
            return

        self.check_black_listed_user()
        if self.is_send_response_flag_on():
            return

        self.check_device_black_listed()
        if self.is_send_response_flag_on():
            return

        self.check_customer_profile_invoice_based()
        self.check_session_invoice_based()
        self.device_info_invoice_based()
        # self.customer_profile_trial_membership()
        # self.check_new_key_added()
        self.set_final_response_invoice_based()

    def check_email_password_look_up(self):
        """
        Check email and password crg
        :rtype: dict
        """
        if not self.email or not self.password:
            if self.wl_company == self.wl_company_repo.COMPANY_CODE_ENTERTAINER_GEMS:
                message = self.translation_manager.get_translation(
                    self.translation_manager.gems_user_id_and_password_is_required,
                    self.messages_locale
                )
            else:
                message = self.translation_manager.get_translation(
                    self.translation_manager.email_password_required,
                    self.messages_locale
                )
            self.response = {
                'success': False,
                'message': message,
                'code': 70,
            }
            self.status_code = 422
            self.send_response_flag = True
            return self.send_response(self.response, self.status_code)

    def check_registration_look_up(self):
        """
        Check registration crg
        :rtype: dict
        """
        self.lookup_data = {}
        if self.wl_company == self.wl_company_repo.COMPANY_CODE_ENTERTAINER_GEMS:
            self.lookup_data = self.wl_gem_lookup_repo.find_gem(self.email)
        elif self.wl_company == self.wl_company_repo.COMPANY_CODE_ENTERTAINER_CRG:
            self.lookup_data = self.wl_crg_lookup_repo.find_crg(self.email)
        elif self.wl_company == self.wl_company_repo.COMPANY_CODE_ENTERTAINER_NAAMA:
            self.lookup_data = self.wl_naama_lookup_repo.find_naama(self.email)
        elif (
                self.wl_company == self.wl_company_repo.COMPANY_CODE_DUBAI_ENTERTAINMENTS or
                self.wl_company == self.wl_company_repo.COMPANY_CODE_DHL
        ):
            customer_by_email = self.customer_repo.load_customer_by_email(self.email, True)
            if not customer_by_email:
                self.response = {
                    'success': True,
                    'message': self.translation_manager.get_translation(
                        self.translation_manager.success,
                        self.messages_locale
                    ),
                    'data': {'registration_required': True}
                }
                self.status_code = 200
                return self.send_response(self.response, self.status_code)
            customer_id = self.customer_id
            if customer_id > 0:
                if self.wl_company == WLCompany.COMPANY_CODE_DUBAI_ENTERTAINMENTS:
                    self.lookup_data = self.wl_dxb_ent_lookup_repo.find_customer(customer_id)
                elif self.wl_company == WLCompany.COMPANY_CODE_DHL:
                    self.lookup_data = self.dhl_lookup_repo.find_customer(customer_id)

        if not self.lookup_data:
            translation_message_identifier = self.translation_manager.get_translation(
                self.translation_manager.you_are_not_allowed_to_access_this_application
            )
            company_message_var = 'access_restricted_to_application_{}'.format(self.wl_company.lower())
            if self.translation_manager.get_translation(company_message_var):
                translation_message_identifier = self.translation_manager.get_translation(company_message_var)
            self.response = {
                'success': False,
                'message': translation_message_identifier,
                'code': 70,
                'data': []
            }
            self.status_code = 422
            self.send_response_flag = True
            return self.send_response(self.response, self.status_code)

    def check_registration_for_dubai_entertainer_look_up(self):
        """
        Check registration for dubai entertainer
        :rtype: dict
        """
        if (
            self.wl_company != self.wl_company_repo.COMPANY_CODE_DUBAI_ENTERTAINMENTS and
            self.wl_company != self.wl_company_repo.COMPANY_CODE_DHL
        ):
            self.email = self.lookup_data.get("email")
        self.user_group = self.lookup_data.get("user_group")
        self.customer_by_email = self.customer_repo.load_customer_by_email(self.email, True)
        password_hashed = self.customer_repo.get_password_hash(email=self.email)
        if not self.customer_by_email or not password_hashed:
            self.response = {
                'success': True,
                'message': self.translation_manager.get_translation(
                    self.translation_manager.success,
                    self.messages_locale
                ),
                'data': {'registration_required': True}
            }
            self.status_code = 422
            self.send_response_flag = True
            return self.send_response(self.response, self.status_code)

    def check_gem_password_info_look_up(self):
        """
        Check gem password info
        :rtype: dict
        """
        self.customer_id = self.customer_by_email.get('id')
        self.gems_password_info = self.wl_customer_custom_info_repo.get_user_custom_info(self.customer_id, self.wl_company)
        if not self.gems_password_info:
            self.response = {
                'success': True,
                'message': self.translation_manager.get_translation(
                    self.translation_manager.success,
                    self.messages_locale
                ),
                'data': {'registration_required': True}
            }
            self.status_code = 422
            self.send_response_flag = True
            return self.send_response(self.response, self.status_code)

    def check_password_hash_and_device_key_look_up(self):
        """
        Check password hash and device key for crg
        :rtype: dict
        """
        if self.device_key:
            self.device_id = self.device_key
        password_hashed = self.gems_password_info.get('password_hash')
        if password_hashed:
            self.customer = self.customer_repo.login_customer(
                self.email, self.password, password_hashed, self.wl_company
            )
            if not self.customer:
                self.response = {
                    'success': False,
                    'message': self.translation_manager.get_translation(
                        self.translation_manager.invalid_password,
                        self.messages_locale
                    )
                }
                self.status_code = 422
                self.send_response_flag = True
                return self.send_response(self.response, self.status_code)

        else:
            self.response = {
                'success': False,
                'message': self.translation_manager.get_translation(
                    self.translation_manager.invalid_password,
                    self.messages_locale
                )
            }
            self.status_code = 422
            self.send_response_flag = True
            return self.send_response(self.response, self.status_code)

    def check_keys_and_set_response_look_up(self):
        """
        Check number of valid keys
        """
        number_of_valid_keys = self.wl_validation_repo.get_number_of_valid_keys(self.wl_company, self.email)
        if number_of_valid_keys == 0:
            if self.lookup_data.get('user_group'):
                self.user_group = self.lookup_data.get('user_group')
            else:
                self.user_group = 1
            prefix = WLCompany().get_key_prefix_by_company(self.wl_company)
            wl_key = CommonHelpers().generate_unique_id(prefix, 7)
            self.wl_validation_repo.add_new_key(
                wl_key,
                self.wl_company,
                self.customer_id,
                self.email,
                self.user_group,
                1
            )
            if self.wl_company == self.wl_company_repo.COMPANY_CODE_ENTERTAINER_GEMS:
                self.wl_gem_points_repo.update_for_gem(self.customer_id, self.email)
            email_template_id = self.wl_templates_repo.get_template_by_company_and_type(
                self.wl_company, self.wl_templates_repo.ACTIVATION_OF_TRAIL, self.user_group
            )
            self.customer_profile = self.customer_repo.load_customer_profile_by_id(self.customer_id)
            email_data = php_json_dumps({'user_id': self.customer_id})
            optional_data = php_json_dumps({})
            if self.customer_profile.get("firstname"):
                optional_data = {"FIRST_NAME": self.customer_profile.get("firstname")}
            self.customer_repo.send_email(
                email_type_id=email_template_id,
                email_data=email_data.decode(errors='ignore'),
                email=self.email,
                language=self.locale,
                priority=self.wl_email_send_repo.Priority_Medium,
                dump=False,
                optional_data=optional_data
            )

    def check_device_info_look_up(self):
        """
        Checks device info for crg
        :rtype: dict
        """
        self.wl_validation_repo.update_customer_validation(self.wl_company, self.email, self.customer_id)
        product_ids = self.customer_repo.get_customer_products(user_id=self.customer_id, company=self.user_group)
        self.customer_profile = self.customer_repo.load_customer_profile_by_id(self.customer_id)
        self.session_token = self.wl_session_repo.generate_session(
            customer_id=self.customer_id,
            product_ids=product_ids,
            company=self.wl_company,
            platform=self.platform,
            device_model=self.device_model,
            device_id=self.device_id,
            app_version=self.app_version
        )
        self.session = self.wl_session_repo.find_by_token(company=self.wl_company, session_token=self.session_token)
        self.session_id = self.session.get("id", 0)
        device_info = self.customer_device_repo.find_one_by_device_id_and_customer_id(
            customer_id=self.customer_id,
            device_id=self.device_id,
            company=self.wl_company
        )
        if not device_info:
            self.device_num = self.customer_device_repo.count_devices_by_customer_id(
                self.customer_id,
                self.wl_company
            )
            check_device_nums = 8
            if self.device_num > check_device_nums:
                self.response = {
                    'success': False,
                    'message': self.translation_manager.get_translation(
                        self.translation_manager.you_have_exceeded_your_devices_limit,
                        self.messages_locale
                    )
                }
                self.status_code = 422
                self.send_response_flag = True
                return self.send_response(self.response, self.status_code)
            self.customer_device_repo.create_new_record(
                customer_id=self.customer_id,
                device_install_token=self.device_install_token,
                device_os=self.platform,
                device_model=self.device_model,
                session=self.session,
                primary=1 if self.device_num else 0,
                device_id=self.device_id
            )

    def put_customer_in_trial_look_up(self):
        """
        Puts customer in trial membership if qualifies
        """
        self.customer_profile_look_up = self.customer_repo.put_customer_in_trial_membership_if_qualifies(
            self.customer_profile
        )

    def set_final_response_look_up(self):
        """
        Sets final response for crg
        :rtype: dict
        """
        is_demographics_updated = self.customer_repo.is_demographics_updated(self.customer.get('id'))
        data = {
            'message': "",
            'user_id': self.customer_id,
            'session_token': self.session_token,
            'member_type': 1,
            'currency': self.customer_profile_look_up.get("currency"),
            'new_user': False,
            'device_install_token': self.device_install_token,
            'device_uid': self.device_id,
            'device_os': self.platform,
            'device_model': self.device_model,
            'pop_up_screen_upon_successful_activation': "",
            'registration_required': False,
            "user_group": self.user_group,
            "user_group_code": self.user_group_code,
            "user_group_logo": self.user_group_logo,
            "number_of_offers": self.number_of_offers,
            'is_demographics_updated': is_demographics_updated
        }
        self.response = {
            'success': True,
            'data': data,
            'message': self.translation_manager.get_translation(
                self.translation_manager.success,
                self.messages_locale
            )
        }
        self.status_code = 200
        self.send_response_flag = True
        return self.send_response(self.response, self.status_code)

    def post_session_lookup_based(self):
        """
        Handles the process of post session gem crg action
        :return:
        """
        self.initialize_repos()
        self.local_variables()
        self.check_email_password_look_up()
        if self.is_send_response_flag_on():
            return

        self.check_registration_look_up()
        if self.is_send_response_flag_on():
            return

        self.check_registration_for_dubai_entertainer_look_up()
        if self.is_send_response_flag_on():
            return

        self.check_gem_password_info_look_up()
        if self.is_send_response_flag_on():
            return
        self.check_password_hash_and_device_key_look_up()
        if self.is_send_response_flag_on():
            return

        self.check_keys_and_set_response_look_up()
        self.check_device_info_look_up()
        if self.is_send_response_flag_on():
            return
        self.put_customer_in_trial_look_up()
        self.set_final_response_look_up()

    def check_wl_key_branch_io(self):
        """
        Check wl key of gem branch iobased action
        :rtype: dict
        """
        if not self.wl_key:
            self.number_of_valid_keys = self.wl_validation_repo.get_number_of_valid_keys(
                self.wl_company,
                self.email
            )
            if self.number_of_valid_keys < 1:
                self.response = {
                    'success': False,
                    'message': self.translation_manager.get_translation(
                        self.translation_manager.you_are_not_allowed_to_access_this_application,
                        self.messages_locale
                    ),
                    'code': 70
                }
                self.status_code = 422
                self.send_response_flag = True
                return self.send_response(self.response, self.status_code)

    def check_customer_profile_branch_io(self):
        """
        Check customer profile
        :rtype: dict
        """
        self.customer_profile = self.customer_repo.load_customer_by_email(self.email, True)
        if not self.customer_profile:
            self.response = {
                'success': True,
                'message': self.translation_manager.get_translation(
                    self.translation_manager.success,
                    self.messages_locale
                ),
                'data': {'registration_required': True},
                'code': 70
            }
            self.status_code = 422
            self.send_response_flag = True
            return self.send_response(self.response, self.status_code)

        self.customer_id = self.customer_profile.get("id")

    def check_platform_branch_io(self):
        """
        Check platform
        """
        if (
            self.platform == GlobalConstants.PLATFORM_IOS and
            self.wl_company != self.wl_company_repo.COMPANY_CODE_ENTERTAINER_HSBC
        ):
            self.app_without_validation_screen = True
        else:
            self.app_without_validation_screen = False

    def check_email_and_password_branch_io(self):
        """
        Check email and password
        :rtype: dict
        """
        self.email_data = php_json_dumps({"user_id": 0})
        self.email_data_optional = php_json_dumps({})
        if not self.email:
            self.response = {
                'message': self.translation_manager.get_translation(
                    self.translation_manager.email_required,
                    self.messages_locale
                ),
                'code': 70
            }
            self.status_code = 422
            self.send_response_flag = True
            return self.send_response(self.response, self.status_code)
        if not self.password and not self.app_without_validation_screen:
            self.response = {
                'message': self.translation_manager.get_translation(
                    self.translation_manager.email_password_required,
                    self.messages_locale
                ),
                'code': 70
            }
            self.status_code = 422
            self.send_response_flag = True
            return self.send_response(self.response, self.status_code)

    def check_password_hased_branch_io(self):
        """
        Check password hased of gem iobased action
        :rtype: dict
        """
        password_hashed = self.customer_repo.get_password_hash(email=self.email)
        if password_hashed:
            if not self.password:
                self.response = {
                    'message': self.translation_manager.get_translation(
                        self.translation_manager.invalid_password,
                        self.messages_locale
                    ),
                    'code': 70
                }
                self.status_code = 422
                self.send_response_flag = True
                return self.send_response(self.response, self.status_code)

            self.customer = self.customer_repo.login_customer(self.email, self.password, password_hashed)
            if not self.customer:
                self.response = {
                    'message': self.translation_manager.get_translation(
                        self.translation_manager.invalid_password,
                        self.messages_locale
                    ),
                    'code': 70
                }
                self.status_code = 422
                self.send_response_flag = True
                return self.send_response(self.response, self.status_code)
        else:
            self.response = {
                'message': self.translation_manager.get_translation(
                    self.translation_manager.invalid_password,
                    self.messages_locale
                ),
                'code': 70
            }
            self.status_code = 422
            self.send_response_flag = True
            return self.send_response(self.response, self.status_code)

    def check_device_and_wl_key_branch_io(self):
        """
        Check wl key gem iobased
        :rtype: dict
        """
        if not self.device_key:
            self.device_id = self.device_key
        self.assign_key_to_customer = False
        self.is_required_deactive_old_group_keys = False
        if self.wl_key:
            self.is_multiple_subscription_allowed = self.wl_company_repo.get_company_multiple_status(
                self.wl_company
            )
            self.validation_response = self.wl_validation_repo.validate_key(
                self.wl_key,
                self.wl_company,
                self.email
            )
            self.number_of_valid_keys = self.wl_validation_repo.get_number_of_valid_keys(
                self.wl_company,
                self.email
            )
            if self.validation_response == self.wl_validation_repo.INVALID_KEY:
                self.response = {
                    'message': self.translation_manager.get_translation(
                        self.translation_manager.invalid_wl_key_with_branch,
                        self.messages_locale
                    ),
                    'code': 70
                }
                self.status_code = 422
                self.send_response_flag = True
                return self.send_response(self.response, self.status_code)
            elif self.validation_response == self.wl_validation_repo.UNUSED_VALID_KEY:
                if not self.is_multiple_subscription_allowed and self.number_of_valid_keys > 0:
                    self.response = {
                        'message': self.translation_manager.get_translation(
                            self.translation_manager.you_have_already_activated_the_app_for_multiple_keys_not_allowed,
                            self.messages_locale
                        ),
                        'code': 70
                    }
                    self.status_code = 422
                    self.send_response_flag = True
                    return self.send_response(self.response, self.status_code)
                self.assign_key_to_customer = True

    def assign_key_to_customer_branch_io(self):
        """
        Assign key to customer
        """
        self.customer_profile = self.customer_repo.load_customer_profile_by_id(self.customer_id)
        if self.assign_key_to_customer:
            self.wl_validation_repo.assign_key_to_customer(
                self.wl_key, self.wl_company, self.email, True, self.customer_id
            )
            self.user_group = self.wl_validation_repo.get_user_group_id_by_key(self.wl_key, self.wl_company)
            if self.wl_company.lower() == self.wl_company_repo.COMPANY_CODE_ENTERTAINER_HSBC:
                self.email_template_id = 550
                if self.user_group == 2:
                    self.email_template_id = 553
            else:
                self.email_template_id = self.wl_templates_repo.get_template_by_company_and_type(
                    self.wl_company, self.wl_templates_repo.ACTIVATION_OF_TRAIL, self.user_group
                )
            self.customer_repo.send_email(
                email_type_id=self.email_template_id,
                email_data=self.email_data.decode(errors='ignore'),
                email=self.email,
                language=self.locale,
                priority=self.wl_email_send_repo.Priority_Medium,
                dump=False,
                optional_data=self.email_data_optional
            )

    def get_customer_product_branch_io(self):
        """
        Get customer product
        """
        self.products_ids = self.customer_repo.get_customer_products(
            user_id=self.customer_id,
            company=self.wl_company
        )

    def generate_session_branch_io(self):
        """
        Generate session
        """
        self.session_token = self.wl_session_repo.generate_session(
            customer_id=self.customer_id,
            product_ids=self.products_ids,
            company=self.wl_company,
            platform=self.platform,
            device_model=self.device_model,
            device_id=self.device_id,
            app_version=self.app_version
        )
        self.session = self.wl_session_repo.find_by_token(company=self.wl_company, session_token=self.session_token)
        if self.session:
            self.session_id = self.session.get("id", None)

    def check_device_info_branch_io(self):
        """
        Check device info
        """
        self.check_device_info_for_all()

    def update_customer_ionfo_branch_io(self):
        """
        Update customer info
        """
        self.customer_profile = self.customer_repo.put_customer_in_trial_membership_if_qualifies(
            customer_profile=self.customer_profile
        )
        self.wl_validation_repo.update_customer_validation(self.wl_company, self.email, self.customer_id)

    def set_response_branch_io(self):
        """
        Sets final response of gem iobased action
        :rtype: dict
        """
        is_demographics_updated = self.customer_repo.is_demographics_updated(self.customer.get('id'))
        data = {
            'message': "",
            'user_id': self.customer_id,
            'session_token': self.session_token,
            'member_type': 1,
            'currency': self.customer_profile.get('currency'),
            'new_user': False,
            'device_install_token': self.device_install_token,
            'device_uid': self.device_id,
            'device_os': self.platform,
            'device_model': self.device_model,
            'pop_up_screen_upon_successful_activation': "",
            'registration_required': False,
            "user_group": self.user_group,
            "user_group_code": self.user_group_code,
            "user_group_logo": self.user_group_logo,
            "number_of_offers": self.number_of_offers,
            'is_demographics_updated': is_demographics_updated
        }
        self.response = {
            'success': True,
            'message': self.translation_manager.get_translation(
                self.translation_manager.success,
                self.messages_locale
            ),
            'data': data,
            'code': 70
        }
        self.status_code = 200
        self.send_response_flag = True
        return self.send_response(self.response, self.status_code)

    def post_session_gem_branch_io_based_action(self):
        """
        Handles the process request for post session gem branch iobased action
        """
        self.initialize_repos()
        self.local_variables()
        self.check_wl_key_branch_io()
        if self.is_send_response_flag_on():
            return

        self.check_customer_profile_branch_io()
        self.check_platform_branch_io()
        self.check_email_and_password_branch_io()
        if self.is_send_response_flag_on():
            return

        self.check_password_hased_branch_io()
        if self.is_send_response_flag_on():
            return

        self.check_device_and_wl_key_branch_io()
        if self.is_send_response_flag_on():
            return

        self.assign_key_to_customer_branch_io()
        self.get_customer_product_branch_io()
        self.generate_session_branch_io()
        self.check_device_info_branch_io()
        self.update_customer_ionfo_branch_io()
        self.set_response_branch_io()
