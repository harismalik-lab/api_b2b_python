"""
Validation for Sign in api
"""
from flask_restful.inputs import regex

from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import (boolean, language,
                                                             validate_email_string)

user_sign_in_parser = get_request_parser()
user_sign_in_parser.add_argument(
    '__platform',
    type=regex('[a-z]'),
    required=True,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'app_version',
    type=regex('[0-9][0-9]*[.]*'),
    required=True,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'language',
    type=language,
    default='en',
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'email',
    type=validate_email_string,
    required=True,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'password',
    type=str,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'device_model',
    type=str,
    required=True,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'device_install_token',
    type=str,
    required=False,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'device_uid',
    type=str,
    required=False,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'mobile_phone',
    type=str,
    default='',
    required=False,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'device_key',
    type=str,
    required=False,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'key',
    type=str,
    required=False,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'using_branch_activation',
    type=boolean,
    required=False,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'invoice_number',
    type=str,
    required=False,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'is_user_agreement_accepted',
    type=boolean,
    default=False,
    required=False,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'is_privacy_policy_accepted',
    type=bool,
    default=False,
    required=False,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'wl_company',
    type=str,
    required=True,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    'force_login',
    type=boolean,
    default=False,
    required=False,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    '__lat',
    type=str,
    required=False,
    location=['mobile', 'json', 'values']
)
user_sign_in_parser.add_argument(
    '__lng',
    type=str,
    required=False,
    location=['mobile', 'json', 'values'],
)
