"""
Module contains App Tutorial APi
"""
from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from common_white_label.common_helpers import CommonHelpers
from common_white_label.constants import GlobalConstants
from repositories_white_label.app_tutorial_repo import AppTutorialRepository
from repositories_white_label.translations_repo import TranslationManager
from user_authentication_white_label.authentication import get_company
from white_labels_api.v1.app_tutorial_api.validation import app_tutorial_parser


class AppTutorialApi(BaseGetResource):
    """
    @api {get} /v1/app/tutorial Get App Tutorial
    @apiSampleRequest /v1/app/tutorial
    @apiVersion 1.0.0
    @apiName AppTutorialApi
    @apiGroup Configurations
    @apiParam {String}                                          app_version             Mobile app version
    @apiParam {String="ios","android", "web"}                   __platform              Mobile Platform
    @apiParam {String="en", "ar", "cn", "el""de", "zh"}         [language]              Response language
    """
    request_parser = app_tutorial_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='app_tutorial_api/app_tutorial_api.log',
        ),
        'name': 'app_tutorial_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.app_version = self.request_args.get('app_version', '')
        self.locale = self.request_args.get('language')
        self.platform = self.request_args.get('__platform', '')

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.translation_manager = TranslationManager()

    def setting_variables(self):
        """
        Sets variables for api
        """
        self.locale = CommonHelpers.get_locale(self.locale)
        self.messages_locale = CommonHelpers.get_locale_for_messaging(self.locale)
        self.company = get_company()

    def get_app_tutorial(self):
        """
        Gets app tutorial
        """
        self.app_tutorials = AppTutorialRepository.get_app_tutorials(
            company=self.company,
            platform=self.platform,
            app_version=self.app_version,
            locale=self.messages_locale
        )

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': {
                'tutorial': {
                    'background_image': GlobalConstants.APP_TUTORIAL_BACKGROUND_IMAGE,
                    'app_tutorial': self.app_tutorials
                }
            },
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.initialize_repos()
        self.setting_variables()
        self.get_app_tutorial()
        self.generate_final_response()
