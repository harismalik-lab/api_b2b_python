"""
app tutorial validation parsers
"""
from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import device_list, language

app_tutorial_parser = get_request_parser()

app_tutorial_parser.add_argument(
    name="language",
    type=language,
    required=False,
    default="en",
    location=['mobile', 'values', 'json'],
)
app_tutorial_parser.add_argument(
    name="__platform",
    type=device_list,
    required=True,
    location=['mobile', 'values', 'json'],
)
app_tutorial_parser.add_argument(
    name="app_version",
    type=str,
    required=True,
    location=['mobile', 'values', 'json'],
)
