"""
verify model validation parser
"""
from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import language

verify_model_parser = get_request_parser()

verify_model_parser.add_argument(
    name="model",
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
verify_model_parser.add_argument(
    name="language",
    default="en",
    type=language,
    required=False,
    location=['mobile', 'values', 'json']
)
