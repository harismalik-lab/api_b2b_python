"""
Verify Model Api Whitelabel
"""
from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.validate_mobile_os_repo import ValidateMobileOsRepository
from user_authentication_white_label.authentication import get_company
from white_labels_api.v1.verify_model_api.validation import verify_model_parser


class VerifyModelApi(BaseGetResource):
    """
    @api {get} /v1/verify/model Get Verify Model
    @apiSampleRequest /v1/verify/model
    @apiVersion 1.0.0
    @apiName VerifyModelApi
    @apiGroup Configurations
    @apiParam {String}                                  model           Mobile model to verify
    @apiParam {String="en", "ar", "cn", "el","zh"}      [language]      Response Language
    """
    request_parser = verify_model_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='verify_model_api/verify_model_api.log',
        ),
        'name': 'verify_model_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.model = self.request_args.get('model')
        self.locale = self.request_args.get('language')

    def initialize_local_variables(self):
        """
        Sets local variables
        """
        self.company = get_company()

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.translation_manager = TranslationManager()
        self.validate_mobile_os = ValidateMobileOsRepository()

    def set_validation_status_and_response(self):
        """
        Gets validation status of device
        """
        self.validation_status = self.validate_mobile_os.validate_model(self.model, self.company)

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': {'result': self.validation_status},
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.initialize_local_variables()
        self.initialize_repos()
        self.set_validation_status_and_response()
        self.generate_final_response()
