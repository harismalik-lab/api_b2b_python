"""
Validation for user password token api
"""
from common_white_label.common_helpers import get_request_parser

user_password_token = get_request_parser()

user_password_token.add_argument(
    'password_token',
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
user_password_token.add_argument(
    'password',
    type=str,
    required=False,
    location=['mobile', 'values', 'json']
)
