"""
User password token api
"""

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BasePostResource
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.session_repo import SessionRepositoryWhiteLabel
from repositories_white_label.translations_repo import TranslationManager
from user_authentication_white_label.authentication import get_company
from white_labels_api.v1.user_password_token.validation import user_password_token


class UserPasswordTokenApiWl(BasePostResource):
    """
    @api {post} /v1/user/password/token Post Authenticate User PasswordToken
    @apiSampleRequest /v1/user/password/token
    @apiVersion 1.0.0
    @apiName UserPasswordToken
    @apiGroup Users
    @apiParam {String}          password_token       Password Reset Token
    @apiParam {String}          [password]           Password
    """
    request_parser = user_password_token
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='user_password_token_api/user_password_token_api.log',
        ),
        'name': 'user_password_token_api'
    }

    def populate_request_arguments(self):
        """
        Add request arguments of user password token
        """
        self.password_token = self.request_args.get('password_token')
        self.password = self.request_args.get('password')

    def initialize_repos(self):
        """
        Initialize repos for user password token api
        """
        self.session_repo = SessionRepositoryWhiteLabel()
        self.customer_repo = CustomerProfileWhiteLabel()
        self.translation_manager = TranslationManager()

    def initialize_class_attributes(self):
        """
        Initialize class attributes of user password token api
        """
        self.is_valid_member = False
        self.company = get_company()

    def is_customer_valid_mermber(self):
        """
        Check customer is a valid member
        """
        customer_id = 0
        if self.password_token:
            customer_id = self.customer_repo.check_customer_by_password_token(self.password_token)
            if customer_id:
                self.is_valid_member = True

        if customer_id and self.password:
            self.is_valid_member = self.customer_repo.update_password_for_lookup_based_company(
                self.password_token,
                self.password,
                customer_id,
                self.company
            )
            self.session_repo.update_customer_company_sessions(self.company, customer_id)

    def prepare_response(self):
        """
        Sets final response of user password token api
        :rtype: dict
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': {
                'is_valid_member': self.is_valid_member
            },
            'message': self.translation_manager.get_translation(
                self.translation_manager.success
            ),
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of user password token api
        """
        self.initialize_repos()
        self.initialize_class_attributes()
        self.is_customer_valid_mermber()
        self.prepare_response()
