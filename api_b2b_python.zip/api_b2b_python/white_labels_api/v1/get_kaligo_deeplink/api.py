"""
Get kaligo deeplink api white label
"""
import base64
import datetime
import json
import os
import urllib
from urllib.parse import urlencode

from Crypto.Cipher import AES
from flask import current_app
from requests import codes

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from common_white_label.common_helpers import CommonHelpers
from common_white_label.constants import GlobalConstants
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.home_screen_configurations_repo import HomeScreenRepositoryWL
from repositories_white_label.translations_repo import TranslationManager
from user_authentication_white_label.authentication import get_company, get_current_customer
from white_labels_api.v1.get_kaligo_deeplink.validation import kaligo_deeplink_parser


class GetKaligoDeeplinkApiWl(BaseGetResource):
    """
    @api {get} /v1/kaligo/deeplink Get Kaligo Deeplink
    @apiSampleRequest /v1/kaligo/deeplink
    @apiVersion 1.0.0
    @apiName GetKaligoDeeplinkApi
    @apiGroup Home
    @apiParam {String='de', 'en', 'ar', 'cn', 'el', 'zh'}    [language]                      Response language
    @apiParam {String}                                       [location_id]                   Location id of the logged in user  # noqa:E501
    @apiParam {String}                                       [app_version]                   Installed app version
    @apiParam {String}                                       [build_no]                      Build Number
    @apiParam {String}                                       [kaligo_location_identifier]    Kaligo Location Identifier
    """
    request_parser = kaligo_deeplink_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='kaligo_deeplink_api/kaligo_deeplink_api.log',
        ),
        'name': 'kaligo_deeplink_api'
    }
    required_token = True
    strict_token = True

    def populate_request_arguments(self):
        """
        Add request arguments of kaligo deeplink api
        """
        self.locale = self.request_args.get('language')
        self.location_id = self.request_args.get('location_id')
        self.kaligo_location_identifier = self.request_args.get('kaligo_location_identifier')

    def setting_variables(self):
        """
        Sets variables for kaligo deeplink api
        """
        self.locale = CommonHelpers.get_locale(self.locale)
        self.company = get_company()

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.home_screen_configurations_repo = HomeScreenRepositoryWL()
        self.customer_repo = CustomerProfileWhiteLabel()
        self.translation_manager = TranslationManager()

    def initialize_class_params(self):
        """
        Initializes the class param
        """
        self.email = ""
        self.first_name = ""
        self.user_name = ""
        self.customer = get_current_customer()
        self.customer_id = self.customer.get('customer_id')
        self.session_token = self.customer.get('session_token')
        self.member_group = self.customer_repo.MEMBERSTATUS_PROSPTECT
        self.kaligo_encrypted_string = ""
        self.kaligo_sign_in_api_endpoint = current_app.config['KALIGO_SIGN_IN_API_ENDPOINT']
        self.is_kaligo_travel_enable = False
        self.kaligo_section = {}
        self.result = {}

    def set_customer_data(self):
        if self.customer:
            self.customer_profile_info = self.customer_repo.load_customer_profile_by_user_id(self.customer_id)
            if self.customer_profile_info:
                self.email = self.customer_profile_info.get('email')
                self.first_name = self.customer_profile_info.get('firstname')
                self.user_name = self.first_name.lower().title()
                self.member_group = self.customer_profile_info.get('new_member_group')
                self.currency = self.customer_profile_info.get('currency')

    def generate_kaligo_encoded_string(self, company, customer_id, customer_profile_info, locale):
        """
        Generate Kaligo Encoded string
        :rtype = str
        """
        self.email = customer_profile_info.get('email')
        self.first_name = customer_profile_info.get('firstname')
        self.user_name = self.first_name.lower().title()
        self.member_group = customer_profile_info.get('new_member_group')
        self.membership_status_text = 'member'
        if self.locale == 'cn':
            locale = 'zh'
        else:
            locale = self.locale
        params_to_encode = {
            'user_id': customer_id,
            'email': self.email,
            'first_name': self.first_name,
            'user_level': '',
            'c_id': '',
            'c_4': '',
            'c_type': '',
            'language': locale,
            'membership_status': self.membership_status_text,
            'referrer': '19',
        }
        plaintext = json.dumps(params_to_encode)
        self.kaligo_encryption_key = current_app.config.get('KALIGO_ENCRYPTION_KEY', '')
        iv = os.urandom(16)
        aes = AES.new(self.kaligo_encryption_key, mode=AES.MODE_CBC, IV=iv)
        ciphertext = (base64.encodebytes(iv + aes.encrypt(CommonHelpers.pkcs5_padding(plaintext, 16)))).decode()
        kaligo_encrypted_string = urlencode({'login': '{encrypted_data}'.format(encrypted_data=ciphertext)})
        return kaligo_encrypted_string

    def get_kaligo(self):
        """
        Get Kaligo Deeplink
        """
        if self.customer:
            self.is_kaligo_travel_enable = True
            self.kaligo_encrypted_string = self.generate_kaligo_encoded_string(
                self.company,
                self.customer_id,
                self.customer_profile_info,
                self.locale
            )
            self.kaligo_section = self.home_screen_configurations_repo.get_kaligo_deeplink(
                locale=self.locale,
                location_id=self.location_id,
                entity_type=self.kaligo_location_identifier,
                company=self.company
            )
            today_date = datetime.datetime.now()
            self.check_in_date = (today_date + datetime.timedelta(days=7)).strftime('%m/%d/%Y')
            self.check_out_date = (today_date + datetime.timedelta(days=9)).strftime('%m/%d/%Y')
        if self.kaligo_section:
            self.kaligo_section['is_external_link'] = False
            parts = urllib.parse.urlparse(self.kaligo_section.get('deep_link'))
            query = dict(urllib.parse.parse_qsl(parts.query))
            query['currency'] = self.currency
            query['checkInDate'] = self.check_in_date
            query['checkOutDate'] = self.check_out_date
            self.kaligo_section['deep_link'] = '{0}://{1}{2}?{3}'.format(
                parts.scheme,
                parts.hostname,
                parts.path,
                urllib.parse.urlencode(query)
            )
            redirect = urllib.parse.quote_plus(self.kaligo_section.get('deep_link'))
            self.kaligo_section['deep_link'] = '{0}?{1}&redirect={2}'.format(
                self.kaligo_sign_in_api_endpoint,
                self.kaligo_encrypted_string,
                redirect
            )
            self.kaligo_section['internal_webview_title'] = GlobalConstants.ENTERTAINER_GETAWAYS
            self.kaligo_section['on_close_webview_message'] = self.translation_manager.get_translation(
                self.translation_manager.NAVIGATE_AWAY_FROM_ENTERTAINER_GETAWAYS,
                locale=self.locale
            )
            self.result = {'tile': self.kaligo_section}

    def generate_final_response(self):
        """
        Sets final response of kaligo deeplink api
        :rtype = dict
        """
        if self.kaligo_section:
            response = {'success': True, 'message': 'success', 'data': self.result}
            self.status_code = codes.OK
            self.set_response(response)
        else:
            self.set_response({'success': True, 'message': 'No kaligo section found'})
            self.status_code = codes.NOT_FOUND
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.initialize_repos()
        self.setting_variables()
        self.initialize_class_params()
        self.set_customer_data()
        self.get_kaligo()
        self.generate_final_response()
