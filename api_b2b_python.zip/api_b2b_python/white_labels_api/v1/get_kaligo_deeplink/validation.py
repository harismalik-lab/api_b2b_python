"""
Validation params of kaligo deeplink api
"""
from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import boolean, language

kaligo_deeplink_parser = get_request_parser()

kaligo_deeplink_parser.add_argument(
    name="istravel",
    default=False,
    type=boolean,
    required=True,
    location=['mobile', 'values', 'json']
)
kaligo_deeplink_parser.add_argument(
    name="language",
    type=language,
    default="en",
    required=True,
    location=['mobile', 'values', 'json']
)
kaligo_deeplink_parser.add_argument(
    name="location_id",
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
kaligo_deeplink_parser.add_argument(
    name="app_version",
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
kaligo_deeplink_parser.add_argument(
    name="build_no",
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
kaligo_deeplink_parser.add_argument(
    name="kaligo_location_identifier",
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
