"""
Verify code api white label
"""

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BasePostResource
from common_white_label.common_helpers import CommonHelpers
from repositories_white_label.phone_verification_repo import PhoneVerificationRepository
from repositories_white_label.translations_repo import TranslationManager
from user_authentication_white_label.authentication import get_company
from white_labels_api.v1.verify_code.validation import verify_code_parser


class VerifyCodeApiWl(BasePostResource):
    """
    @api {post} /v1/user/verify/code Post Verify Code
    @apiSampleRequest /v1/user/verify/code
    @apiVersion 1.0.0
    @apiName VerifyCode
    @apiGroup Validate Key
    @apiParam {Integer}                                 user_id             White label key
    @apiParam {String}                                  email               Email address
    @apiParam {String}                                  phone_number        Mobile number
    @apiParam {String}                                  verification_code   White label code verification
    @apiParam {String="en", "ar", "cn", "el","zh"}      [language]          Response Language
    """
    request_parser = verify_code_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='verify_code_api/verify_code_api.log',
        ),
        'name': 'verify_code_api'
    }

    def populate_request_arguments(self):
        """
        Add request arguments of verify code api
        """
        self.locale = self.request_args.get('language')
        self.user_id = self.request_args.get('user_id')
        self.email = self.request_args.get('email')
        self.phone_number = self.request_args.get('phone_number')
        self.verification_code = self.request_args.get('verification_code')

    def initialize_class_attributes(self):
        """
        Initialize class attributes of verify code api
        """
        self.company = get_company()
        self.phone_verification_repo = PhoneVerificationRepository()
        self.translation_manager = TranslationManager()
        self.locale = CommonHelpers.get_locale(self.locale, location_id=0)

    def check_code_verification_attempt_limit(self):
        """
        Check code verification attempt limit exceeded or not
        """
        code_verification_attempts_limit_exceeded = self.phone_verification_repo.\
            is_code_verification_attempts_limit_exceeded(
                user_id=self.user_id,
                email=self.email,
                phone_number=self.phone_number,
                locale=self.locale,
                company_code=self.company
            )
        if code_verification_attempts_limit_exceeded:
            self.send_response_flag = True
            self.status_code = 422
            self.response = {
                'message': self.translation_manager.get_translation(
                    self.translation_manager.limit_exceeded_to_verify_the_code,
                    self.locale
                ),
                'code': 90,
            }
            return self.send_response(self.response, self.status_code)

        self.code_verification_response = self.phone_verification_repo.validate_verification_code(
            user_id=self.user_id,
            email=self.email,
            phone_number=self.phone_number,
            code_to_verify=self.verification_code,
            locale=self.locale,
            company_code=self.company
        )

    def prepare_response(self):
        """
        Sets final response of verify code api
        :rtype: dict
        """
        self.send_response_flag = True
        if self.code_verification_response:
            self.response = {
                'data': self.code_verification_response,
                'success': True,
                'message': self.translation_manager.get_translation(
                    self.translation_manager.success,
                    self.locale
                )
            }
            self.status_code = 200
            return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of verify code api
        """
        self.initialize_class_attributes()
        self.check_code_verification_attempt_limit()
        if self.is_send_response_flag_on():
            return
        self.prepare_response()
