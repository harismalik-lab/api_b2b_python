"""
Validation for verify code api
"""
from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import language, validate_email_string

verify_code_parser = get_request_parser()

verify_code_parser.add_argument(
    'user_id',
    type=int,
    required=True,
    location=['mobile', 'values', 'json']
)
verify_code_parser.add_argument(
    'verification_code',
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
verify_code_parser.add_argument(
    'phone_number',
    type=str,
    required=False,
    location=['mobile', 'values', 'json']
)
verify_code_parser.add_argument(
    'email',
    type=validate_email_string,
    required=True,
    location=['mobile', 'values', 'json']
)
verify_code_parser.add_argument(
    'language',
    type=language,
    default='en',
    required=False,
    location=['mobile', 'values', 'json']
)
