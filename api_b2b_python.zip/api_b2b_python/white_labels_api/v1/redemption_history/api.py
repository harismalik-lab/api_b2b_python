import json

from werkzeug.exceptions import Forbidden, NotFound, Unauthorized

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource, BasePostResource, BasePutResource
from repositories_white_label.bridge_repo import BridgeRepository


class RedemptionHistoryApi(BasePutResource, BasePostResource, BaseGetResource):
    """
   Calling php endpoint /redemption/history with the help of the request in python.
    """
    api_path = '/api_analytics/web/v2/user/redemption/history'
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='redemption_history/redemption_history.log',
        ),
        'name': 'redemption_history'
    }
    logger = None
    request_parser = None
    status_code = 422
    connections_names = []

    def initialize_repos(self):
        """
        Initialize repos
        """
        self.bridge_repo = BridgeRepository()

    def process_request(self):
        """
        process request as follows:
        - replacing url path with php analytics api path
        - getting request dat from request obj
        - setting new request to process
        - get response from previously set request
        """
        self.initialize_repos()
        self.new_path = self.bridge_repo.replace_request_path(self.api_path)
        self.request_data = self.bridge_repo.get_request_data()
        self._request = self.bridge_repo.set_new_request(self.request_data, self.new_path)
        response = self.bridge_repo.get_response_from_request(self._request)

        if response.status_code in [200, 201]:
            self.redemption_response_data = response.json()
            self.send_response_flag = True
            self.status_code = 200
            return self.set_response(self.redemption_response_data, self.status_code)
        if response.status_code == 404:
            raise NotFound(
                'Url not found'
            )
        try:
            response_data = json.loads(response.text)
            self.status_code = response.status_code
            self.send_response_flag = True
            self.response = {
                "message": response_data.get('message'),
                "success": response_data.get('success'),
                "data": response_data.get('data', {}),
                "code": self.status_code
            }
        except Exception:
            if response.status_code == 401:
                raise Unauthorized(
                    'Unauthorized Access'
                )
            else:
                raise Forbidden(
                    'Something went wrong.'
                )
        return self.send_response(self.response, self.status_code)
