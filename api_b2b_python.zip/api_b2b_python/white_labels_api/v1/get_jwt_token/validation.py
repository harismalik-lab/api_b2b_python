"""
Validation for Get JWT Token API
"""
from common_white_label.common_helpers import get_request_parser

jwt_token_parser = get_request_parser()

jwt_token_parser.add_argument(
    'wlcompany',
    type=str,
    required=True,
    location=['mobile', 'json', 'values']
)
jwt_token_parser.add_argument(
    'session_token',
    type=str,
    required=False,
    location=['mobile', 'json', 'values']
)
