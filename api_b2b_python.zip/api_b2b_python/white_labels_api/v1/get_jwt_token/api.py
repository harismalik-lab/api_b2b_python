"""
Get JWT token API
"""
from flask import current_app
from jwt import encode

from app import g
from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BasePostResource
from repositories_white_label.company_limit_repo import CompanyLimit

from .validation import jwt_token_parser


class GetJwtToken(BasePostResource):
    """
    @api {post} /v1/get_jwt_token Generate JWT
    @apiSampleRequest /v1/get_jwt_token
    @apiVersion 1.0.0
    @apiName GetJwtToken
    @apiGroup Authorization
    @apiParam {String="ios, android", "web"}          wlcompany          White label client
    @apiParam {String="ios, android", "web"}          api_token          uuid identity of white label client
    """
    decorators = [g.limiter.exempt]
    BASIC_AUTH_ENABLED = True
    request_parser = jwt_token_parser
    response = {}
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='jwt/get_jwt_token.log',
        ),
        'name': 'get_jwt_token'
    }
    logger = None
    status_code = 200

    def populate_request_arguments(self):
        self.wlcompany = self.request_args.get('wlcompany')
        self.session_token = self.request_args.get('session_token', '')

    def initialize_repos(self):
        """
        Initialize the repos
        """
        self.company_limit_repo = CompanyLimit()

    def generate_jw_token(self):
        """
        create a jwt token using company code and api_token as identity
        """
        self.jw_token = encode({
            'wlcompany': self.wlcompany,
            'session_token': self.session_token
        }, self.secret_key, algorithm='HS256')

    def generating_final_response(self):
        """
        Preparing final response
        """
        self.secret_key = current_app.config.get('JWT_SECRET_KEY')
        self.send_response_flag = True
        self.success = True
        self.response = {
            'data': '',
            'success': self.success,
            'code': self.status_code
        }
        self.generate_jw_token()
        self.response['jw_token'] = self.jw_token.decode(errors='ignore')
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        self.initialize_repos()
        self.generating_final_response()
