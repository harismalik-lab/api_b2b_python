"""
login message validation parser
"""
from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import language

login_message_parser = get_request_parser()
login_message_parser.add_argument(
    name="language",
    required=False,
    default="en",
    type=language,
    location=['mobile', 'values', 'json']
)
