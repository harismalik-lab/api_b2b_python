"""
Module contains Login Message Api
"""
from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from common_white_label.common_helpers import CommonHelpers
from repositories_white_label.wl_company_repo import WLCompany
from user_authentication_white_label.authentication import get_company
from white_labels_api.v1.login_message.validation import login_message_parser


class LoginMessageApiWL(BaseGetResource):
    """
    @api {get} /v1/pre/login/message Get Login Message
    @apiSampleRequest /v1/pre/login/message
    @apiVersion 1.0.0
    @apiName LoginMessageApiWL
    @apiGroup Authentication
    @apiParam {String='de', 'en', 'ar', 'cn', 'el', 'zh'}      [language]      Response language
    """
    request_parser = login_message_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='login_message_api/login_message_api.log',
        ),
        'name': 'login_message_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')

    def setting_variables(self):
        """
        Sets variables for api
        """
        self.company = get_company()
        self.locale = CommonHelpers.get_locale(self.locale)

    def get_login_message(self):
        """
        Gets login message
        """
        self.pre_login_message = ""
        if self.company == WLCompany.COMPANY_CODE_ENTERTAINER_KEL:
            self.pre_login_message = "Please go to http://kelloggsentertainer.com/ to register your Kelloggs key."
            if self.locale == "ar":
                self.pre_login_message = "يرجى الذهاب إلى http://kelloggsentertainer.com/ لتسجيل مفتاح kelloggs الخاص بك"  # noqa:E501

    def generate_final_response(self):
        """
        Sets final response of login message api
        :rtype: dict
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'success': True,
            'message': '',
            'data': {'message': self.pre_login_message}
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.setting_variables()
        self.get_login_message()
        self.generate_final_response()
