"""
Home screen api white labels
"""
import base64
import datetime
import json
import os
import urllib
from urllib.parse import urlencode

from Crypto.Cipher import AES
from flask import current_app
from requests import codes

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from common_white_label.common_helpers import CommonHelpers
from common_white_label.constants import GlobalConstants
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.exchange_rates_repo import ExchangeRatesRepositoryWL
from repositories_white_label.home_screen_configurations_repo import HomeScreenRepositoryWL
from repositories_white_label.home_screen_configurations_section_repo import HomeScreenConfigurationsSectionRepository
from repositories_white_label.product_repo import ProductRepositoryWhiteLabel
from repositories_white_label.session_repo import SessionRepositoryWhiteLabel
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.v_67.product_wl_active_repo import ProductWlActiveRepository
from repositories_white_label.wl_company_repo import WLCompany
from repositories_white_label.wl_gem_lookup_repo import WlGemLookupRepository
from repositories_white_label.wl_gem_points_repo import WlGemPointsRepository
from repositories_white_label.wl_validtion_repo import WlValidationRepository
from user_authentication_white_label.authentication import get_company, get_current_customer
from white_labels_api.v1.home_api.validation import home_wl_api_parser


class HomeWlApi(BaseGetResource):
    """
    @api {get} /v1/home Get home screen
    @apiSampleRequest /v1/home
    @apiVersion 1.0.0
    @apiName UserGemsPointsSummaryApiWL
    @apiGroup Users
    @apiParam {String}                                      app_version      Mobile App Version.
    @apiParam {String="android", "ios", "web"}              __platform       Mobile Platform.
    @apiParam {String='de', 'en', 'ar', 'cn', 'el', 'zh'}   [language]       Response Language.
    @apiParam {Integer}                                     [location_id]    User Location Id.
    @apiParam {String="BHD", "EGP", "EUR", "GBP", "HKD", "JOD", "KWD", "LBP", "MYR", "OMR", "QAR", "SAR", "SGD", "USD", "ZAR", "AED"}    [currency]  Currency   # noqa:E501
    """
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='home_api/home_api.log',
        ),
        'name': 'home_api'
    }
    logger = None
    request_parser = home_wl_api_parser
    required_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.location_id = self.request_args.get('location_id')
        self.currency = self.request_args.get('currency')
        self.app_version = self.request_args.get('app_version')
        self.locale = self.request_args.get('locale')
        self.platform = self.request_args.get('__platform')
        self.build_no = self.request_args.get('build_no')
        self.session_token = ''
        self.user_id = 0
        self.is_user_logged_in = False

    def initialize_local_variables(self):
        """
        Sets variables for emax card number api
        """
        self.company = get_company()

    def initialize_repose(self):
        """
        Initializes the different repos
        """
        self.home_screen_config_repo = HomeScreenRepositoryWL()
        self.customer_repo = CustomerProfileWhiteLabel()
        self.product_repo = ProductRepositoryWhiteLabel()
        self.gems_points_repo = WlGemPointsRepository()
        self.session_repo = SessionRepositoryWhiteLabel()
        self.product_wl_active_repo = ProductWlActiveRepository()
        self.exchange_rate_repo = ExchangeRatesRepositoryWL()
        self.wl_validation_repo = WlValidationRepository()
        self.translation_repo = TranslationManager()
        self.wl_gem_lookup_repo = WlGemLookupRepository()
        self.home_screen_config_section_repo = HomeScreenConfigurationsSectionRepository()

    def parse_request_args(self):
        """
        Parses request args
        """
        self.customer = get_current_customer()
        if self.customer:
            self.is_user_logged_in = True
            self.user_id = self.customer.get('customer_id')
            self.session_token = self.customer.get('session_token')
        self.locale = CommonHelpers.get_locale_for_messaging(self.locale)
        self.savings_messages = []
        self.message_to_append_with_this_year_savings = self.translation_repo.get_translation(
            self.translation_repo.SAVED_THIS_YEAR_LABEL,
            self.locale
        )
        self.user_yearly_savings = self.customer_repo.get_user_yearly_savings(
            user_id=self.user_id,
            currency=self.currency,
            locale=self.locale,
            message_to_append_with_this_year_savings=self.message_to_append_with_this_year_savings,
            company=self.company
        )
        self.user_yearly_savings['smiles_earned'] = 0
        self.user_points = 0
        self.user_points_earned = 0
        self.user_points_burned = 0
        self.user_points_available = 0
        self.featured_heading = ''

    def get_users_points(self):
        """
        Gets users points
        """
        if self.company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
            user_points_result = self.gems_points_repo.get_user_points_stats(self.user_id)
            if user_points_result:
                self.user_points_earned = user_points_result.get('points_earned', '')
                self.user_points_burned = user_points_result.get('points_burned', '')
                self.user_points_available = user_points_result.get('points_available', '')
            if self.user_yearly_savings.get('total_points'):
                self.user_points = self.user_yearly_savings.get('total_points')
            else:
                self.user_points = 0
            self.user_yearly_savings['smiles_earned'] = self.user_points_earned
        else:
            if self.user_yearly_savings.get('total_points'):
                self.external_savings = self.user_yearly_savings.get('total_points')
            else:
                self.external_savings = 0
            self.user_yearly_savings['external_savings'] = self.external_savings
            if self.user_yearly_savings.get('gems_savings'):
                del self.user_yearly_savings['gems_savings']
            if self.user_yearly_savings.get('total_points'):
                del self.user_yearly_savings['total_points']

    def show_aag_message(self):
        user_profile = self.customer_repo.load_customer_profile_by_id(self.user_id)
        user_name = ''
        if user_profile:
            user_name = user_profile.get('firstname', '')
        if self.company == WLCompany.COMPANY_CODE_AAG:
            user_yearly_saving = self.user_yearly_savings.get('savings_this_year')
            self.savings_messages = "{user_name} you've saved {currency} {user_yearly_saving} so far!".format(
                user_name=user_name,
                currency=self.currency,
                user_yearly_saving=user_yearly_saving
            )
        else:
            if self.user_yearly_savings.get('savings_this_year'):
                self.savings_messages = self.home_screen_config_repo.get_saving_messages(
                    self.user_yearly_savings.get('savings_this_year'), self.locale, user_profile
                )
            else:
                self.savings_messages = self.home_screen_config_repo.get_saving_messages(
                    0, self.locale, user_profile
                )
            # if self.company == WLCompany.COMPANY_CODE_ENTERTAINER_SENSODYNE:
            #     synsodyne_code = GlobalConstants.SYNSODYNE_CODE
            #     self.savings_messages.append(
            #         "Enjoy your free offers without worry of sensitivity \n\n {}".format(synsodyne_code)
            #     )
        self.all_links = self.home_screen_config_repo.get_all(self.locale, self.location_id, self.company)
        self.home_sections = []
        self.location_version = WLCompany().get_location_version()
        self.app_configuration_version = 1
        self.purchasable_products = []
        self.purchased_product_ids = []
        self.purchasable_product_ids = []
        self.purchasable_product_detail = {"id": 0}
        self.show_upgrade_button = False
        self.show_cart_button = False
        self.main_cover = {
            'identifier': 'main_cover',
            'section_identifier': 'main_cover',
            'title': '',
            'section_title': 'main_cover',
            'tiles': []
        }

    def set_categories(self):
        self.categories = {
            'identifier': 'categories',
            'section_identifier': 'categories',
            'title': '',
            'section_title': 'categories',
            'tiles': HomeScreenRepositoryWL.get_categories(
                is_user_logged_in=self.is_user_logged_in,
                company=self.company,
                user_id=self.user_id,
                location_id=self.location_id,
                purchased_product_ids=self.purchased_product_ids,
                purchasable_product_ids=self.purchasable_product_ids,
                locale=self.locale
            )
        }

    def is_user_hsbc_black_card_holder(self):
        self.hsbc_black_card_holder = False
        if (
            self.customer and
            self.company.lower() == WLCompany.COMPANY_CODE_ENTERTAINER_HSBC
        ):
            user_group = self.wl_validation_repo.get_user_group(self.company, self.user_id)
            if user_group == GlobalConstants.USER_GROUP_2:
                self.hsbc_black_card_holder = True

    def add_ambassador_program_link(self):
        if (
            self.customer and
            self.company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS
        ):
            try:
                gems_encryption_key = current_app.config.get('gems_encryption_key')
                if gems_encryption_key:
                    gem_lookup_data = self.wl_gem_lookup_repo.find_gem_data_by_id(self.user_id)
                    if gem_lookup_data:
                        parent_id = gem_lookup_data.get('parent_id', '')
                        gem_school = gem_lookup_data.get('school', '')
                        for link in self.all_links:
                            if link['link_type'] == self.home_screen_config_repo.type_gems_referral:
                                gems_referral_url = self.home_screen_config_repo.get_gems_ambassador_program_url(
                                    link['deep_link'],
                                    gems_encryption_key,
                                    parent_id,
                                    gem_school
                                )
                                link['deep_link'] = gems_referral_url
                                if gems_referral_url:
                                    link['link_type'] = self.home_screen_config_repo.type_extra
            except Exception:
                pass

    def check_user_black_card_holder(self):
        if self.hsbc_black_card_holder:
            self.link_type = '{}_group2'.format(self.home_screen_config_repo.type_extra)
        else:
            self.link_type = self.home_screen_config_repo.type_extra
        self.extras = {
            'identifier': 'featured_sections',
            'section_identifier': 'more_to_enjoy',
            'title': '',   # 'Extras',
            'section_title': 'more_to_enjoy',
            'tiles': self.home_screen_config_repo.get_sub_section(self.all_links, self.link_type, self.locale)
        }
        self.for_the_weekend = {
            'identifier': 'featured_sections',
            'section_identifier': 'for_the_weekend',
            'title': '',
            'section_title': 'for_the_weekend',
            'tiles': self.home_screen_config_repo.get_sub_section(
                self.all_links,
                self.home_screen_config_repo.type_for_the_weekend,
                self.locale
            )
        }
        if self.hsbc_black_card_holder:
            self.link_type = '{}_group2'.format(self.home_screen_config_repo.type_featured)
        else:
            self.link_type = self.home_screen_config_repo.type_featured

    def set_featured_section(self):
        self.feature_section = self.home_screen_config_repo.get_sub_section(
            self.all_links,
            self.link_type,
            self.locale
        )
        if self.company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
            self.featured_heading = self.translation_repo.get_translation(
                self.translation_repo.gems_featured_heading,
                self.locale
            )
        elif self.company.lower() == WLCompany.COMPANY_CODE_ENTERTAINER_HSBC:
            if self.hsbc_black_card_holder:
                self.featured_heading = self.translation_repo.get_translation(
                    self.translation_repo.hsbc_more_to_enjoy_group2,
                    self.locale
                )
            else:
                self.featured_heading = self.translation_repo.get_translation(
                    self.translation_repo.hsbc_more_to_enjoy,
                    self.locale
                )
        elif self.company == WLCompany.COMPANY_CODE_DUBAI_ENTERTAINMENTS:
            self.featured_heading = self.translation_repo.get_translation(
                GlobalConstants.DUBAI_ENTERTAINMENTS_What_New,
                self.locale
            )
        self.featured = {
            'identifier': 'featured_sections',
            'section_identifier': 'featured',
            'title': self.featured_heading,   # 'Featured',
            'section_title': 'featured',
            'is_show_view_all_button': False,
            'tiles': self.feature_section
        }
        self.birthday = {
            'identifier': 'featured_sections',
            'section_identifier': 'Birthday Offer',
            'title': '',
            'section_title': 'Birthday Offer',
            'tiles': []
        }

    def set_branding_attributes(self):
        if not self.savings_messages:
            self.savings_messages = []
            self.savings_messages.append(self.translation_repo.get_translation(
                self.translation_repo.savings_message_welcome_guest,
                self.locale
            )
            )
        self.branding_attributes = []
        if self.company.lower() == WLCompany.COMPANY_CODE_ENTERTAINER_HSBC:
            if self.hsbc_black_card_holder:
                self.branding_attributes = {
                    'main_top_image': GlobalConstants.ENTERTAINER_HSBC_MAIN_TOP_IMAGE_BLACK_CARD,
                    'main_top_color': GlobalConstants.ENTERTAINER_HSBC_MAIN_TOP_COLOR_BLACK_CARD,
                    'main_top_text_color': GlobalConstants.ENTERTAINER_HSBC_MAIN_TOP_TEXT_COLOR
                }
            else:
                self.branding_attributes = {
                    'main_top_image': GlobalConstants.ENTERTAINER_HSBC_MAIN_TOP_IMAGE,
                    'main_top_color': GlobalConstants.ENTERTAINER_HSBC_MAIN_TOP_COLOR,
                    'main_top_text_color': GlobalConstants.ENTERTAINER_HSBC_MAIN_TOP_TEXT_COLOR
                }
        elif self.company == WLCompany.COMPANY_CODE_AAG:
            self.branding_attributes = {
                'main_top_image': GlobalConstants.AAG_MAIN_TOP_IMAGE,
                'main_top_color': GlobalConstants.AAG_MAIN_TOP_COLOR,
                'main_top_text_color': GlobalConstants.AAG_MAIN_TOP_TEXT_COLOR
            }
        else:
            self.branding_attributes = {
                'main_top_image': '',
                'main_top_color': 'B3000000',
                'main_top_text_color': "ffffff"
            }

    def set_main_cover_title(self):
        self.main_cover['tiles'].append({
            'identifier': 'messaging_tile',
            'image': '',
            # 'synsodyne_code': self.synsodyne_code,
            'messages': self.savings_messages,   # {("You have saved 10,000 AED this year so far!") //$savings_messages
            'main_top_image': self.branding_attributes.get('main_top_image'),
            'main_top_color': self.branding_attributes.get('main_top_color'),
            'main_top_text_color': self.branding_attributes.get('main_top_text_color')
        })
        self.main_cover['tiles'].append({
            'identifier': 'savings_tile',
            'image': '',
            'savings': self.user_yearly_savings
        })
        if (
                self.company.lower() == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS and
                self.app_version > GlobalConstants.MIN_VALID_APP_VERSION
        ):
            self.is_show_grey_view = True
            if self.user_points_available >= 5550:
                self.is_show_grey_view = False
            self.main_cover['tiles'].append({
                'identifier': 'points_section',
                'image': "",
                'detail': {
                    'points_available_image': GlobalConstants.POINTS_AVAILABLE_IMAGE,
                    'points_used_image': GlobalConstants.POINTS_USED_IMAGE,
                    'points_available': self.user_points_available,
                    'points_used': self.user_points_burned,
                    'points_available_title': "GEMS POINTS AVAILABLE",
                    'points_used_title': "GEMS POINTS USED",
                    'bottom_message': GlobalConstants.TITLE_DETAIL_BOTTOM_MESSAGE,
                    'is_show_grey_view': self.is_show_grey_view
                }
            })
        self.home_sections.append(self.main_cover)
        self.home_sections.append(self.categories)

    def generate_kaligo_login_string(self, company, customer_id, customer_profile_info, locale):
        email = customer_profile_info.get('email')
        first_name = customer_profile_info.get('firstname')
        membership_status_text = customer_profile_info.get('membership_status_text')
        if locale == 'zh':
            locale = 'cn'
        params_to_encode = {
            'user_id': customer_id,
            'email': email,
            'first_name': first_name,
            'user_level': '',
            'c_id': '',
            'c_4': '',
            'c_type': '',
            'language': locale,
            'membership_status': membership_status_text,
            'referrer': 19
        }
        plaintext = json.dumps(params_to_encode)
        self.kaligo_encryption_key = current_app.config.get('KALIGO_ENCRYPTION_KEY', '')
        iv = os.urandom(16)
        aes = AES.new(self.kaligo_encryption_key, mode=AES.MODE_CBC, IV=iv)
        ciphertext = (base64.encodebytes(iv + aes.encrypt(CommonHelpers.pkcs5_padding(plaintext, 16)))).decode()
        self.kaligo_encrypted_string = urlencode(
            {
                'login': '{encrypted_data}'.format(encrypted_data=ciphertext)
            }
        )
        return self.kaligo_encrypted_string

    def check_is_kaligo_travel_enabled(self):
        self.is_kaligo_travel_enable = False
        self.kaligo_encrypted_string = ""
        self.kaligo_sign_in_api_endpoint = current_app.config.get('KALIGO_SIGN_IN_API_ENDPOINT', '')
        self.user_group = 0
        required_kaligo = False
        if int(self.build_no) >= 70:
            required_kaligo = True
        if (
            self.customer and
            self.company.lower() == WLCompany.COMPANY_CODE_ENTERTAINER_HSBC and
            required_kaligo
        ):
            self.user_group = self.wl_validation_repo.get_user_group(self.company, self.user_id)
            if self.user_group == 2:
                self.hsbc_black_card_holder = True
            # kaligo stuff start
            self.user_profile = self.customer_repo.load_customer_profile_by_id(self.user_id)
            self.is_kaligo_travel_enable = True
            self.kaligo_encrypted_string = self.generate_kaligo_login_string(
                self.company,
                self.user_id,
                self.user_profile,
                self.locale
            )
            self.kaligo_section_final = []
            # & checkInDate=04 % 2F14 % 2F2018 & checkOutDate=04 % 2F16 % 2F2018
            self.kaligo_section = self.home_screen_config_repo.get_sub_section(
                self.all_links,
                'kaligo',
                self.locale
            )
            today_date = datetime.datetime.now()
            check_in_date = today_date + datetime.timedelta(days=7)
            check_out_date = check_in_date + datetime.timedelta(days=2)
            if self.kaligo_section:
                for section in self.kaligo_section:
                    section['is_external_link'] = False
                    parts = urllib.parse.urlparse(section.get('deep_link'))
                    query = dict(urllib.parse.parse_qsl(parts.query))
                    query['currency'] = self.currency
                    query['check_in_date'] = check_in_date
                    query['check_out_date'] = check_out_date
                    section['deep_link'] = '{}://{}{}?{}'.format(
                        parts.get('scheme'),
                        parts.get('host'),
                        parts.get('path'),
                        urllib.parse.urlencode(query)
                    )
                    redirect = urlencode(section['deep_link'])
                    section['deep_link'] = '{}?{}&redirect={}'.format(
                        self.kaligo_sign_in_api_endpoint,
                        self.kaligo_encrypted_string,
                        redirect
                    )
                    section['internal_webview_title'] = GlobalConstants.ENTERTAINER_GETAWAYS_INTERNAL_WEBVIEW_TITTLE
                    section['on_close_webview_message'] = GlobalConstants.ENTERTAINER_GETAWAYS_CLOSE_WEBVIEW_MESSAGE
                    self.kaligo_section_final.append(section)
            self.home_sections.append({
                'identifier': 'featured_sections',
                'section_identifier': 'featured',
                'title': '',
                'section_title': 'featured_kaligo',
                'tiles': self.kaligo_section_final
            })
            # kaligo stuff end
            # fetching home screen configurations
        home_scr_conf = self.home_screen_config_section_repo.get_all(
            self.location_id, self.user_group,
            self.company,
            self.locale
        )

        # setting home sections attributes
        if home_scr_conf:
            index = 0
            for index, key in enumerate(self.home_sections):
                if home_scr_conf[key["section_title"]]:
                    # setting title
                    if home_scr_conf[key["section_title"]].get('title'):
                        self.home_sections[index]["title"] = home_scr_conf[key["section_title"]].get('title')
                    else:
                        self.home_sections[index]["title"] = ""
                    # setting title color
                    if home_scr_conf[key["section_title"]].get('title_color'):
                        self.home_sections[index]["section_title_color"] = home_scr_conf[key["section_title"]].get('title_color')  # noqa:501
                    # setting background color
                    if home_scr_conf[key["section_title"]].get('background_color'):
                        self.home_sections[index]["section_bg_color"] = home_scr_conf[key["section_title"]].get('background_color')  # noqa:501
                    del self.home_sections[index]["section_title"]

    def set_home_section(self):
        if len(self.birthday['tiles']) > 0:
            self.home_sections.append(self.birthday)
        if len(self.extras['tiles']) > 0:
            self.home_sections.append(self.extras)
        if len(self.for_the_weekend['tiles']) > 0:
            self.home_sections.append(self.for_the_weekend)
        if len(self.featured['tiles']) > 0:
            self.home_sections.append(self.featured)

    def generate_final_response(self):
        data = {
            'purchasable_product_ids': self.purchasable_product_ids,
            'purchasable_product_detail': self.purchasable_product_detail,
            'show_upgrade_button': self.show_upgrade_button,
            'show_cart_button': self.show_cart_button,
            'location_version': self.location_version,
            'app_configuration_version': self.app_configuration_version,
            'is_kaligo_travel_enable': self.is_kaligo_travel_enable,
            'kaligo_encrypted_string': self.kaligo_encrypted_string,
            'kaligo_sign_in_api_endpoint': self.kaligo_sign_in_api_endpoint,
            'home_sections': self.home_sections
        }
        self.send_response_flag = True
        self.response = {
            'data': data,
            'success': True,
            'message': 'success'
        }
        self.status_code = codes.OK

    def process_request(self):
        self.initialize_local_variables()
        self.initialize_repose()
        self.parse_request_args()
        # self.get_customer_from_session()
        self.get_users_points()
        self.show_aag_message()
        self.set_categories()
        self.is_user_hsbc_black_card_holder()
        self.add_ambassador_program_link()
        self.check_user_black_card_holder()
        self.set_featured_section()
        self.set_branding_attributes()
        self.set_main_cover_title()
        self.set_home_section()
        self.check_is_kaligo_travel_enabled()
        self.generate_final_response()
