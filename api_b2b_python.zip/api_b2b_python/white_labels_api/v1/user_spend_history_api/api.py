"""
User spend History api white label
"""
import datetime

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from common_white_label.common_helpers import CommonHelpers
from common_white_label.constants import GlobalConstants
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.wl_invoice_headers_repo import WlInvoiceHeadersRepository
from user_authentication_white_label.authentication import get_company, get_current_customer
from white_labels_api.v1.user_spend_history_api.validation import user_spend_history_parser


class UserSpendHistoryApiWL(BaseGetResource):
    """
    @api {get} /v1/user/spend/history Get User Spend History
    @apiSampleRequest /v1/user/spend/history
    @apiVersion 1.0.0
    @apiName UserSpendHistoryApiWL
    @apiGroup Users
    @apiParam {String}                              app_version         Mobile App Version
    @apiParam {String="ios","android","web"}        __platform          All supported platform
    @apiParam {String="en", "ar", "cn", "el","zh"}  [language]          Response Language
    @apiParam {Integer}                             location_id         Location id of user
    @apiParam {String}                              [currency]          Currency.
    """
    request_parser = user_spend_history_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='user_spend_history_api/user_spend_history_api.log',
        ),
        'name': 'user_spend_history_api'
    }
    required_token = True
    strict_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')
        self.__platform = self.request_args.get('__platform')
        self.location_id = self.request_args.get('location_id')
        self.app_version = self.request_args.get('app_version')
        self.currency = self.request_args.get('currency')

    def setting_variables(self):
        """
        Sets variables for user spend history api
        """
        self.locale = CommonHelpers.get_locale(self.locale)
        self.company = get_company()

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.wl_invoice_headers_repo = WlInvoiceHeadersRepository()
        self.translation_manager = TranslationManager()

    def initialize_class_attributes(self):
        """
        Sets variables for api
        """
        self.customer = get_current_customer()
        self.customer_id = self.customer.get('customer_id')
        self.session_token = self.customer.get('session_token')
        self.user_id = None
        today_date = datetime.datetime.now()
        self.current_year = today_date.year
        self.current_month = today_date.month
        self.lifetime_savings = 0
        self.current_month_savings = 0
        self.first_day_of_current_year = datetime.datetime.now().replace(month=1, day=1)
        self.first_day_of_current_month = datetime.datetime.now().replace(
            month=self.current_month,
            day=1,
            year=self.current_year
        )
        self.month_names = self.translation_manager.get_translation(
            self.translation_manager.MOMTHS_NAME_LIST,
            self.locale
        )
        self.code_redemption = ''
        self.merchant = ''
        self.graph_data = []
        self.years_months_having_redemptions = []
        self.months_having_redemptions = []
        self.years_having_redemptions = []
        self.year_month_wise_redemptions = []
        self.total_redemptions = 0
        self.total_savings = 0
        self.total_valid_months = self.month_names[0: int(self.current_month)]
        self.month_index = 1

    def validate_customer(self):
        """
        Throw an Error if user_id do not match with customer_id stored in session data
        :rtype: dict
        """
        if not self.customer_id:
            self.send_response_flag = True
            self.status_code = 403
            self.response = {
                "message": self.translation_manager.get_translation(
                    self.translation_manager.you_are_not_allowed_to_access_this_application,
                    self.locale
                ),
                "success": False,
                "code": 90
            }
            return self.send_response(self.response, self.status_code)

    def get_user_spend_history(self):
        """
        Gets user spend history
        """
        self.validate_customer()
        self.redemption_summary = {
            'current_year': self.current_year,
            'total_redemptions': 0,
            'month_wise_redemmptions': {}
        }
        self.all_points = self.wl_invoice_headers_repo.find_items_for_history(self.user_id, self.company)
        for self.total_redemptions, point in enumerate(self.all_points):
            self.lifetime_savings += point.get('transaction_total_price')
            self.savings = point.get('transaction_total_price')
            self.total_savings += self.savings
            index = point.get('invoice_date').month
            if not self.year_month_wise_redemptions[index]:
                month = point.get('invoice_date').month
                self.year_month_wise_redemptions[index].append({
                    'index': index,
                    'month': '{current_year} {month}'.format(current_year=self.current_year, month=month),
                    'redemption_count': 0,
                    'redemptions': []
                })
            if self.year_month_wise_redemptions[index]:
                self.year_month_wise_redemptions[index]['redemption_count'] += 1
                self.year_month_wise_redemptions[index]['redemptions'].append({
                    'id': point.get('id'),
                    'purchase_date': point.get('invoice_date').strftime('%d/%m/%Y'),
                    'code': "{}{}".format(point.get('transaction_type'), point.get('invoice_number')),
                    'savings': self.savings,
                    'offer': '',
                    'outlet_id': 0,
                    'outlet': point.get('location_name'),
                    'merchant_id': 0,
                    'merchant': "{}{}".format(point.get('transaction_type'), point.get('invoice_number')),
                    'category': '',
                    'logo_url': GlobalConstants.EMAX_LOGO,
                    'items': point.get('items')
                })
        self.redemption_summary['total_redemptions'] = self.total_savings
        self.months_having_redemptions.reverse()
        self.years_months_having_redemptions = self.months_having_redemptions
        self.redemption_summary['month_wise_redemmptions'] = self.years_months_having_redemptions

    def generate_final_response(self):
        """
        Generates final response
        :rtype: dict
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': self.redemption_summary,
            'message': '',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.setting_variables()
        self.initialize_repos()
        self.initialize_class_attributes()
        self.get_user_spend_history()
        self.generate_final_response()
