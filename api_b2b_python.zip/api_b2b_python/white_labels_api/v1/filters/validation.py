"""
Validation params of filters api
"""
from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import device_list, language

filters_parser = get_request_parser()

filters_parser.add_argument(
    '__platform',
    type=device_list,
    required=True,
    location=['mobile', 'values', 'json']
)
filters_parser.add_argument(
    'app_version',
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
filters_parser.add_argument(
    'language',
    type=language,
    required=False,
    default='en',
    location=['mobile', 'values', 'json'],
)
