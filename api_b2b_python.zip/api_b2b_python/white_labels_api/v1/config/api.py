"""
Config api white label
"""
import datetime
from flask import current_app

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BasePostResource
from common_white_label.common_helpers import CommonHelpers
from repositories_white_label.wl_company_repo import WLCompany
from repositories_white_label.currency_repo import CurrencyRepositoryWL
from repositories_white_label.configuration import UiConfigs
from user_authentication_white_label.authentication import get_company
from white_labels_api.v1.config.validation import configs_parser


class ConfigsApiWL(BasePostResource):
    """
    @api {post} /v1/configs Get Configs
    @apiSampleRequest /v1/configs
    @apiVersion 1.0.0
    @apiName configs
    @apiGroup Configurations
    @apiParam {String}                                            app_version             Mobile app version
    @apiParam {String="ios","android", "web"}                     __platform              Mobile Platform
    @apiParam {String="en", "ar", "cn", "el", "de", "zh"}         [language]              Response language
    """
    request_parser = configs_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='configs_api/configs_api.log',
        ),
        'name': 'configs_api'
    }

    def populate_request_arguments(self):
        """
        Add request arguments of config api
        """
        self.locale = self.request_args.get('language')
        self.platform = self.request_args.get('__platform')
        self.app_version = self.request_args.get('app_version')

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.currencies_repo = CurrencyRepositoryWL()

    def initialize_local_veriables(self):
        """
        Sets variables for api
        """
        self.company = get_company()

    def initialize_class_attributes(self):
        """
        Initialize class attributes of config api
        """
        self.wl_company_repo = WLCompany()
        self.locale = CommonHelpers.get_locale(self.locale, location_id=0)
        self.currencies = []

    def process_data(self):
        """
        Process the data of configurations.
        """
        self.currencies = self.currencies_repo.get_currencies_lookup(locale=self.locale)
        ui_configs = UiConfigs.UI_CONFIGURATIONS
        ui_configs['calender_minimum_check_in_date'] = datetime.datetime.utcnow().date().strftime('%d-%m-%Y')
        ui_configs['calender_maximum_check_out_date'] = (
            datetime.datetime.utcnow().date() + datetime.timedelta(days=365)
        ).strftime('%d-%m-%Y')
        self.data = {
            "express_exit_confirmation_alert_text": UiConfigs.EXIT_CONFIRMATION_ALERT_TEXT,
            "should_hide_SDK_exit_alert": False,
            "currencies": self.currencies,
            "ui_config": ui_configs,
        }

    def prepare_response(self):
        """
        Sets final response of config api
        :rtype: dict
        """
        self.send_response_flag = True
        self.response = {
            'data': self.data,
            'success': True,
            'message': 'success'
        }
        self.status_code = 200
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Retrieve all the configs
        """
        self.initialize_local_veriables()
        self.initialize_class_attributes()
        self.initialize_repos()
        self.process_data()
        self.prepare_response()
