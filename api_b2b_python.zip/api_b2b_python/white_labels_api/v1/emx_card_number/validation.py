"""
Validation params of emax card number api
"""
from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import device_list, language

emx_card_parser = get_request_parser()

emx_card_parser.add_argument(
    name="card_number",
    type=int,
    required=True,
    location=['mobile', 'values', 'json']
)
emx_card_parser.add_argument(
    name="session_token",
    type=str,
    required=False,
    location=['mobile', 'values', 'json']
)
emx_card_parser.add_argument(
    name="language",
    type=language,
    default="en",
    required=False,
    location=['mobile', 'values', 'json']
)
emx_card_parser.add_argument(
    '__platform',
    type=device_list,
    required=True,
    location=['mobile', 'values', 'json']
)
emx_card_parser.add_argument(
    'app_version',
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
