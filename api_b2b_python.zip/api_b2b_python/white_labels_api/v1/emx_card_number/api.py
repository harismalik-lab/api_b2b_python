"""
Enax card number api white label
"""
from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BasePostResource
from common_white_label.common_helpers import CommonHelpers
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.session_repo import SessionRepositoryWhiteLabel
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.wl_invoice_headers_repo import WlInvoiceHeadersRepository
from repositories_white_label.wl_membership_cards_repo import WlMembershipCardRepository
from user_authentication_white_label.authentication import get_company, get_current_customer
from white_labels_api.v1.emx_card_number.validation import emx_card_parser


class AddCardNumberApi(BasePostResource):
    """
    @api {post} /v1/card_number POST Add new card number
    @apiSampleRequest /v1/card_number
    @apiVersion 1.0.0
    @apiName AddCardNumberAction
    @apiGroup Emax
    @apiParam {String}                                           app_version         Mobile app version
    @apiParam {String="ios","android", "web"}                    __platform          Mobile Platform
    @apiParam {Integer}                                          card_number         Card number
    @apiParam {String="en", "ar", "cn", "el", "de", "zh"}        [language]          Response language
    """
    request_parser = emx_card_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='emx_card_number/emx_card_number.log',
        ),
        'name': 'emx_card_number'
    }
    strict_token = True
    required_token = True

    def populate_request_arguments(self):
        """
        Add request arguments of emax card number api
        """
        self.locale = self.request_args.get('language')
        self.card_number = self.request_args.get('card_number')
        self.messages_locale = CommonHelpers.get_locale_for_messaging(self.locale)

    def initialize_local_variables(self):
        """
        Sets variables for emax card number api
        """
        self.customer = get_current_customer()
        self.customer_id = self.customer.get('customer_id')
        self.company = get_company()

    def initialize_repos(self):
        """
        Initializes the different repos
        """
        self.translation_manager = TranslationManager()
        self.customer_repo = CustomerProfileWhiteLabel()
        self.session_repo = SessionRepositoryWhiteLabel()

    def validate_customer(self):
        """
        Validates customer
        """
        if not self.customer.get('is_user_logged_in'):
            self.send_response_flag = True
            self.status_code = 422
            self.response = {
                "message": self.translation_manager.get_translation(
                    self.translation_manager.not_authorized_to_access_user,
                    self.messages_locale
                ),
                "success": False,
                "code": 50
            }
            return self.send_response(self.response, self.status_code)

    def validate_card(self):
        """
        Validates card
        """
        self.user_profile = self.customer_repo.get_user_profile_by_user_id(
            self.customer_id,
            self.company
        )
        self.email = self.user_profile.get('email')

        if self.card_number:
            card_validation_status = WlMembershipCardRepository().validate_card_number(
                self.card_number,
                self.company,
                self.customer_id
            )
            if card_validation_status != WlInvoiceHeadersRepository.VALID_STATUS:
                message = WlInvoiceHeadersRepository().get_card_validation_message(
                    card_validation_status,
                    self.locale
                )
                self.send_response_flag = True
                self.response = {
                    'success': True,
                    'message': message,
                    'data': {'validation_status': False}
                }
                self.status_code = 200
                return self.send_response(self.response, self.status_code)
            WlMembershipCardRepository().add_card_to_user(
                self.card_number,
                self.company,
                self.customer_id,
                self.email
            )
            self.session_repo.mark_all_sessions_for_customer_date_cached(self.customer_id, self.company)

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'message': WlInvoiceHeadersRepository().get_card_validation_message(
                WlInvoiceHeadersRepository.VALID_STATUS,
                self.locale
            ),
            'data': {'validation_status': True},
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.initialize_local_variables()
        self.initialize_repos()
        self.validate_customer()
        if self.is_send_response_flag_on():
            return
        self.validate_card()
        if self.is_send_response_flag_on():
            return
        self.generate_final_response()
