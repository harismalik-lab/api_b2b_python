"""
Outlets validation parser
"""
import re

from flask_restful.inputs import regex

from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import boolean, currency, device_list, language

outlet_validation_parser = get_request_parser()

outlet_validation_parser.add_argument(
    '__platform',
    type=device_list,
    default='',
    required=True,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'location_id',
    type=int,
    default=0,
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'language',
    type=language,
    default='en',
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'locale',
    type=language,
    default='en',
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'app_version',
    type=str,
    default='',
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'sort',
    type=regex('^[a-z]+$'),
    required=False,
    default='default',
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'first_sort_by_redeemability',
    type=boolean,
    default=False,
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'lat',
    type=float,
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'lng',
    type=float,
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'radius',
    type=int,
    default=0,
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'query',
    default='',
    type=str,
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'query_type',
    type=regex('(name|area|address)', flags=re.IGNORECASE),
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'category',
    type=str,
    required=False,
    default='All',
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'cuisine',
    type=str,
    required=False,
    default='All',
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'cuisine_filter[]',
    type=str,
    required=False,
    action='append',
    default=[],
    location=['mobile', 'values', 'json']
)

outlet_validation_parser.add_argument(
    'redeemability',
    type=regex('(all|not_redeemable|redeemed|redeemable|reusable|redeemable_reusable)', flags=re.IGNORECASE),
    default='redeemable_reusable',
    required=False,
    help='(all|not_redeemable|redeemed|redeemable|reusable|redeemable_reusable) redeemability is allowed',
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'filter_by_type',
    type=regex('(0|1|2|3|4|5)', flags=re.IGNORECASE),
    default='',
    required=False,
    help='only (0|1|2|3|4|5) filter_by_type is allowed',
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'neighborhood',
    type=str,
    default='',
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'mall',
    type=str,
    default='',
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'hotel',
    type=str,
    default='',
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'offset',
    type=int,
    default=0,
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'limit',
    type=int,
    default=60,
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'outlet_limit',
    type=int,
    default=60,
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'currency',
    type=currency,
    default='USD',
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'billing_country',
    type=str,
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'outlet_id',
    type=int,
    default=0,
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'product_sku',
    type=str,
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'sub_category_filter',
    type=str,
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'cuisine_filter',
    type=str,
    action='append',
    required=False,
    default=[],
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    name="filters_selected_for_yes[]",
    action='append',
    default="",
    type=str,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    name="filters_selected_for_no[]",
    action='append',
    default="",
    type=str,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'is_more_sa',
    type=boolean,
    default=False,
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'device_key',
    type=str,
    default='',
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'is_cheers',
    type=boolean,
    default=False,
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    name="user_include_cheers",
    required=False,
    default="False",
    type=boolean,
)
outlet_validation_parser.add_argument(
    'is_delivery',
    type=boolean,
    default=False,
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    name='fuzzy',
    type=boolean,
    default=False,
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    name="is_cuckoo",
    required=False,
    default=False,
    type=boolean,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    name="is_company_specific",
    required=False,
    default=False,
    type=boolean,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    'show_new_offers',
    type=boolean,
    default=False,
    required=False,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    name="show_monthly_offers",
    required=False,
    default=False,
    type=boolean,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser.add_argument(
    name="show_only_core_product_offers",
    required=False,
    default=False,
    type=boolean,
    location=['mobile', 'values', 'json']
)
