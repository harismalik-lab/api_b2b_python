"""
Outlet Api
"""
import copy
import datetime
from datetime import timedelta
from operator import itemgetter

from flask import current_app

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from common_white_label.common_helpers import CommonHelpers, OfferManager, multi_key_sort
from common_white_label.constants import GlobalConstants
from common_white_label.fuzzy_manager import FuzzySearchManager
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.home_screen_configurations_repo import HomeScreenRepositoryWL
from repositories_white_label.offer_wl_active_repo import OfferWlRepository
from repositories_white_label.outlet_repo import OutletRepositoryWl
from repositories_white_label.redemption_repo import RedemptionRepositoryWhiteLabel
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.wl_categories_repo import CategoriesRepositoryWl
from repositories_white_label.wl_company_repo import WLCompany
from repositories_white_label.wl_product_repo import WLProductRepository
from repositories_white_label.wl_tabs_repo import WlTabsRepository
from repositories_white_label.wl_user_group_repo import WlUserGroup
from repositories_white_label.wl_validtion_repo import WlValidationRepository
from user_authentication_white_label.authentication import get_company, get_current_customer
from white_labels_api.v1.outlet.validation import outlet_validation_parser


class OutletsApi(BaseGetResource):
    """
    @api {get} /v1/outlets Outlets
    @apiSampleRequest /v1/outlets
    @apiVersion 1.0.0
    @apiName OutletsApi
    @apiGroup Outlets
    @apiParam {String}                                  app_version                  Mobile app version
    @apiParam {String="android", "ios", "web"}          __platform                   Mobile Platform
    @apiParam {Boolean}                                 is_cuckoo                    Checks flag is_cuckoo
    @apiParam {Boolean}                                 is_cheers                    Checks flag is_cheers
    @apiParam {Boolean}                                 is_company_specific          Checks flag is_company_specific
    @apiParam {Boolean}                                 is_more_sa                   Checks flag is_more_sa
    @apiParam {Integer}                                 [location_id]                Location_id
    @apiParam {String}                                  [product_sku]                Product_sku
    @apiParam {Integer}                                 [outlet_id]                  Outlet_id
    @apiParam {String}                                  [sub_category_filter]        Sub_category_filter
    @apiParam {String}                                  [redeemability]              Redeemability value
    @apiParam {String}                                  [filter_by_type]             Filter_by_type
    @apiParam {String}                                  [query_type]                 Query_type
    @apiParam {String}                                  [category]                   Name category to filter outlets by
    @apiParam {String}                                  [user_include_cheers]        User include cheers
    @apiParam {String}                                  [location_id]                ID of location to filter outlets by
    @apiParam {String='de', 'en', 'ar', 'cn', 'el', 'zh'}       [language]           Response language
    """
    request_parser = outlet_validation_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='outlets_api/outlets_api.log',
        ),
        'name': 'outlets_api'
    }
    strict_token = True
    required_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.location_id = self.request_args.get('location_id')
        self.locale = self.request_args.get('locale')
        self.message_locale = CommonHelpers.get_locale_for_messaging(self.request_args.get('language'))
        self.offer_redeemability = self.request_args.get('redeemability')
        self.filter_by_type = self.request_args.get('filter_by_type')
        self.queryType = self.request_args.get('query_type')
        self.query = self.request_args.get('query')
        self.outlet_id = self.request_args.get('outlet_id')
        self.offset = self.request_args.get('offset')
        self.is_more_sa = self.request_args.get('is_more_sa')
        self.is_cuckoo = self.request_args.get('is_cuckoo')
        self.is_cheers = self.request_args.get('is_cheers')
        self.lat = self.request_args.get('lat')
        self.lng = self.request_args.get('lng')
        self.radius = self.request_args.get('radius')
        self.cuisine = self.request_args.get('cuisine')
        self.user_include_cheers = self.request_args.get('user_include_cheers')
        self.is_delivery = self.request_args.get('is_delivery')
        self.category = self.request_args.get('category')
        self.query_type = self.request_args.get('query_type')
        self.neighborhood = self.request_args.get('neighborhood')
        self.mall = self.request_args.get('mall')
        self.hotel = self.request_args.get('hotel')
        self.sub_category_filter = self.request_args.get('sub_category_filter')
        self.cuisine_filter = self.request_args.get('cuisine_filter[]')
        self.filters_selected_for_yes = self.request_args.get('filters_selected_for_yes[]')
        self.filters_selected_for_no = self.request_args.get('filters_selected_for_no[]')
        self.billing_country = self.request_args.get('billing_country')
        self.fuzzy = self.request_args.get('fuzzy')
        self.redeemability_first = self.request_args.get('first_sort_by_redeemability')
        self.is_company_specific = self.request_args.get('is_company_specific')
        self.show_monthly_offers = self.request_args.get('show_monthly_offers')
        self.show_new_offers = self.request_args.get('show_new_offers')
        self.app_version = self.request_args.get('app_version')
        self.show_only_core_product_offers = self.request_args.get('show_only_core_product_offers')
        self.product_sku = self.request_args.get('product_sku')
        self.sort = self.request_args.get('sort')
        self.is_company_specific = self.request_args.get('is_company_specific')

    def initialize_local_veriables(self):
        """
        Sets variables for api
        """
        self.company = get_company()

    def initialize_class_attributes(self):
        """
        Initialize class attributes
        """
        self.limit = OutletRepositoryWl.MAX_OUTLETS
        self.outlet_ids = []
        self._fuzzy_search_outlet_ids = []
        self._fuzzy_search_outlet_id_score = []
        self.is_fuzzy_server_down = False
        self.__fuzzy_host = current_app.config['ELASTIC_SEARCH_URL']
        self.elastic_search_is_on = current_app.config["ELASTIC_SEARCH_IS_ON"]
        self.elastic_search_min_string_length_for_search = current_app.config[
            "ELASTIC_SEARCH_MIN_STRING_LENGTH_FOR_SEARCH"
        ]
        self.customer = get_current_customer()
        self.customer_id = self.customer.get('customer_id', 0)

    def initialize_repos(self):
        """
        Initialize repos
        """
        self.customer_profile_class_instance = CustomerProfileWhiteLabel()
        self.product_repo = WLProductRepository()
        self.redemption_repo = RedemptionRepositoryWhiteLabel()
        self.offer_wl_active_repo = OfferWlRepository()
        self.outlet_repo = OutletRepositoryWl()
        self.wl_tabs_repo = WlTabsRepository()
        self.wl_validation_repo = WlValidationRepository()
        self.redemption_class_instance = RedemptionRepositoryWhiteLabel()
        self.translation_manager = TranslationManager()

    def load_customer_profile_and_session_data(self):
        """
        Load the customer-profile and customer session_data
        """
        if self.customer_id:
            self.customer_profile = self.customer_profile_class_instance.load_customer_profile_by_user_id(
                self.customer_id
            )

    def is_show_monthly_offers(self):
        """
        Checks Monthly offers in outlet
        """
        if not self.show_monthly_offers:
            self.show_monthly_offers = False
            if (
                self.filter_by_type == str(self.offer_wl_active_repo.TYPE_MEMBER) and
                self.offer_redeemability == self.offer_wl_active_repo.Redeemability_reusable
            ):
                self.show_monthly_offers = True

        self.offer_valid_from_start_date = datetime.datetime.now().replace(month=1, day=31)  # Offers Cut off date
        self.offer_valid_from_cut_off_date = datetime.datetime.now()
        self.offer_valid_from_cut_off_date = self.offer_valid_from_cut_off_date.replace(hour=0, minute=0, second=0)
        self.offer_valid_from_cut_off_date = self.offer_valid_from_cut_off_date - timedelta(days=30)
        self._is_fuzzy_search_on = (
            (self.elastic_search_is_on or self.fuzzy) and
            self.query and
            self.queryType == 'name' and
            self.locale == 'en'
        )
        if self.query in GlobalConstants.EID_OFFERS:
            self.query = 'eid offer'
        if self.query == GlobalConstants.EID_OFFER:
            self._is_fuzzy_search_on = False

    def get_tabs_info(self):
        """
        Gets tabs info
        """
        self.tabs = []
        self.hsbc_black_card_holder = False
        if (
            self.customer.get('customer_id') and
            self.company == WLCompany.COMPANY_CODE_ENTERTAINER_HSBC
        ):
            user_group = self.wl_validation_repo.get_user_group(self.company, self.customer_id)
            if user_group == WlValidationRepository.SECOND_GROUP:
                self.hsbc_black_card_holder = True
        if (
            self.offset == 0 and
            not self.filter_by_type
        ):
            self.show_buy_more_tab = False

            # Same as commented in Php
            # self.show_buy_more_tab = len(self.customer['purchased_product_ids']) > 0
            # if self.show_buy_more_tab:
            #     purchasable_product = self.product_wl_active_repo.get_purchasable_products(
            #         self.company,
            #         self.location_id
            #     )
            #     show_buy_more_tab = len(self.purchasable_product['purchasable_products_this_location']) > 0

    def skip_mode(self):
        """
        Skip mode
        """
        if not self.customer.get('session_token'):
            if not self.customer.get(GlobalConstants.IS_PREACTIVATED_APP):
                self.send_response_flag = True
                self.response = {
                    'success': True,
                    'message': self.translation_manager.get_translation(
                        self.translation_manager.success,
                        self.locale
                    ),
                    'data': {
                        'search_results': [],
                        'featured_merchants': [],
                        'outlets': [],
                        'tabs': self.tabs
                    }
                }
                self.status_code = 200
                return self.send_response(self.response, self.status_code)
            else:
                self.user_groups = [WlUserGroup.DEFAULT_USER_GROUP]
                self.customer[GlobalConstants.PRODUCT_IDS] = self.product_repo.get_configured_products(
                    self.company,
                    self.user_groups
                )

    def set_categories(self):
        self.categories = HomeScreenRepositoryWL.get_categories(
            is_user_logged_in=self.customer.get('is_user_logged_in'),
            company=self.company,
            user_id=self.customer_id,
            location_id=self.location_id,
            purchased_product_ids=[],
            purchasable_product_ids=[],
            locale=self.locale
        )
        self.search_results = []
        self.final_outlets = []

    def is_fuzzy_search_on(self):
        if self._is_fuzzy_search_on:
            __fuzzy_search_manager = FuzzySearchManager()
            fuzzy_search_result = __fuzzy_search_manager.get_fuzzy_results(
                self.query,
                self.category,
                self.sub_category_filter
            )
            if fuzzy_search_result.is_timeout_or_server_down:
                self._is_fuzzy_search_on = False
                self.is_fuzzy_server_down = True
            elif (
                fuzzy_search_result.is_succeeded and
                fuzzy_search_result.total_unique_results_found > 0
            ):
                self._fuzzy_search_outlet_ids = fuzzy_search_result.outlet_ids
                self._fuzzy_search_outlet_id_score = fuzzy_search_result.outlet_id_score

    def initialize_data_offers(self):
        """
        Set offers data to find offers.
        """
        self.data_offers = dict()
        self.data_offers['locale'] = self.locale
        self.data_offers['customer'] = self.customer
        self.data_offers['product_sku'] = self.product_sku
        self.data_offers['offer_redeemability'] = self.offer_redeemability
        self.data_offers['show_only_core_product_offers'] = self.show_only_core_product_offers
        self.data_offers['is_cuckoo'] = self.is_cuckoo
        self.data_offers['is_cheers'] = self.is_cheers
        self.data_offers['is_delivery'] = self.is_delivery
        self.data_offers['show_monthly_offers'] = self.show_monthly_offers
        self.data_offers['show_new_offers'] = self.show_new_offers
        self.data_offers['is_more_sa'] = self.is_more_sa
        self.data_offers['user_include_cheers'] = self.user_include_cheers
        self.data_offers['category'] = self.category
        self.data_offers['_is_fuzzy_search_on'] = self._is_fuzzy_search_on
        self.data_offers['sub_category_filter'] = self.sub_category_filter
        self.data_offers['outlet_id'] = self.outlet_id
        self.data_offers['location_id'] = self.location_id
        self.data_offers['filter_by_type'] = self.filter_by_type
        self.data_offers['is_company_specific'] = self.is_company_specific
        self.data_offers['offer_valid_from_start_date'] = self.offer_valid_from_start_date
        self.data_offers['offer_valid_from_cut_off_date'] = self.offer_valid_from_cut_off_date

    def get_offers_from_db(self):
        self.offers = self.offer_wl_active_repo.find_offers(self.data_offers)

    def get_redemptions_quantities(self):
        """
        Set redemptions quantities.
        """
        if self.customer:
            self.redemptions_quantities = self.redemption_class_instance.get_redeemed_quantities_for_customer(
                self.customer_id,
                self.company
            )

    def set_offer_related_defaults(self):
        self.product_offers = []

    def process_offers(self):
        if self.offers:
            self.set_offer_related_defaults()
            for offer in self.offers:
                product_ids = offer['product_id'].split(',')
                product_skus = offer['product_sku'].split(',')
                product_offer_count = len(product_ids)
                for index in range(product_offer_count):
                    self.product_offers.append(copy.deepcopy(offer))
                    self.product_offers[-1]['product_id'] = product_ids[index]
                    self.product_offers[-1]['product_sku'] = product_skus[index]
                    self.product_offers[-1]['offer_product'] = '{}_{}'.format(
                        offer['id'],
                        product_ids[index]
                    )
                    purchased_through_connect = False
                    self.product_offers[-1]['purchased_through_connect'] = purchased_through_connect
            self.offers = self.product_offers

        if self.offers:
            #  Collect Outlet SF IDs
            self.get_redemptions_quantities()
            self.query_matched_offers_outlets = []  # outlet id's of the offers that match search query
            self.outlet_offer_info = {}
            for offer in self.offers:
                offer['expiration_date'] = self.offer_wl_active_repo._fix_expiration_date(offer['expiration_date'])
                this_outlet_ids = offer['outlet_ids'].split(',')
                if not self._is_fuzzy_search_on:
                    if (
                        self.query and
                        self.queryType == 'name'
                    ):
                        if not self.outlet_repo.is_search_string_found(offer['offer_name'], self.query, True):
                            for ids in this_outlet_ids:
                                self.query_matched_offers_outlets.append(ids)
                redeemability = self.offer_wl_active_repo.calculate_offer_redeemability_for_customer(
                    self.customer,
                    offer,
                    self.redemptions_quantities
                )
                offer['is_redeemable'] = redeemability['is_redeemable']
                offer['redeemability'] = redeemability['redeemability']
                offer['is_purchased'] = redeemability['is_purchased']

                try:
                    outlet_ids = list(map(int, list(filter(None, offer.get('outlet_ids').split(',')))))
                except AttributeError:
                    outlet_ids = [offer['outlet_ids']]

                for outlet_id in outlet_ids:
                    self.outlet_ids.append(outlet_id)

                    if not self.outlet_offer_info.get(outlet_id):
                        self.outlet_offer_info[outlet_id] = {'offer_ids': [offer['id']]}
                        changes = {
                            'product_id': [offer['product_id']],
                            'product_sku': [offer['product_sku']],
                            'is_redeemable': offer['is_redeemable'],
                            'redeemability': offer['redeemability'],
                            'is_purchased': offer['is_purchased'],
                            'is_cheers': True if offer['is_cheers'] else False,
                            'is_delivery': True if offer['is_delivery'] else False,
                            'is_more_sa': True if offer['is_more_sa'] else False,
                            'type': offer['type'],
                            'is_point_based_offer': offer['is_point_based_offer']
                        }
                        self.outlet_offer_info[outlet_id].update(changes)

                        if self.show_monthly_offers or offer['type'] == self.offer_wl_active_repo.TYPE_MEMBER:
                            self.outlet_offer_info[outlet_id].update({'is_monthly': True})
                        else:
                            self.outlet_offer_info[outlet_id].update({'is_monthly': False})

                        if (self.show_new_offers or (
                                offer['type'] != OfferWlRepository.TYPE_MEMBER and
                                offer['valid_from_date'] > self.offer_valid_from_start_date and
                                offer['valid_from_date'] > self.offer_valid_from_cut_off_date
                        )):
                            self.outlet_offer_info[outlet_id]['is_new'] = True
                        else:
                            self.outlet_offer_info[outlet_id]['is_new'] = False
                        if not self.outlet_offer_info[outlet_id].get('categories'):
                            self.outlet_offer_info[outlet_id]['categories'] = []

                        self.outlet_offer_info[outlet_id]['categories'].append(offer['merchant_category'])
                        if not self.outlet_offer_info[outlet_id].get('sub_categories'):
                            self.outlet_offer_info[outlet_id]['sub_categories'] = []
                        if (
                            offer['sub_category'] and
                            offer['sub_category'] not in self.outlet_offer_info[outlet_id].get('sub_categories')
                        ):
                            self.outlet_offer_info[outlet_id]['sub_categories'].append(offer['sub_category'])
                    else:
                        if offer['id'] not in self.outlet_offer_info[outlet_id].get('offer_ids'):
                            self.outlet_offer_info[outlet_id]['offer_ids'].append(offer['id'])
                        if offer['product_id'] not in self.outlet_offer_info[outlet_id].get('product_id'):
                            self.outlet_offer_info[outlet_id]['product_id'].append(offer['product_id'])
                        if offer['product_sku'] not in self.outlet_offer_info[outlet_id].get('product_sku'):
                            self.outlet_offer_info[outlet_id]['product_sku'].append(offer['product_sku'])
                        if offer['is_redeemable']:
                            self.outlet_offer_info[outlet_id]['is_redeemable'] = True
                        if offer['redeemability'] > self.outlet_offer_info[outlet_id]['redeemability']:
                            self.outlet_offer_info[outlet_id]['redeemability'] = offer['redeemability']
                        if offer['is_purchased']:
                            self.outlet_offer_info[outlet_id]['is_purchased'] = offer['is_purchased']
                        if offer['is_cheers']:
                            self.outlet_offer_info[outlet_id]['is_cheers'] = offer['is_cheers']
                        if offer['is_delivery']:
                            self.outlet_offer_info[outlet_id]['is_delivery'] = offer['is_delivery']
                        self.outlet_offer_info[outlet_id]['is_more_sa'] = (
                            True if offer['is_more_sa'] else self.outlet_offer_info[outlet_id]['is_more_sa']
                        )
                        self.outlet_offer_info[outlet_id]['type'] = (
                            offer['type']
                            if offer['type'] > self.outlet_offer_info[outlet_id]['type']
                            else self.outlet_offer_info[outlet_id]['type']
                        )
                        self.outlet_offer_info[outlet_id]['is_point_based_offer'] = (
                            True
                            if offer['is_point_based_offer']
                            else self.outlet_offer_info[outlet_id]['is_point_based_offer']
                        )
                        if not self.outlet_offer_info[outlet_id].get('categories'):
                            self.outlet_offer_info[outlet_id]['categories'] = []
                        if offer['merchant_category'] not in self.outlet_offer_info[outlet_id]['categories']:
                            self.outlet_offer_info[outlet_id]['categories'].append(offer['merchant_category'])
                        if (
                            self.show_monthly_offers or
                            offer['type'] == OfferWlRepository.TYPE_MEMBER or
                            self.outlet_offer_info[outlet_id]['is_monthly']
                        ):
                            self.outlet_offer_info[outlet_id]['is_monthly'] = True
                        else:
                            self.outlet_offer_info[outlet_id]['is_monthly'] = False
                        if (self.show_new_offers or self.outlet_offer_info[outlet_id]['is_new'] or (
                                offer['type'] != OfferWlRepository.TYPE_MEMBER and
                                offer['valid_from_date'] > self.offer_valid_from_start_date and
                                offer['valid_from_date'] > self.offer_valid_from_cut_off_date
                        )):
                            self.outlet_offer_info[outlet_id]['is_new'] = True
                        else:
                            self.outlet_offer_info[outlet_id]['is_new'] = False

                    if not self.outlet_offer_info[outlet_id].get('sub_categories'):
                        self.outlet_offer_info[outlet_id]['sub_categories'] = []

                    if (
                        offer['sub_category'] and
                        offer['sub_category'] not in self.outlet_offer_info[outlet_id].get('sub_categories')
                    ):
                        self.outlet_offer_info[outlet_id]['sub_categories'].append(offer['sub_category'])

            self.update_outlets()
            self.process_outlets()
            self.convert_merchant_name_lower()
            self.process_fuzzy_search()
        if self.limit <= 0:
            filter_limit = None
        else:
            filter_limit = self.limit
        self.filtered_outlets = self.final_outlets[self.offset:filter_limit]

    def update_outlets(self):
        self.outlet_ids = list(set(list(filter(None, self.outlet_ids))))
        self.merchant_criteria = {
            'lat': self.lat,
            'lng': self.lng,
            'radius': self.radius,
            'category': self.category,
            'cuisine': self.cuisine,
            'sort': self.sort,
            'query': self.query,
            'query_type': self.query_type,
            'neighborhood': self.neighborhood,
            'mall': self.mall,
            'hotel': self.hotel,
            'billing_country': self.billing_country,
            'outlet_ids': self.outlet_ids,
            'sub_category_filter': self.sub_category_filter,
            'cuisine_filter': self.cuisine_filter,
            'filters_selected_for_yes': self.filters_selected_for_yes,
            'filters_selected_for_no': self.filters_selected_for_no,
            'fuzzy_search_outlet_id_score': self._fuzzy_search_outlet_id_score,
        }
        # Grab current, active Outlets that match criteria
        self.outlets = self.outlet_repo.find_by_criteria_merchant_attributes(
            merchant_criteria=self.merchant_criteria,
            locale=self.locale
        )
        self.redeemabilities = []
        self.distances = []
        self.merchant_names = []
        self.final_outlets = []
        self.outlet_ids = []
        self.offers = []

    def process_outlets(self):
        for outlet in self.outlets:
            outlet['product_id'] = self.outlet_offer_info[outlet['id']]['product_id']
            outlet['product_sku'] = self.outlet_offer_info[outlet['id']]['product_sku']
            outlet['top_offer_redeemability'] = self.outlet_offer_info[outlet['id']]['redeemability']
            outlet['top_offer_type'] = self.outlet_offer_info[outlet['id']]['type']
            outlet['is_redeemable'] = self.outlet_offer_info[outlet['id']]['is_redeemable']
            outlet['is_purchased'] = self.outlet_offer_info[outlet['id']]['is_purchased']
            outlet['is_monthly'] = self.outlet_offer_info[outlet['id']]['is_monthly']
            outlet['is_new'] = self.outlet_offer_info[outlet['id']]['is_new']
            outlet['is_cheers'] = self.outlet_offer_info[outlet['id']]['is_cheers']
            outlet['is_delivery'] = self.outlet_offer_info[outlet['id']]['is_delivery']
            outlet['is_more_sa'] = self.outlet_offer_info[outlet['id']]['is_more_sa']
            outlet['is_point_based_offer'] = self.outlet_offer_info[outlet['id']]['is_point_based_offer']
            outlet['locked_image_url'] = ""
            outlet['categories'] = self.outlet_offer_info[outlet['id']]['categories']
            outlet['sub_categories'] = self.outlet_offer_info[outlet['id']]['sub_categories']

            if outlet['categories']:
                outlet['categories'] = OfferManager().sort_categories(outlet['categories'])

            outlet['merchant_categories'] = outlet['categories']
            outlet['merchant_categories_analytics'] = OfferManager().get_category_codes_for_analytics(
                outlet['merchant_categories'])

            outlet['merchant']['categories'] = outlet['merchant_categories']
            outlet['merchant']['categories_analytics'] = outlet['merchant_categories_analytics']

            if self.outlet_offer_info[outlet['id']]['sub_categories']:
                outlet['merchant']['digital_section'] = ", ".join(
                    self.outlet_offer_info[outlet['id']]['sub_categories'])
            else:
                outlet['merchant']['digital_section'] = ""
            if (
                self.category and
                self.category in GlobalConstants().get_valid_categories()
            ):
                outlet['merchant']['category'] = self.category
            elif outlet['categories']:
                outlet['merchant']['category'] = outlet['categories'][0]
            else:
                outlet['merchant']['category'] = ""

            if self.company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
                if outlet['merchant']['category'] == CategoriesRepositoryWl.category_API_Name_Retail:
                    outlet['merchant']['category'] = CategoriesRepositoryWl.category_API_Name_Services
                company_skus = GlobalConstants().get_configured_sku_by_company(self.company)
                outlet['is_company_specific'] = self.is_company_specific
                if not outlet['is_company_specific']:
                    for skus in outlet['product_sku']:
                        if skus in company_skus:
                            outlet['is_company_specific'] = True
                            break
            OutletRepositoryWl().set_images_and_attributes(
                self.company,
                outlet,
                self.categories,
                self.category
            )
            if not self._is_fuzzy_search_on:
                if self.query and self.queryType == 'name':
                    if (
                            not self.outlet_repo.is_search_string_found(outlet['merchant_name'], self.query, True) and
                            outlet['id'] not in self.query_matched_offers_outlets
                    ):
                        continue

            if (
                self.offer_redeemability != self.offer_wl_active_repo.Redeemability_not_redeemable and
                self.offer_redeemability.lower() != 'all'
            ):
                if (
                        (
                            self.offer_redeemability == self.offer_wl_active_repo.Redeemability_redeemable_reusable and
                            not (outlet['top_offer_redeemability'] == self.offer_wl_active_repo.REDEEMABLE or
                                 outlet['top_offer_redeemability'] == self.offer_wl_active_repo.REUSABLE)
                        ) or
                        (
                            self.offer_redeemability == self.offer_wl_active_repo.Redeemability_reusable and
                            outlet['top_offer_redeemability'] != self.offer_wl_active_repo.REUSABLE
                        ) or
                        (
                            self.offer_redeemability == self.offer_wl_active_repo.Redeemability_not_redeemable and
                            outlet['top_offer_redeemability'] != self.offer_wl_active_repo.NOT_REDEEMABLE
                        ) or
                        (
                            self.offer_redeemability == self.offer_wl_active_repo.Redeemability_redeemable and
                            outlet['top_offer_redeemability'] != self.offer_wl_active_repo.REDEEMABLE
                        ) or
                        (
                            self.offer_redeemability == self.offer_wl_active_repo.Redeemability_redeemed and
                            outlet['top_offer_redeemability'] != self.offer_wl_active_repo.REDEEMED
                        )
                ):
                    continue

            self.final_outlets.append(outlet)
            self.redeemabilities.append(outlet['top_offer_redeemability'])
            self.merchant_names.append(outlet['merchant_name'].lower())
            self.distances.append(outlet['distance'])

    def convert_merchant_name_lower(self):
        """
        Convert merchant name into lower in final outlets
        :return:
        """
        for outlet in self.final_outlets:
            outlet.update({'merchant_name': outlet['merchant_name'].lower()})

    def process_fuzzy_search(self):
        """
        Process the fuzzy search
        """

        if self._is_fuzzy_search_on:
            self.__wildcard_outlets = []
            self.__fuzzy_search_outlets = []
            self.fuzzy_search_result = FuzzySearchManager().get_fuzzy_results(
                self.query,
                self.category,
                self.sub_category_filter
            )
            if self.fuzzy_search_result.is_timeout_or_server_down:
                self._is_fuzzy_search_on = False
                self.is_fuzzy_server_down = True
            elif self.fuzzy_search_result.is_succeeded and self.fuzzy_search_result.total_unique_results_found:
                self._fuzzy_search_outlet_ids = self.fuzzy_search_result.outlet_ids
                self._fuzzy_search_outlet_id_score = self.fuzzy_search_result.outlet_id_score

            for __outlet in self.final_outlets:
                if __outlet['fuzzy_relevance'] == FuzzySearchManager().SCORE_FOR_WILDCARD_SEARCH:
                    self.__wildcard_outlets.append(__outlet)
                else:
                    self.__fuzzy_search_outlets.append(__outlet)
            self.__wildcard_outlets = sorted(self.__wildcard_outlets, key=itemgetter('distance'))
            self.__fuzzy_search_outlets = sorted(self.__fuzzy_search_outlets, key=itemgetter('fuzzy_relevance'))
            self.final_outlets = self.__wildcard_outlets + self.__fuzzy_search_outlets
        else:
            if self.sort == GlobalConstants.DEFAULT:
                if self.redeemability_first:
                    self.final_outlets = multi_key_sort(
                        self.final_outlets,
                        ['-top_offer_redeemability', 'distance', 'merchant_name']
                    )
                else:
                    self.final_outlets = multi_key_sort(
                        self.final_outlets,
                        ['distance', 'merchant_name', '-top_offer_redeemability']
                    )
            if self.sort == GlobalConstants.ALPHA:
                if self.redeemability_first:
                    self.final_outlets = multi_key_sort(
                        self.final_outlets,
                        ['-top_offer_redeemability', 'merchant_name']
                    )
                else:
                    self.final_outlets = multi_key_sort(
                        self.final_outlets,
                        ['merchant_name', '-top_offer_redeemability']
                    )
        self.merchant_names = []

    def prepare_final_response(self):
        self.outlet_response = {
            'is_fuzzy_search_results': self._is_fuzzy_search_on,
            'is_fuzzy_server_down': self.is_fuzzy_server_down,
            'limit': str(self.limit),
            'outlets': self.filtered_outlets
        }
        self.set_response({
            'success': True,
            'message': 'success',
            'data': self.outlet_response
        })

    def process_request(self, *args, **kwargs):
        self.initialize_local_veriables()
        self.initialize_repos()
        self.initialize_class_attributes()
        self.is_show_monthly_offers()
        self.load_customer_profile_and_session_data()
        self.get_tabs_info()
        self.skip_mode()
        if self.is_send_response_flag_on():
            return
        self.set_categories()
        self.is_fuzzy_search_on()
        self.initialize_data_offers()
        self.get_offers_from_db()
        self.process_offers()
        self.prepare_final_response()
