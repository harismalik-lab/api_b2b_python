"""
User Profile api white label
"""
import datetime
from math import floor

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BasePostResource
from common_white_label.common_helpers import CommonHelpers
from common_white_label.constants import GlobalConstants
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.merchant_repo import MerchantRepositoryWl
from repositories_white_label.wl_company_repo import WLCompany
from repositories_white_label.wl_gem_points_repo import WlGemPointsRepository
from user_authentication_white_label.authentication import get_company, get_current_customer
from white_labels_api.v1.user_profile_get_api.validation import user_profile_parser


class UserProfileWhiteLable(BasePostResource):
    """
    @api {get} /v1/user/profile Get User Profile
    @apiSampleRequest /v1/user/profile
    @apiVersion 1.0.0
    @apiName user/profile
    @apiGroup User
    @apiParam {String="ios","android","web"}        __platform          Mobile Platform
    @apiParam {String}                              app_version         Mobile App Version
    @apiParam {String="en", "ar", "cn", "el","zh"}  [language]          Response Language
    @apiParam {String}                              [currency]          Currency
    """
    request_parser = user_profile_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='user_profile_api/user_profile_api.log',
        ),
        'name': 'user_profile_api'
    }
    required_token = True
    strict_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')
        self.currency = self.request_args.get('currency', '')

    def initialize_repose(self):
        """
        Initializes the repositories
        """
        self.merchant_repo = MerchantRepositoryWl()
        self.customer_repo = CustomerProfileWhiteLabel()
        self.gems_points_repo = WlGemPointsRepository()

    def initialize_local_veriables(self):
        """
        Sets variables for api
        """
        self.company = get_company()
        self.locale = CommonHelpers.get_locale(self.locale)
        self.messages_locale = CommonHelpers.get_locale_for_messaging(self.locale)
        self.current_year = datetime.date.year

    def get_user_profile(self):
        """
        Gets user profile data
        """
        self.customer = get_current_customer()
        self.customer_id = self.customer.get(GlobalConstants.CUSTOMER_ID)
        self.user_profile = self.customer_repo.get_user_profile_by_user_id(
            self.customer_id,
            self.company
        )
        self.owned_products = self.customer_repo.get_customer_purchased_skus_profile(
            self.customer_id,
            self.company,
            self.messages_locale
        )
        self.savings = self.customer_repo.get_user_savings_online(
            self.customer_id,
            self.current_year,
            self.currency,
            self.messages_locale,
            self.company
        )
        if self.savings:
            self.savings['lifetime'] = self.savings.get('savings')
            self.savings['yearly'] = self.savings.get('yearly_savings')
        if self.user_profile.get('days_since_registration'):
            self.days_since_registration = int(self.user_profile.get('days_since_registration')) + 1
        else:
            self.days_since_registration = 1
        months = floor(self.days_since_registration) / 30
        years = floor(self.days_since_registration) / 365
        if months >= 1:
            months = months
        else:
            months = 1
        if years >= 1:
            years = years
        else:
            years = 1
        self.user_profile['member_since'] = self.customer_repo.calculate_aging(
            self.days_since_registration
        )
        if 'days_since_registration' in self.user_profile.keys():
            del self.user_profile['days_since_registration']
        self.user_profile['savings'] = str(self.savings.get('lifetime'))
        self.user_profile['savings_yearly_int'] = int(self.savings.get('yearly'))
        self.user_profile['savings_lifetime_int'] = int(self.savings.get('lifetime'))
        self.user_profile['savings_monthly_avg_int'] = floor(int(self.savings.get('lifetime')) / months)
        self.user_profile['savings_yearly_avg_int'] = floor(int(self.savings.get('lifetime')) / years)
        self.user_profile['currency'] = 'AED'
        self.user_profile['products'] = []
        self.user_profile['user_creation_date'] = str(self.user_profile.get('user_creation_date'))
        self.user_profile['redemptionsCount'] = str(self.user_profile.get('redemptions_count'))
        self.user_profile['userId'] = self.user_profile.get('user_id')

        if self.company != WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
            self.user_profile['products'] = self.owned_products
        if self.company.lower() == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
            user_points_earned = 0
            user_points_result = self.gems_points_repo.get_user_points_stats(self.customer_id)
            if user_points_result:
                user_points_earned = user_points_result['points_earned']
            self.user_profile['points'] = int(user_points_earned)
            self.user_profile['points_yearly'] = int(user_points_earned)
        else:
            self.user_profile['external_savings'] = int(self.savings.get('points', 0))
        if self.company.lower() == WLCompany.COMPANY_CODE_ENTERTAINER_EMAX:
            membership_number = self.customer_repo.get_user_membership_card(self.customer_id, self.company)
            self.user_profile['membership_number'] = WLCompany.format_credit_card(membership_number.get('card_number'))
        try:
            del self.user_profile['user_id']
            del self.user_profile['redemptions_count']
        except KeyError:
            pass

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': self.user_profile,
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.initialize_repose()
        self.initialize_local_veriables()
        self.get_user_profile()
        self.generate_final_response()
