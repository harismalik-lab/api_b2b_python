"""
User Spend Summary
"""
from collections import OrderedDict
from datetime import date

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from common_white_label.common_helpers import CommonHelpers
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.wl_invoice_headers_repo import WlInvoiceHeadersRepository
from user_authentication_white_label.authentication import get_company, get_current_customer
from white_labels_api.v1.user_spend_summary.validation import user_spend_parser


class UserSpendSummaryApiWl(BaseGetResource):
    """
    @api {get} /v1/user/spend/summary Get user_spend_summary
    @apiSampleRequest /v1/user/spend/summary
    @apiVersion 1.0.0
    @apiName user_spend_summary
    @apiGroup Configurations
    @apiParam {String}                              app_version     Mobile App Version
    @apiParam {String="by_month","by_year"}         summary_type    User spend summary type by_month|by_year
    @apiParam {String="en", "ar", "cn", "el","zh"}  [language]      Response Language
    """
    request_parser = user_spend_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='user_spend_summary/user_spend_summary.log',
        ),
        'name': 'user_spend_summary'
    }
    strict_token = True
    required_token = True

    def populate_request_arguments(self):
        """
        populate request arguments
        """
        self.language = self.request_args.get('language')
        self.currency = self.request_args.get('currency')
        self.loaction_id = self.request_args.get('location_id')
        self.summary_type = self.request_args.get('summary_type')

    def initialize_repo(self):
        """
        Initialize repositories for accessing user spend summary and valiating user
        """
        self.invoice_repo = WlInvoiceHeadersRepository()
        self.translation_manager = TranslationManager()

    def initialize_class_attributes(self):
        """
        Initializing class attribute
        """
        self.locale = CommonHelpers.get_locale(self.language, self.loaction_id)
        current_date = date.today()
        self.current_month_name = current_date.strftime('%B')
        self.current_user = get_current_customer()
        self.current_month = current_date.month
        self.current_year = current_date.year
        self.company = get_company()

    def month_wise_redemption(self):
        """
        Generates user spend summary based on month wise redemption
        """
        progress_data = []
        index = 0
        accumulative_sum = 0
        if self.invoice_history:
            for data in self.invoice_history:
                if data.get('invoice_date').year == self.current_year:
                    progress_data_dict = OrderedDict()
                    index = [index for index, value in enumerate(progress_data) if
                             value.get("name") == data.get("invoice_date").strftime("%Y %B")]
                    if not index:
                        progress_data_dict["index"] = len(progress_data) + 1
                        progress_data_dict["name"] = data.get("invoice_date").strftime("%Y %B")
                        progress_data_dict["redemption_count"] = 0
                        progress_data_dict["total_redemptions"] = self.total_redemptions
                        progress_data_dict["savings"] = 0
                        progress_data_dict["total_savings"] = self.redemption_summary.get("life_time_saving")
                        progress_data_dict["currency"] = ""
                        progress_data_dict["redemptions"] = []
                        progress_data.append(progress_data_dict)
                        index = [len(progress_data) - 1]
                    if data.get('invoice_date').month == self.current_month:
                        accumulative_sum += data.get("transaction_total_price")
                        graph_dict = OrderedDict()
                        graph_dict["index"] = data.get('invoice_date').day
                        graph_dict["value"] = accumulative_sum
                        graph_dict["currency"] = ""
                        self.redemption_summary["graph_data"].append(graph_dict)
                    progress_data[index[0]]["redemption_count"] += 1
                    savings = data.get("transaction_total_price")
                    progress_data[index[0]]["savings"] += savings
                    redemptions_dict = OrderedDict()
                    redemptions_dict["id"] = data.get('id')
                    # offer redemption date for progress data
                    redemptions_dict["date_created"] = str(data.get("invoice_date")).replace(' ', 'T').replace('.', '+')
                    redemptions_dict["savings"] = savings
                    progress_data[index[0]]["redemptions"].append(redemptions_dict)
        self.redemption_summary["progress_data"] = progress_data
        self.redemption_summary["progress_data"].reverse()

    def year_wise_redemption(self):
        """
        Generates user spend summary based on yearly data
        """
        progress_data = []
        index = 0
        if self.invoice_history:
            for data in self.invoice_history:
                progress_data_dict = OrderedDict()
                index = [index for index, x in enumerate(progress_data) if
                         x.get("name") == data.get("invoice_date").strftime("%Y")]

                if not index:
                    progress_data_dict["index"] = len(progress_data) + 1
                    progress_data_dict["name"] = data.get("invoice_date").strftime("%Y")
                    progress_data_dict["redemption_count"] = 0
                    progress_data_dict["total_redemptions"] = self.total_redemptions
                    progress_data_dict["savings"] = 0
                    progress_data_dict["total_savings"] = self.redemption_summary.get("life_time_saving")
                    progress_data_dict["currency"] = ""
                    progress_data.append(progress_data_dict.copy())
                    index = [len(progress_data) - 1]

                progress_data[index[0]]["redemption_count"] += 1
                progress_data[index[0]]["savings"] += data.get("transaction_total_price")

            accumultive_saving = 0
            for yearly_data in progress_data:
                accumultive_saving += yearly_data.get("savings")
                graph_dict = OrderedDict()
                graph_dict["value"] = accumultive_saving
                graph_dict["currency"] = ""
                self.redemption_summary["graph_data"].append(graph_dict)

            self.redemption_summary["progress_data"] = progress_data
            self.redemption_summary["progress_data"].reverse()

    def calculate_total_saving(self):
        """
        Generates global saving and redemption data w.r.t user spend summary
        """
        self.total_redemptions = 0
        if self.invoice_history:
            for data in self.invoice_history:
                self.total_redemptions += 1
                self.redemption_summary["life_time_saving"] += data.get('transaction_total_price')
                invoice_date = data.get("invoice_date")
                if invoice_date.year == self.current_year and invoice_date.month == self.current_month:
                    self.redemption_summary["current_month_saving"] += data.get('transaction_total_price')
        else:
            self.redemption_summary["life_time_saving"] = 0
            self.redemption_summary["current_month_saving"] = 0

    def get_your_invoice(self):
        """
        Get user invoices from repository
        """
        customer = self.current_user.get('customer_id')
        self.invoice_history = self.invoice_repo.find_all(customer, self.company)
        self.redemption_summary = OrderedDict()
        self.redemption_summary["current_year"] = self.current_year
        self.redemption_summary["current_month"] = self.current_month_name
        self.redemption_summary["current_month_saving"] = 0
        self.redemption_summary["currency"] = ''
        self.redemption_summary["life_time_saving"] = 0
        self.redemption_summary["graph_data"] = []
        self.redemption_summary["progress_data"] = []
        self.calculate_total_saving()

        if self.summary_type == WlInvoiceHeadersRepository.SUMMARY_BY_MONTH:
            self.month_wise_redemption()
        elif self.summary_type == WlInvoiceHeadersRepository.SUMMARY_BY_YEAR:
            self.year_wise_redemption()

    def generate_response(self):
        """
        Generates response of user spend summary in case of authorized user
        :return: sends user spend summary response
        """
        self.status_code = 200
        self.send_response_flag = True
        self.response = {
            "success": True,
            "message": self.translation_manager.get_translation(self.translation_manager.success, self.locale),
            'data': self.redemption_summary
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Main process to process user request
        """
        self.initialize_repo()
        self.initialize_class_attributes()
        self.get_your_invoice()
        self.generate_response()
