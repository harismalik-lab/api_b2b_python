from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import currency, language

user_spend_parser = get_request_parser()

user_spend_parser.add_argument(
    'language',
    default="en",
    required=False,
    type=language,
    location=['mobile', 'values', 'json']
)
user_spend_parser.add_argument(
    'currency',
    default='AED',
    type=currency,
    required=False,
    location=['mobile', 'values', 'json']
)
user_spend_parser.add_argument(
    'location_id',
    default=0,
    type=int,
    required=False,
    location=['mobile', 'values', 'json']
)
user_spend_parser.add_argument(
    'summary_type',
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
