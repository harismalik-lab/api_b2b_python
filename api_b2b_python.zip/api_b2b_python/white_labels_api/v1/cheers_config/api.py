"""
Cheers Config API white label
"""
from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BaseGetResource
from common_white_label.common_helpers import CommonHelpers
from repositories_white_label.cheers_config_repo import CheersConfigsRepositoryWL
from user_authentication_white_label.authentication import get_company
from white_labels_api.v1.cheers_config.validation import cheers_config_parser


class CheersConfigsApiWL(BaseGetResource):
    """
    @api {get} /v1/configurations/cheers Get Cheers configurations
    @apiSampleRequest /v1/configurations/cheers
    @apiVersion 1.0.0
    @apiName CheersConfig
    @apiGroup Configurations
    @apiParam {String}                                       app_version             Mobile app version
    @apiParam {String="ios","android", "web"}                __platform              Mobile Platform
    @apiParam {String="en", "ar", "cn", "el", "de", "zh"}    [language]              Response language
    """
    request_parser = cheers_config_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='cheers_configs_api/cheers_config_api.log',
        ),
        'name': 'cheers_configs_api'
    }

    def populate_request_arguments(self):
        """
        Add request arguments of cheers config api
        """
        self.locale = self.request_args.get('language')

    def initialize_local_veriables(self):
        """
        Sets variables for api
        """
        self.company = get_company()

    def initialize_class_attributes(self):
        """
        Initialize class attributes for cheers config api
        """
        self.locale = CommonHelpers.get_locale(self.locale, location_id=0)

    def generate_final_response(self):
        """
        Sets final response of cheers config api
        :rtype: dict
        """
        cheers_configurations = CheersConfigsRepositoryWL.get_cheers_configuration(self.locale, self.company)
        self.send_response_flag = True
        self.response = {
            'data': {
                'cheers_rules': cheers_configurations
            },
            'success': True,
            'message': 'success'
        }
        self.status_code = 200

    def process_request(self):
        """
        Retrieve all the configs related to cheers
        """
        self.initialize_local_veriables()
        self.initialize_class_attributes()
        if self.is_send_response_flag_on():
            return
        self.generate_final_response()
