from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import (
    currency, device_list, language, marital_status, validate_gender
)

user_action_in_parser = get_request_parser()

user_action_in_parser.add_argument(
    'location_id',
    type=int,
    required=False,
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'language',
    type=language,
    required=False,
    default='en',
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'app_version',
    type=str,
    required=True,
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    '__platform',
    type=device_list,
    default='',
    required=True,
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'affiliate_code',
    type=str,
    required=False,
    default="",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'language_preference',
    type=str,
    required=False,
    default="",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'education_level',
    type=str,
    required=False,
    default="",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'occupation_level',
    type=str,
    required=False,
    default="",
    location=['mobile', 'values', 'json'],
)
user_action_in_parser.add_argument(
    'currency',
    type=currency,
    required=False,
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'lifestyle_preference',
    required=False,
    type=str,
    default="",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'age_bracket',
    type=str,
    required=False,
    default="",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'marital_status',
    type=marital_status,
    required=False,
    default="",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'income_bracket',
    required=False,
    default="",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'mobile_phone',
    type=str,
    required=False,
    default="",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'number_children',
    type=str,
    required=False,
    default="",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'residential_neighborhood',
    type=str,
    required=False,
    default="",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'business_neighborhood',
    type=str,
    required=False,
    default="",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'city_of_residence',
    type=str,
    required=False,
    default="",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'do_not_email',
    type=str,
    required=False,
    default="1",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'session_token',
    type=str,
    required=False,
    default="",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'country_of_residence',
    type=str,
    required=False,
    default="",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'nationality',
    type=str,
    required=False,
    default="",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'date_of_birth',
    type=str,
    required=False,
    default="",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'gender',
    type=validate_gender,
    required=False,
    default="",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'push_notifications',
    type=str,
    required=False,
    default="1",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'work_address',
    type=str,
    required=False,
    default="",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'home_address',
    type=str,
    required=False,
    default="",
    location=['mobile', 'values', 'json']
)
user_action_in_parser.add_argument(
    'default_currency',
    type=str,
    required=False,
    default="",
    location=['mobile', 'values', 'json']
)
