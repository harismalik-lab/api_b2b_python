"""
User action api
"""
import datetime

from dateutil.relativedelta import relativedelta

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BasePostResource
from common_white_label.common_helpers import CommonHelpers
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.translations_repo import TranslationManager
from user_authentication_white_label.authentication import get_company, get_current_customer
from white_labels_api.v1.users_user_id.validation import user_action_in_parser
from repositories_white_label.location_repo import LocationRepositoryWhiteLabel
from common_white_label.custom_fields_request_parser import boolean
from repositories_white_label.wl_company_repo import WLCompany
from common_white_label.constants import GlobalConstants


class PostUserActionApiWl(BasePostResource):
    """
    @api {post} /v1/users/action Post Update user's profile information.
    @apiSampleRequest /v1/users/{user_id}
    @apiVersion 1.0.0
    @apiName PostUserActionApiWl
    @apiGroup Users
    @apiParam {String}             __platform                    All supported platform
    @apiParam {String}             app_version                   App version
    @apiParam {String}             [language]                    Response language
    @apiParam {String}             [education_level]             Education
    @apiParam {String}             [occupation_level]            Occupation
    @apiParam {String}             [language_preference]         Language Preference
    @apiParam {String}             [default_currency]            Currency Preference
    @apiParam {String}             [lifestyle_preference]        Lifestyle Preference
    @apiParam {String}             [age_bracket]                 Age Bracket
    @apiParam {String}             [income_bracket]              Household Income Bracket
    @apiParam {String}             [mobile_phone]                Mobile phone number
    @apiParam {String}             [number_children]             Number of Children
    @apiParam {String}             [residential_neighborhood]    Residential Neighborhood
    @apiParam {String}             [business_neighborhood]       Business Neighborhood
    @apiParam {String}             [city_of_residence]           City of Residence
    @apiParam {String}             [country_of_residence]        Country of Residence
    @apiParam {String}             [nationality]                 Nationality
    @apiParam {String}             [date_of_birth]               Date of birth
    @apiParam {String}             [push_notifications]          Push notifications
    @apiParam {String}             [do_not_email]                Would you like to receive emails?
    @apiParam {String}             [work_address]                Work address
    @apiParam {String}             [home_address]                Home address
    @apiParam {String}             [currency]                    Currency
    @apiParam {String}             [marital_status]              Marital Status
    @apiParam {String}             [gender]                      Gender
    """
    request_parser = user_action_in_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='post_user_action_api/post_user_action_api.log',
        ),
        'name': 'post_user_action_api'
    }
    strict_token = True
    required_token = True

    def populate_request_arguments(self):
        """
        Add request arguments of post user action id
        """
        self.country_of_residence = self.request_args.get('country_of_residence')
        self.mobile_phone = self.request_args.get('mobile_phone')
        self.currency = self.request_args.get('currency')
        self.push_notifications = self.request_args.get('push_notifications')
        self.receive_email = self.request_args.get('do_not_email')
        self.date_of_birth = self.request_args.get('date_of_birth')
        self.nationality = self.request_args.get('nationality')
        self.locale = self.request_args.get('language')

    def initialize_repos(self):
        """
        Initialize repos for post user action api
        """
        self.customer_repo = CustomerProfileWhiteLabel()
        self.translation_manager = TranslationManager()

    def initialize_class_attributes(self):
        """
        Initialize class attributes of post user action api
        """
        self.customer = get_current_customer()
        self.messages_locale = CommonHelpers.get_locale(self.locale, location_id=0)
        self.company = get_company()
        self.user_id = self.customer.get('customer_id')

    def check_customer(self):
        """
        Check customer
        :rtype: dict
        """
        # if str(self.customer.get('customer_id')) != str(self.user_id):
        if not self.user_id:
            self.send_response_flag = True
            self.status_code = 403
            self.response = {
                'success': 'false',
                'message': self.translation_manager.get_translation(
                    self.translation_manager.you_are_not_allowed_to_access_this_application,
                    self.messages_locale
                ),
                'code': 90,
                'data': []
            }
            return self.send_response(self.response, self.status_code)

    def test_and_validate_date_of_birth(self):
        """
        Test and validate user date of birth
        :rtype: dict
        """
        is_valid_date_of_birth = True
        if self.date_of_birth and self.date_of_birth != "":
            try:
                self.date_of_birth = self.date_of_birth.replace('/', '-')
                self.date_of_birth = datetime.datetime.strptime(self.date_of_birth, '%d-%m-%Y')
                current_date = datetime.datetime.now()
                date_13_years_back = datetime.datetime.now() - relativedelta(years=13)
                minimum_valid_dob = datetime.datetime.now() - relativedelta(years=120)

                if self.date_of_birth > current_date or self.date_of_birth < minimum_valid_dob:
                    self.status_code = 422
                    self.send_response_flag = True
                    self.response = {
                        "message": self.translation_manager.get_translation(
                            self.translation_manager.invalid_dob,
                            self.messages_locale
                        ),
                        "code": 90,
                        "success": False
                    }
                    return self.send_response(self.response, self.status_code)

                if date_13_years_back < self.date_of_birth:
                    self.status_code = 422
                    self.send_response_flag = True
                    self.response = {
                        "message": self.translation_manager.get_translation(
                            self.translation_manager.dob_minimum_value_error,
                            self.messages_locale
                        ),
                        "code": 90,
                        "success": False
                    }
                    return self.send_response(self.response, self.status_code)
            except Exception:
                is_valid_date_of_birth = False
        if not is_valid_date_of_birth:
            self.status_code = 422
            self.send_response_flag = True
            self.response = {
                "message": self.translation_manager.get_translation(
                    self.translation_manager.invalid_dob,
                    self.messages_locale
                ),
                "code": 90,
                "success": False
            }
            return self.send_response(self.response, self.status_code)

    def update_customer(self):
        """
        Update customer information
        """
        self.cutomer_updated = self.customer_repo.update_customer_profile(self.user_id, self.request_args)

    def generate_final_response(self):
        if self.cutomer_updated:
            self.status_code = 200
            self.send_response_flag = True
            self.response = {
                "message": "success",
                "success": True,
                "data": []
            }
            return self.send_response(self.response, self.status_code)
        else:
            self.send_response_flag = True
            self.status_code = 400
            self.response = {
                "message": self.translation_manager.get_translation(
                    self.translation_manager.problems_with_your_submission,
                    self.messages_locale
                ),
                "success": False,
                "code": 95
            }
            return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Process the request
        :return: Response
        """
        self.initialize_repos()
        self.initialize_class_attributes()
        # self.user_id = kwargs.get('user_id')
        self.check_customer()
        self.test_and_validate_date_of_birth()
        if self.is_send_response_flag_on():
            return
        self.update_customer()
        self.generate_final_response()


class GetUserActionApiWl(BasePostResource):
    """
    @api {post} /users/action Get Provides user information
    @apiVersion 1.0.0
    @apiName GetUserActionApiWl
    @apiGroup Users
    @apiParam {String}                              wlcompany           White Label Client
    @apiParam {String="ios","android","web"}        __platform          All supported platform
    @apiParam {Integer}                             location_id         ID of location to filter outlets by
    @apiParam {String}                              app_version         Mobile App Version
    @apiParam {String="en", "ar", "cn", "el","zh"}  [language]          Response Language

    """
    request_parser = user_action_in_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='get_user_action_api/get_user_action_api.log',
        ),
        'name': 'get_user_action_api'
    }
    strict_token = True
    required_token = True

    def populate_request_arguments(self):
        """
        Add request arguments of get user action id
        """
        self.locale = self.request_args.get('language')

    def initialize_repos(self):
        """
        Initialize repos for get user action api
        """
        self.customer_repo = CustomerProfileWhiteLabel()
        self.translation_manager = TranslationManager()

    def initialize_class_attributes(self):
        """
        Initialize class attributes for get user action api
        """
        self.customer = get_current_customer()
        self.wlcompany = get_company()
        self.messages_locale = CommonHelpers.get_locale(self.locale, location_id=0)
        self.customer_id = self.customer.get('customer_id')
        self.user_id = None
        self.result = None
        self.user_details = {}

    def validate_customer(self):
        """
        Throw an Error if user_id do not match with customer_id stored in session data
        :rtype: dict
        """
        # if str(self.customer_id) != str(self.user_id):
        if not self.customer_id:
            self.send_response_flag = True
            self.status_code = 403
            self.response = {
                "message": self.translation_manager.get_translation(
                    self.translation_manager.you_are_not_allowed_to_access_this_application,
                    self.messages_locale
                ),
                "success": False,
                "code": 90
            }
            return self.send_response(self.response, self.status_code)

    def process_data(self):
        """
        Process the data
        """
        self.user_details = self.customer_repo.get_user_profile_by_user_id(self.customer_id, self.wlcompany)
        self.user_details['profile'] = []
        self.locations = LocationRepositoryWhiteLabel.get_locations(company=self.wlcompany, locale=self.locale)
        for location in self.locations:
            # we are converting location active key value to boolean to match php response
            location['active'] = boolean(location.get('active', False))
            location['is_show_category'] = False
            location['is_careem_enabled'] = int(location['is_careem_enabled'])
            # change location name from Riyadh & E. Prov to Riyadh
            if (
                self.wlcompany.lower() == WLCompany.company_code_ENTERTAINER_EXPRESS and
                location['id'] == 10
            ):
                location['name'] = 'Riyadh'
        self.location_version = WLCompany().get_location_version()

        section_general_settings = {
            "section_identifier": "general_settings",
            "section_title": "",
            "section_list": [{
                    "title": GlobalConstants.TITLE_LOCATION,
                    "type": GlobalConstants.TYPE_LOCATION,
                    "web_url": GlobalConstants.WEB_URL_LOCATION,
                    "items": self.locations
                },
                {
                    "title": GlobalConstants.TITLE_REDEMPTION,
                    "type": GlobalConstants.TYPE_REDEMPTION,
                    "web_url": GlobalConstants.WEB_URL_REDEMPTION
                }
            ],
        }
        self.user_details['profile'].append(section_general_settings)
        section_web = {
            "section_identifier": "web",
            "section_title": "",
            "section_list": [
                {
                    "title": GlobalConstants.TITLE_END_USER_LICENSE,
                    "type": GlobalConstants.TYPE_END_USER_LICENSE,
                    "web_url": GlobalConstants.WEB_URL_END_USER_LICENSE
                },
                {
                    "title": GlobalConstants.TITLE_TERMS_OF_USE,
                    "type": GlobalConstants.TYPE_TERMS_OF_USE,
                    "web_url": GlobalConstants.WEB_URL_TERMS_OF_USE
                },
                {
                    "title": GlobalConstants.TITLE_PRIVACY_POLICY,
                    "type": GlobalConstants.TYPE_PRIVACY_POLICY,
                    "web_url": GlobalConstants.WEB_URL_PRIVACY_POLICY
                }
            ]
        }
        self.user_details['profile'].append(section_web)
        section_logout = {
            "section_identifier": "logout",
            "section_title": "",
            "section_list": [
                {
                    "title": GlobalConstants.TITLE_LOGOUT,
                    "type": GlobalConstants.TYPE_LOGOUT,
                    "web_url": GlobalConstants.WEB_URL_LOGOUT
                },
            ]
        }
        self.user_details['profile'].append(section_logout)

    def generate_final_response(self):
        """
        Sets final api response
        :rtype: dict
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            "message": 'success',
            "data": self.user_details,
            "success": True,
            "code": None
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Process the request
        :return: Response
        """
        self.initialize_repos()
        self.initialize_class_attributes()
        self.process_data()
        # self.session_token = kwargs.get('session_token')
        self.validate_customer()
        if self.is_send_response_flag_on():
            return
        self.generate_final_response()
