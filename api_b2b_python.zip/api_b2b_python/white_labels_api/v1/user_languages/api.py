"""
User languages api
"""

from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BasePostResource
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.translations_repo import TranslationManager
from user_authentication_white_label.authentication import get_company, get_current_customer
from white_labels_api.v1.user_languages.validation import user_language_parser


class UserLanguagesApiWl(BasePostResource):
    """
    @api {post} /v1/userlanguages Post Update user's language information
    @apiSampleRequest /v1/userlanguages
    @apiVersion 1.0.0
    @apiName UserLanguages
    @apiGroup Users
    @apiParam {Integer}                             location_id        Id of location to filter outlets by
    @apiParam {String="ios","android","web"}        __platform         All supported platform
    @apiParam {String}                              app_version        app version of app
    @apiParam {String="en", "ar", "cn", "el","zh"}  [language]         Response language
    """
    request_parser = user_language_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='user_language_api/user_language_api.log',
        ),
        'name': 'user_language_api'
    }
    strict_token = True
    required_token = True

    def populate_request_arguments(self):
        """
        Add request arguments of user language api
        """
        self.locale = self.request_args.get('language')

    def initialize_local_variables(self):
        """
        Sets Local Variables
        """
        self.company = get_company()

    def initialize_class_attributes(self):
        """
        Initialize class attributes of user language api
        """
        self.customer_repo = CustomerProfileWhiteLabel()
        self.translation_manager = TranslationManager()
        self.customer = get_current_customer()
        self.session_id = self.customer.get('id')

    def insert_user_language(self):
        """
        Insert user language against company and user id
        """
        if self.customer.get('is_user_logged_in'):
            self.customer_repo.insert_customer_language(
                self.customer.get('customer_id'),
                self.session_id,
                self.locale,
                self.company
            )

    def prepare_response(self):
        """
        Sets final response of user language api
        :rtype: dict
        """
        self.send_response_flag = True
        self.response = {
            'success': True,
            'message': self.translation_manager.get_translation(
                self.translation_manager.success,
                self.locale
            ),
            'data': []
        }
        self.status_code = 200
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of user language api
        """
        self.initialize_class_attributes()
        self.insert_user_language()
        self.prepare_response()
