"""
location validation parser
"""
from common_white_label.common_helpers import get_request_parser
from common_white_label.custom_fields_request_parser import device_list, language

locations_parser = get_request_parser()

locations_parser.add_argument(
    name="language",
    required=False,
    default="en",
    type=language,
    location=['mobile', 'values', 'json']
)
locations_parser.add_argument(
    name="__platform",
    required=True,
    type=device_list,
    location=['mobile', 'values', 'json']
)
locations_parser.add_argument(
    name="app_version",
    required=True,
    type=str,
    location=['mobile', 'values', 'json']
)
locations_parser.add_argument(
    name="location_id",
    required=False,
    type=int,
    location=['mobile', 'values', 'json']
)
locations_parser.add_argument(
    name="build_no",
    required=True,
    type=int,
    location=['mobile', 'values', 'json']
)
