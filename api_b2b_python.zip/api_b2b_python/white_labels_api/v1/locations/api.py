"""
Module contains Locations APi
"""
from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BasePostResource
from common_white_label.common_helpers import CommonHelpers
from common_white_label.custom_fields_request_parser import boolean
from repositories_white_label.location_repo import LocationRepositoryWhiteLabel
from repositories_white_label.wl_company_repo import WLCompany
from user_authentication_white_label.authentication import get_company
from white_labels_api.v1.locations.validation import locations_parser


class LocationsApiWL(BasePostResource):
    """
    @api {post} /v1/locations Get Configured Locations
    @apiSampleRequest /v1/locations
    @apiVersion 1.0.0
    @apiName LocationsApiWL
    @apiGroup Configurations
    @apiParam {String="android", "ios", "web"}             __platform      All supported platform
    @apiParam {String}                                     app_version     App version
    @apiParam {String}                                     build_no        Build no
    @apiParam {Integer}                                    [location_id]   ID of location to filter outlets by
    @apiParam {String='de', 'en', 'ar', 'cn', 'el', 'zh'}  [language]      Response language
    """
    request_parser = locations_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='locations_api/locations_api.log',
        ),
        'name': 'locations_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.app_version = self.request_args.get('app_version')
        self.platform = self.request_args.get('__platform')
        self.build_no = self.request_args.get('build_no')
        self.locale = self.request_args.get('language')

    def setting_variables(self):
        """
        Sets variables for api
        """
        self.locale = CommonHelpers.get_locale(self.locale)
        self.company = get_company()

    def get_locations(self):
        """
        Gets the locations
        """
        self.locations = LocationRepositoryWhiteLabel.get_locations(company=self.company, locale=self.locale)
        for location in self.locations:
            # we are converting location active key value to boolean to match php response
            location['active'] = boolean(location.get('active', False))
            location['is_show_category'] = False
            location['is_careem_enabled'] = int(location['is_careem_enabled'])
            # change location name from Riyadh & E. Prov to Riyadh
            if (
                self.company.lower() == WLCompany.company_code_ENTERTAINER_EXPRESS and
                location['id'] == 10
            ):
                location['name'] = 'Riyadh'
        self.location_version = WLCompany().get_location_version()

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': {'locations': self.locations},
            'version': self.location_version,
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of api
        """
        self.setting_variables()
        self.get_locations()
        self.generate_final_response()
