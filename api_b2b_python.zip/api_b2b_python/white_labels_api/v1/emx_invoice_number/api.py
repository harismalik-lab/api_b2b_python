"""
Invoice number api wl
"""
from app_configurations_white_label.settings import WHITE_LABEL_LOG_PATH
from common_white_label.base_resource import BasePostResource
from common_white_label.common_helpers import CommonHelpers
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.session_repo import SessionRepositoryWhiteLabel
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.wl_invoice_headers_repo import WlInvoiceHeadersRepository
from user_authentication_white_label.authentication import get_company, get_current_customer
from white_labels_api.v1.emx_invoice_number.validation import emx_invoice_parser


class AddInvoiceAction(BasePostResource):
    """
    @api {post} /v1/invoice_number Post Add new invoice number
    @apiSampleRequest /v1/invoice_number
    @apiVersion 1.0.0
    @apiName AddInvoiceAction
    @apiGroup Emax
    @apiParam {String}                                           invoice_number     Card number
    @apiParam {String}                                           app_version        Mobile app version
    @apiParam {String="ios","android", "web"}                    __platform         Mobile Platform
    @apiParam {Integer}                                          [Amount]           Amount
    @apiParam {String="en", "ar", "cn", "el", "de", "zh"}        [language]         Response language
    """
    request_parser = emx_invoice_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=WHITE_LABEL_LOG_PATH,
            file_path='emax_invoice_number_api/emax_invoice_number_api.log',
        ),
        'name': 'emax_invoice_number_api'
    }
    strict_token = True
    required_token = True

    def populate_request_arguments(self):
        """
        Add request arguments of emax invoice number api
        """
        self.locale = self.request_args.get('language')
        self.message_locale = CommonHelpers.get_locale_for_messaging(self.locale)
        self.card_number = self.request_args.get('card_number')
        self.invoice_number = self.request_args.get('invoice_number')
        self.invoice_amount = self.request_args.get('amount')

    def initialize_local_variables(self):
        """
        Sets variables for emax card number api
        """
        self.company = get_company()

    def initialize_class_attributes(self):
        """
        Initialize class attributes of emax invoice number api
        """
        self.customer_repo = CustomerProfileWhiteLabel()
        self.translation_manager = TranslationManager()
        self.invoice_headers = WlInvoiceHeadersRepository()
        self.session_repo = SessionRepositoryWhiteLabel()
        self.customer = get_current_customer()
        self.customer_id = self.customer.get('customer_id')
        self.is_user_upgraded = False

    def validate_customer(self):
        """
        Validates customer
        """
        if not self.customer.get('is_user_logged_in'):
            self.send_response_flag = True
            self.status_code = 422
            self.response = {
                'message': self.translation_manager.get_translation(
                    self.translation_manager.not_authorized_to_access_user,
                    self.message_locale
                ),
                'code': 50
            }
            return self.send_response(self.response, self.status_code)

    def gets_user_profiler(self):
        """
        Gets user profile information
        """
        self.user_profile = self.customer_repo.get_user_profile_by_user_id(
            user_id=self.customer_id,
            company=self.company
        )
        self.email = self.user_profile.get('email')

    def check_invoice_number(self):
        """
        Checks invoice number
        """
        if self.invoice_number:
            invoice_validation_status = self.invoice_headers.validate_invoice_number(
                invoice_number=self.invoice_number,
                company=self.company,
                is_for_sign_up_or_sign_in=False,
                user_id=self.customer_id,
                invoice_amount=self.invoice_amount
            )
            if invoice_validation_status != WlInvoiceHeadersRepository.VALID_STATUS:
                message = self.invoice_headers.get_invoice_validation_message(
                    validation_status=invoice_validation_status,
                    locale=self.locale
                )
                self.send_response_flag = True
                self.status_code = 200
                self.response = {
                    'success': True,
                    'message': message,
                    'data': {'validation_status': False}
                }
                return self.send_response(self.response, self.status_code)
            self.is_user_upgraded = self.invoice_headers.add_invoice_to_user(
                invoice_number=self.invoice_number,
                company=self.company,
                user_id=self.customer_id,
                email=self.email
            )
            self.session_repo.mark_all_sessions_for_customer_date_cached(
                customer_id=self.customer_id,
                company=self.company
            )

    def generate_final_response(self):
        """
        Generates final response
        """
        message = self.invoice_headers.get_invoice_validation_message(
            validation_status=WlInvoiceHeadersRepository.VALID_STATUS,
            locale=self.locale,
            is_user_upgraded=self.is_user_upgraded
        )
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'success': True,
            'message': message,
            'data': {'validation_status': True}
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the process of emx invoice number api
        """
        self.initialize_class_attributes()
        self.validate_customer()
        if self.is_send_response_flag_on():
            return
        self.gets_user_profiler()
        self.check_invoice_number()
        if self.is_send_response_flag_on():
            return
        self.generate_final_response()
