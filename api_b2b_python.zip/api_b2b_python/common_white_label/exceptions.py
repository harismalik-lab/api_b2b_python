"""
Custom Exceptions
"""


class InvalidConfigResource(Exception):
    """
    Raises when BaseResource configs are missing or invalid.
    """
    pass
