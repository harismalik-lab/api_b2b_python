import datetime
import json
import sqlite3
import uuid
from collections import Mapping

from flask import current_app, g, request
from flask_restful import Resource
from flask_restful.utils import OrderedDict, unpack
from flask_restful_swagger import swagger
from PyMysqlPool.db_util.mysql_pool import get_connections_count
from PyMysqlPool.mysql.connector import _CONNECTION_POOLS
from PyMysqlPool.mysql.connector.errors import OperationalError
from werkzeug.exceptions import BadRequest
from werkzeug.wrappers import Response as ResponseBase

from common_white_label.common_helpers import broker_connections, get_logger
from common_white_label.constants import TASKS_FAILURE_TABLE_STRUCTURE, GlobalConstants
from common_white_label.exceptions import InvalidConfigResource
from user_authentication_white_label.authentication import HTTPBasicAuthEntertainer, token_decorator

basic_auth = getattr(current_app, 'basic_auth', HTTPBasicAuthEntertainer())
token_decorator = getattr(current_app, 'token_decorator', token_decorator)


@basic_auth.get_password
def get_basic_auth_password(username):
    try:
        return current_app.config['BASIC_AUTH_CREDENTIALS'].get(username)
    except KeyError:
        return None


class BaseResource(Resource):

    backup_request_args_for_exception = False
    backup_folder = ''
    backup_filename = ''
    logger_info = {}
    logger = None
    request_parser = None
    response = {}
    status_code = 200
    code = 0
    send_response_flag = False
    connections_names = []
    connections = {}
    required_token = False
    strict_token = False  # if its True then error will be raise in-case of empty session_token.
    api_version = 'v59'
    if current_app.config.get('LIMITER_EXEMPT_FLAG'):
        decorators = [g.limiter.exempt]  # rate limit is set to exempt
    else:
        decorators = [g.limiter.limit(GlobalConstants.DEFAULT_LIMIT)]  # default limit is set initially

    def get_connections(self):
        pass

    def close_connections(self):
        for pool_name in self.connections_names:
            connection_count = get_connections_count(pool_name=pool_name)
            if connection_count:
                try:
                    cnx_pool = _CONNECTION_POOLS[pool_name]
                    if cnx_pool:
                        cnx_pool.remove_connection(connection_count=connection_count)
                except (AttributeError, OperationalError):
                    pass

    def get_logger(self):
        """
        Get log instance with given params
        :Raises: Exception when filename is missing.
        """
        if not self.logger and self.logger_info:
            try:
                self.logger = get_logger(
                    filename=self.logger_info.get('filename'),
                    name=self.logger_info.get('name', str(uuid.uuid4()))
                )
            except KeyError:
                raise InvalidConfigResource('filename missing for logs.')

    def send_response(self, data, status_code):
        """
        :param data: http response-data
        :param status_code: http-status-code
        :return: data, status
        """
        if isinstance(data, str):
            message = data
            data = dict()
            data['message'] = message
        data['cmd'] = request.full_path
        data['http_response'] = status_code
        if 'code' not in data.keys():
            data['code'] = self.code
        return data, status_code

    def backup_request_args(self):
        """
        Save request_data to json file in case of failure.
        :return: new file_name created.
        """
        if not getattr(self, 'request_args', None):
            request_params = request.values.to_dict()
        else:
            request_params = self.request_args
        str_datetime = str(datetime.datetime.now()).replace(' ', '-').replace(':', '-').replace('.', '-')
        file_name = '{backup_folder}/{backup_filename}_{id}.json'.format(
            backup_folder=self.backup_folder,
            backup_filename=self.backup_filename,
            id=str_datetime
        )
        with open(file_name, 'w') as outfile:
            json.dump(request_params, outfile, ensure_ascii=False, indent=4)
        return file_name

    def process_bad_request(self, exception_raised=None):
        """
        Process the bad request exception of http-view
        :return: http-response
        """
        message = getattr(exception_raised, 'data', {}).get('message', exception_raised.description)
        if isinstance(message, dict):
            for exception_field, exception_message in message.items():
                message = '{field}: {message}'.format(field=exception_field, message=exception_message)
                if exception_message.startswith('Missing required parameter in'):
                    message = '{field}: missing required parameter'.format(field=exception_field)
                break
        if not getattr(exception_raised, 'data', {}):
            setattr(exception_raised, 'data', {})
        exception_raised.data['message'] = message
        return self.process_request_exception(exception_raised=exception_raised)

    def process_request_exception(
            self,
            exception_raised=None,
            code=None,
            status_code=None,
            message=GlobalConstants.INTERNAL_SERVER_ERROR
    ):
        """
        Process the general exception of http-view
        :return: http-response
        """
        if not self.logger:
            self.get_logger()
        if self.backup_request_args_for_exception:
            self.backup_request_args()
        if current_app.config['DEBUG']:
            if exception_raised:
                raise exception_raised
        self.code = 500
        self.status_code = 500
        if exception_raised:
            if getattr(exception_raised, 'data', None):
                message = exception_raised.data.get('message', exception_raised.data)
            elif getattr(exception_raised, 'description', None):
                message = exception_raised.description
            self.status_code = getattr(exception_raised, 'code', 500)
            self.code = getattr(exception_raised, 'code', 500)
        if self.logger:
            if not getattr(self, 'request_args', None):
                request_params = request.values.to_dict()
            else:
                request_params = self.request_args
            self.logger.exception(
                'Exception occurred with url:{full_url} params:{params} message:{message}'.format(
                    message=message,
                    full_url=request.path,
                    params=request_params
                )
            )
        if current_app.config['DEBUG']:
            raise exception_raised
        self.response = {
            "message": message,
            'success': False
        }
        if code:
            self.code = code
        if status_code:
            self.status_code = status_code
        return self.send_response(self.response, self.status_code)

    def remove_logger_handlers(self):
        if self.logger:
            for handler in getattr(self.logger, 'handlers', []):
                if not current_app.config.get('GENERATE_APM_ERROR_LOGS', False):
                    handler.stream.close()
                self.logger.removeHandler(handler)

    def populate_request_arguments(self):
        """
        Set the class arguments using request_parser.
        """
        pass

    def process_request(self, *args, **kwargs):
        """
        Business logic goes here.
        """
        self.send_response_flag = True
        pass

    def set_response(self, response, code=None):
        """
        Set class attributes response along with send_response_flag.
        """
        if code:
            self.code = code
        self.send_response_flag = True
        self.response = response

    def is_send_response_flag_on(self):
        """
        :return: True if send_response_flag is on.
        """
        return self.send_response_flag

    def pre_processsing(self):
        """
        Pre-processing.
        """
        self.get_connections()
        self.get_logger()

    def request_flow(self, *args, **kwargs):
        """
        Http Request flow.
        """
        if getattr(request, 'dont_process', False):
            return
        self.pre_processsing()
        self.request_args = None
        try:
            if self.request_parser:
                self.request_args = self.request_parser.parse_args()
        except BadRequest as bad_request_exception:
            return self.process_bad_request(exception_raised=bad_request_exception)

        try:
            if self.request_args:
                self.populate_request_arguments()
            self.process_request(*args, **kwargs)
            if self.send_response_flag:
                return self.send_response(self.response, self.status_code)
        except Exception as exception_raised:
            return self.process_request_exception(exception_raised=exception_raised)
        finally:
            self.close_connections()
            if self.logger:
                for handler in getattr(self.logger, 'handlers', []):
                    if not current_app.config.get('GENERATE_APM_ERROR_LOGS', False):
                        handler.stream.close()
                    self.logger.removeHandler(handler)

    def celery_tasks(self, connection=None, backup=False):
        pass

    def start_celery_tasks(self, **kwargs):
        connections_info = {}
        try:
            connections_info = broker_connections()
            backup = connections_info['backup']
            connection = connections_info['connection']
            self.celery_tasks(connection=connection, backup=backup)
        finally:
            if connections_info and connections_info['broker_connections']:
                for connection in connections_info['broker_connections']:
                    connection.release()

    @staticmethod
    def backup_celery_to_sql_lite(tasks=[]):
        connection = None
        try:
            connection = sqlite3.connect(current_app.config['CELERY_BACKUP_DB'])
            cursor = connection.cursor()
            cursor.execute(TASKS_FAILURE_TABLE_STRUCTURE)
            cursor.execute(
                "INSERT INTO tasks_failures(date_created, data) VALUES (?, ?);",
                [datetime.datetime.now(), json.dumps(tasks)]
            )
            connection.commit()
        finally:
            if connection:
                connection.close()


class BaseDynamicResource(BaseResource):
    method = 'get'

    def get(self):
        pass

    def post(self):
        pass

    @basic_auth.login_required
    @token_decorator
    def anonymouse(self, *args, **kwargs):
        return self.request_flow(*args, **kwargs)

    def dispatch_request(self, *args, **kwargs):

        # Taken from flask
        # noinspection PyUnresolvedReferences
        if self.method.lower() != request.method.lower():
            return None, 404
        meth = getattr(self, request.method.lower(), None)
        if meth is None and request.method == 'HEAD':
            meth = getattr(self, 'get', None)
        if self.method:
            setattr(self, self.method.lower(), self.anonymouse)
            meth = getattr(self, self.method.lower())
        assert meth is not None, 'Unimplemented method %r' % request.method

        if isinstance(self.method_decorators, Mapping):
            decorators = self.method_decorators.get(request.method.lower(), [])
        else:
            decorators = self.method_decorators

        for decorator in decorators:
            meth = decorator(meth)

        resp = meth(*args, **kwargs)

        if isinstance(resp, ResponseBase):  # There may be a better way to test
            return resp

        representations = self.representations or OrderedDict()

        # noinspection PyUnresolvedReferences
        mediatype = request.accept_mimetypes.best_match(representations, default=None)
        if mediatype in representations:
            data, code, headers = unpack(resp)
            resp = representations[mediatype](data, code, headers)
            resp.headers['Content-Type'] = mediatype
            return resp
        return resp


class BasePostResource(BaseResource):

    @basic_auth.login_required
    @token_decorator
    @swagger.operation()
    def post(self, *args, **kwargs):
        """
        Post request handler.
        """
        return self.request_flow(*args, **kwargs)


class BaseGetResource(BaseResource):

    @basic_auth.login_required
    @token_decorator
    @swagger.operation()
    def get(self, *args, **kwargs):
        """
        Get request handler.
        """
        return self.request_flow(*args, **kwargs)


class BasePutResource(BaseResource):

    @basic_auth.login_required
    @token_decorator
    def put(self, *args, **kwargs):
        """
        Put request handler.
        """
        return self.request_flow(*args, **kwargs)
