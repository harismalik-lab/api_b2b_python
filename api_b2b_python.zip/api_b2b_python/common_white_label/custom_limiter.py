from functools import wraps

from flask import Blueprint, current_app, g
from flask_limiter import Limiter, RateLimitExceeded
from flask_limiter.util import get_ipaddr
from flask_limiter.wrappers import LimitGroup

from repositories_white_label.company_limit_repo import CompanyLimit

limit_repo = CompanyLimit()


class CustomLimiter(Limiter):
    """
    Override `flask_limiter.Limiter#limit` decorator since it does NOT support
    dynamic limiting for `flask-restful`.

    NOTE: `if company_limit_int > 0:` condition is explicitly used in
    `flask_limiter.Limiter#_evaluate_limits` for `moving-window` strategy. Otherwise
    it allows bypassing on `0` limit.
    """
    def __init__(self):
        super().__init__(
            key_func=lambda: str(g.user.id) if hasattr(g, 'user') else get_ipaddr(),
            auto_check=False,
        )

    def _evaluate_limits(self, limits):
        if not limit_repo.set_jwt_identity():
            return
        company_code = limit_repo.get_company_code()
        if company_code:
            # getting limit per min as an integer value from ctx_stack
            company_limit_int = limit_repo.get_company_limit_from_stack()
            # if limit value is 0 or less then dont set limit, instead use DEFAULT_LIMIT
            if company_limit_int > 0:
                # converting integer into str and concatenating for limiter to parse
                company_limit = "{}/minute".format(company_limit_int)
                limits = list(LimitGroup(
                    company_limit,
                    limit_repo.get_company_code,
                    None,
                    False,
                    None,
                    None,
                    None
                ))
        failed_limit = None
        limit_for_header = None
        for lim in limits:
            # setting common scope for sharing limits for the routes
            limit_scope = current_app.config.get('LIMIT_SCOPE')  # getting from app config settings
            limit_key = lim.key_func()
            assert limit_key, 'key expected'
            args = [limit_scope, limit_key]

            if self._key_prefix:
                args = [self._key_prefix] + args
            if not limit_for_header or lim.limit < limit_for_header[0]:
                limit_for_header = [lim.limit] + args
            if not self.limiter.hit(lim.limit, *args):
                self.logger.warning(
                    "ratelimit %s (%s) exceeded at endpoint: %s",
                    lim.limit, limit_key, limit_scope
                )
                failed_limit = lim
                limit_for_header = [lim.limit] + args
                break
        g.view_rate_limit = limit_for_header
        if failed_limit:
            raise RateLimitExceeded(failed_limit.limit)

    def limit(self, limit_value, key_func=None):
        def _inner(obj):
            assert not isinstance(obj, Blueprint)
            func = key_func or self._key_func

            if callable(limit_value):
                limits = [LimitGroup(limit_value, func, None, False, None, None, None)]
            else:
                limits = list(LimitGroup(limit_value, func, None, False, None, None, None))

            @wraps(obj)
            def __inner(*a, **k):
                self._evaluate_limits(limits)
                return obj(*a, **k)
            return __inner
        return _inner
