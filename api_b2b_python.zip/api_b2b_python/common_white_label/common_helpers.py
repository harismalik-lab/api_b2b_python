import datetime
import importlib
import json
import locale
import logging
import math
import os
import random
import re
import uuid
from functools import cmp_to_key
from urllib.parse import parse_qs

import boto3
import requests
import six
from elasticapm.contrib.flask import ElasticAPM
from elasticapm.handlers.logging import LoggingHandler
from flask import current_app, url_for
from flask_restful import reqparse
from flask_restful.reqparse import Argument
from kombu import BrokerConnection
from requests import codes
from werkzeug.datastructures import CombinedMultiDict, MultiDict

from _operator import itemgetter
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.wl_categories_repo import CategoriesRepositoryWl


class CommonHelpers(object):
    supported_locales = ['ar', 'el', 'cn', 'de']
    Locations_Arabic = [1, 2, 3, 6, 7, 8, 9, 10, 16, 18]
    Locations_Greek = [5, 23]
    Locations_Cantonese = [13]
    All_Locations = [1, 2, 3, 6, 7, 8, 9, 10, 13, 16, 18, 23]

    @staticmethod
    def get_ping_section():
        """
        Returns ping section dict
        :rtype: dict
        """
        return {
            'is_sender_info': False,
            'is_recipient_info': False,
            'can_user_ping': False,
            'can_user_receive_ping': False,
            'total_quota_to_send_pings': 0,
            'total_quota_to_receive_pings': 0,
            'total_pings_sent': 0,
            'total_pings_received': 0,
            'message': '',
            'background_color': ''
        }

    @staticmethod
    def get_locale(locale, location_id=0):
        default_locale_english = 'en'
        try:
            location_id = int(location_id)
            if locale in CommonHelpers.supported_locales:
                if location_id > 0:
                    if locale == 'ar' and location_id in CommonHelpers.Locations_Arabic:
                        return locale
                    elif locale == 'el' and location_id in CommonHelpers.Locations_Greek:
                        return locale
                    elif locale == 'cn' and location_id in CommonHelpers.Locations_Cantonese:
                        return locale
                    else:
                        return default_locale_english
                return locale
        except (TypeError, ValueError):
            pass
        return default_locale_english

    @staticmethod
    def get_locale_for_messaging(locale):
        default_locale_english = 'en'
        if locale in CommonHelpers.supported_locales:
            return locale
        return default_locale_english

    @staticmethod
    def number_format(num, decimals=0, ):
        return locale.format("%.*f", (decimals, num), True)

    @staticmethod
    def pkcs5_padding(text, length):
        text += (length - len(text) % length) * chr(length - len(text) % length)
        return text

    @staticmethod
    def pkcs7_padding(b_string, k=16):
        """
        Pad an input byte string according to PKCS#7
        """
        length = len(b_string)
        val = k - (length % k)
        return b_string + bytearray([val] * val)

    @staticmethod
    def unpad(s):
        s = s[0:s[-1]]
        if b'{' in s and b'}' not in s:
            s += b'"}'
        return s

    @staticmethod
    def is_string_exist(haystack, needle):
        if haystack and needle:
            return needle.lower() in haystack.lower()
        return False

    @staticmethod
    def array_merge(first_array, second_array):
        if isinstance(first_array, list) and isinstance(second_array, list):
            return first_array + second_array
        elif isinstance(first_array, dict) and isinstance(second_array, dict):
            return dict(list(first_array.items()) + list(second_array.items()))
        elif isinstance(first_array, set) and isinstance(second_array, set):
            return first_array.union(second_array)
        return False

    @staticmethod
    def calculate_distance(lat, lng, outlet_lat, outlet_lng):
        """
        Returns outlet's distance in KM from target lat long
        :param float lat: Target latitude
        :param float lng: Target longitude
        :param float outlet_lat: Outlet latitude
        :param float outlet_lng: Outlet longitude
        :rtype: int
        """
        return round(
            math.acos(
                math.cos(math.radians(90.0 - lat)) * math.cos(math.radians(90.0 - outlet_lat)) +
                math.sin(math.radians(90.0 - lat)) * math.sin(math.radians(90.0 - outlet_lat)) *
                math.cos(math.radians((lng - outlet_lng)))
            ) * 6371.0 * 1000.0
        )

    @staticmethod
    def get_facebook_access_token():
        return "1706482312911018|9SJGhZnipO8nH5fMJ_jzDznwqgI"

    @staticmethod
    def get_custom_request_session(max_retries=1, secure=False):
        """
        Returns custom request session
        :param bool secure:
        :param int max_retries:
        :return request.Session:
        """
        session = requests.Session()
        adapter = requests.adapters.HTTPAdapter(max_retries=max_retries)
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        return session

    def generate_unique_id(self, prefix, length):
        """
        Generate unique id
        """
        prefix = prefix + str(uuid.uuid4())[:length]
        return ''.join(random.choice(prefix) for _ in range(length))

    def get_hsbc_love_dining_skus(self):
        love_dining_skus = (
            'L18DBHSDC', 'L19DBHSDC', 'L18ADHSDC', 'L19ADHSDC',
            'L18DBHSDB', 'L19DBHSDB', 'L18ADHSDB', 'L19ADHSDB'
        )
        return love_dining_skus

    def get_configured_sku_by_company(self, company):
        company = company.lower()
        skus = {
            'gem': [
                'L18DBGEPE',
                'L19DBGEPE',
                'L18ADGEPE',
                'L19ADGEPE',
                'L18TRGEPE',
                'L19TRGEPE',
                'L18DBGESE',
                'L19DBGESE',
                'L18ADGESE',
                'L19ADGESE',
                'L18TRGESE',
                'L19TRGESE'
            ]
        }
        return skus.get(company, [])


class OfferManager(object):

    Image_Type_Voucher_Type = 1
    Image_Type_Voucher_Restriction = 2
    Image_Type_Party_Size = 3

    @classmethod
    def get_ping_section(cls):
        """
        Returns ping section dict
        :rtype: dict
        """
        return {
            'is_sender_info': False,
            'is_recipient_info': False,
            'can_user_ping': False,
            'can_user_receive_ping': False,
            'total_quota_to_send_pings': 0,
            'total_quota_to_receive_pings': 0,
            'total_pings_sent': 0,
            'total_pings_received': 0,
            'message': '',
            'background_color': ''
        }

    def get_voucher_restrictions(self):
        return {
            "1": "Valid for Dine-in and Take-Away",
            "2": "Excluding Friday Brunch",
            "3": "Advance Booking is Required",
            "4": "Delivery only",
            "5": "Dine-in only",
            "6": "Excluding Brunch",
            "7": "Food only",
            "8": "No Corkage Allowed",
            "9": "Not Valid on Delivery",
            "10": "Not Valid on Public Holidays",
            "11": "Rack Rate Applies",
            # Must comply with applicable local laws
            "12": "To redeem you must be of legal drinking age and non-Muslim",
            "13": "Valid on All Packages",
            "14": "Valid on Delivery",
            "15": "Must comply with applicable local laws",
            "16": "Rate Includes Breakfast",
            "17": "Rate Room Only",
            "18": "Based on Best Available Rates",
            "19": "All Inclusive",
        }

    def get_voucher_restriction_details(self, voucher_restriction_id, offer_category, locale='en'):
        _voucher_restrictions = self.get_voucher_restrictions()
        _voucher_restriction_key = ''

        if _voucher_restrictions[str(voucher_restriction_id)]:
            if voucher_restriction_id == 1:
                _voucher_restriction_key = TranslationManager.voucher_restriction_1
            if voucher_restriction_id == 2:
                _voucher_restriction_key = TranslationManager.voucher_restriction_2
            if voucher_restriction_id == 3:
                _voucher_restriction_key = TranslationManager.voucher_restriction_3
            if voucher_restriction_id == 4:
                _voucher_restriction_key = TranslationManager.voucher_restriction_4
            if voucher_restriction_id == 5:
                _voucher_restriction_key = TranslationManager.voucher_restriction_5
            if voucher_restriction_id == 6:
                _voucher_restriction_key = TranslationManager.voucher_restriction_6
            if voucher_restriction_id == 7:
                _voucher_restriction_key = TranslationManager.voucher_restriction_7
            if voucher_restriction_id == 8:
                _voucher_restriction_key = TranslationManager.voucher_restriction_8
            if voucher_restriction_id == 9:
                _voucher_restriction_key = TranslationManager.voucher_restriction_9
            if voucher_restriction_id == 10:
                _voucher_restriction_key = TranslationManager.voucher_restriction_10
            if voucher_restriction_id == 11:
                _voucher_restriction_key = TranslationManager.voucher_restriction_11
            if voucher_restriction_id == 12:
                _voucher_restriction_key = TranslationManager.voucher_restriction_12
            if voucher_restriction_id == 13:
                _voucher_restriction_key = TranslationManager.voucher_restriction_13
            if voucher_restriction_id == 14:
                _voucher_restriction_key = TranslationManager.voucher_restriction_14
            if voucher_restriction_id == 15:
                _voucher_restriction_key = TranslationManager.voucher_restriction_15
            if voucher_restriction_id == 16:
                _voucher_restriction_key = TranslationManager.voucher_restriction_16
            if voucher_restriction_id == 17:
                _voucher_restriction_key = TranslationManager.voucher_restriction_17
            if voucher_restriction_id == 18:
                _voucher_restriction_key = TranslationManager.voucher_restriction_18
            if voucher_restriction_id == 19:
                _voucher_restriction_key = TranslationManager.voucher_restriction_19

            if _voucher_restrictions[str(voucher_restriction_id)]:
                voucher_restriction_title = TranslationManager().get_translation(
                    _voucher_restriction_key,
                    locale
                )
                if voucher_restriction_title:
                    return self.get_offer_sub_detail_object(
                        voucher_restriction_id,
                        self.get_image_url(
                            OfferManager.Image_Type_Voucher_Restriction, offer_category, '0',
                            False, voucher_restriction_id
                        ),
                        voucher_restriction_title, ''
                    )
        return None

    def get_offer_sub_detail_object(self, id='', image='', title='', color=''):
        return {
            'id': id,
            'image': image,
            'title': title,
            'color': color
        }

    def get_voucher_types(self):
        return {
            "1": "Buy_One_Get_One_Free",
            "2": "PERCENTAGE_OFF",
            "3": "GIFT",
            "4": "PACKAGE",
            "5": "FIX_PRICE_OFF",
            "6": "SPEND_THIS_GET_THIS"
        }

    def get_image_url(self, image_type, category, voucher_type_id='', replace_241_type_with_141=False,
                      voucher_restriction_id='', is_monthly=False):
        image_url = ""
        _category = None
        if category == CategoriesRepositoryWl.category_API_Name_Body:
            _category = "body"

        if category == CategoriesRepositoryWl.category_API_Name_Leisure:
            _category = "leisure"

        if category == CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars:
            _category = "food"

        if category == CategoriesRepositoryWl.category_API_Name_Retail:
            _category = "retail"

        if category == CategoriesRepositoryWl.category_API_Name_Services:
            _category = "services"

        if category == CategoriesRepositoryWl.category_API_Name_Travel:
            _category = "travel"
        from repositories_white_label.offer_wl_active_repo import OfferWlRepository
        if _category:
            end_format = ""
            if voucher_type_id == OfferWlRepository.OFFER_TYPE_VALUE_Buy_One_Get_One_Free:
                end_format = "_1_for_1"
            if image_type == self.Image_Type_Voucher_Type:
                if is_monthly:
                    if replace_241_type_with_141:
                        image_url = "{}{}_{}{}.png".format(
                            OfferWlRepository.Voucher_Type_Image_URL_Prefix,
                            "monthly",
                            voucher_type_id,
                            end_format
                        )
                    else:
                        image_url = "{}{}_{}.png".format(
                            OfferWlRepository.Voucher_Type_Image_URL_Prefix,
                            "monthly",
                            voucher_type_id
                        )
                else:
                    if replace_241_type_with_141:
                        image_url = "{}{}_{}{}.png".format(
                            OfferWlRepository.Voucher_Type_Image_URL_Prefix,
                            _category,
                            voucher_type_id,
                            end_format
                        )
                    else:
                        image_url = "{}{}_{}.png".format(
                            OfferWlRepository.Voucher_Type_Image_URL_Prefix,
                            _category,
                            voucher_type_id
                        )

            if image_type == OfferManager.Image_Type_Voucher_Restriction:
                image_url = "{}{}_{}.png".format(
                    OfferWlRepository.Voucher_Restriction_Image_URL_Prefix,
                    _category,
                    voucher_restriction_id
                )

            if image_type == OfferManager.Image_Type_Party_Size:
                image_url = "{}{}{}.png".format(
                    OfferWlRepository.Party_Size_Image_URL_Prefix,
                    "party_size_",
                    _category
                )

        return image_url

    def get_voucher_type_details(self, voucher_type, offer_category, locale='en',
                                 replace_241_type_with_141=False, is_monthly=False):
        _voucher_types = self.get_voucher_types()
        _voucher_type_key = ''

        if _voucher_types[str(voucher_type)]:
            if voucher_type == 1:
                if replace_241_type_with_141:
                    _voucher_type_key = TranslationManager().voucher_type_141
                else:
                    _voucher_type_key = TranslationManager().voucher_type_1
            if voucher_type == 2:
                _voucher_type_key = TranslationManager.voucher_type_2
            if voucher_type == 3:
                _voucher_type_key = TranslationManager.voucher_type_3
            if voucher_type == 4:
                _voucher_type_key = TranslationManager.voucher_type_4
            if voucher_type == 5:
                _voucher_type_key = TranslationManager.voucher_type_5
            if voucher_type == 6:
                _voucher_type_key = TranslationManager.voucher_type_6
            if _voucher_types[str(voucher_type)]:
                voucher_type_title = TranslationManager().get_translation(
                    _voucher_type_key,
                    locale
                )
                if voucher_type_title:
                    return OfferManager().get_offer_sub_detail_object(
                        voucher_type,
                        self.get_image_url(
                            OfferManager.Image_Type_Voucher_Type, offer_category, voucher_type,
                            replace_241_type_with_141, '', is_monthly
                        ), voucher_type_title, ''
                    )
        return None

    def get_message_for_offer_type(self, locale='en', offer_type=0, spend=0, reward=0,
                                   discount_off_or_percentage_off=0):
        """
        Gets the offer message for the offer type
        :param str locale: locality of the user
        :param str offer_type: type of the offer
        :param str spend: spends of the user
        :param str reward: rewards of the user till now
        :param str discount_off_or_percentage_off: discount of the user availed
        :rtype: str
        """
        from repositories_white_label.offer_wl_active_repo import OfferWlRepository
        if offer_type:
            offer_type = OfferWlRepository.OFFER_TYPE_VALUE_DEFAULT

        offer_type = int(offer_type)
        message = ""
        if offer_type == OfferWlRepository.OFFER_TYPE_VALUE_DEFAULT:
            message = TranslationManager().get_translation(TranslationManager.voucher_type_1, locale)
        if offer_type == OfferWlRepository.OFFER_TYPE_VALUE_Buy_One_Get_One_Free:
            message = TranslationManager().get_translation(TranslationManager.voucher_type_1, locale)
        if offer_type == OfferWlRepository.OFFER_TYPE_VALUE_PERCENTAGE_OFF:
            message = TranslationManager().get_translation(TranslationManager.voucher_type_2, locale)
            message = message.replace('_percentage_value_', str(discount_off_or_percentage_off))
        if offer_type == OfferWlRepository.OFFER_TYPE_VALUE_GIFT:
            message = TranslationManager().get_translation(TranslationManager.voucher_type_3, locale)
        if offer_type == OfferWlRepository.OFFER_TYPE_VALUE_PACKAGE:
            message = TranslationManager().get_translation(TranslationManager.voucher_type_4, locale)
        if offer_type == OfferWlRepository.OFFER_TYPE_VALUE_FIX_PRICE_OFF:
            message = TranslationManager().get_translation(TranslationManager.voucher_type_5, locale)
            message = message.replace('_discount_value_', str(discount_off_or_percentage_off))
        if offer_type == OfferWlRepository.OFFER_TYPE_VALUE_SPEND_THIS_GET_THIS:
            message = TranslationManager().get_translation(TranslationManager.voucher_type_6, locale)
            message = message.replace('_spend_value_', str(spend))
            message = message.replace('_reward_value_', str(reward))
        return message

    def sort_categories(self, categories):
        Categories = CategoriesRepositoryWl()
        categories_array = []

        if Categories.category_API_Name_Restaurants_and_Bars in categories:
            categories_array.append(Categories.category_API_Name_Restaurants_and_Bars)

        if Categories.category_API_Name_Body in categories:
            categories_array.append(Categories.category_API_Name_Body)

        if Categories.category_API_Name_Leisure in categories:
            categories_array.append(Categories.category_API_Name_Leisure)

        if Categories.category_API_Name_Retail in categories:
            categories_array.append(Categories.category_API_Name_Retail)

        if Categories.category_API_Name_Services in categories:
            categories_array.append(Categories.category_API_Name_Services)

        if Categories.category_API_Name_Travel in categories:
            categories_array.append(Categories.category_API_Name_Travel)

        return categories_array

    def get_category_codes_for_analytics(self, categories):
        categories_analytics = []
        if not categories:
            return categories_analytics
        for category in categories:
            analytics_category_code = self.get_analytics_category_code(category)
            if analytics_category_code:
                categories_analytics.append(analytics_category_code)
        return ",".join(categories_analytics)

    def get_analytics_category_code(self, category):
        Categories = CategoriesRepositoryWl()
        if category == Categories.category_API_Name_Body:
            return Categories.Analytics_Category_Code_Body

        if category == Categories.category_API_Name_Leisure:
            return Categories.Analytics_Category_Code_Leisure

        if category == Categories.category_API_Name_Restaurants_and_Bars:
            return Categories.Analytics_Category_Code_RestaurantsAndBars

        if category == Categories.category_API_Name_Retail:
            return Categories.Analytics_Category_Code_Retail

        if category == Categories.category_API_Name_Services:
            return Categories.Analytics_Category_Code_Services

        if category == Categories.category_API_Name_Travel:
            return Categories.Analytics_Category_Code_Travel

        return ""

    def get_offer_type_key(self, offer_type):
        """
        return key for offer type
        __author__: Farhat
        :param int offer_type: type of the offer
        :rtype: str
        """
        return {
            '1': 'Buy One Get One',
            '2': 'PERCENTAGE OFF',
            '3': 'GIFT',
            '4': 'PACKAGE',
            '6': 'SPEND THIS GET THIS'
        }.get(str(offer_type), 'unknown_offer_type')

    def get_offer_type_label_without_value(self, offer_type, locale='en'):
        """
        return key for offer type
        __author__: Farhat
        :param str locale: locale for which translated label is to be fetched
        :param int offer_type: type of the offer
        :rtype: str
        """
        quick_trans_repo_instance = TranslationManager()
        translation_key = {
            '1': quick_trans_repo_instance.voucher_type_1_Label,
            '2': quick_trans_repo_instance.voucher_type_2_Label,
            '3': quick_trans_repo_instance.voucher_type_3_Label,
            '4': quick_trans_repo_instance.voucher_type_4_Label,
            '6': quick_trans_repo_instance.voucher_type_6_Label,
        }.get(str(offer_type))
        return quick_trans_repo_instance.get_translation(translation_key, locale) or ''

    def get_offer_type_filters_for_category(self, category_id, _locale='en'):
        """
        returns offer type filters for category
        __author__: Farhat
        :param int category_id: id of the category
        :param str _locale: locale for which offer type filters are to be fetched
        :rtype: list
        """
        offer_types = []
        offer_types_for_category = []
        from repositories_white_label.offer_wl_active_repo import OfferWlRepository
        offer_wl_active_repo_instance = OfferWlRepository()
        categories_repo_instance = CategoriesRepositoryWl()
        if category_id == categories_repo_instance.Body_Id:
            offer_types_for_category = [
                offer_wl_active_repo_instance.OFFER_TYPE_VALUE_Buy_One_Get_One_Free,
                offer_wl_active_repo_instance.OFFER_TYPE_VALUE_PERCENTAGE_OFF
            ]
        elif category_id == categories_repo_instance.Leisure_Id:
            offer_types_for_category = [
                offer_wl_active_repo_instance.OFFER_TYPE_VALUE_Buy_One_Get_One_Free,
                offer_wl_active_repo_instance.OFFER_TYPE_VALUE_PERCENTAGE_OFF
            ]
        elif category_id == categories_repo_instance.RestaurantsAndBars_Id:
            offer_types_for_category = [
                offer_wl_active_repo_instance.OFFER_TYPE_VALUE_Buy_One_Get_One_Free,
                offer_wl_active_repo_instance.OFFER_TYPE_VALUE_SPEND_THIS_GET_THIS,
                offer_wl_active_repo_instance.OFFER_TYPE_VALUE_GIFT,
            ]
        elif category_id == categories_repo_instance.Services_Id:
            offer_types_for_category = [
                offer_wl_active_repo_instance.OFFER_TYPE_VALUE_Buy_One_Get_One_Free,
                offer_wl_active_repo_instance.OFFER_TYPE_VALUE_SPEND_THIS_GET_THIS,
                offer_wl_active_repo_instance.OFFER_TYPE_VALUE_PERCENTAGE_OFF,
            ]
        elif category_id == categories_repo_instance.Retail_Id:
            offer_types_for_category = [
                offer_wl_active_repo_instance.OFFER_TYPE_VALUE_Buy_One_Get_One_Free,
                offer_wl_active_repo_instance.OFFER_TYPE_VALUE_PERCENTAGE_OFF,
            ]
        elif category_id == categories_repo_instance.Travel_Id:
            offer_types_for_category = [
                offer_wl_active_repo_instance.OFFER_TYPE_VALUE_Buy_One_Get_One_Free,
                offer_wl_active_repo_instance.OFFER_TYPE_VALUE_PERCENTAGE_OFF,
                offer_wl_active_repo_instance.OFFER_TYPE_VALUE_SPEND_THIS_GET_THIS,
            ]
        for _offer_type in offer_types_for_category:
            offer_types.append(
                {
                    'offer_type': _offer_type,
                    'key': self.get_offer_type_key(_offer_type),
                    'label': self.get_offer_type_label_without_value(_offer_type, _locale)
                }
            )
        return offer_types

    def get_image_url_for_voucher_type_filter(self, voucher_type, is_active):
        """
        fetched image url for voucher type filter
        __author__: Farhat
        :param str voucher_type:
        :param bool is_active:
        :rtype: str
        """
        from repositories_white_label.offer_wl_active_repo import OfferWlRepository
        offer_wl_active_repo_instance = OfferWlRepository()
        if is_active:
            return '{url_prefix}filter_{voucher_type}_active.png'.format(
                url_prefix=offer_wl_active_repo_instance.Voucher_Type_Image_URL_Prefix,
                voucher_type=voucher_type
            )
        else:
            return '{url_prefix}filter_{voucher_type}.png'.format(
                url_prefix=offer_wl_active_repo_instance.Voucher_Type_Image_URL_Prefix,
                voucher_type=voucher_type
            )

    def generate_unique_id(self, prefix, length):
        """
        Generate unique id
        """
        prefix = prefix + str(uuid.uuid4())[:length]
        return ''.join(random.choice(prefix) for _ in range(length))


def compare(a, b):
    """
    Compare 2 values
    """
    try:
        return (a > b) - (a < b)
    except TypeError:
        return -1


def multi_key_sort(items, columns, functions={}, getter=itemgetter):
    """
    Sort a list of dictionary objects or objects by multiple keys bidirectionally.
    Keyword Arguments:
    items -- A list of dictionary objects or objects
    columns -- A list of column names to sort by. Use -column to sort in descending order
    functions -- A Dictionary of Column Name -> Functions to normalize or process each column value
    getter -- Default "getter" if column function does not exist
              operator.itemgetter for Dictionaries
              operator.attrgetter for Objects
    usage: https://gist.github.com/malero/418204
    """
    comparers = []
    for column in columns:
        column = column[1:] if column.startswith('-') else column
        if column not in functions:
            functions[column] = getter(column)
        comparers.append((functions[column], 1 if column == column else -1))

    def comparer(left, right):
        for func, polarity in comparers:
            result = compare(func(left), func(right))
            if result:
                return polarity * result
        else:
            return 0

    return sorted(items, key=cmp_to_key(comparer))


def split_and_filter_null_entries(data, delimiter=' '):
    """
    Splits string and filter None entries and returns a list
    :param str|list data: Data to be split
    :param str delimiter: character on which you want to split
    :rtype: list
    """
    if isinstance(data, str):
        return list(filter(None, data.split(delimiter)))
    elif isinstance(data, list):
        return list(filter(None, data))
    return []


class AwsS3Manager(object):
    ACL_PRIVATE = 'private'
    ACL_PUBLIC_READ = 'public-read'
    ACL_PUBLIC_READ_WRITE = 'public-read-write'
    ACL_AUTHENTICATED_READ = 'authenticated-read'
    STORAGE_CLASS_STANDARD = 'STANDARD'
    STORAGE_CLASS_RRS = 'REDUCED_REDUNDANCY'
    STORAGE_CLASS_STANDARD_IA = 'STANDARD_IA'
    FILE_MAXIMUM_ALLOWED_SIZE = 2097152
    RESPONSE_CODE_SUCCESS = 200
    RESPONSE_CODE_BAD_REQUEST = 400
    ENDPOINT = 's3.amazonaws.com'
    AWS_ACCESS_KEY = 'AKIAJ2CHVBBS5NUO6IKQ',
    AWS_SECRET_KEY = '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',
    BUCKET = 'entertainer-profile-images'
    URLS = {
        'http': 'http://s3-us-west-2.amazonaws.com/bucket',
        'https': 'https://s3-us-west-2.amazonaws.com/bucket'
    }
    HEADERS = {
        'Cache-Control': 'max-age=2592000',
        'Expires': 2592000
    }
    S3 = boto3.resource('s3')
    allowed_types = [
        'image/jpeg',
        'image/jpg',
        'image/gif',
        'image/png',
        'image/*'
    ]

    def _put_object(self, file, image_name):
        """
        Puts the object in the bucket
        :param file:
        :param image_name:
        :param data:
        :param urls:
        :param headers:
        :return:
        """
        response = {
            'code': self.RESPONSE_CODE_BAD_REQUEST,
            'error': True,
            'message': 'Something went wrong!',
            'url': ''
        }
        if file.content_type not in self.allowed_types:
            response = {
                'code': self.RESPONSE_CODE_BAD_REQUEST,
                'error': True,
                'message': 'Invalid file type. Only JPG, GIF and PNG types are accepted.',
                'url': ''
            }
            return response
        blob = file.read()
        if len(blob) > self.FILE_MAXIMUM_ALLOWED_SIZE or not blob:
            response = {
                'code': self.RESPONSE_CODE_BAD_REQUEST,
                'error': True,
                'message': 'File too large. File must be less than 2 megabytes.',
                'url': ''
            }
            return response
        try:
            client = boto3.client(
                's3',
                aws_secret_access_key=current_app.config['AWS_SECRET_ACCESS_KEY'],
                aws_access_key_id=current_app.config['AWS_ACCESS_KEY_ID']
            )
            upload_response = client.put_object(
                Bucket=self.BUCKET,
                Key=image_name,
                Body=blob,
                ACL=self.ACL_PUBLIC_READ,
                StorageClass=self.STORAGE_CLASS_STANDARD,
            )
            if upload_response and isinstance(upload_response, dict):
                status = upload_response.get('ResponseMetadata', {}).get('HTTPStatusCode', 400)
                if status == codes.OK:
                    response = {
                        'code': self.RESPONSE_CODE_SUCCESS,
                        'error': False,
                        'message': '',
                        'url': 'https://entertainer-profile-images.s3.amazonaws.com/{}'.format(image_name)
                    }
        except Exception:
            pass
        return response


def blue_print_app():
    if current_app.config['IS_OFFLINE']:
        app_blue_print = 'offline'
    elif current_app.config['IS_ANALYTICS']:
        app_blue_print = 'analytics'
    elif current_app.config['IS_REWARDS']:
        app_blue_print = 'rewards'
    elif current_app.config.get('IS_WHITE_LABEL'):
        app_blue_print = 'b2b'
    else:
        app_blue_print = 'web_api'
    return app_blue_print


def get_function_from_string(function_string='', seperator='.'):
    function_info = {}
    if function_string:
        mod_name, func_name = function_string.rsplit(seperator, 1)
        mod = importlib.import_module(mod_name)
        func = getattr(mod, func_name)
        function_info['func_name'] = func_name
        function_info['func'] = func
    return function_info


def get_logger(filename='', name=''):
    """
    Return a logger with the specified name, creating it if necessary. If apm error logging is on then it also
    sends log to apm server otherwise it logs them in file.
    :param filename: log file name
    :param name: logger name
    :return:
    """
    parent_directory = os.path.dirname(filename)
    parent_directory = os.path.join(current_app.config.get('LOGS_PATH'), parent_directory)
    # create api log folders if not exist example outlet_api, country_api
    if parent_directory and not os.path.exists(parent_directory):
        os.makedirs(parent_directory)
    log_file_name = os.path.join(current_app.config.get('LOGS_PATH'), filename)
    logging_level = logging.ERROR
    formatter = logging.Formatter('%(asctime)s %(name)s %(levelname)s %(message)s')
    # if apm error logging is on then initialize flask elastic apm logging
    logger = logging.getLogger(name)  # or pass string to give it a name
    if current_app.config.get('GENERATE_APM_ERROR_LOGS', False):
        apm = ElasticAPM(current_app)
        handler = LoggingHandler(client=apm.client)
        logger.addHandler(handler)
    # set TimedRotatingFileHandler for root, use very short interval for this example, typical
    # 'when' would be 'midnight' and no explicit interval
    handler = logging.handlers.TimedRotatingFileHandler(log_file_name, when='midnight', backupCount=10)
    handler.suffix = "%Y-%m-%d"
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging_level)
    return logger


def broker_connections():
    broker_connections = []
    connection = None
    backup = False
    try:
        transport_options = current_app.config.get('BROKER_TRANSPORT_OPTIONS', {})
        connection = BrokerConnection(current_app.config['CELERY_BROKER_URL'], transport_options=transport_options)
        broker_connections.append(connection)
        connection.connect()
    except Exception:
        connection = None
        try:
            if current_app.config['CELERY_BACKUP_BROKER_URL']:
                transport_options = current_app.config.get('BACKUP_BROKER_TRANSPORT_OPTIONS', {})
                connection = BrokerConnection(
                    current_app.config['CELERY_BACKUP_BROKER_URL'],
                    transport_options=transport_options
                )
                broker_connections.append(connection)
                connection.connect()
                backup = True
        except Exception:
            connection = None
    return {'connection': connection, 'broker_connections': broker_connections, 'backup': backup}


class EntertainerArgument(Argument):

    def source(self, request):
        """Pulls values off the request in the provided location
        :param request: The flask request object to parse arguments from
        """
        if isinstance(self.location, six.string_types):
            value = getattr(request, self.location, MultiDict())
            if callable(value):
                value = value()
            if value is not None:
                return value
        else:
            values = MultiDict()
            is_mobile_included = 'mobile' in self.location
            for location in self.location:
                if location.lower() == 'mobile':
                    data = getattr(request, 'data', b'').decode()
                    data = re.sub(r'%5B[0-9]*%5D=', '[]=', data)
                    value = parse_qs(data)
                    value = CombinedMultiDict([MultiDict(), MultiDict(value)])
                else:
                    try:
                        value = getattr(request, location, None)
                    except Exception:
                        if not is_mobile_included:
                            raise
                if callable(value):
                    value = value()
                if value is not None:
                    values.update(value)
            return values

        return MultiDict()


def get_request_parser():
    return reqparse.RequestParser(argument_class=EntertainerArgument, bundle_errors=True)


def get_formated_date(date):
    if isinstance(date, datetime.datetime):
        date = datetime.datetime.strftime(date, '%Y-%m-%dT%H:%M:%S+0400')
    return date


def get_current_date_time(get_end_date=False):
    current_date = datetime.datetime.now()
    current_date = current_date.replace(microsecond=0)
    end_date = None
    if get_end_date:
        end_date = current_date + datetime.timedelta(days=14)
        end_date = end_date.strftime('%Y-%m-%d %H:%M:%S')
    current_date = datetime.datetime.strftime(current_date, '%Y-%m-%d %H:%M:%S')
    if get_end_date:
        return current_date, end_date
    return current_date


def parse_voucher_restrictions(json_encoded_voucher_restriction):
    """
    parses a json encoded string
    :param json_encoded_voucher_restriction: json encoded string
    :return: decoded json
    """
    voucher_restrictions = {}
    try:
        voucher_restrictions = json.loads(json_encoded_voucher_restriction)
    except Exception:
        pass
    return voucher_restrictions


def get_hsbc_fine_dining_skus():
    """
    Gets the skus for hsbc fine dining
    :rtype: list
    """
    return ['L19DBFHSC', 'L19DBHSFD']


def check_value_true_or_false(value):
    """
    If boolean value found then returns the value as it is, else return the same value.
    :param value: value to be passed
    """
    if isinstance(value, bool):
        return value

    if value is None:
        return False

    if value in ["1", 1, "true", "True"]:
        return True

    if value in ["0", 0, "false", "", "False"]:
        return False

    return value


def url_for_api_version(endpoint='', version='', **kwargs):
    api_url = 'api_v{version}_{app}.{endpoint}'.format(app=blue_print_app(), endpoint=endpoint, version=version)
    return url_for(api_url, **kwargs)


def list_to_str_tuple(characters_list=[]):
    return "({})".format(str(characters_list).strip('[]'))


def cmp(left_func_val, right_func_val):
    try:
        return (left_func_val > right_func_val) - (left_func_val < right_func_val)
    except TypeError:
        return -1
