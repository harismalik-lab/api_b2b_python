"""
Swagger documentation
"""
import json
import os

from flask import current_app, request
from flask_restful import Resource
from flask_restful_swagger.swagger import (
    SwaggerEndpoint, SwaggerRegistry, _get_current_registry, extract_swagger_path, make_class, register_once,
    render_endpoint, render_homepage
)

from common_white_label.base_resource import basic_auth


def swagger_endpoint(api, resource, path):
    endpoint = SwaggerEndpoint(resource, path)
    req_registry = _get_current_registry(api=api)
    req_registry.setdefault('apis', []).append(endpoint.__dict__)

    class SwaggerResource(Resource):

        @basic_auth.login_required
        def get(self):
            if request.path.endswith('.help.json'):
                return endpoint.__dict__
            if request.path.endswith('.help.html'):
                return render_endpoint(endpoint)

    return SwaggerResource


class SwaggerRegistryAuthentication(Resource):

    @basic_auth.login_required
    def get(self):
        req_registry = _get_current_registry()
        if request.path.endswith('.html'):
            home_path = '{base_path}{spec_endpoint_path}/_/resource_list.json'.format(
                base_path=req_registry['basePath'],
                spec_endpoint_path=req_registry['spec_endpoint_path']
            )
            return render_homepage(home_path)
        return req_registry


def docs(api, apiVersion='0.0', swaggerVersion='1.2',
         basePath='http://localhost:5000',
         resourcePath='/',
         produces=["application/json"],
         api_spec_url='/api/spec',
         description='Auto generated API docs by flask-restful-swagger'):
    api_add_resource = api.add_resource

    def add_resource(resource, *urls, **kwargs):
        SwaggerRegistry.get = SwaggerRegistryAuthentication.get
        register_once(api, api_add_resource, apiVersion, swaggerVersion, basePath,
                      resourcePath, produces, api_spec_url, description)

        resource = make_class(resource)
        method = getattr(resource, 'method', resource.methods[0].lower())
        # Setting doc json path
        swagger_doc_path = ''
        for _version in range(int(apiVersion), 58, -1):
            dir_path = '{path}/v{version}'.format(
                path=current_app.config.get('SWAGGER_DOCS_PATH'),
                version=_version
            )
            if not os.path.isdir(dir_path):
                continue
            swagger_temp_path = '{path}/v{version}/{endpoint}.json'.format(
                path=current_app.config.get('SWAGGER_DOCS_PATH'),
                endpoint=kwargs.get('endpoint', None),
                version=_version
            )

            # Some end points eg: get-user has '-' in names, doc files only have '_' as separator.
            swagger_temp_path = swagger_temp_path.replace('-', '_')

            if os.path.exists(swagger_temp_path):
                swagger_doc_path = swagger_temp_path
                break

        try:
            with open(swagger_doc_path, 'r') as fp:
                swagger_document = json.load(fp)
        except:
            swagger_document = {
                'notes': 'No document present.'
            }

        if method in ['get', 'post']:  # We are having only one method implementation (GET/POST) in every view class.
            resource_method = getattr(resource, method, None)
            if resource_method:
                setattr(resource_method, '__swagger_attr', swagger_document)

        for url in urls:
            endpoint = swagger_endpoint(api, resource, url)

            # Add a .help.json help url
            swagger_path = extract_swagger_path(url)

            # Add a .help.html help url
            endpoint_html_str = '{0}/help'.format(kwargs.get('endpoint', swagger_path))
            api_add_resource(
                endpoint,
                "{0}.help.json".format(swagger_path),
                "{0}.help.html".format(swagger_path),
                endpoint=endpoint_html_str)

        return api_add_resource(resource, *urls, **kwargs)

    api.add_resource = add_resource
    return api
