import re

from validate_email import validate_email

from common_white_label.constants import SUPPORTED_LOCALES, VALID_CURRENCIES


def str_list(value):
    if isinstance(value, str):
        values_list = list(filter(None, value.split(',')))
        for v in values_list:
            if re.search('\'|"|\(|\)', v):
                raise ValueError("Invalid character in \"{}\"".format(value))
        return values_list


def int_list(value):
    if isinstance(value, str):
        values_list = list(filter(None, value.split(',')))
        try:
            values_list = map(int, values_list)
        except AttributeError:
            raise ValueError("array should contain only digits")
        return list(values_list)


def currency(value):
    if isinstance(value, str):
        if not value or value.upper() in VALID_CURRENCIES:
            return value
        raise ValueError('Invalid currency "{}"'.format(value))


def language(value):
    if isinstance(value, str):
        if not value or value.lower() in SUPPORTED_LOCALES:
            return value.lower()
        raise ValueError('Invalid language "{}"'.format(value))


def email(email_str):
    """Return email_str if valid, raise an exception in other case."""
    if validate_email(email_str):
        return email_str
    else:
        raise ValueError('{} is not a valid email'.format(email_str))


def validate_email_string(email_str):
    if validate_email(email_str) or email_str == '':
        return email_str
    else:
        raise ValueError('{} is not a valid email'.format(email_str))


def device_list(device_os):
    """
    Checks that the device os is android or ios
    :param device_os: __platform of device
    :return:
    """
    if isinstance(device_os, str):
        device_os_lower = device_os.lower()
        if device_os_lower in ['ios', 'android', 'web', ""]:
            return device_os_lower
        raise ValueError('{} is not a valid device os'.format(device_os))
    raise ValueError('Invalid __platform type, expected string got {}'.format(type(device_os)))


def device_list_for_sign_up(device_os):
    """
    Checks that the device os is android or ios or blackberry or wp
    """
    device_os_lower = device_os.lower()
    if isinstance(device_os, str):
        if device_os_lower == 'ios' \
                or device_os_lower == 'android' \
                or device_os_lower == "blackberry" \
                or device_os_lower == "wp" \
                or device_os_lower == "":
            return device_os_lower
        raise ValueError('{} is not a valid device os'.format(device_os))
    raise ValueError('Invalid __platform type, expected string got {}'.format(type(device_os)))


def validate_value(value):
    if isinstance(value, str):
        return value
    raise ValueError('{} is not a of type string'.format(value))


def validate_gender(gender):
    """
    Validates that user is male or female
    """
    if isinstance(gender, str):
        gender = gender.lower()
        if gender in ['', 'male', 'female']:
            return gender
        raise ValueError('{} is not a valid gender'.format(gender))
    raise ValueError('{} is not a of type string'.format(gender))


def boolean(value):
    """Parse the string ``"true"`` or ``"false"`` as a boolean (case
    insensitive). Also accepts ``"1"`` and ``"0"`` as ``True``/``False``
    (respectively). If the input is from the request JSON body, the type is
    already a native python boolean, and will be passed through without
    further parsing.
    """
    if isinstance(value, bool):
        return value

    if value is None:
        raise ValueError("boolean type must be non-null")
    value = str(value).lower()
    if value in ('true', '1', 1):
        return True
    if value in ('false', '0', 0, ''):
        return False
    raise ValueError("Invalid literal for boolean(): {0}".format(value))


def validate_platform(platform):
    """
    Validates that __platform is valid
    """
    if isinstance(platform, str):
        platform = platform.lower()
        if platform in ['ios', 'android', 'web']:
            return platform
        raise ValueError('{} is not a valid platform'.format(platform))
    raise ValueError('{} is not a of type string'.format(platform))


def marital_status(status):
    status = status.lower()
    if status in ['married', 'unmarried', ""]:
        return status
    else:
        raise ValueError('{} is not a valid marital_status'.format(status))


def validate_platform_for_reward(platform):
    """
    Validates that __platform is valid for reward users
    """
    if isinstance(platform, str):
        platform = platform.lower()
        if platform in ['ios', 'android', 'wp', 'blackberry']:
            return platform
        raise ValueError('{} is not a valid platform'.format(platform))
    raise ValueError('{} is not a of type string'.format(platform))
