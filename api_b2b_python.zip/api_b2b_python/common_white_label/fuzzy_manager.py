"""
Fuzzy search manager makes an API call that generates a response dict and it contains
 following classes:
 - FuzzySearchResponse
 - OutletScore
 - FuzzySearchManager
"""
# 3rd party imports
import requests
from flask import current_app
from requests import codes

__author__ = 'kamalhasan.qc@gmail.com'


class FuzzySearchResponse(object):
    """
    FuzzySearchResponse contains some attributes which we want to return as part
     of our API call's response data
    """
    def __init__(self):
        self.fuzzy_response = None
        self.wildcard_response = None
        self.outlet_ids = []
        self.outlet_id_score = None
        self.outlet_ids_with_score = None
        self.all_scores = []
        self.is_valid_query = False
        self.is_succeeded = False
        self.is_timeout_or_server_down = False
        self.curl_status = 0
        self.total_results_found = 0
        self.total_unique_results_found = 0


class OutletScore(object):
    """
    OutletScore class contains some attributes related to OutletScore
    """
    def __init__(self):
        self.outlet_ids = []
        self.outlet_id_score = {}
        self.outlet_ids_with_score = []
        self.scores = []


class FuzzySearchManager(object):
    """
    FuzzySearchManager manages fuzzy searching, it has following methods:_
     - get_fuzzy_results
    """
    SCORE_FOR_WILDCARD_SEARCH = 100

    def get_fuzzy_results(self, query, category, sub_category):
        """
        Get fuzzy results makes an API call to fuzzy_host and generates a
        FuzzySearchResponse accordingly and returns
        :param str query: Fuzzy query
        :param str|None category:
        :param sub_category:
        :rtype: FuzzySearchResponse
        """
        # TODO: assert on other params
        assert isinstance(category, str) or category is None, \
            'Invalid category'
        fuzzy_host = current_app.config['ELASTIC_SEARCH_URL']
        response = FuzzySearchResponse()
        must_match, must_not_match = [], []
        search_in_fields = ['merchant_name', 'offer_name', 'outlet_name']
        must_match.append({'multi_match': {'query': query,
                                           'fields': search_in_fields,
                                           'fuzziness': 'AUTO'}})
        search_results_fuzzy, search_results_wildcard = None, None

        if category and category.lower() != 'all':
            must_match_category = {'match': {'category': {'query': category}}}
            must_match.append(must_match_category)
        if sub_category:
            must_match.append({'match': {'digital_section': {
                'query': sub_category
            }}})
        _query_fuzzy, _query_wildcard, _query_wildcard_2 = self.\
            get_query_dicts(must_match, must_not_match, [], 0, query)
        # TODO: get timeout value from configuration module when available
        wildcard_response = requests.get(
            fuzzy_host,
            data=_query_wildcard,
            timeout=current_app.config['ELASTIC_SEARCH_MAX_SEC_FOR_TIMEOUT']
        )
        if wildcard_response.status_code == codes.OK:
            search_results_wildcard = wildcard_response.json()
        # TODO: get timeout value from configuration module when available
        fuzzy_response = requests.get(
            fuzzy_host,
            data=_query_fuzzy,
            timeout=current_app.config['ELASTIC_SEARCH_MAX_SEC_FOR_TIMEOUT']
        )
        if fuzzy_response.status_code == codes.OK:
            search_results_fuzzy = fuzzy_response.json()
        response.curl_status = fuzzy_response.status_code
        if search_results_fuzzy and search_results_wildcard:
            outlet_score = OutletScore()
            response.is_succeeded = True
            response.fuzzy_response = search_results_fuzzy
            response.wildcard_response = search_results_wildcard
            wildcard_search_hits = search_results_wildcard['hits']['total']
            if wildcard_search_hits > 0:
                response.total_results_found += wildcard_search_hits
                self.__process_search_results(search_results_wildcard,
                                              outlet_score, True)
            fuzzy_search_hits = search_results_fuzzy['hits']['total']
            if fuzzy_search_hits > 0:
                response.total_results_found += fuzzy_search_hits
                self.__process_search_results(search_results_fuzzy,
                                              outlet_score, False)
            response.total_unique_results_found = len(outlet_score.outlet_ids)
            # Just for debugging
            response.outlet_ids = sorted(outlet_score.outlet_ids)
            response.outlet_id_score = outlet_score.outlet_id_score
            response.outlet_ids_with_score = outlet_score.outlet_ids_with_score
            response.all_scores = sorted(list(set(outlet_score.scores)),
                                         reverse=True)
            return response
        response.is_timeout_or_server_down = True
        return response

    @classmethod
    def __process_search_results(cls, search_response, outlet_score,
                                 is_wildcard_results=False):
        if search_response['hits']['total'] > 0:
            for hit in search_response['hits']['hits']:
                outlet_id = hit['_source']['outlet_id']
                score = FuzzySearchManager.SCORE_FOR_WILDCARD_SEARCH if\
                    is_wildcard_results else hit['_score']

                if outlet_id not in outlet_score.outlet_ids:
                    # searched_outlet_ids.append(outlet_id)
                    outlet_score.outlet_ids.append(outlet_id)
                    outlet_score.outlet_id_score[outlet_id] = score
                    outlet_score.scores.append(score)
                    outlet_score.outlet_ids_with_score.append({
                        'outlet_id': outlet_id,
                        'relevance_score': score
                    })
                else:  # override if new score is greater
                    outlet_score_against_id = outlet_score.outlet_id_score.\
                        get(outlet_id)
                    if outlet_score_against_id and score > \
                            outlet_score_against_id:
                        outlet_score.outlet_id_score[outlet_id] = score

    @classmethod
    def get_query_dicts(cls, must_match, must_not_match, should_match,
                        minimum_should_match, query):
        """
        Generates query dicts and return them
        :param list must_match:
        :param list must_not_match:
        :param list should_match:
        :param int minimum_should_match: minimum matching threshold value
        :param query:
        :rtype: tuple(dict, dict, dict)
        """
        assert isinstance(must_match, list), 'Invalid must_match parameter type'
        assert isinstance(must_not_match, list), 'Invalid must_not_match parameter type'
        assert isinstance(should_match, list), 'Invalid should_match parameter type'
        assert isinstance(minimum_should_match, int), 'Invalid minimum_should_match parameter type'
        query_fuzzy = {
            'from': 0,
            'size': 2000,
            'query': {
                'bool': {
                    'must': must_match,
                    'must_not': must_not_match,
                    'should': should_match,
                    'minimum_should_match': minimum_should_match
                }
            }
        }
        query_wildcard = {
            'from': 0,
            'size': 5000,
            'query': {
                'wildcard': {
                    'merchant_name': {
                        'wildcard': '*{}*'.format(query),
                        'boost': 1.0
                    }
                }
            }
        }
        query_wildcard_2 = {
            'from': 0,
            'size': 5000,
            'query': {
                'query_string': {
                    'query': '*{}*'.format(query),
                    'fields': ['merchant_name', 'offer_name']
                }
            }
        }
        return query_fuzzy, query_wildcard, query_wildcard_2
