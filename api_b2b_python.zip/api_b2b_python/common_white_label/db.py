import mysql.connector
from flask import current_app
from PyMysqlPool.db_util.mysql_pool import get_pool_connection

# DB Constants
DEFAULT = 'default'
CONSOLIDATION = 'consolidation'
BACKUP = 'backup'
INFORMATICA = 'informatica'
ENTERTAINER_GO = 'entertainer_go'


def get_db_settings_from_app(connection_name=None, pool=False):
    db_config, db_settings = {}, {}
    if pool:
        db_config = {
            DEFAULT: {
                'pool': {
                    # use = 0 no pool else use pool
                    "use": True,
                    # size is >=0,  0 is dynamic pool
                    "size": 0,
                    # pool name
                    "name": DEFAULT
                }
            },
            CONSOLIDATION: {
                'pool': {
                    "use": True,
                    "size": 0,
                    "name": CONSOLIDATION
                }
            },
            INFORMATICA: {
                'pool': {
                    "use": True,
                    "size": 0,
                    "name": INFORMATICA
                }
            }
        }

    if connection_name:
        if connection_name == DEFAULT:
            db_settings = current_app.config['SQL_DB_CONFIG']
        elif connection_name == CONSOLIDATION:
            db_settings = current_app.config['SQL_CONSOLIDATION_DB_CONFIG']
        elif connection_name == BACKUP:
            db_settings = current_app.config['SQL_BACKUP_DB_CONFIG']
        elif connection_name == INFORMATICA:
            db_settings = current_app.config['SQL_INFORMATICA_DB_CONFIG']
        elif connection_name == ENTERTAINER_GO:
            db_settings = current_app.config['SQL_ENTERTAINER_GO_DB_CONFIG']
        if db_settings and pool:
            db_config[connection_name].update(db_settings)
            db_settings = db_config[connection_name]
    return db_settings


def get_single_connection_for_db(connection_name=None):
    db_connection = None
    db_settings = get_db_settings_from_app(connection_name)
    if db_settings:
        try:
            db_connection = mysql.connector.connect(**db_settings)
        except mysql.connector.Error:
            raise
    return db_connection


def get_connection_for_db(connection_name=None, db_settings={}):
    db_connection = None
    if not db_settings:
        db_settings = get_db_settings_from_app(connection_name, pool=True)
    if db_settings:
        try:
            db_connection = get_pool_connection(db_settings)
        except mysql.connector.Error:
            raise
    return db_connection


def set_all_pools_for_app():
    ALL_DBS = [CONSOLIDATION, DEFAULT]
    # INFORMATICA will not be pooled for offline and analytics app.
    if not any([current_app.config.get('IS_OFFLINE', False), current_app.config.get('IS_ANALYTICS', False)]):
        ALL_DBS.append(INFORMATICA)
    for db in ALL_DBS:
        get_connection_for_db(connection_name=db).close()
