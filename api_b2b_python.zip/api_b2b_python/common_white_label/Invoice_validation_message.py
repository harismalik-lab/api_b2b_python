"""
Reads proper validation messages according to invoice validation message
"""
from repositories_white_label.translations_repo import TranslationManager


class InvoiceValidationMessage(object):
    """
    Gets invoice validation message according to validation status of invoice.
    """
    translation_manager = TranslationManager()

    def validation_status(self, validation_status, locale, is_user_upgraded=False):
        """
        Gets invoice validation message according to validation status of invoice.
        :param validation_status: invoice validation status
        :param locale: language for message
        :param is_user_upgraded:
        :return: function output according to validation_status
        """
        method_name = 'status_{}'.format(str(validation_status))
        method = getattr(self, method_name, lambda: "default")
        if is_user_upgraded:
            return method(locale, is_user_upgraded=False)
        return method(locale)

    def status_1(self, locale, is_user_upgraded=False):
        """
        Reads status according to validation message
        :param locale: language of validation message
        :param is_user_upgraded: check to invoice is updated
        :return: Translated message
        """
        if is_user_upgraded:
            return self.translation_manager.get_translation(
                self.translation_manager.invoice_validation_success_message_upgraded, locale
            )
        return self.translation_manager.get_translation(
            self.translation_manager.invoice_validation_success_message, locale
        )

    def status_2(self, locale):
        """
        Reads status according to validation message
        :param locale: language of validation message
        :return: Translated message
        """
        return self.translation_manager.get_translation(
            self.translation_manager.invoice_validation_already_linked_message, locale
        )

    def status_4(self, locale):
        """
        Reads status according to validation message
        :param locale: language of validation message
        :return: Translated message
        """
        return self.translation_manager.get_translation(
            self.translation_manager.invoice_validation_invalid_message, locale
        )

    def status_5(self, locale):
        """
        Reads status according to validation message
        :param locale: language of validation message
        :return: Translated message
        """
        return self.translation_manager.get_translation(
            self.translation_manager.invoice_validation_invalid_message, locale
        )

    def status_6(self, locale):
        """
        Reads status according to validation message
        :param locale: language of validation message
        :return: Translated message
        """
        return self.translation_manager.get_translation(
            self.translation_manager.invoice_validation_outdated_invoice, locale
        )

    def status_7(self, locale):
        """
        Reads status according to validation message
        :param locale: language of validation message
        :return: Translated message
        """
        return self.translation_manager.get_translation(
            self.translation_manager.invoice_validation_invalid_code_message, locale
        )

    def status_8(self, locale):
        """
        Reads status according to validation message
        :param locale: language of validation message
        :return: Translated message
        """
        return self.translation_manager.get_translation(
            self.translation_manager.invoice_validation_invalid_message_wrong_amount, locale
        )

    def status_default(self, locale):
        """
        Reads default status for validation message
        :param locale: language of validation message
        :return: Translated message
        """
        return self.translation_manager.get_translation(
            self.translation_manager.invoice_validation_invalid_message, locale
        )

    def get_invoice_validation_message(self, invoice_validation_status, locale, is_user_upgraded=False):
        """
        Gets invoice validation message according to validation status of invoice.
        """
        return self.validation_status(
            invoice_validation_status, locale, is_user_upgraded=is_user_upgraded
        )
