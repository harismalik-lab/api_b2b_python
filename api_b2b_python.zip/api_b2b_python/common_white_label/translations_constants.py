# -*- coding: utf-8 -*-
LOCALE_AR = 'أنت'
LOCALE_CN = 'You'
LOCALE_EL = 'Εσύ'
LOCALE_CN_RESET_PASSWORD = "重設密碼的連結已發送到您的電郵信箱!"
LOCALE_AR_RESET_PASSWORD = "تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني الخاص!"
PRODUCT_LOCALE_AR = 'صالح لغاية'
PRODUCT_LOCALE_CN = "有效期至"
PRODUCT_LOCALE_EL = "Ισχύει έως"
