"""
Constants for WhiteLabel Api
"""
from repositories_white_label.wl_categories_repo import CategoriesRepositoryWl

SUPPORTED_LOCALES = ['de', 'en', 'ar', 'cn', 'el', 'zh']
VALID_CURRENCIES = [
    "BHD", "EGP", "EUR", "GBP", "HKD", "JOD", "KWD", "LBP", "MYR", "OMR", "QAR", "SAR", "SGD", "USD", "ZAR", "AED"
]
TASKS_FAILURE_TABLE_STRUCTURE = '''
            CREATE TABLE IF NOT EXISTS tasks_failures(
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                date_created date,
                date_update TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
                status INTEGER DEFAULT 0,
                data TEXT
            );
            '''


class GlobalConstants(object):
    """
    Class to define constant variables
    """

    Body = 'body'
    Kids = 'kids'
    Leisure = 'leisure'
    ResturantsAndBars = 'restaurants and bars'
    Retail = 'retail'
    Services = 'services'
    Travel = 'travel'
    category_name_Body = 'Body'
    category_name_Leisure = 'Leisure'
    category_name_Restaurants_and_Bars = 'Restaurants and Bars'
    category_name_Retail = 'Retail'
    category_name_Services = 'Services'
    category_name_Travel = 'Travel'
    category_API_Name_Body = 'Body'
    category_API_Name_Leisure = 'Leisure'
    category_API_Name_Restaurants_and_Bars = 'Restaurants and Bars'
    category_API_Name_Retail = 'Retail'
    category_API_Name_Services = 'Services'
    category_API_Name_Travel = 'Travel'
    category_API_Name_Kids = 'Kids'
    Analytics_Category_Code_Body = "BF"
    Analytics_Category_Code_Leisure = "AL"
    Analytics_Category_Code_RestaurantsAndBars = "FD"
    Analytics_Category_Code_Retail = "FR"
    Analytics_Category_Code_Services = "ES"
    Analytics_Category_Code_Travel = "HW"
    ENTERTAINER_GETAWAYS = "ENTERTAINER getaways"
    CHEERS_LOCATION_CHECK = (1, 2)
    MIN_VALID_APP_VERSION = '1.3'
    INTERNAL_SERVER_ERROR = 'Internal Server Error'
    PLATFORM_IOS = "ios"
    PLATFORM_ANDROID = "android"
    SERVICE_Session_Helper_DEFAULT = "api.session_helper"
    PARAM_VALUE_GEMS_Student_Patent_Id = "{student_parent_id}"
    PARAM_VALUE_GEMS_BSU = "{bsu}"
    CUSTOMER_ID = "customer_id"
    IS_USER_LOGGED_IN = "is_user_logged_in"
    IS_PREACTIVATED_APP = "is_preactivated_app"
    NON_DEPLETABLE_OFFERS_APP = "non_depletable_offers_app"
    PRODUCT_IDS = "product_ids"
    PARAM_FETCHER = "param_fetcher"
    REQUEST = 'request'
    APP_TUTORIAL_BACKGROUND_IMAGE = 'https://www.pixelstalk.net/wp-content/uploads/2016/11/iPhone-7-Wallpaper-Grey-no-logo.jpg'  # noqa: E501
    SAVINGS_IMAGE_URL = "https://s3.amazonaws.com/entertainer-app-assets/savings_image.png"
    SAVINGS_SMALL_IMAGE_URL = "https://s3.amazonaws.com/entertainer-app-assets/savings_image_small.png"
    app_tutorial_background_image = 'https://www.pixelstalk.net/wp-content/uploads/2016/11/iPhone-7-Wallpaper-Grey-no-logo.jpg'  # noqa: E501
    NOT_INTERESTED_CHEERS_OFFER_MESSAGE = 'I do not want Clink but thanks anyway.'
    PRODUCT_INFORMATION = 'Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across the UAE.'  # noqa: E501
    CHEERS_LOGO_URL = 'https://s3-us-west-2.amazonaws.com/app-assets-whitelabel/logo-cheers-gems.png'  # noqa: E501
    SYNSODYNE_CODE = 'CHSAU/CHSENO/0094/17a'

    ENTERTAINER_HSBC_MAIN_TOP_COLOR_BLACK_CARD = 'aa000000'
    ENTERTAINER_HSBC_MAIN_TOP_COLOR = 'aae63a2a'
    ENTERTAINER_HSBC_MAIN_TOP_TEXT_COLOR = 'FFFFFF'
    ENTERTAINER_HSBC_MAIN_TOP_IMAGE_BLACK_CARD = 'https://s3.amazonaws.com/app-home-tiles/more-from-hsbc/Black_hs.jpg'
    ENTERTAINER_HSBC_MAIN_TOP_IMAGE = 'https://s3.amazonaws.com/entertainer-app-assets/Generic-ios-Visual.jpg'

    POINTS_AVAILABLE_IMAGE = 'https://s3.amazonaws.com/entertainer-app-assets/icons/ic_home_points.png'
    POINTS_USED_IMAGE = "https://s3.amazonaws.com/entertainer-app-assets/icons/ic_home_points.png"
    TITLE_DETAIL_BOTTOM_MESSAGE = "Use your GEMS Points toward school fees! Minimum number of GEMS Points required: 5,550"  # noqa:E501
    ENTERTAINER_GETAWAYS_INTERNAL_WEBVIEW_TITTLE = "ENTERTAINER getaways"
    ENTERTAINER_GETAWAYS_CLOSE_WEBVIEW_MESSAGE = 'Are you sure you want to navigate away from ENTERTAINER getaways?'

    AAG_MAIN_TOP_COLOR = 'aaff5c5c'
    AAG_MAIN_TOP_TEXT_COLOR = '252525'
    AAG_MAIN_TOP_IMAGE = ''

    USER_GROUP_2 = 2
    TITLE_COLOR = 'f99f1c'
    TRAVEL_CAT_IMG_GEM = "https://s3.amazonaws.com/app-home-tiles/category-icons/gem/hotel.png"
    TRAVEL_CAT_IMG_HSBS = "https://s3.amazonaws.com/entertainer-app-assets/categories/hsbc/hotel.png"
    DUBAI_ENTERTAINMENTS_What_New = "What’s New"

    ICON_URL_BASE = "https://s3.amazonaws.com/entertainer-app-assets/icons/"
    HOTEL_IMAGE = "https://s3-us-west-2.amazonaws.com/ent-search-results/hotel.png"
    MALL_IMAGE = "https://s3-us-west-2.amazonaws.com/ent-search-results/mall.png"
    NEIGHBORHOOD_IMAGE = "https://s3-us-west-2.amazonaws.com/ent-search-results/neighbourhood.png"
    BADGE_NEW_IMAGE_URL = "{icon_base}badge_new.png".format(icon_base=ICON_URL_BASE)
    BADGE_MONTHLY_IMAGE_URL = "{icon_base}badge_monthly.png".format(icon_base=ICON_URL_BASE)
    BADGE_CHEERS_IMAGE_URL = "{icon_base}badge_cheers.png".format(icon_base=ICON_URL_BASE)
    BADGE_DELIVERY_IMAGE_URL = "{icon_base}badge_delivery.png".format(icon_base=ICON_URL_BASE)
    BADGE_MORE_SA_IMAGE_URL = "{icon_base}badge_more_sa.png".format(icon_base=ICON_URL_BASE)
    BADGE_PINGED_IMAGE_URL = "{icon_base}badge_pinged.png".format(icon_base=ICON_URL_BASE)
    EID_OFFERS = ('eid', 'eid offers')
    EID_OFFER = 'eid offer'
    DEFAULT = 'default'
    ALPHA = 'alpha'
    HOTEL = 'hotel'
    MALL = 'mall'
    NEIGHBORHOOD = 'neighborhood'

    GEMS_LOGO = 'https://s3.amazonaws.com/entertainer-app-assets/icons/gem-logo.png'
    NBAD_PAY_GEMS_LOGO = 'https://s3-us-west-2.amazonaws.com/app-assets-whitelabel/nbad.png'
    NBAD_PAY = "NBAD Pay"
    ENBD = "ENBD"
    ENBD_GEMS_LOGO = 'https://s3-us-west-2.amazonaws.com/app-assets-whitelabel/nbd.png'
    EMAX_LOGO = 'https://s3.amazonaws.com/entertainer-app-assets/icons/emax_logo.png'

    summary_type_by_year = 'by_year'
    summary_type_by_month = 'by_month'

    JWT_HEADER_ERROR_MESSAGE = 'This device is not authorized to access the server. Please contact support team'
    MISSING_JWT_ERROR_MESSAGE = 'JWT authorization missing'
    JWT_DECODE_ERROR_MESSAGE = 'Invalid JWT'
    JWT_SIGNATURE_MISMATCH = 'JWT SIGNATURE MISMATCH'

    INVALID_TOKEN = "Token is not valid"
    INVALID_JWT = "Unauthorized JWT Token"
    INVALID_PARAMS = 'Invalid parameters'

    DEFAULT_LIMIT = "0/day;0/hour;0/minute"

    TITLE_END_USER_LICENSE = "End User License Agreement"
    TYPE_END_USER_LICENSE = "web"
    WEB_URL_END_USER_LICENSE = "https://www.theentertainerme.com/end-user-license-agreement?language=%@"

    TITLE_TERMS_OF_USE = "Terms of Use"
    TYPE_TERMS_OF_USE = "web"
    WEB_URL_TERMS_OF_USE = "https://www.theentertainerme.com/rules-of-use?language=%@"

    TITLE_PRIVACY_POLICY = "Privacy Policy"
    TYPE_PRIVACY_POLICY = "web"
    WEB_URL_PRIVACY_POLICY = "https://www.theentertainerme.com/Privacy-Policy?language=%@&header=no"

    TITLE_LOCATION = "Location (Dubai)"
    TYPE_LOCATION = "location"
    WEB_URL_LOCATION = ""

    TITLE_REDEMPTION = "Redemptions"
    TYPE_REDEMPTION = "redemptions"
    WEB_URL_REDEMPTION = ""

    TITLE_LOGOUT = "Logout"
    TYPE_LOGOUT = "logout"
    WEB_URL_LOGOUT = ""

    def get_valid_categories(self):
        """
        Gets valid categories
        :rtype: list
        """
        return [
            CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
            CategoriesRepositoryWl.category_API_Name_Body,
            CategoriesRepositoryWl.category_API_Name_Leisure,
            CategoriesRepositoryWl.category_API_Name_Retail,
            CategoriesRepositoryWl.category_API_Name_Services,
            CategoriesRepositoryWl.category_API_Name_Travel
        ]

    def get_configured_sku_by_company(self, company):
        company = company.lower()
        skus = {
            'gem': [
                'L18DBGEPE',
                'L19DBGEPE',
                'L18ADGEPE',
                'L19ADGEPE',
                'L18TRGEPE',
                'L19TRGEPE',
                'L18DBGESE',
                'L19DBGESE',
                'L18ADGESE',
                'L19ADGESE',
                'L18TRGESE',
                'L19TRGESE'
            ]
        }
        return skus.get(company, [])
