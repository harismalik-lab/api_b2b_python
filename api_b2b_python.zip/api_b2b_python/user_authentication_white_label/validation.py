from common_white_label.common_helpers import get_request_parser

token_parser = get_request_parser()
token_parser.add_argument(
    'session_token',
    type=str,
    default='',
    required=False,
    location=['mobile', 'json', 'values'],
    help='request parameter session_token is empty.'
)

token_parser.add_argument(
    'app_version',
    type=str,
    default='',
    location=['mobile', 'json', 'values'],
    required=False
)

token_parser.add_argument(
    'key',
    type=str,
    default='',
    location=['mobile', 'json', 'values'],
    required=False
)
