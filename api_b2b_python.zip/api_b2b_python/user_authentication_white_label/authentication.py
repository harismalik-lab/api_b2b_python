"""
User Authentication
"""
import json
import time
from base64 import b64decode

from flask import current_app, request
from flask_httpauth import HTTPBasicAuth
from flask_jwt_extended.exceptions import InvalidHeaderError, NoAuthorizationError
from flask_jwt_extended.view_decorators import ctx_stack, wraps
from jwt import InvalidAlgorithmError, decode
from jwt.exceptions import InvalidSignatureError
from werkzeug.datastructures import Authorization
from werkzeug.exceptions import BadRequest, Forbidden

from common_white_label.constants import GlobalConstants
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.session_repo import SessionRepositoryWhiteLabel
from repositories_white_label.wl_company_repo import WLCompany
from user_authentication_white_label.validation import token_parser


def token_decorator(fn):
    @wraps(fn)
    def validator(self, *args, **kwargs):
        return jwt_token_required_wl(fn)(self, *args, **kwargs)
    return validator


def token_required_white_label(fn):

    @wraps(fn)
    def wrapper(self, *args, **kwargs):
        common_helpers_instance = WLCompany()
        close_connection = True
        try:
            if not getattr(self, 'required_token', False):
                close_connection = False
                return fn(self, *args, **kwargs)

            request_args = token_parser.parse_args()
            jw_data = ctx_stack.top.jwt_identity
            wlcompany = jw_data.get('wlcompany')
            # session_token = request_args.get('session_token', '')
            session_token = jw_data.get('session_token')
            session_data = dict()
            session_data['company'] = wlcompany
            session_data['is_user_logged_in'] = False
            session_data['is_using_trial'] = False
            session_data['user_id'] = 0
            session_data['customer_id'] = 0

            if session_token:
                # Initialize Repos
                session_repo_instance = SessionRepositoryWhiteLabel()
                customer_repo_instance = CustomerProfileWhiteLabel()

                # Param Fetcher Object

                app_version = request_args.get('app_version', '')

                user_id = request_args.get('__i', 0)
                if not wlcompany:
                    data = GlobalConstants.INVALID_TOKEN
                    self.status_code = 403
                    self.code = 403
                    self.send_response_flag = True
                    self.process_request_exception(code=self.code, status_code=self.status_code, message=data)
                    self.remove_logger_handlers()
                    return self.send_response(data, self.status_code)
                try:
                    # session_id = request_args.get('__sid', 0)
                    if not session_token:
                        raise Forbidden(
                            'A valid session session_token is required for this call. - {session_token} - {url}'.format(
                                session_token=session_token,
                                url=str(request.path)
                            )
                        )
                    if common_helpers_instance.get_pre_activated_apps(wlcompany):
                        white_label_key = request_args.get('key', '')
                        if not white_label_key:
                            data = "The imie number is required"
                            self.status_code = 403
                            self.code = 403
                            self.send_response_flag = True
                            self.process_request_exception(code=self.code, status_code=self.status_code, message=data)
                            self.remove_logger_handlers()
                            return self.send_response(data, self.status_code)
                except Exception:
                    data = {}
                    self.status_code = 403
                    self.code = 403
                    self.send_response_flag = True
                    self.process_request_exception(code=self.code, status_code=self.status_code, message=data)
                    self.remove_logger_handlers()
                    return self.send_response(data, self.status_code)

                # if session_id:
                #     # Validate Session Token and populate the request session object
                #     session = session_repo_instance.find_by_id(company=wlcompany, session_id=session_id)
                else:
                    session = session_repo_instance.find_by_token(company=wlcompany, session_token=session_token)
                if session:
                    session_id = session.get('id')
                    user_id = session.get('customer_id')

                if session.get('session_token') != session_token:
                    raise Forbidden(
                        'Session is tempered. -> token:{session_token}, user_id:{user_id}, request:{url} '.format(
                            session_token=session_token,
                            user_id=user_id,
                            url=str(request.path)
                        )
                    )

                if app_version and session.get('app_version') != app_version:
                    session_repo_instance.update_app_version(
                        app_version=app_version,
                        session=session
                    )

                refresh_required = session.get('refresh_required', 0)
                product_ids = session.get('product_ids', '')

                if refresh_required == 1:
                    try:
                        # need to be according to white label
                        product_ids = customer_repo_instance.get_customer_products(
                            user_id=user_id,
                            company=wlcompany
                        )
                        date_created = time.time()
                        if product_ids:
                            session_repo_instance.update_session_product_ids(
                                session_id=session_id,
                                product_ids=product_ids,
                                date_cached=date_created
                            )
                    except Exception:
                        raise
                session_data['is_user_logged_in'] = False
                if session:
                    session_data['is_user_logged_in'] = True
                session_data['id'] = session.get('id')
                session_data['session_token'] = session.get('session_token')
                session_data['is_using_trial'] = False
                session_data['user_id'] = user_id
                session_data['customer_id'] = user_id
                session_data['new_member_group'] = customer_repo_instance.MEMBERSTATUS_PROSPTECT
                if product_ids:
                    session_data['new_member_group'] = customer_repo_instance.MEMBERSTATUS_MEMBER
                session_data['member_type_id'] = session_data['new_member_group']
                session_data['member_type'] = customer_repo_instance.get_member_type(
                    session_data['new_member_group']
                )
                session_data['family_is_active'] = False
                session_data['is_user_in_family'] = False
                session_data['owns_cheer_products'] = False
                session_data['company'] = wlcompany
                try:
                    session_data['product_ids'] = session.get('product_ids', '').split(',')
                except AttributeError:
                    session_data['product_ids'] = []
            ctx_stack.top.session_data = session_data
            return fn(self, *args, **kwargs)
        except BadRequest as bad_request_exception:
            return self.process_bad_request(exception_raised=bad_request_exception)
        except Exception as exception_raised:
            return self.process_request_exception(exception_raised=exception_raised)
        finally:
            if close_connection:
                self.close_connections()
    return wrapper


def get_current_customer():
    """
    Return the customer's session-data.
    """
    return getattr(ctx_stack.top, 'session_data', {})


def get_jw_token_identity():
    """
    Returns JWT identity
    """
    return getattr(ctx_stack.top, 'jwt_identity', {})


def get_company():
    """
     Return company name
    """
    return get_jw_token_identity().get('wlcompany')


class HTTPBasicAuthEntertainer(HTTPBasicAuth):

    def login_required(self, f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if not (current_app.config.get('BASIC_AUTH_ENABLED', False) and getattr(args[0], 'BASIC_AUTH_ENABLED', False)):
                return f(*args, **kwargs)
            auth = request.authorization
            # To avoid circular import
            # from web_api.sharing.api import PostSharingSendApi
            # if isinstance(args[0], PostSharingSendApi):
            #     return f(*args, **kwargs)
            if auth is None and 'Authorization' in request.headers:
                # Flask/Werkzeug do not recognize any authentication types
                # other than Basic or Digest, so here we parse the header by
                # hand
                try:
                    auth_type, token = request.headers['Authorization'].split(
                        None, 1)
                    auth = Authorization(auth_type, {'token': token})
                except ValueError:
                    # The Authorization header is either empty or has no token
                    pass

            # if the auth type does not match, we act as if there is no auth
            # this is better than failing directly, as it allows the callback
            # to handle special cases, like supporting multiple auth types
            if auth is not None and auth.type.lower() != self.scheme.lower():
                auth = None

            # Flask normally handles OPTIONS requests on its own, but in the
            # case it is configured to forward those to the application, we
            # need to ignore authentication headers and let the request through
            # to avoid unwanted interactions with CORS.
            if request.method != 'OPTIONS':  # pragma: no cover
                if auth and auth.username:
                    password = self.get_password_callback(auth.username)
                else:
                    password = None
                if not self.authenticate(auth, password):
                    # Clear TCP receive buffer of any pending data
                    return self.auth_error_callback()

            return f(*args, **kwargs)
        return decorated


def jwt_token_required_wl(fn):
    """
    If you decorate a vew with this, it will ensure that the requester has a
    valid JWT before calling the actual view. This does not check the freshness
    of the token.
    See also: fresh_jwt_required()
    :param fn: The view function to decorate
    """
    @wraps(fn)
    def wrapper(self, *args, **kwargs):
        if getattr(self, 'BASIC_AUTH_ENABLED', False):
            return fn(self, *args, **kwargs)
        # get decoded JWT token using secret key and algo OR:
        # get jwt error message for invalid or required jwt or invalid algo
        data = decode_jwt_from_header()
        if data and data.get('error_msg'):
            data = data.get('error_msg')
            self.status_code = 401
            self.code = 401
            self.send_response_flag = True
            self.process_request_exception(code=self.code, status_code=self.status_code, message=data)
            self.remove_logger_handlers()
            return self.send_response(data, self.status_code)
        return token_required_white_label(fn)(self, *args, **kwargs)
    return wrapper


def process_exception(exception_raised, message="Unable to authorize"):
    if getattr(exception_raised, 'data', None):
        message = exception_raised.data.get('message', exception_raised.data)
    elif getattr(exception_raised, 'description', None):
        message = exception_raised.description
    elif getattr(exception_raised, 'args', []):
        message = exception_raised.args[0]
    return message


def get_verified_jwt_payload():
    """ Returns decoded JWT token or raise exceptions for invalid data or missing data

    1. Extract token from header
    2. get token hashing algo
    3. decode using secret key and hashing algo
    """
    jwt_bearer = request.environ.get('HTTP_AUTHORIZATION')
    if jwt_bearer:
        jwt_bearer = jwt_bearer.split(' ')[1]
        header = b64decode(jwt_bearer.split('.')[0])
        jwt_algorithm = json.loads(header.decode()).get('alg')
        secret_key = current_app.config.get('JWT_SECRET_KEY')
        return decode(jwt_bearer, secret_key, algorithms=[jwt_algorithm])
    raise InvalidHeaderError


def decode_jwt_from_header():
    """
    Decodes JWT from authorization header and get identity
    :return: JWT identity or exception if raised
    """
    try:
        data = get_verified_jwt_payload()
    # except BadRequest as bad_request_exception:
    #     error = process_exception(bad_request_exception)
    #     data = {'error_msg': error}
    except InvalidHeaderError:
        data = {'error_msg': GlobalConstants.JWT_HEADER_ERROR_MESSAGE}
    except NoAuthorizationError:
        data = {'error_msg': GlobalConstants.MISSING_JWT_ERROR_MESSAGE}
    # except DecodeError as error:
    #     data = {'error_msg': error.args[0]}
    except (InvalidSignatureError, InvalidAlgorithmError):
        data = {'error_msg': GlobalConstants.JWT_SIGNATURE_MISMATCH}
    except Exception as exception_raised:
        error = process_exception(exception_raised)
        data = {'error_msg': error}
    finally:
        ctx_stack.top.jwt_identity = data
        return data
