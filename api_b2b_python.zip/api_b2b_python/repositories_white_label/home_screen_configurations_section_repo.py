"""
Home screen configurations section repo
"""
from common_white_label.db import DEFAULT as ENTERTAINER_WEB
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class HomeScreenConfigurationsSectionRepository(BaseRepository):
    """
    Repo for wl home screen API configurations section which holds the helper methods required.
    """
    __count = 0

    def get_all(self, location_id, user_group=0, company='', locale='en'):
        """
        Gets all home screen configurations section
        :param  int location_id: user location id
        :param  int user_group:  user group
        :param  str company:     user company
        :param  str locale:      user language
        :rtype: dict
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select([
            'hscs.id', 'hscs.section_name', 'hscs.company', 'hscs.section_width', 'hscs.section_height',
            'hscs.title_color', 'hscs.background_color', 'hscs.user_group', 'hscs.location_id',
            'hscs.is_active,coalesce(t.title, "") as title'
        ])
        sql_dal.from_(['home_screen_configurations_section'], ['hscs'])
        sql_dal.left_join(
            'home_screen_configurations_section_translation as t',
            'hscs.id',
            't.section_id AND t.locale= "{locale}"'.format(locale=locale)
        )
        sql_dal.where({
            'hscs.is_active': 1,
            'hscs.company': company,
        })
        sql_dal.where_in('hscs.user_group', [user_group, 0])
        sql_dal.where_in('hscs.location_id', [location_id, 0])
        result = sql_dal.get(default={})
        if not result and HomeScreenConfigurationsSectionRepository.__count == 0:
            HomeScreenConfigurationsSectionRepository.__count += 1
            result = self.get_all(location_id=0, user_group=0, company=company, locale=locale)

        home_scr_conf = {}
        rec_status = {}  # 0= > no record, 1= > both location and group, 2= > only group
        for item in result:
            # check if location and user group both present
            if item.get('location_id') == location_id and item.get('user_group') == user_group:
                home_scr_conf[item['section_name']] = item
                rec_status[item['section_name']] = 1
            elif item['location_id'] == '0' and item['user_group'] == user_group and user_group > 0:
                if not rec_status[item['section_name']] or not rec_status[item['section_name']] == 1:
                    home_scr_conf[item['section_name']] = item
                    rec_status[item['section_name']] = 2
            else:
                if not rec_status.get(item.get('section_name')):
                    home_scr_conf[item.get('section_name')] = item
        return home_scr_conf
