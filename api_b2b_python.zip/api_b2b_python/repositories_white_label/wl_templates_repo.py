"""
WL Templates Repository
"""
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class WLTemplatesRepository(BaseRepository):
    """
    Repo for white label template API which holds all the helper methods required.
    """
    ACTIVATION_OF_TRAIL = 1
    FORGOT_PASSWORD = 2
    REGISTER_INSTRUCTIONS = 3
    HOTEL_BOOKING = 4

    def get_template_by_company_and_type(self, wl_company, type_id, user_group=1):
        """
        Gets template by company and their type
        :param str wl_company: whitelabel company
        :param int type_id: type id
        :param int user_group: user group
        :rtype: str
        """
        sql_dal = SqlDal()
        sql_dal.select(['template_id'])
        sql_dal.from_(['wltemplates'])
        sql_dal.where({
            'wl_company': wl_company,
            'type_id': type_id,
            'user_group': user_group
        })
        template = sql_dal.get_one(default={})
        return template.get('template_id')
