"""
WL Gem lookup Repository
"""
from collections import OrderedDict

from common_white_label.db import CONSOLIDATION, get_db_settings_from_app
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class WlGemLookupRepository(BaseRepository):
    """
    White label GEM lookup repository
    """

    def update_gem_points(self, customer_id, email):
        """
        Updates the gem points
        :param int customer_id: id of customer
        :param str email: email of the user
        """
        if customer_id and email:
            consolidation_db = get_db_settings_from_app(connection_name=CONSOLIDATION)['database']
            sql_dal = SqlDal(connection=self.db_connection or CONSOLIDATION, single_connection=self.single_connection)
            changes = {
                'user_id': customer_id
            }
            sql_dal.where({'email': email})
            sql_dal.update(
                '{}.wl_gems_points_source'.format(consolidation_db),
                changes=changes
            )

    def find_on_by_email(self, email, gems=False, crg=False, nama=False,
                         dubai_ent=False, parent_id=0, is_active=False):
        """
        Finds on the base of email from different tables.
        :param str email: email of the user
        :param bool gems: company flag
        :param bool crg: company flag
        :param bool nama: company flag
        :param bool dubai_ent: company flag
        :param int parent_id: in case of dxb
        :param is_active: in case of dxb
        :rtype: dict
        """
        sql_dal = SqlDal(connection=CONSOLIDATION)
        sql_dal.select(['*'])
        if gems:
            sql_dal.from_('ent_gems_data')
        if crg:
            sql_dal.from_('ent_crg_lookup')
        if nama:
            sql_dal.from_('ent_nama_lookup')
        sql_dal.where({'email': email})

        if dubai_ent and is_active:
            sql_dal.from_('dxb_ent_lookup')
            sql_dal.where({'email': email, 'is_active': True, 'emp_code': parent_id})
        return sql_dal.get_one(default={})

    def update_user_data(self, customer_id, gems=False, crg=False, nama=False,
                         dubai_ent=False, parent_id=0, is_active=False):
        """
        Finds on the base of email from different tables.
        :param str email: email of the user
        :param bool gems: company flag
        :param bool crg: company flag
        :param bool nama: company flag
        :param bool dubai_ent: company flag
        :param int parent_id: in case of dxb
        :param is_active: in case of dxb
        :rtype: dict
        """
        sql_dal = SqlDal(connection=CONSOLIDATION)
        changes = {'user_id': customer_id}
        try:
            if gems:
                sql_dal.update('ent_gems_data', changes=changes)
            if crg:
                sql_dal.update('ent_crg_lookup', changes=changes)
            if nama:
                sql_dal.update('ent_nama_lookup', changes=changes)
            if dubai_ent:
                sql_dal.update('dxb_ent_lookup', changes=changes)
            return True

        except Exception:
            return False

    def find_gem(self, email):
        """
        Find gem data according to email
        :param email: customer's email
        :return:
        """
        sql_dal = SqlDal(connection=CONSOLIDATION)
        sql_dal.select(['*'])
        sql_dal.from_('ent_gems_data')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['parent_id'] = email
        ordered_where_clause['is_active'] = True
        sql_dal.limit(1)
        return sql_dal.get_one(default={})

    def find_gem_data_by_id(self, user_id):
        """
        Find gems data for user id
        :param int user_id: user id
        :rtype dict
        """
        sql_dal = SqlDal(connection=CONSOLIDATION)
        sql_dal.select(['*'])
        sql_dal.from_('ent_gems_data')
        sql_dal.where({
            'user_id': user_id,
            'is_active': True
        })
        return sql_dal.get_one(default={})
