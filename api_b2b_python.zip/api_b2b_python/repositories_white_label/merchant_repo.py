"""
Merchant Repository
"""
import datetime
from collections import OrderedDict

from flask import g
from flask_apscheduler import json

from _md5 import md5
from _operator import itemgetter
from common_white_label.common_helpers import get_formated_date, multi_key_sort, split_and_filter_null_entries
from repositories_white_label.base_repo import BaseRepository
from repositories_white_label.cuisine_repo import CuisineRepository
from repositories_white_label.offer_wl_active_repo import OfferWlRepository
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.wl_categories_repo import CategoriesRepositoryWl
from repositories_white_label.wl_company_repo import WLCompany
from repositories_white_label.wl_offer_manager_repo import WlOfferManagerRepository
from wrapper_white_labels.sql_dal import DEFAULT as ENTERTAINER_WEB
from wrapper_white_labels.sql_dal import SqlDal

cache = g.cache


class MerchantRepositoryWl(BaseRepository):

    Button_Type_Call = "call"
    Button_Type_Email = "email"
    Button_Type_Map = "map"
    Button_Type_Invite = "invite"
    Button_Type_Menu = "menu"
    Button_Type_Ping = "ping"

    SUB_CATEGORIES_TO_EXCLUDE_FOR_COMPANY = ["Cafes & Nightspots", "Nightspots", "Spas", "Upmarket Bars"]
    CUISINES_TO_EXCLUDE_FOR_COMPANY = ["Bar Food"]
    ATTRIBUTES_TO_EXCLUDE_FOR_COMPANY_ALBILAD = [
        'alcohol', 'pork_products', 'live_entertainment', 'smoking_indoor', 'smoking_outdoor',
        'smoking_shisha', 'pets_allowed', 'couples_friendly', 'couples_only', 'night_club', 'beach_club',
        'day_spa', 'inhouse_movies', 'mini_bar', 'smoking_rooms'
    ]
    ATTRIBUTES_TO_EXCLUDE_FOR_COMPANY_NAAMA = [
        'alcohol', 'pork_products', 'smoking_indoor', 'smoking_outdoor', 'smoking_shisha'
    ]
    attribute_value_no = 0
    attribute_value_yes = 1
    attribute_value_outlet_specific = 2
    attribute_type_merchant = 1
    attribute_value_type_ternary = 1
    attribute_value_type_value = 2
    COLOR_CODE_ALREADY_REDEEMED = 'de595b'
    merchant_attributes = [
        'age',
        'age_restrictions',
        'air_conditioning',
        'alcohol',
        'aviation',
        'balcony',
        'beach',
        'beach_club',
        'beauty_centre',
        'bed_breakfast',
        'boating',
        'boutique',
        'brunch',
        'buffet',
        'by_appointment_only',
        'car_park',
        'certified',
        'changing_facilities',
        'city',
        'closest_airport_name',
        'club_lounge',
        'concierge',
        'couples_friendly',
        'couples_only',
        'cuisine',
        'day_spa',
        'delivery',
        'desert_safari',
        'dress_code',
        'extreme_sports',
        'family',
        'female_only',
        'fine_dining',
        'fishing',
        'golf',
        'groups_welcome',
        'gym_fitness',
        'hair_salon',
        'halal',
        'health_programmes',
        'health_spa_resort',
        'heating',
        'height_restrictions',
        'holiday_programmes',
        'hotel_apartment',
        'in_room_spa_bath',
        'indoor_activities',
        'indoor_facilities',
        'indoor_play_area',
        'inhouse_movies',
        'kids_club',
        'kids_welcome',
        'kitchen_facilities',
        'laundry_service',
        'live_entertainment',
        'lodge_safari',
        'lodge_ski',
        'male_only',
        'mini_bar',
        'motor_sports',
        'mountain_country',
        'night_club',
        'no_of_bars',
        'no_of_cafes',
        'no_of_restaurants',
        'outdoor_activities',
        'outdoor_cooling',
        'outdoor_facilities',
        'outdoor_heating',
        'outdoor_play_area',
        'outdoor_seating',
        'parking',
        'pets_allowed',
        'pick_up_drop_off',
        'plunge_pool',
        'pork_products',
        'prayer_room',
        'proximity_to_airport_kms',
        'proximity_to_city_centre_kms',
        'racquet_sports',
        'refreshments',
        'resort',
        'rooftop_bars',
        'safe_deposit_box',
        'seaside',
        'shopping_mall',
        'smoking_indoor',
        'smoking_outdoor',
        'smoking_rooms',
        'smoking_shisha',
        'sound_system',
        'sports_club',
        'sports_screens',
        'supervised_play_area',
        'swimming_pool',
        'takeaway',
        'team_sports',
        'theme_park',
        'total_no_of_rooms',
        'tv_in_room',
        'valet_parking',
        'villas',
        'water_park',
        'water_sports',
        'wheelchair_accessible',
        'wi_fi',
        'wineries',
        'x24_hour_reception',
        'x24_hour_room_service',

        'children_baby_only', 'fashion_accessories', 'footwear', 'ladieswear', 'menswear', 'opticians', 'sportswear',
        'sportswear', 'pharmacy', 'with_a_view', 'price_range', 'open_late', 'hubbly_bubbly', 'beauty_products',
        'jacuzzi', 'kids_play_area', 'moroccan_bath', 'personal_trainer', 'refreshments', 'sauna', 'steam_room', 'pool'
    ]

    merchant_attributes_body = [
        'by_appointment_only',
        'certified',
        'female_only',
        'couples_friendly',
        'indoor_facilities',
        'jacuzzi',
        'kids_play_area',
        'male_only',
        'moroccan_bath',
        'outdoor_facilities',
        'personal_trainer',
        'refreshments',
        'pool',
        'sauna',
        'steam_room',
        'supervised_play_area',
        'parking',
        'valet_parking'
    ]

    merchant_attributes_kids = ['changing_facilities', 'age', 'supervised_play_area']
    merchant_attributes_leisure = [
        'age_restrictions',
        'aviation',
        'desert_safari',
        'fishing',
        'height_restrictions',
        'indoor_activities',
        'kids_welcome',
        'motor_sports',
        'outdoor_activities',
        'parking',
        'team_sports',
        'valet_parking',
        'alcohol',
        'boating',
        'extreme_sports',
        'golf',
        'holiday_programmes',
        'indoor_play_area',
        'live_entertainment',
        'outdoor_cooling',
        'outdoor_play_area',
        'racquet_sports',
        'rooftop_bars',
        'theme_park',
        'water_park',
        'water_sports',
        'wineries'
    ]
    merchant_attributes_restaurants_and_bars = [
        'alcohol',
        'brunch',
        'buffet',
        'cuisine',
        'delivery',
        'dress_code',
        'fine_dining',
        'groups_welcome',
        'halal',
        'hubbly_bubbly',
        'kids_welcome',
        'live_entertainment',
        'open_late',
        'outdoor_cooling',
        'outdoor_heating',
        'outdoor_seating',
        'parking',
        'pets_allowed',
        'pork_products',
        'price_range',
        'rooftop_bars',
        'smoking_indoor',
        'smoking_outdoor',
        'smoking_shisha',
        'sports_screens',
        'supervised_play_area',
        'takeaway',
        'valet_parking',
        'wheelchair_accessible',
        'wi_fi',
        'wineries',
        'with_a_view'
    ]
    merchant_attributes_services = [
        'beauty_products',
        'by_appointment_only',
        'delivery',
        'pharmacy',
        'pick_up_drop_off'
    ]
    merchant_attributes_travel = [
        'x24_hour_reception',
        'x24_hour_room_service',
        'air_conditioning',
        'alcohol',
        'balcony',
        'beach',
        'beach_club',
        'beauty_centre',
        'bed_breakfast',
        'boutique',
        'car_park',
        'city',
        'closest_airport_name',
        'club_lounge',
        'concierge',
        'couples_only',
        'day_spa',
        'family',
        'golf',
        'gym_fitness',
        'hair_salon',
        'health_programmes',
        'health_spa_resort',
        'heating',
        'hotel_apartment',
        'inhouse_movies',
        'in_room_spa_bath',
        'kids_club',
        'kitchen_facilities',
        'laundry_service',
        'lodge_safari',
        'lodge_ski',
        'mini_bar',
        'mountain_country',
        'night_club',
        'no_of_bars',
        'no_of_cafes',
        'no_of_restaurants',
        'plunge_pool',
        'prayer_room',
        'proximity_to_airport_kms',
        'proximity_to_city_centre_kms',
        'resort',
        'safe_deposit_box',
        'seaside',
        'shopping_mall',
        'smoking_rooms',
        'sound_system',
        'sports_club',
        'swimming_pool',
        'total_no_of_rooms',
        'tv_in_room',
        'valet_parking',
        'villas',
        'water_sports',
        'wheelchair_accessible',
        'wi_fi'
    ]
    merchant_attributes_retail = [
        'children_baby_only', 'fashion_accessories',
        'footwear', 'ladieswear',
        'menswear', 'opticians',
        'sportswear'
    ]

    def process_merchant(self, merchant, app_version='0', skip_app_version_check=False):
        """
        Process merchant after getting from db, sets image urls and encrypts merchant pin etc
        :param dict merchant: Merchant dict
        :param str app_version: App version
        :param bool skip_app_version_check: Flag to disable or enable version checking
        :return:
        """
        merchant['merchant_pin'] = md5(merchant.get('merchant_pin', '').encode()).hexdigest()
        hero_urls = []
        hero_small_urls = []
        hero_urls_old = []
        hero_small_urls_old = []
        if skip_app_version_check or app_version >= '5.8':
            if merchant['p3_hero_image_retina']:
                hero_urls.append(merchant['p3_hero_image_retina'])
            if merchant['photo_url']:
                hero_urls.append(merchant['photo_url'])
            if merchant['p3_hero_image_non_retina']:
                hero_small_urls.append(merchant['p3_hero_image_non_retina'])
            if merchant['photo_small_url']:
                hero_small_urls.append(merchant['photo_small_url'])
        if merchant.get('hero_urls'):
            hero_urls_old = json.loads(merchant['hero_urls'])
        if merchant.get('hero_small_urls'):
            hero_small_urls_old = json.loads(merchant['hero_small_urls'])

        merchant['hero_urls'] = hero_urls + hero_urls_old
        merchant['hero_small_urls'] = hero_small_urls + hero_small_urls_old

        images_360 = {}
        if merchant['is_opted_in_for_360_image'] and merchant['p3_360_degree_image']:
            count = 1
            for hero_url in merchant['hero_urls']:
                if count > 1:
                    break
                images_360[hero_url] = merchant['p3_360_degree_image']
                count += 1
            hero_images_360 = images_360
        else:
            hero_images_360 = {}
        merchant['hero_images_360'] = hero_images_360

    def find_by_id(self, *args, **kwargs):
        """
        Finds merchant by id.
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select([
            'm.id', 'm.pin as merchant_pin', 'm.email', 'm.website', 't.name', 't.description', 'm.category',
            'm.categories', 'm.categories as merchant_categories', 'm.categories as categories_analytics',
            'group_concat(distinct o.merchant_category) as offer_categories',
            'group_concat(distinct o.sub_category) as sub_categories',
            'COALESCE(t.cuisine) AS cuisine', 'm.cuisines', 'COALESCE(t.opening_hours, "") as opening_hours',
            'COALESCE(m.is_tutorial, 0) as is_tutorial',
            '(case When m.booking_link is null then "" else m.booking_link end) as booking_link',
            'Case When m.booking_request=0 then False else true end as booking_request',
            'm.logo_retina_url as logo_url', 'm.logo_non_retina_url as logo_small_url',
            'm.logo_offer_retina_url as logo_offer_url', 'm.logo_offer_non_retina_url as logo_offer_small_url',
            'm.photo_retina_url as photo_url', 'm.photo_non_retina_url as photo_small_url', 'm.pdf_url',
            'm.hero_retina_urls as hero_urls', 'm.hero_non_retina_urls as hero_small_urls',
            'm.is_opted_in_for_360_image', 'COALESCE(m.p3_360_degree_image, "") as p3_360_degree_image',
            'COALESCE(m.p3_hero_image_retina, "") as p3_hero_image_retina',
            'COALESCE(m.p3_hero_image_non_retina, "") as p3_hero_image_non_retina',
            'COALESCE(m.delivery_contact_no, "") as delivery_contact_no'
        ])
        sql_dal.from_(['merchant'], ['m'])
        sql_dal.inner_join('merchant_translation AS t', 't.merchant_id', 'm.id')
        sql_dal.inner_join('offer_wl_active AS o', 'o.merchant_id', 'm.id')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['m.id'] = kwargs.get('merchant_id')
        ordered_where_clause['t.locale'] = kwargs.get('locale', 'en')
        sql_dal.where(ordered_where_clause)
        merchant = sql_dal.get_one(default={})
        if merchant:
            self.process_merchant(merchant, skip_app_version_check=True)
            merchant['cuisines'] = split_and_filter_null_entries(merchant['cuisines'], ';')
            merchant['sub_categories'] = (merchant['sub_categories'] or '').split(',')
            merchant['offer_categories'] = split_and_filter_null_entries(merchant['offer_categories'], ',')
            merchant['categories'] = split_and_filter_null_entries(merchant['categories'], ';')
            merchant['merchant_categories'] = merchant['categories']
            merchant['booking_request'] = str(merchant.get('booking_request'))
            categories_repo_instance = CategoriesRepositoryWl()
            merchant['categories_analytics'] = categories_repo_instance.get_analytics_codes_against_categories(
                merchant['categories']
            )
            if merchant.get('offer_categories'):
                merchant['categories'] = merchant['offer_categories']
        return merchant

    def get_merchant_cuisine(self, merchant_id, locale='en'):
        """
        :param merchant_id:
        :param locale:
        :return:
        """
        if merchant_id:
            sql_dal = SqlDal()
            sql_dal.select(["t.cuisine AS t_cuisine", "m.cuisine AS m_cuisine", "t.dress_code", "t.fine_dining"])
            sql_dal.from_(["merchant"], ["m"])
            sql_dal.left_join('merchant_translation AS t', 't.merchant_id', 'm.id')
            sql_dal.where({"t.locale": locale, "m.id": merchant_id})
            merchant_cuisine = sql_dal.get_one(default='')
            if merchant_cuisine:
                merchant_cuisine = merchant_cuisine['t_cuisine'] or merchant_cuisine['m_cuisine']
            return merchant_cuisine
        return ''

    def format_merchant_attributes(self, merchant_id, merchant_attributes, merchant_category, locale='en', company=''):
        """
        Formats merchant attributes e.g cuisine and dress codes.
        :param int merchant_id: Merchant Id
        :param dict merchant_attributes: Merchant Attributes
        :param str merchant_category: Merchant category
        :param str locale: Locale
        :rtype: list
        """
        fine_dining_dress_code_translation = {
            'dress_code': {
                'formal_ar': 'لباس رسمي',
                'formal_el': 'Επίσημο',
                'formal_cn': '正式',
                'formal_en': 'Formal',
                'informal_ar': 'لباس غير رسمي ',
                'informal_el': 'Ανεπίσημο',
                'informal_cn': '非正式',
                'informal_en': 'Informal',
                'smart casual_ar': ' لباس أنيق وغير رسمي',
                'smart casual_el': 'Καθημερινό',
                'smart casual_cn': '商務休閒',
                'smart casual_en': 'Smart Casual'
            },
            'fine_dining': {
                'no_en': 'No',
                'no_ar': 'لا',
                'no_el': 'ΟΧΙ',
                'no_cn': '不是',
                'gold_en': 'Gold',
                'gold_ar': 'فئة ذهبية',
                'gold_el': 'Χρυσό',
                'gold_cn': '金',
                'silver_en': 'Silver',
                'silver_ar': 'فئة فضية',
                'silver_el': 'Ασήμι',
                'silver_cn': '銀'
            }
        }
        if company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
            merchant_attributes_by_section = self.get_merchant_attributes_by_category_v_6(merchant_category, locale)
        else:
            merchant_attributes_by_section = self.get_merchant_attributes_by_category(merchant_category, locale)

        for merchant_attribute_section in merchant_attributes_by_section:
            for merchant_attribute in merchant_attribute_section['attributes']:

                if (
                    merchant_attribute['key'] in self.merchant_attributes and
                    merchant_attribute['key'] in merchant_attributes
                ):
                    merchant_attribute['value'] = self.get_merchant_attribute_translation_for_value(
                        merchant_attributes[merchant_attribute['key']],
                        merchant_attribute['type'],
                        locale
                    )
                    if (
                        merchant_attributes.get(merchant_attribute['key']) and
                        merchant_attributes[merchant_attribute['key']] == self.attribute_value_outlet_specific or
                        merchant_attribute['type'] == self.attribute_value_type_value
                    ):
                        if locale == 'en':
                            case = merchant_attribute['key']
                            localed_merchant_value = ("{value}_{locale}".format(
                                value=merchant_attribute['value'],
                                locale=locale)
                            ).lower()
                            fine_dining_merchant_key = fine_dining_dress_code_translation.get(
                                merchant_attribute['key']
                            )
                            if case == 'cuisine':
                                merchant_attribute['name'] = "{name}: {cuisine}".format(
                                    name=merchant_attribute['name'],
                                    cuisine=self.get_merchant_cuisine(merchant_id, locale)
                                )
                            elif case == 'dress_code':
                                merchant_attribute['name'] = "{name}: {localed_merchant}".format(
                                    name=merchant_attribute['name'],
                                    localed_merchant=fine_dining_merchant_key.get(localed_merchant_value)
                                )
                            elif case == 'fine_dining':
                                merchant_attribute['name'] = "{name}: {value}".format(
                                    name=merchant_attribute['name'],
                                    value=fine_dining_merchant_key.get(localed_merchant_value)
                                )
                            else:
                                merchant_attribute['name'] = "{name}: {value}".format(
                                    name=merchant_attribute['name'],
                                    value=merchant_attribute['value']
                                )
                        else:
                            merchant_attribute['name'] = "{name}: {value}".format(
                                name=merchant_attribute['name'],
                                value=merchant_attribute['value']
                            )
            # remove unselected attributes
            merchant_attribute_section['attributes'] = list(filter(
                itemgetter('value'),
                merchant_attribute_section['attributes']
            ))
        return [section for section in merchant_attributes_by_section if section['attributes']]

    def get_merchant_attribute_translation_for_value(self, value, attribute_type, locale='en'):
        """
        Gets merchant attribute translation
        :param value: value
        :param attribute_type: attribute type
        :param locale: locale
        :return: attribute value
        """
        self.translation_manager = TranslationManager()
        if not value:
            return ""
        if attribute_type == self.attribute_value_type_ternary:
            if value == self.attribute_value_no:
                message = self.translation_manager.get_translation(
                    self.translation_manager.NO,
                    locale
                )
                return message
            elif value == self.attribute_value_yes:
                message = self.translation_manager.get_translation(
                    self.translation_manager.YES,
                    locale
                )
                return message
            elif value == self.attribute_value_outlet_specific:
                message = self.translation_manager.get_translation(
                    self.translation_manager.OUTLET_SPECIFIC,
                    locale
                )
                return message
        elif attribute_type == self.attribute_value_type_value:
            return value

    def find_name_by_id(self, merchant_id, locale='en'):
        """
        This method returns merchant dict with it's name in it
        :param merchant_id:
        :param locale:
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select(['t.name'])
        sql_dal.from_(['merchant'], ['m'])
        sql_dal.inner_join('merchant_translation as t', 't.merchant_id', 'm.id')
        sql_dal.where({'t.locale': locale, 'm.id': merchant_id})
        merchant = sql_dal.get_one(default={})
        return merchant

    def get_merchant_attributes_by_merchant_id(self, merchant_id, merchant_category, locale='en', company=''):
        """
        Gets merchant attributes against merchant id.
        :param int merchant_id: Merchant id
        :param str merchant_category: Merchant category
        :param str locale: Locale
        """
        sql_dal = SqlDal()
        from_table = ''
        if merchant_category == CategoriesRepositoryWl.category_API_Name_Body:
            from_table = 'merchant_attributes_body'
        elif merchant_category == CategoriesRepositoryWl.category_API_Name_Kids:
            from_table = 'merchant_attributes_kids'
        elif merchant_category == CategoriesRepositoryWl.category_API_Name_Leisure:
            from_table = 'merchant_attributes_leisure'
        elif merchant_category == CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars:
            from_table = 'merchant_attributes_restaurants_and_bars'
        elif merchant_category == CategoriesRepositoryWl.category_API_Name_Services:
            from_table = 'merchant_attributes_services'
        elif merchant_category == CategoriesRepositoryWl.category_API_Name_Retail:
            from_table = 'merchant_attributes_fashion_and_retail'
        elif merchant_category == CategoriesRepositoryWl.category_API_Name_Travel:
            from_table = 'merchant_attributes_travel'

        if from_table:
            sql_dal.from_([from_table], ['ma'])
            sql_dal.where('ma.merchant_id', merchant_id)
            merchant_attribute = sql_dal.get_one(default={})
            if merchant_attribute:
                return self.format_merchant_attributes(merchant_id, merchant_attribute, merchant_category, locale, company)
        return None

    def get_merchant_attributes_by_category_v_6(self, category, locale='en'):
        """
        Returns merchant attributes by category
        :param category:
        :param locale:
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select(["ag.id", "ag.category_id", "agt.name", "ag.order_id"])
        sql_dal.from_(["category"], ["c"])
        sql_dal.inner_join("attribute_group AS ag", "c.id", "ag.category_id")
        sql_dal.inner_join("attribute_group_translation AS agt", "ag.id", "agt.attribute_group_id")
        sql_dal.where({"c.name": category, "magt.locale": locale})
        merchant_attribute_groups = sql_dal.get(default=[])

        # Merchant attributes
        sql_dal.select([
            "a.category_id", "a.attribute_group_id", "a.attribute_key AS `key`",
            "at.attribute_title as name", "a.attribute_type AS type", "a.attribute_values", "a.image_url"
        ])
        sql_dal.from_(["category"], ["c"])
        sql_dal.inner_join("attribute AS a", "c.id", "a.category_id")
        sql_dal.inner_join("attribute_translation AS at", "a.id", "at.attribute_id")
        sql_dal.where({
            "a.type": self.attribute_type_merchant,
            "a.is_active": 1,
            "at.locale": locale,
            "c.name": category
        })
        sql_dal.order_by({"ma.order_id": "ASC"})
        merchant_attributes = sql_dal.get(default=[])
        merchant_attributes_by_group = []
        for filter_group in merchant_attribute_groups:
            group = {
                'section_name': filter_group['name'],
                'attributes': []
            }
            for merchant_attribute in merchant_attributes:
                if filter_group['id'] in merchant_attribute['attribute_group_id']:
                    data = {
                        'key': merchant_attribute['attribute_key'],
                        'name': merchant_attribute['attribute_name'],
                        'type': merchant_attribute['attribute_type'],
                        'image_url': merchant_attribute['image_url'],
                        'value': ''
                    }
                    group['attributes'].append(data)
            if len(group['attributes']) > 0:
                merchant_attributes_by_group.append(group)
        return merchant_attributes_by_group

    def get_merchant_attributes_by_category(self, category, locale='en'):
        """
        Returns merchant attributes by category
        :param category: category
        :param locale: response langugae
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select(["mag.id", "mag.category_id", "magt.name", "mag.order_id"])
        sql_dal.from_(["category"], ["c"])
        sql_dal.inner_join("merchant_attribute_group AS mag", "c.id", "mag.category_id")
        sql_dal.inner_join("merchant_attribute_group_translation AS magt", "mag.id", "magt.attribute_group_id")
        sql_dal.where({"c.name": category, "magt.locale": locale})
        merchant_attribute_groups = sql_dal.get(default=[])

        # Merchant attributes
        sql_dal.select([
            "ma.merchant_attribute_group_id", "ma.attribute_key AS `key`",
            "mat.attribute_title as name", "ma.attribute_type AS type", "ma.image_url", "'' as value"
        ])
        sql_dal.from_(["category"], ["c"])
        sql_dal.inner_join("merchant_attribute AS ma", "c.id", "ma.category_id")
        sql_dal.inner_join("merchant_attribute_translation AS mat", "ma.id", "mat.attribute_id")
        sql_dal.where({"ma.is_active": 1, "mat.locale": locale, "c.name": category})
        sql_dal.order_by({"ma.order_id": "ASC"})
        merchant_attributes = sql_dal.get(default=[])
        merchant_attributes_by_group = []
        hashed_merchant_attributes = {}
        for merchant_attribute in merchant_attributes:
            key = merchant_attribute["merchant_attribute_group_id"]
            del merchant_attribute["merchant_attribute_group_id"]
            if hashed_merchant_attributes.get(key):
                hashed_merchant_attributes[key].append(merchant_attribute)
            else:
                hashed_merchant_attributes.update({key: [merchant_attribute]})

        for filter_group in merchant_attribute_groups:
            attributes = hashed_merchant_attributes.get(filter_group['id'])
            if attributes:
                group = dict()
                group['section_name'] = filter_group['name']
                group['attributes'] = attributes
                merchant_attributes_by_group.append(group)
        return merchant_attributes_by_group

    def get_bundled_product(self, product_sku):
        sql_dal = SqlDal()
        sql_dal.select(['p.bundled_product_sku'])
        sql_dal.from_(['product'], ['p'])
        sql_dal.where({'p.sf_id': product_sku})
        bundled_result = sql_dal.get(default=[])
        return bundled_result

    def get_merchant_offers(self, active, locale, bundled_product_skus):
        sql_dal = SqlDal()
        sql_dal.select([
            'm.id', 't.name', 't.description', 'm.category', 'm.logo_retina_url  AS logo_url',
            'm.logo_non_retina_url AS logo_non_retina_url', 'm.logo_offer_retina_url AS logo_offer_retina_url',
            'm.logo_offer_non_retina_url AS logo_offer_non_retina_url', 'm.photo_retina_url AS photo_url',
            'm.photo_non_retina_url AS photo_non_retina_url', 't.cuisine', 'm.digital_section AS digital_section',
            'GROUP_CONCAT(o.id) AS outlet_ids', 'max(p.is_cheers) AS is_cheers', 'max(p.delivery_enabled) AS is_delivery',
            'max(p.is_more_sa) AS is_more_sa', 'max(p.ismember) is_member'
        ])
        sql_dal.from_(['offer_wl_active'], ['ofr'])
        sql_dal.inner_join('product_offer AS po', 'ofr.id', 'po.offer_id')
        sql_dal.inner_join('product AS p', 'po.product_id', 'p.id')
        sql_dal.inner_join('outlet_offer AS ot', 'ofr.id', 'ot.offer_id')
        sql_dal.inner_join('outlet AS o', 'o.id', 'ot.outlet_id')
        sql_dal.inner_join('merchant AS m', 'ofr.merchant_id', 'm.id')
        sql_dal.inner_join('merchant_translation AS t', 't.merchant_id', 'm.id')
        sql_dal.where({
            'o.active': 1,
            'locale': locale,

        })
        if bundled_product_skus:
            sql_dal.where_in('p.sf_id', bundled_product_skus)
        sql_dal.group_by(['m.id'])
        sql_dal.order_by({'t.name': 'ASC'})
        query_result = sql_dal.get(default=[])

        return query_result

    @staticmethod
    @cache.memoize(timeout=3600)
    def get_merchant_categories():
        sql_dal = SqlDal()
        sql_dal.select(['c.id as category_id', 'c.name as category_name'])
        sql_dal.from_(['category'], ['c'])
        merchant_categories = sql_dal.get(default=[])
        return merchant_categories

    @staticmethod
    @cache.memoize(timeout=3600)
    def get_merchant_sub_categories(locale='en', sub_categories_to_exclude_for_company=[]):
        sql_dal = SqlDal()
        sql_dal.select(['c.id as sub_catgory_id', 'c.category_id', 'ct.name', 'c.name as category_key'])
        sql_dal.from_(['merchant_sub_category'], ['c'])
        sql_dal.inner_join('merchant_sub_category_translation AS ct', 'c.id', 'ct.sub_category_id')
        sql_dal.where({'c.is_active': 1, 'ct.locale': locale})
        if sub_categories_to_exclude_for_company:
            sql_dal.where_not_in('c.name', sub_categories_to_exclude_for_company)
        sql_dal.order_by({'c.name': 'ASC'})
        merchant_sub_categories = sql_dal.get(default=[])
        return merchant_sub_categories

    @staticmethod
    @cache.memoize(timeout=3600)
    def get_merchant_attribute_groups(locale='en'):
        sql_dal = SqlDal()
        sql_dal.select(['g.id', 'g.category_id', 'gt.name', 'g.order_id'])
        sql_dal.from_(['merchant_attribute_group'], ['g'])
        sql_dal.inner_join('merchant_attribute_group_translation AS gt', 'g.id', 'gt.attribute_group_id')
        sql_dal.where({'gt.locale': locale})
        merchant_attribute_groups = sql_dal.get(default=[])
        return merchant_attribute_groups

    @staticmethod
    @cache.memoize(timeout=3600)
    def get_merchant_attributes(locale='en', attributes_to_exclude_for_company=[]):
        sql_dal = SqlDal()
        sql_dal.select([
            'ma.category_id', 'ma.merchant_attribute_group_id', 'ma.attribute_key',
            'mat.attribute_title as attribute_name', 'ma.attribute_type', 'ma.attribute_values', 'ma.image_url'
        ])
        sql_dal.from_(['merchant_attribute'], ['ma'])
        sql_dal.inner_join('merchant_attribute_translation AS mat', 'ma.id', 'mat.attribute_id')
        sql_dal.where({
            'ma.is_active': 1,
            'ma.attribute_type': 1,
            'mat.locale': locale
        })
        if attributes_to_exclude_for_company:
            sql_dal.where_not_in('ma.attribute_key', attributes_to_exclude_for_company)

        merchant_attributes = sql_dal.get(default=[])
        return merchant_attributes

    @staticmethod
    @cache.memoize(timeout=1800)
    def get_merchant_filters(locale='en', company=''):
        """
        Returns merchant filters
        :rtype: list
        """
        sub_categories_to_exclude_for_company = []
        attributes_to_exclude_for_company = []
        cuisines_to_exclude_for_company = []
        if company == WLCompany.COMPANY_CODE_ALBILAD:
            sub_categories_to_exclude_for_company = MerchantRepositoryWl.SUB_CATEGORIES_TO_EXCLUDE_FOR_COMPANY
            cuisines_to_exclude_for_company = MerchantRepositoryWl.CUISINES_TO_EXCLUDE_FOR_COMPANY
            attributes_to_exclude_for_company = MerchantRepositoryWl.ATTRIBUTES_TO_EXCLUDE_FOR_COMPANY_ALBILAD

        if company == WLCompany.COMPANY_CODE_ENTERTAINER_NAAMA:
            attributes_to_exclude_for_company = MerchantRepositoryWl.ATTRIBUTES_TO_EXCLUDE_FOR_COMPANY_NAAMA

        merchant_categories = MerchantRepositoryWl.get_merchant_categories()
        merchant_sub_categories = MerchantRepositoryWl.get_merchant_sub_categories(
            locale,
            sub_categories_to_exclude_for_company
        )
        merchant_attribute_groups = MerchantRepositoryWl.get_merchant_attribute_groups()
        merchant_attributes = MerchantRepositoryWl.get_merchant_attributes(locale, attributes_to_exclude_for_company)

        cuisines = CuisineRepository().get_cuisines_for_merchant_filters(locale=locale)
        translation_manager = TranslationManager()
        for category in merchant_categories:
            category['filter_sections'] = []
            type_title = 'Type'
            if category['category_name'] == CategoriesRepositoryWl.category_API_Name_Travel:
                type_title = 'Star Rating'
            if locale == 'ar':
                type_title = "النوع"
                if category['category_name'] == CategoriesRepositoryWl.category_API_Name_Travel:
                    type_title = translation_manager.get_translation(
                        translation_manager.TYPE_TITLE,
                        locale
                    )
            elif locale == 'el':
                type_title = "Είδος"
                if category['category_name'] == CategoriesRepositoryWl.category_API_Name_Travel:
                    type_title = translation_manager.get_translation(
                        translation_manager.TYPE_TITLE,
                        locale
                    )
            elif locale == 'cn':
                type_title = "類別"
                if category['category_name'] == CategoriesRepositoryWl.category_API_Name_Travel:
                    type_title = translation_manager.get_translation(
                        translation_manager.TYPE_TITLE,
                        locale
                    )

            _filter = {
                'section_order_id': len(category['filter_sections']) + 1,
                'category_id': category['category_id'],
                'section_name': type_title,
                'selection_type': 1,
                'has_icons': False,
                'collapsible': False,
                'options': []
            }
            _filter['options'].append({
                'uid': '0_{category}_All'.format(category=category['category_name']),
                'key': 'All',
                'name': translation_manager.get_translation(translation_manager.ALL, locale)
            })
            category_name = category.get('category_name', '')
            _category_id = category.get('category_id', 0)
            for sub_category in merchant_sub_categories:
                if _category_id == sub_category.get('category_id', 0):
                    _filter['options'].append({
                        'uid': '{category}_{sub_category}'.format(
                            category=category['category_name'],
                            sub_category=sub_category['category_key']
                        ),
                        'key': sub_category['category_key'],
                        'name': sub_category['name']
                    })
            category['filter_sections'].append(_filter)
            if all([category_name == CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars, cuisines]):
                top_cuisines = TranslationManager().get_translation(
                    TranslationManager.top_cuisines,
                    locale
                )
                _cuisine_title = translation_manager.get_translation(
                    translation_manager.CUISINE,
                    locale
                )
                _filter = {
                    'section_order_id': len(category.get('filter_sections', [])) + 1,
                    'category_id': _category_id,
                    'section_name': _cuisine_title,
                    'selection_type': 2,
                    'has_icons': False,
                    'collapsible': False,
                    'options': []
                }
                for _cuisine in top_cuisines:
                    _filter['options'].append({
                        'uid': '{category}_{options_len}_{cuisine}'.format(
                            category=category['category_name'],
                            options_len=len(_filter['options']),
                            cuisine=_cuisine
                        ),
                        'key': _cuisine,
                        'name': _cuisine
                    })
                for cuisine in cuisines:
                    if all([
                        cuisine['cuisine'] in top_cuisines,
                        cuisine['cuisine'] not in cuisines_to_exclude_for_company
                    ]):
                        _filter['options'].append({
                            'uid': '{category}_{options_len}_{cuisine}'.format(
                                category=category['category_name'],
                                options_len=len(_filter['options']),
                                cuisine=cuisine['cuisine']
                            ),
                            'key': cuisine['cuisine'],
                            'name': cuisine['cuisine']
                        })
                category['filter_sections'].append(_filter)

            # add merchant attribute filter
            for filter_group in merchant_attribute_groups:
                if filter_group.get('category_id') == _category_id:
                    _filter = {
                        'section_order_id': len(category.get('filter_sections', [])) + 1,
                        'category_id': _category_id,
                        'section_name': filter_group['name'],
                        'selection_type': 3,
                        'has_icons': False,
                        'collapsible': False,
                        'options': []
                    }
                    for merchant_attribute in merchant_attributes:
                        if all([
                            filter_group.get('category_id') == merchant_attribute.get('category_id'),
                            filter_group.get('id') == merchant_attribute.get('merchant_attribute_group_id')
                        ]):
                            _filter['options'].append({
                                'uid': '{category}_{attribute_key}'.format(
                                    category=category['category_name'],
                                    attribute_key=merchant_attribute['attribute_key']
                                ),
                                'key': merchant_attribute['attribute_key'],
                                'name': merchant_attribute['attribute_name'],
                                'image_url': merchant_attribute['image_url']
                            })
                    if _filter['options']:
                        category['filter_sections'].append(_filter)
        return merchant_categories

    def is_app_tutorial_by_merchant_id(self, merchant_id):
        """
        Checks if is_app_tutorial is supported by desired merchant
        :param int merchant_id: merchant id
        :rtype: bool
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select(["id"]).from_(['merchant_translation'])
        sql_dal.where({
            'merchant_id': merchant_id,
            'locale': 'en'
        }).like('name', 'App Tutor', enable_start_wild_card=False)
        return bool(sql_dal.get_one(default={}))

    def get_merchant_info(self, merchant_id):
        """
        Returns merchant info against merchant_id
        :param int merchant_id: Merchant Id
        :rtype: dict
        """
        if merchant_id:
            sql_dal = SqlDal(connection=ENTERTAINER_WEB)
            sql_dal.select(['sf_id', 'pin'])
            sql_dal.from_(['merchant'])
            sql_dal.where('id', merchant_id)
            return sql_dal.get_one(default={})
        return {}

    def initialize_offer_to_display_array(self, *args, **kwargs):
        """
        Initialize offer to display offers
        :param args:
        :param kwargs:
        :rtype: dict
        """
        offer_to_display = {}
        offer = kwargs.get('offer')
        categories = kwargs.get('categories')
        redeemability = kwargs.get('redeemability')
        locale = kwargs.get('locale')
        company = kwargs.get('company')
        replace_241_type_with_141 = kwargs.get('replace_241_type_with_141')
        category_repo = CategoriesRepositoryWl()
        category_color = WlOfferManagerRepository().get_category_color_code(offer['merchant_category'], categories)
        categories_list = []
        if offer['merchant_category']:
            categories_list.append(offer['merchant_category'])
        offer_to_display['categories_analytics'] = category_repo.get_analytics_codes_against_categories(
            categories_list
        )
        offer_to_display['offer_id'] = offer['id']
        offer_to_display['category'] = offer.get('merchant_category')
        offer_to_display['category_color'] = category_color
        offer_to_display['name'] = offer.get('name')
        offer_to_display['details'] = offer.get('details')
        offer_to_display['offer_detail'] = offer.get('details')
        offer_to_display['is_cheers'] = bool(offer.get('is_cheers'))  # Offer belongs to cheers
        offer_to_display['voucher_type'] = offer.get('voucher_type')
        offer_to_display['voucher_type_image'] = ""
        offer_to_display['voucher_restriction1'] = offer.get('voucher_restriction1')
        offer_to_display['voucher_restriction2'] = offer.get('voucher_restriction2')
        offer_to_display['voucher_restrictions'] = offer.get('voucher_restrictions')  # Offer Voucher Restriction
        offer_to_display['savings_estimate'] = round(offer.get('savings_estimate'))
        offer_to_display['savings_estimate_aed'] = offer.get('savings_estimate_aed')
        offer_to_display['savings_estimate_local_currency'] = offer.get('savings_estimate_local_currency')
        offer_to_display['redeemability'] = redeemability
        offer_to_display['is_topup_offer_allowed'] = False  # Offer Buy Back Allowed
        offer_to_display['is_pingable'] = False  # Is offer Pingable?
        offer_to_display['is_pinged'] = False  # Customer Already Pinged This offer to other customer ?
        offer_to_display['is_show_smiles'] = offer.get('show_smiles_earn_value')
        offer_to_display['smiles_earn_value'] = offer.get('smiles_earn_value')
        offer_to_display['smiles_burn_value'] = offer.get('smiles_burn_value')
        offer_to_display['dcp_license'] = offer.get('dcp_license')
        offer_to_display['valid_from_date'] = offer.get('valid_from_date').replace(
            tzinfo=datetime.timezone.utc
        ).isoformat()
        offer_to_display['expiration_date'] = offer.get('expiration_date').replace(
            tzinfo=datetime.timezone.utc
        ).isoformat()
        offer_to_display['validity_date'] = offer.get('expiration_date').replace(
            tzinfo=datetime.timezone.utc
        ).isoformat()
        offer_to_display['outlet_ids'] = offer.get('outlet_ids')
        offer_to_display['item_code'] = offer.get('item_code')
        offer_to_display['is_barcode_enabled'] = offer.get('is_barcode_enabled')
        offer_to_display['is_point_based_offer'] = True if offer.get('is_point_based_offer') else False
        offer_to_display['gems_points'] = offer.get('gems_points') if offer.get('gems_points') else 0
        offer_to_display['gems_points_reflect_message'] = self.translation_manager.get_translation(
            self.translation_manager.gems_points_reflect_message,
            locale
        )
        offer_to_display['is_merlin_offer'] = offer.get('is_merlin_offer')
        offer_to_display['outlet_merlin_urls'] = offer.get('outlet_merlin_urls')
        offer_to_display['merlin_title'] = offer.get('merlin_title')
        offer_to_display['message'] = WlOfferManagerRepository().get_message_for_offer_type(
            locale,
            offer.get('voucher_type'),
            offer.get('spend'),
            offer.get('reward'),
            offer.get('percentage_off')
        )
        offer_to_display['sub_detail_label'] = ""
        offer_to_display['additional_details'] = []
        offer_to_display['voucher_details'] = []
        offer_to_display['voucher_rules_of_use'] = []
        offer['voucher_type'] = 1 if not offer.get('voucher_type') else offer.get('voucher_type')
        if offer['voucher_type']:
            voucher_type_details = WlOfferManagerRepository().get_voucher_type_details(
                offer['voucher_type'],
                offer['merchant_category'],
                locale,
                replace_241_type_with_141,
                offer['is_monthly'],
                company
            )
            if voucher_type_details:
                voucher_type_details['title'] = offer_to_display['message']
                offer_to_display['voucher_details'].append(voucher_type_details)
                offer_to_display['voucher_type_image'] = voucher_type_details.get('image')

        if offer['voucher_restriction1']:
            voucher_restriction1_details = WlOfferManagerRepository().get_voucher_restriction_details(
                offer['voucher_restriction1'],
                offer['merchant_category'],
                locale
            )
            if voucher_restriction1_details:
                offer_to_display['voucher_details'].append(voucher_restriction1_details)
                voucher_restriction1_details['title'] = voucher_restriction1_details['title'].lower()
                offer_to_display['additional_details'].append(voucher_restriction1_details)

        if offer['voucher_type'] == OfferWlRepository.OFFER_TYPE_VALUE_Buy_One_Get_One_Free:
            party_size_image_url = WlOfferManagerRepository().get_image_url(
                OfferWlRepository.Image_Type_Party_Size,
                offer['merchant_category'],
                0, False, 0, False
            )
            offer_to_display['additional_details'].append(WlOfferManagerRepository().get_offer_sub_detail_object(
                0,
                party_size_image_url,
                self.translation_manager.get_translation(self.translation_manager.Two_People, locale),
                category_color
            ))

        if offer['voucher_restriction2']:
            voucher_restriction2_details = WlOfferManagerRepository().get_voucher_restriction_details(
                offer['voucher_restriction2'],
                offer['merchant_category'],
                locale
            )
            if voucher_restriction2_details:
                offer_to_display['voucher_details'].append(voucher_restriction2_details)

        if offer['smiles_earn_value']:
            offer_to_display['additional_details'].append(WlOfferManagerRepository().get_offer_sub_detail_object(
                offer["smiles_earn_value"],
                'https://s3.amazonaws.com/entertainer-app-assets/icons/smiles_icon.png',
                '+{smiles_earn_value} SMILES'.format(smiles_earn_value=offer["smiles_earn_value"]),
                'e2bb55'
            ))

        if offer["voucher_restrictions"].strip():
            offer_to_display['voucher_rules_of_use'].append(offer["voucher_restrictions"].upper())

        if offer['is_offer_expired']:
            offer_to_display['sort_order'] = OfferWlRepository.SORT_EXPIRED

        return offer_to_display

    def set_offer_label(self, offer_section, offer, offer_to_display, messages_locale, is_skip_mode=False):
        """
        Sets Label to offer to display object based on different criteria
        :param offer_section:
        :param offer:
        :param offer_to_display:
        :param messages_locale:message_locale
        :param is_skip_mode:
        """
        translation_repo = TranslationManager()
        if offer['is_offer_expired']:
            offer_to_display['sub_detail_label'] = translation_repo.get_translation(
                TranslationManager.expired_offer, messages_locale
            )
            return offer_to_display
        if offer_section == OfferWlRepository.SECTION_REDEEMABLE:
            if offer['is_offer_valid_in_future']:
                offer_to_display['sub_detail_label'] = translation_repo.get_translation(
                    TranslationManager.purchased_available_from,
                    messages_locale
                )
                offer_to_display['validity_date'] = get_formated_date(offer['valid_from_date'])
            else:
                offer_to_display['sub_detail_label'] = translation_repo.get_translation(
                    TranslationManager.valid_to,
                    messages_locale
                )
        elif offer_section == OfferWlRepository.SECTION_REDEEMED:
            offer_to_display['sub_detail_label'] = translation_repo.get_translation(
                TranslationManager.already_redeemed,
                messages_locale
            )
        elif offer_section == OfferWlRepository.SECTION_NOT_REDEEMABLE:
            if offer['is_show_purchase_button'] or is_skip_mode:
                offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                    TranslationManager.included_in_mobile_product_not_yet_purchased,
                    messages_locale
                )
        return offer_to_display

    def assign_sort_order_to_offers(self, offer_section, offer, offer_to_display):
        """
        Assigns sort order to offer to display object based on different criteria.
        :param offer_section:
        :param offer:
        :param offer_to_display:
        """
        if offer['is_offer_expired']:
            offer_to_display['sort_order'] = OfferWlRepository.SORT_EXPIRED
            return offer_to_display

        if offer_section == OfferWlRepository.SECTION_REDEEMABLE:
            if offer['is_offer_valid_in_future']:
                offer_to_display['sort_order'] = OfferWlRepository.SORT_PURCHASED_AVAILABLE_IN_FUTURE
            else:
                offer_to_display['sort_order'] = OfferWlRepository.SORT_REDEEMABLE
        elif offer_section == OfferWlRepository.SECTION_REDEEMED:
            offer_to_display['sort_order'] = OfferWlRepository.SORT_REDEEMED
        elif offer_section == OfferWlRepository.SECTION_NOT_REDEEMABLE:
            offer_to_display['sort_order'] = OfferWlRepository.SORT_NOT_REDEEMABLE
        return offer_to_display

    def initialize_offers_array(self, offer_array, offer, is_pinged_section):
        """
        Initializes offer array
        :param offer_array:
        :param offer:
        :param is_pinged_section:
        :rtype: dict
        """
        offer_array['product_id'] = offer['product_id']
        offer_array['purchase_product_id'] = offer['purchase_product_id']
        offer_array['section_name'] = offer.get('product_name')
        offer_array['product_sku'] = offer['product_sku']
        offer_array['is_delivery_section'] = bool(offer['is_delivery'])
        offer_array['is_monthly_section'] = offer['is_monthly']
        if not is_pinged_section:
            offer_array['is_show_purchase_button'] = offer['is_show_purchase_button']
        else:
            offer_array['is_show_purchase_button'] = False
        offer_array['offers_to_display'] = []
        return offer_array

    def formulate_offer_details_array(
            self, offers, offers_array, message_locale, is_skip_mode, company, categories={},
            replace_241_type_with_141=False
    ):
        """
        Formulated offer details
        """
        # replace_retail_to_services - its for supporting retail to be treated as services
        # for apps before v5.92 (Till Jan 31, 2017)
        for offer in offers:
            for offer_array in offers_array:
                if offer_array.get('product_id') == offer.get('product_id'):
                    if not offer_array.get('offers_to_display'):
                        offer_array = self.initialize_offers_array(offer_array, offer, True)
                        # offer_quantity_redeemable = offer.get('quantity_redeemable')
                        # Show the offers which are either redeemable or reusable
                    for index in range(int(offer.get('quantity_redeemable', 0))):
                        redeemability = offer.get('redeemability')
                        offer_to_display = self.initialize_offer_to_display_array(
                            offer=offer,
                            locale=message_locale,
                            offer_section_by_redeemability=OfferWlRepository.SECTION_REDEEMABLE,
                            redeemability=redeemability,
                            is_skip_mode=is_skip_mode,
                            replace_241_type_with_141=replace_241_type_with_141,
                            categories=categories,
                            company=company
                        )
                        offer_to_display['redeemability'] = offer.get('redeemability')
                        if offer_to_display['redeemability'] == OfferWlRepository.REUSABLE:
                            offer_to_display['redeemability'] = OfferWlRepository.REDEEMABLE
                        offer_to_display = self.set_offer_label(
                            OfferWlRepository.SECTION_REDEEMABLE,
                            offer,
                            offer_to_display,
                            message_locale
                        )
                        offer_to_display = self.assign_sort_order_to_offers(
                            OfferWlRepository.SECTION_REDEEMABLE, offer, offer_to_display
                        )
                        offer_array['offers_to_display'].append(offer_to_display)

                        # Show the offers which are already redeemed
                    for index in range(int(offer.get('quantity_redeemed', 0))):
                        redeemability = OfferWlRepository.REDEEMED
                        offer_to_display = self.initialize_offer_to_display_array(
                            offer=offer,
                            locale=message_locale,
                            offer_section_by_redeemability=OfferWlRepository.SECTION_REDEEMED,
                            redeemability=redeemability,
                            is_skip_mode=is_skip_mode,
                            replace_241_type_with_141=replace_241_type_with_141,
                            categories=categories,
                            company=company
                        )
                        offer_to_display['redeemability'] = OfferWlRepository.REDEEMED
                        offer_to_display = self.set_offer_label(
                            OfferWlRepository.SECTION_REDEEMED,
                            offer,
                            offer_to_display,
                            message_locale
                        )
                        offer_to_display = self.assign_sort_order_to_offers(
                            OfferWlRepository.SECTION_REDEEMED, offer, offer_to_display
                        )
                        offer_to_display['additional_details'] = []
                        offer_to_display['additional_details'].append(
                            OfferWlRepository().get_offer_sub_detail_object(
                                offer.get("smiles_earn_value", ""),
                                "",
                                offer_to_display.get('sub_detail_label', '').upper(),
                                self.COLOR_CODE_ALREADY_REDEEMED
                            )
                        )
                        if offer_array.get('offers_to_display'):
                            offer_array['offers_to_display'].append(offer_to_display)
                        else:
                            offer_array['offers_to_display'].append(offer_to_display)
                        # Show the offers which are not redeemable
                    for index in range(offer.get('quantity_not_redeemable')):
                        redeemability = OfferWlRepository.NOT_REDEEMABLE
                        offer_to_display = self.initialize_offer_to_display_array(
                            offer=offer,
                            locale=message_locale,
                            offer_section_by_redeemability=OfferWlRepository.SECTION_NOT_REDEEMABLE,
                            redeemability=redeemability,
                            is_skip_mode=is_skip_mode,
                            replace_241_type_with_141=replace_241_type_with_141,
                            categories=categories,
                            company=company
                        )
                        offer_to_display['redeemability'] = OfferWlRepository.NOT_REDEEMABLE
                        offer_to_display = self.set_offer_label(
                            OfferWlRepository.SECTION_NOT_REDEEMABLE,
                            offer,
                            offer_to_display,
                            message_locale
                        )

                        offer_to_display = self.assign_sort_order_to_offers(
                            OfferWlRepository.SECTION_NOT_REDEEMABLE, offer, offer_to_display
                        )
                        offer_to_display['additional_details'] = []
                        offer_to_display['additional_details'].append(
                            OfferWlRepository.get_offer_sub_detail_object(
                                offer.get("smiles_earn_value", ""),
                                "",
                                offer_to_display.get('sub_detail_label', '').upper(),
                                self.COLOR_CODE_ALREADY_REDEEMED
                            )
                        )
                        if offer_array.get('offers_to_display'):
                            offer_array['offers_to_display'].append(offer_to_display)
                        else:
                            offer_array['offers_to_display'] = [offer_to_display]

        _filtered_product_offers = []

    # remove sections where there is no offer available to redeem
        for product_section in offers_array:
            if product_section.get('offers_to_display'):
                product_section['offers_to_display'] = multi_key_sort(
                    product_section['offers_to_display'],
                    ['sort_order', 'offer_id']
                )
            _filtered_product_offers.append(product_section)

        offers_array = _filtered_product_offers

        return offers_array
