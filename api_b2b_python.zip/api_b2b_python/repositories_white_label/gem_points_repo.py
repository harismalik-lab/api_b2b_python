"""
Gem points Repository.
Contains the methods to get points information of user.
"""
from collections import OrderedDict

from flask import current_app

from python_api.repositories.base_repo import BaseRepository
from python_api.wrapper.sql_dal import SqlDal


class GemPointsRepository(BaseRepository):
    """
    Gem and points repository for users
    """

    def find_points(self, locale='en', user_id=0):
        """
        Finds points of a specific user from databsae.
        :param locale: str language selected
        :param user_id: str user id
        :rtype: objects Points of user
        """
        web_db = current_app.config['SQL_DB_CONFIG']['database']
        consolidation_db = current_app.config['SQL_CONSOLIDATION_DB_CONFIG']['database']
        sql_dal = SqlDal()
        sql_dal.select([
            'points.id', 'points.user_id', 'points.gems_persistent_id', 'points.email',
            'points.source_id', 'points.source_transaction_id', 'points.created_date', 'points.gems_points',
            'points.savings', 'sources.name as source', 'points.redemption_id', 'r.code as redemption_code',
            'r.offer_id', 'r.outlet_id', 'ott.name as outlet_name', 'm.logo_non_retina_url as merchant_logo_url'
        ])
        sql_dal.from_(['{co_db}.wl_gems_points_source'.format(co_db=consolidation_db)], ['points'])
        sql_dal.left_join('{co_db}.wl_gems_source as sources'.format(
            co_db=consolidation_db), 'sources.id', 'points.source_id'
        )
        sql_dal.left_join('{web_db}.redemption as r'.format(web_db=web_db), 'r.id', 'points.redemption_id')
        sql_dal.left_join('{web_db}.outlet_translation as ott'.format(web_db=web_db), 'ott.outlet_id', 'r.outlet_id')
        sql_dal.left_join('{web_db}.outlet as ot'.format(web_db=web_db), 'ot.id', 'r.outlet_id')
        sql_dal.left_join('{web_db}.merchant as m'.format(web_db=web_db), 'm.id', 'ot.merchant_id')
        where_dict_clause = OrderedDict()
        where_dict_clause['ott.locale'] = locale
        where_dict_clause['points.user_id'] = user_id
        where_dict_clause['points.status'] = True
        sql_dal.where(where_dict_clause)
        sql_dal.where_gt("points.gems_points", 0)
        sql_dal.group_by(['points.created_date'])
        result = sql_dal.get_one(default={})
        return result

    def get_user_points_stats(self, user_id):
        """
        Calculates the stats for user points
        :param int user_id: user id
        :rtype: str database objects containing points_available, points burned and points earned by user
        """
        consolidation_db = current_app.config['SQL_CONSOLIDATION_DB_CONFIG']['database']
        sql_dal = SqlDal()
        sql_dal.select([
            'SUM(COALESCE(points.gems_points, 0)) as points_earned',
            'SUM(COALESCE(points.gems_points_burned, 0)) as points_burned',
            '(SUM(COALESCE(points.gems_points, 0)) - SUM(COALESCE(points.gems_points_burned, 0))) as points_available'
        ])
        sql_dal.from_(['{co_db}.wl_gems_points_source'.format(co_db=consolidation_db)], ['points'])
        where_dict_clause = OrderedDict()
        where_dict_clause['points.status'] = True
        where_dict_clause['points.user_id'] = user_id
        sql_dal.where(where_dict_clause)
        sql_dal.group_by(['points.user_id'])
        result = sql_dal.get_one(default={})
        return result
