"""
File contains methods related to top merchant of product.
"""
from python_api.repositories.base_repo import BaseRepository
from python_api.wrapper.sql_dal import SqlDal
from repositories_white_label.translations_repo import TranslationManager


class ProductTopMerchantsRepositoryWhiteLabelV67(BaseRepository):
    """
    Contains methods related to Product top merchants table.
    """
    PAGE_SIZE = 10

    def get_top_merchants(self, product_id, locale):
        """
        Gets top ten merchant against product id and locale.
        :param product_id: id of the product
        :param locale: locale language
        :rtype: list
        """
        sql_dal = SqlDal()
        sql_dal.select(['m.id, t.name, tm.logo_url, tm.logo_small_url, tm.total_savings, tm.color_code'])
        sql_dal.from_(['product_top_merchants'], ['tm'])
        sql_dal.inner_join('merchant AS m', 'm.id', 'tm.merchant_id')
        sql_dal.inner_join('merchant_translation AS t', 't.merchant_id', 'm.id')
        sql_dal.where({'tm.product_id': product_id, 't.locale': locale})
        sql_dal.order_by({'tm.sequence': 'ASC'})
        sql_dal.limit(self.PAGE_SIZE)
        top_merchants = sql_dal.get(default=[])
        trans_manager_instance = TranslationManager()
        for top_merchant in top_merchants:
            top_merchant['total_savings'] = trans_manager_instance.get_translation(
                trans_manager_instance.top_merchant_total_saving,
                locale
            ).format(total_savings=top_merchant.get('total_savings', ''))
        return top_merchants
