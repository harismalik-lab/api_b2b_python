"""
WL Invoice Headers Repository
"""
import datetime
from collections import OrderedDict

from common_white_label.common_helpers import CommonHelpers
from common_white_label.db import DEFAULT as ENTERTAINER_WEB
from repositories_white_label.base_repo import BaseRepository
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.user_savings_repo import UserSavingsRepositoryWhiteLabel
from repositories_white_label.wl_company_repo import WLCompany
from repositories_white_label.wl_validtion_repo import WlValidationRepository
from wrapper_white_labels.sql_dal import SqlDal

__author__ = "Zaheer"


class WlInvoiceHeadersRepository(BaseRepository):
    """
    Repo for wl invoice headers API which holds all the helper methods required.
    """
    NOT_EXIST_STATUS = 0
    VALID_STATUS = 1
    ALREADY_USED_STATUS = 2
    INVALID_STATUS = 3
    Invoice_Status_Valid_For_Sign_In_Sign_Up_Only = 4
    Invoice_Status_Valid_Linking_Through_Profile_Only = 5
    Invoice_Status_Outdated_Invoice = 6
    Invoice_Status_Invalid_Transaction_Type = 7
    Invoice_Status_Wrong_Amount = 8
    Invoice_Valid_For_Past_X_Days = 30
    SUMMARY_BY_MONTH = "by_month"
    SUMMARY_BY_YEAR = "by_year"

    def get_card_validation_message(self, validation_status, locale='en'):
        """
        Gets card validation message
        :param validation_status: validation status
        :param locale: response language
        :rtype: str
        """
        self.translation_manager = TranslationManager()
        message = self.translation_manager.get_translation(
            self.translation_manager.card_validation_invalid_message,
            locale
        )
        if validation_status:
            if validation_status == WlInvoiceHeadersRepository.VALID_STATUS:
                message = self.translation_manager.get_translation(
                    self.translation_manager.card_validation_success_message,
                    locale
                )
            elif validation_status == WlInvoiceHeadersRepository.ALREADY_USED_STATUS:
                message = self.translation_manager.get_translation(
                    self.translation_manager.card_validation_already_linked_message,
                    locale
                )
        return message

    def get_invoice(self, company, invoice_number):
        """
        Gets invoice
        :param str company: company
        :param int invoice_number: invoice number
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select(['*'])
        sql_dal.from_(['wl_invoice_headers'])
        ordered_where_clause = OrderedDict()
        ordered_where_clause['invoice_number'] = invoice_number
        ordered_where_clause['company'] = company
        sql_dal.where(ordered_where_clause)
        invoice = sql_dal.get_one(default={})
        return invoice

    def find_all(self, user_id, company):
        """
        Returns all invoice header for current user
        :param int user_id: User id
        :param str company: Company of user
        :rtype: dict
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select(['*'])
        sql_dal.from_(['wl_invoice_headers'])
        sql_dal.where({'user_id': user_id, 'company': company})
        return sql_dal.get(default=[])

    def get_invoice_validation_message(self, validation_status, locale, is_user_upgraded=False):
        """
        Get invoice validation message
        :param validation_status: Validation status of invoice
        :param locale: Response language
        :param is_user_upgraded: Bool flag for user upgraded
        :return: validation status message
        """
        self.translation_manager = TranslationManager()
        if validation_status:
            if validation_status == WlInvoiceHeadersRepository.VALID_STATUS:
                if is_user_upgraded:
                    self.message = self.translation_manager.get_translation(
                        self.translation_manager.invoice_validation_success_message_upgraded,
                        locale
                    )
                else:
                    self.message = self.translation_manager.get_translation(
                        self.translation_manager.invoice_validation_success_message,
                        locale
                    )
            elif validation_status == WlInvoiceHeadersRepository.ALREADY_USED_STATUS:
                self.message = self.translation_manager.get_translation(
                    self.translation_manager.invoice_validation_already_linked_message,
                    locale
                )
            elif validation_status == WlInvoiceHeadersRepository.Invoice_Status_Valid_Linking_Through_Profile_Only:
                self.message = self.translation_manager.get_translation(
                    self.translation_manager.invoice_validation_invalid_message,
                    locale
                )
            elif validation_status == WlInvoiceHeadersRepository.Invoice_Status_Valid_For_Sign_In_Sign_Up_Only:
                self.message = self.translation_manager.get_translation(
                    self.translation_manager.invoice_validation_invalid_message,
                    locale
                )
            elif validation_status == WlInvoiceHeadersRepository.Invoice_Status_Outdated_Invoice:
                self.message = self.translation_manager.get_translation(
                    self.translation_manager.invoice_validation_outdated_invoice,
                    locale
                )
            elif validation_status == WlInvoiceHeadersRepository.Invoice_Status_Invalid_Transaction_Type:
                self.message = self.translation_manager.get_translation(
                    self.translation_manager.invoice_validation_invalid_code_message,
                    locale
                )
            elif validation_status == WlInvoiceHeadersRepository.Invoice_Status_Wrong_Amount:
                self.message = self.translation_manager.get_translation(
                    self.translation_manager.invoice_validation_invalid_message_wrong_amount,
                    locale
                )
            else:
                self.message = self.translation_manager.get_translation(
                    self.translation_manager.invoice_validation_invalid_message,
                    locale
                )
        return self.message

    def get_user_invoice(self, user_id):
        """
        Gets invoice
        :param int user_id: integer
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select(['*'])
        sql_dal.from_(['wl_invoice_headers'])
        ordered_where_clause = OrderedDict()
        ordered_where_clause['user_id'] = user_id
        sql_dal.where(ordered_where_clause)
        invoice = sql_dal.get_one(default={})
        return invoice

    def validate_invoice_number(self, invoice_number, company, is_for_sign_up_or_sign_in, user_id=0, invoice_amount=-1):
        """
        Validates invoice number
        :param int invoice_number: invoice number
        :param str company: company
        :param bool is_for_sign_up_or_sign_in: check is user sign in or sign up
        :param int user_id: id of user
        :param int invoice_amount: invoice amount
        :rtype:
        """
        wl_invoice_headers_repo = WlInvoiceHeadersRepository()
        if is_for_sign_up_or_sign_in:
            validation_status = wl_invoice_headers_repo.Invoice_Status_Invalid_Transaction_Type
        else:
            validation_status = wl_invoice_headers_repo.INVALID_STATUS
        invoice = self.get_invoice(company, invoice_number)
        if invoice:
            if invoice['user_id'] == 0:
                transaction_type_length = len(invoice['transaction_type'].replace('-', ''))
                is_valid_transaction_type = False
                if is_for_sign_up_or_sign_in:
                    if transaction_type_length == 1:
                        is_valid_transaction_type = True
                else:
                    if transaction_type_length > 1:
                        is_valid_transaction_type = True
                if is_valid_transaction_type:
                    if isinstance(invoice['invoice_date'], datetime.datetime):
                        invoice_cutoff_date = datetime.datetime.now()
                        invoice_cutoff_date = invoice_cutoff_date - datetime.timedelta(
                            days=wl_invoice_headers_repo.Invoice_Valid_For_Past_X_Days + 1
                        )
                        if invoice['invoice_date'] > invoice_cutoff_date:
                            if invoice_amount > 0:
                                if self.__is_equal_invoice_amount(invoice['transaction_total_price'], invoice_amount):
                                    validation_status = wl_invoice_headers_repo.VALID_STATUS
                                else:
                                    validation_status = wl_invoice_headers_repo.Invoice_Status_Wrong_Amount
                            else:
                                validation_status = wl_invoice_headers_repo.VALID_STATUS
                        else:
                            validation_status = wl_invoice_headers_repo.Invoice_Status_Outdated_Invoice
                else:
                    validation_status = wl_invoice_headers_repo.Invoice_Status_Invalid_Transaction_Type
            else:
                validation_status = wl_invoice_headers_repo.ALREADY_USED_STATUS
        return validation_status

    def __is_equal_invoice_amount(self, invoice_amount, amount_to_validate, is_ignore_decimal=True):
        """
        Check is equal invoice amount
        :param int invoice_amount: invoice amount
        :param int amount_to_validate: amount to validate
        :param bool is_ignore_decimal: check ignore the decimal or not?
        :rtype: int
        """
        if not is_ignore_decimal:
            return invoice_amount == amount_to_validate
        invoice_amount = int(invoice_amount)
        amount_to_validate = int(amount_to_validate)
        diff = invoice_amount - amount_to_validate
        return (invoice_amount == amount_to_validate) or (0 < diff >= 1)

    def assign_user_group_and_vip_key(self, user_id, email, company, user_group):
        """
        Assign user group and vip key
        :param user_id: Id of the user
        :param email: email
        :param company: company
        :param user_group: user group
        """
        number_of_valid_keys = WlValidationRepository().get_number_of_valid_keys(company, email)
        is_user_upgraded = False
        if number_of_valid_keys < 1:
            prefix = WLCompany().get_key_prefix_by_company(company)
            wl_key = CommonHelpers().generate_unique_id(prefix, 7)
            sql_dal = SqlDal(connection=ENTERTAINER_WEB)
            columns = [
                'wl_key', 'wl_company', 'email', 'isused', 'activation_date', 'active',
                'user_group', 'existing', 'customer_id'
            ]
            data = [wl_key, company, email, True, datetime.datetime.now(), True, user_group, True, user_id]
            wl_validation = sql_dal.insert('wlvalidation', columns=columns, values=data, last_row_id=True)
        else:
            sql_dal = SqlDal(connection=ENTERTAINER_WEB)
            sql_dal.select(['*'])
            sql_dal.from_(['wlvalidation'])
            sql_dal.where({'wl_company': company, 'email': email, 'active': True})
            wl_validation = sql_dal.get_one(default={})
            if user_group > wl_validation.get('user_group'):
                is_user_upgraded = True
            wl_validation['user_group'] = user_group
        return is_user_upgraded

    def add_invoice_to_user(self, invoice_number, company, user_id, email):
        """
        Add invoice to user
        :param int invoice_number: invoice number
        :param str company: company
        :param int user_id: id of user
        :param str email: email
        :rtype: bool
        """
        invoice_lookup = self.get_invoice(company, invoice_number)
        is_user_upgraded = False
        if invoice_lookup:
            sql_dal = SqlDal(connection=ENTERTAINER_WEB)
            invoice_lookup['user_id'] = user_id
            sql_dal.where({'company': company, 'CONCAT(transaction_type, invoice_number)': invoice_number})
            sql_dal.update('wl_invoice_headers', invoice_lookup)
            # add invoice savings to users_savings table
            user_savings_repo = UserSavingsRepositoryWhiteLabel()
            user_savings = user_savings_repo.get_user_savings(user_id, company)
            if user_savings:
                try:
                    savings = int((invoice_lookup['transaction_total_price'] or 0))
                except Exception:
                    raise TypeError('savings invalid type')
                # commented as now web team setup a cron which is syncing savings from points source after 30 days
                if user_savings.get('total_points'):
                    user_savings['total_points'] += savings
                else:
                    user_savings['total_points'] = savings
                if user_savings.get('create', False):
                    del user_savings['create']
                    columns = list(user_savings.keys())
                    data = list(user_savings.values())
                    sql_dal.insert(
                        table_name='user_savings',
                        columns=columns,
                        values=data,
                        last_row_id=True
                    )
                else:
                    sql_dal.where('user_id', user_id)
                    sql_dal.update('user_savings', user_savings)
                user_savings['total_points'] = (user_savings.get('total_points')
                                                if user_savings.get('total_points')
                                                else 0
                                                ) + savings
                sql_dal.where('user_id', user_id)
                sql_dal.update('user_savings', user_savings)
            emax_user_group = self.get_heighest_emax_user_group(user_id, company)
            user_group = self.get_user_group_based_on_spend(emax_user_group, user_savings['total_points'])
            is_user_upgraded = self.assign_user_group_and_vip_key(user_id, email, company, user_group)
        return is_user_upgraded

    def get_user_group_based_on_spend(self, emax_user_group, user_spend):
        """
        Gets user group based on spend
        :param int emax_user_group: emax user group
        :param int user_spend: user spend
        :rtype: int
        """
        calculated_user_group = 1
        if user_spend <= 3900:
            calculated_user_group = 1
        elif 4000 <= user_spend <= 9999:
            calculated_user_group = 2
        elif user_spend >= 10000:
            calculated_user_group = 3
        return max(calculated_user_group, int(emax_user_group))
    #  TODO: assignUserGroupAndVipKey Function Need to be converted here...

    def get_heighest_emax_user_group(self, user_id, company):
        """
        Gets highest emax user group
        :param int user_id: id of user
        :param str company: company
        :rtype: int
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select(['user_group'])
        sql_dal.from_(['wl_invoice_headers'])
        ordered_where_clause = OrderedDict()
        ordered_where_clause['user_id'] = user_id
        ordered_where_clause['company'] = company
        sql_dal.where(ordered_where_clause)
        sql_dal.order_by({'user_group': 'DESC'})
        result = sql_dal.get_one(default={})
        if result:
            return result.get('user_group')
        return 1

    def find_items_for_history(self, user_id, company):
        """
        Finds item for history
        :param int user_id: id of user
        :param str company: company
        :rtype: list
        """
        sql_dal = SqlDal()
        sql_dal.select([
            'h.id', 'h.user_id', 'h.transaction_type', 'h.invoice_number', 'h.quantity', 'h.location_name',
            'h.invoice_date', 'h.transaction_total_price', 'h.location_name', 'd.*'
        ])
        sql_dal.from_(['wl_invoice_headers as h'])
        sql_dal.inner_join('wl_invoice_details as d', 'h.id', 'd.wl_invoice_headers_id')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['h.user_id'] = user_id
        ordered_where_clause['h.company'] = company
        sql_dal.where(ordered_where_clause)
        sql_dal.limit(2)
        result = sql_dal.get(default=[])
        return result

    def find_by_invoice_lookup(self, company, card_number, user_id=0):
        """
        Find by invoice lookup
        :param company: white label client
        :param card_number: card number
        :param user_id: user id
        :rtype: dict
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select(['*'])
        sql_dal.from_(['wl_invoice_headers'])
        sql_dal.where({'user_id': user_id, 'company': company})
        return sql_dal.get(default=[])

    def get_highest_emax_user_group(self, user_id, company):
        """
        Gets highest emax user_group
        :param user_id: user id
        :param company: white label client
        """
        sql_dal = SqlDal()
        sql_dal.select(['*'])
        sql_dal.from_(['wl_invoice_headers'])
        sql_dal.where({'user_id': user_id, 'company': company})
        result = sql_dal.get_one(default={})
        return result.get('user_group', 1)
