"""
App Key validation Configuration Repository.
Contains the methods related to key validation process.
"""
from collections import OrderedDict

from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class AppKeyValidationConfigurationRepository(BaseRepository):
    PLATFORM = {
        "IOS": {"HS": {"2.1": 2}},
        "ANDROID": {"HS": {"2.1": 1}}
    }

    def get_app_key_validation_configuration(self, company, platform, app_version, locale):
        """
        Search database according to application's platform version, company and locale to get application key
        configuration
        :param str company: company which user's application is attached.
        :param str platform: platform of device.
        :param str app_version: application version.
        :param str locale: language of application.
        :rtype: str Database object containing tutorial information
        """
        version = self.get_app_key_validation_configuration_version(company, platform, app_version)
        sql_dal = SqlDal()
        sql_dal.select([
            'c.id', 'c.company', 'c.version', 'c.key_length', 'c.number_of_boxes', 'c.key_input_pattern',
            'c.key_separator', 'c.is_imei_based', 'ct.platform', 'ct.welcome_message', 'ct.key_activation_guideline',
            'ct.key_input_message', 'ct.key_failure_message'
        ])
        sql_dal.from_(['app_key_validation_configuration'], ['c'])
        sql_dal.inner_join('app_key_validation_configuration_translation as ct', 'c.id', ' ct.config_id')
        where_dict_clause = OrderedDict()
        where_dict_clause['c.is_active'] = 1
        where_dict_clause['c.version'] = version
        where_dict_clause['c.company'] = company
        where_dict_clause['ct.platform'] = platform
        where_dict_clause['ct.locale'] = locale
        where_dict_clause['c.is_active'] = 1
        sql_dal.where(where_dict_clause)
        sql_dal.order_by({"c.id": "ASC"})
        result = sql_dal.get_one(default={})
        if result:
            result['is_imei_based'] = bool(result['is_imei_based'])
        return result

    def get_app_key_validation_configuration_version(self, company, platform, app_version):
        """
        Compares and gets specific tutorial version for an app
        :param str company: company which user's application is attached.
        :param str platform: platform of device.
        :param str app_version: application version.
        :rtype: str Application tutorial version
        """
        app_tutorial_version = 1
        company = company.upper()
        try:
            mappings = self.PLATFORM.get(platform.upper(), {})
            if mappings.get(company) and mappings[company].get(app_version):
                    app_tutorial_version = mappings[company][app_version]
        except Exception:
            pass
        return app_tutorial_version
