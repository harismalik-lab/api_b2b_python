"""
Validate Mobile OS Repository
"""
from common_white_label.base_resource import BaseResource
from wrapper_white_labels.sql_dal import SqlDal


class ValidateMobileOsRepository(BaseResource):
    """
    Validated Mobile OS
    """
    def validate_model(self, model, company='entertainer'):
        """
        Validate the model of the mobile
        :param str model: model of the mobile
        :param str company: company of the user
        :rtype: bool
        """
        sql_dal = SqlDal()
        sql_dal.select(['device_model'])
        sql_dal.from_('validate_mobile_os')
        sql_dal.where({
            'device_model': model,
            'wl_company': company,
            'active': 1
        })
        _os = sql_dal.get_count(default=0)

        if _os:
            return True
        return False
