"""
Product WL Active repository
"""
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class ProductWLActiveRepository(BaseRepository):
    """
    Product wl active repository
    """

    def get_purchasable_products(self, company, location_id):
        """
        Gets purchasable products against given company
        :param company: White label client
        :param location_id: location id
        :rtype: list
        """
        purchasable_products_all = []
        purchasable_products_this_location = []

        sql_dal = SqlDal()
        sql_dal.select(['p.product_id', 'p.location_id'])
        sql_dal.from_(['product_wl_active'], ['p'])
        sql_dal.where({'p.company': company, 'p.is_active': True})
        sql_dal.order_by({'p.location_id': 'ASC'})
        results = sql_dal.get(default=[])

        for result in results:
            purchasable_products_all.append(result.get('product_id'))

            if result['location_id'] == location_id:
                purchasable_products_this_location.append(result.get('product_id'))

        return {
            'purchasable_products_all': purchasable_products_all,
            'purchasable_products_this_location': purchasable_products_this_location
        }
