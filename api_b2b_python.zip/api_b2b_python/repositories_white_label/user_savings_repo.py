"""
User Savings Repository
"""
from collections import OrderedDict

from common_white_label.db import DEFAULT as ENTERTAINER_WEB
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class UserSavingsRepositoryWhiteLabel(BaseRepository):

    def get_user_savings(self, user_id, company='entertainer'):
        """
        Gets user savings
        :param int user_id: id of user
        :param str company: company
        :rtype: dict
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select(['*'])
        sql_dal.from_(['user_savings'])
        ordered_where_clause = OrderedDict()
        ordered_where_clause['user_id'] = user_id
        ordered_where_clause['company'] = company
        sql_dal.where(ordered_where_clause)
        result = sql_dal.get_one(default={})
        if result:
            return result
        else:
            # if user savings doesn't exist
            user_saving = {
                'company': company,
                'user_id': user_id,
                'user_rank': 1,
                'total_points': 0,
                'create': True
            }
            return user_saving

    def get_yearly_saving(self, user_id, start_date, end_date, company='entertainer'):
        """
        Gets User yearly savings
        :param int user_id: user id
        :param str start_date: start date
        :param str end_date: end date
        :param str company: company
        :rtype dict
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select(['SUM(savings_estimate * quantity) as savings'])
        sql_dal.from_('redemption')
        sql_dal.where({'customer_id': user_id, 'company': company})
        sql_dal.where_between("date_created", str(start_date), str(end_date))
        yearly_savings = sql_dal.get_one(default={})
        if not yearly_savings.get('savings'):
            yearly_savings['savings'] = 0
        return yearly_savings

    def add_redemption_savings(self, user_id, savings, company='entertainer', points=0):
        """
        Adds redemption savings
        :param int user_id: id of user
        :param int savings: savings
        :param str company: company
        :param int points: points
        :rtype: dict
        """
        user_savings = self.get_user_savings(user_id, company)
        if user_savings.get('id'):
            sql_dal = SqlDal(connection=ENTERTAINER_WEB)
            sql = 'UPDATE user_savings ' \
                  'SET total_savings = COALESCE(total_savings, 0) + {savings},' \
                  'current_year_savings = COALESCE(current_year_savings, 0) + {savings},' \
                  'current_year_redemptions = COALESCE(current_year_redemptions,0) + 1,' \
                  'total_redemptions = COALESCE(total_redemptions, 0) + 1,' \
                  'total_points = COALESCE(total_points, 0) + {points},' \
                  'current_year_points = COALESCE(current_year_points, 0) + {points},' \
                  'is_user_rank_processed=0 ' \
                  'WHERE user_id={user_id} AND company = "{company}" AND id={id}'
            savings = int(savings)

            sql = sql.format(
                savings=savings,
                points=points,
                company=company,
                user_id=user_id,
                id=user_savings.get('id')
            )
            sql_dal.execute_query(sql, commit_changes=True)
        else:
            sql_dal = SqlDal(connection=ENTERTAINER_WEB)
            if user_savings.get('create'):
                del user_savings['create']
            user_savings['total_savings'] = savings
            user_savings['current_year_savings'] = savings
            user_savings['current_year_redemptions'] = 1
            user_savings['total_redemptions'] = 1
            user_savings['total_points'] = points
            user_savings['current_year_points'] = points
            user_savings['is_user_rank_processed'] = 0
            user_savings['id'] = sql_dal.insert(
                'user_savings',
                columns=list(user_savings.keys()),
                values=list(user_savings.values()),
                last_row_id=True
            )
        return user_savings
