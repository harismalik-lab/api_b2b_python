# -*- coding: utf-8 -*-
"""
Currency repository which contains currency helper methods.
"""
from common_white_label.db import DEFAULT as ENTERTAINER_WEB
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class CurrencyRepositoryWL(BaseRepository):
    """
    Currency repository wl that contains methods related to currencies
    """

    def get_currencies_lookup_hercules(self, locale='en'):
        """
        All the currencies that match the search criteria and return them
        :param locale: the locale for which currencies are to be fetched
        :return: list of currencies fetched
        """
        currencies = []
        if locale in ['cn', 'el']:
            locale = 'en'

        if locale == 'ar':
            currencies.extend(
                (
                    {
                        "id": "AED",
                        "name": "درهم إماراتي ",
                        "translated_currency": "AED"
                    },
                    {
                        "id": "BHD",
                        "name": "دينار بحريني ",
                        "translated_currency": "BHD"
                    },
                    {
                        "id": "EGP",
                        "name": "جنيه مصري ",
                        "translated_currency": "EGP"
                    },
                    {
                        "id": "EUR",
                        "name": "يورو",
                        "translated_currency": "EUR"
                    },
                    {
                        "id": "GBP",
                        "name": "جنيه استرليني",
                        "translated_currency": "GBP"
                    },
                    {
                        "id": "HKD",
                        "name": "دولار هونغ كونغي ",
                        "translated_currency": "HKD"
                    },
                    {
                        "id": "IDR",
                        "name": "Indonesia Rupiah",
                        "translated_currency": "IDR"
                    },
                    {
                        "id": "JOD",
                        "name": "دينار أردني",
                        "translated_currency": "JOD"
                    },
                    {
                        "id": "KWD",
                        "name": "دينار كويتي ",
                        "translated_currency": "KWD"
                    },
                    {
                        "id": "LBP",
                        "name": "ليرة لبنانية",
                        "translated_currency": "LBP"
                    },
                    {
                        "id": "MYR",
                        "name": "رينغيت ماليزي ",
                        "translated_currency": "MYR"
                    },
                    {
                        "id": "OMR",
                        "name": "ريال عماني",
                        "translated_currency": "OMR"
                    },
                    {
                        "id": "QAR",
                        "name": "ريال قطري",
                        "translated_currency": "QAR"
                    },
                    {
                        "id": "SAR",
                        "name": "ريال سعودي",
                        "translated_currency": "SAR"
                    },
                    {
                        "id": "SGD",
                        "name": "دولار سنغافوري",
                        "translated_currency": "SGD"
                    },
                    {
                        "id": "USD",
                        "name": "دولار أميركي ",
                        "translated_currency": "USD"
                    },
                    {
                        "id": "ZAR",
                        "name": "راند جنوب أفريقي ",
                        "translated_currency": "ZAR"
                    }
                )
            )
        else:
            currencies.extend(
                (
                    {
                        "id": "AED",
                        "name": "UAE Dirham",
                        "translated_currency": "AED"
                    },
                    {
                        "id": "BHD",
                        "name": "Bahraini Dinar",
                        "translated_currency": "BHD"
                    },
                    {
                        "id": "EGP",
                        "name": "Egyptian Pound",
                        "translated_currency": "EGP"
                    },
                    {
                        "id": "EUR",
                        "name": "Euro",
                        "translated_currency": "EUR"
                    },
                    {
                        "id": "GBP",
                        "name": "British Pound",
                        "translated_currency": "GBP"
                    },
                    {
                        "id": "HKD",
                        "name": "Hong Kong Dollar",
                        "translated_currency": "HKD"
                    },
                    {
                        "id": "IDR",
                        "name": "Indonesia Rupiah",
                        "translated_currency": "IDR"
                    },
                    {
                        "id": "JOD",
                        "name": "Jordanian Dinar",
                        "translated_currency": "JOD"
                    },
                    {
                        "id": "KWD",
                        "name": "Kuwaiti Dinar",
                        "translated_currency": "KWD"
                    },
                    {
                        "id": "LBP",
                        "name": "Lebanese Pound",
                        "translated_currency": "LBP"
                    },
                    {
                        "id": "MYR",
                        "name": "Malaysian Ringgit",
                        "translated_currency": "MYR"
                    },
                    {
                        "id": "OMR",
                        "name": "Omani Rial",
                        "translated_currency": "OMR"
                    },
                    {
                        "id": "QAR",
                        "name": "Qatar Rial",
                        "translated_currency": "QAR"
                    },
                    {
                        "id": "SAR",
                        "name": "Saudi Arabian Riyal",
                        "translated_currency": "SAR"
                    },
                    {
                        "id": "SGD",
                        "name": "Singapore Dollarي",
                        "translated_currency": "SGD"
                    },
                    {
                        "id": "USD",
                        "name": "U.S Dollar",
                        "translated_currency": "USD"
                    },
                    {
                        "id": "ZAR",
                        "name": "South African Rand",
                        "translated_currency": "ZAR"
                    }
                )
            )
        return currencies

    def get_currencies_lookup(self, locale='en'):
        """
        All the currencies that match the search criteria and return them
        :param locale: the locale for which currencies are to be fetched
        :rtype: list
        """
        currencies = []
        if locale in ['cn', 'el']:
            locale = 'en'

        if locale == 'ar':
            currencies.extend(
                (
                    {
                        "id": "AED",
                        "name": "درهم إماراتي ",
                        "translated_currency": "AED"
                    },
                    {
                        "id": "BHD",
                        "name": "دينار بحريني ",
                        "translated_currency": "BHD"
                    },
                    {
                        "id": "EGP",
                        "name": "جنيه مصري ",
                        "translated_currency": "EGP"
                    },
                    {
                        "id": "EUR",
                        "name": "يورو",
                        "translated_currency": "EUR"
                    },
                    {
                        "id": "GBP",
                        "name": "جنيه استرليني",
                        "translated_currency": "GBP"
                    },
                    {
                        "id": "HKD",
                        "name": "دولار هونغ كونغي ",
                        "translated_currency": "HKD"
                    },
                    {
                        "id": "JOD",
                        "name": "دينار أردني",
                        "translated_currency": "JOD"
                    },
                    {
                        "id": "KWD",
                        "name": "دينار كويتي ",
                        "translated_currency": "KWD"
                    },
                    {
                        "id": "LBP",
                        "name": "ليرة لبنانية",
                        "translated_currency": "LBP"
                    },
                    {
                        "id": "MYR",
                        "name": "رينغيت ماليزي ",
                        "translated_currency": "MYR"
                    },
                    {
                        "id": "OMR",
                        "name": "ريال عماني",
                        "translated_currency": "OMR"
                    },
                    {
                        "id": "QAR",
                        "name": "ريال قطري",
                        "translated_currency": "QAR"
                    },
                    {
                        "id": "SAR",
                        "name": "ريال سعودي",
                        "translated_currency": "SAR"
                    },
                    {
                        "id": "SGD",
                        "name": "دولار سنغافوري",
                        "translated_currency": "SGD"
                    },
                    {
                        "id": "USD",
                        "name": "دولار أميركي ",
                        "translated_currency": "USD"
                    },
                    {
                        "id": "ZAR",
                        "name": "راند جنوب أفريقي ",
                        "translated_currency": "ZAR"
                    }
                )
            )
        else:
            currencies.extend(
                (
                    {
                        "id": "AED",
                        "name": "UAE Dirham",
                        "translated_currency": "AED"
                    },
                    {
                        "id": "BHD",
                        "name": "Bahraini Dinar",
                        "translated_currency": "BHD"
                    },
                    {
                        "id": "EGP",
                        "name": "Egyptian Pound",
                        "translated_currency": "EGP"
                    },
                    {
                        "id": "EUR",
                        "name": "Euro",
                        "translated_currency": "EUR"
                    },
                    {
                        "id": "GBP",
                        "name": "British Pound",
                        "translated_currency": "GBP"
                    },
                    {
                        "id": "HKD",
                        "name": "Hong Kong Dollar",
                        "translated_currency": "HKD"
                    },
                    {
                        "id": "JOD",
                        "name": "Jordanian Dinar",
                        "translated_currency": "JOD"
                    },
                    {
                        "id": "KWD",
                        "name": "Kuwaiti Dinar",
                        "translated_currency": "KWD"
                    },
                    {
                        "id": "LBP",
                        "name": "Lebanese Pound",
                        "translated_currency": "LBP"
                    },
                    {
                        "id": "MYR",
                        "name": "Malaysian Ringgit",
                        "translated_currency": "MYR"
                    },
                    {
                        "id": "OMR",
                        "name": "Omani Rial",
                        "translated_currency": "OMR"
                    },
                    {
                        "id": "QAR",
                        "name": "Qatar Rial",
                        "translated_currency": "QAR"
                    },
                    {
                        "id": "SAR",
                        "name": "Saudi Arabian Riyal",
                        "translated_currency": "SAR"
                    },
                    {
                        "id": "SGD",
                        "name": "Singapore Dollarي",
                        "translated_currency": "SGD"
                    },
                    {
                        "id": "USD",
                        "name": "U.S Dollar",
                        "translated_currency": "USD"
                    },
                    {
                        "id": "ZAR",
                        "name": "South African Rand",
                        "translated_currency": "ZAR"
                    }
                )
            )
        return currencies

    def get_currency_by_code(self, locale, code=None):
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select(['c.id as currency_id', 'c.currency as id', 't.name', 't.translated_currency'])
        sql_dal.from_('currency as c')
        sql_dal.inner_join('currency_translation as t', 'c.id', 't.currency_id')
        sql_dal.where({'t.locale': locale, 'c.currency': code})
        return sql_dal.get_one(default={})
