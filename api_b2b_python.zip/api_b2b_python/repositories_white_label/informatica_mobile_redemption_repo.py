"""
Informatica mobile redemption api
"""
from common_white_label.db import INFORMATICA
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class InformaticaMobileRedemptionRepository(BaseRepository):
    """
    Inserts data in mobile redemption table
    """
    def insert_mobile_redemption(self, data):
        """
        Insertion in mobile redemption table for the provided data
        :param dict data: user mobile information
        :rtype int
        """
        record_id = 0
        try:
            sql_dal = SqlDal(connection=INFORMATICA)
            record_id = sql_dal.insert(
                'mobile_redemption',
                columns=[
                    'id', 'session_token', 'customer_id', 'membership_code', 'quantity',
                    'code', 'date_created', 'offer_sf_id', 'outlet_sf_id', 'merchant_sf_id',
                    'root_code', 'processed', 'company'
                ],
                values=[
                    data['id'], data['session_token'], data['customer_id'],
                    data['membership_code'], data['quantity'], data['code'],
                    data['date_created'], data['offer_sf_id'], data['outlet_sf_id'],
                    data['merchant_sf_id'], data['root_code'], data['processed'],
                    data['company']
                ],
                last_row_id=True
            )
        except Exception:
            pass
        return record_id
