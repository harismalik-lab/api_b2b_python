"""
Offer White Label Active Repository
"""
import copy
from datetime import datetime, timedelta

from common_white_label.common_helpers import CommonHelpers, parse_voucher_restrictions
from common_white_label.constants import GlobalConstants
from common_white_label.db import DEFAULT as ENTERTAINER_WEB
from repositories_white_label.base_repo import BaseRepository
from repositories_white_label.redemption_repo import RedemptionRepositoryWhiteLabel
from repositories_white_label.wl_company_repo import WLCompany
from wrapper_white_labels.sql_dal import SqlDal


class OfferWlRepository(BaseRepository):
    """
    Offer white label repository
    """

    Hours_Adjustment_For_Offer_Expiry_From = 4
    Hours_Adjustment_For_Offer_Expiry_To = -18
    TYPE_DEFAULT = 0
    TYPE_TRIAL = 1
    TYPE_MEMBER = 2
    TYPE_BOTH = 3
    TYPE_NEW_OFFER = 4
    TYPE_FEATURED_OFFER = 5  # Both New and Monthly

    NOT_REDEEMABLE = 0
    REDEEMED = 1
    REDEEMABLE = 2
    REUSABLE = 3

    SECTION_REDEEMABLE = 1
    SECTION_REDEEMED = 2
    SECTION_PINGED = 3
    SECTION_NOT_REDEEMABLE = 4
    SORT_REDEEMABLE = 1
    SORT_PURCHASED_AVAILABLE_IN_FUTURE = 2
    SORT_REDEEMED = 3
    SORT_PINGED = 4
    SORT_NOT_REDEEMABLE = 5
    SORT_EXPIRED = 6
    OFFER_TYPE_VALUE_DEFAULT = 0
    OFFER_TYPE_VALUE_Buy_One_Get_One_Free = 1
    OFFER_TYPE_VALUE_PERCENTAGE_OFF = 2
    OFFER_TYPE_VALUE_GIFT = 3
    OFFER_TYPE_VALUE_PACKAGE = 4
    OFFER_TYPE_VALUE_FIX_PRICE_OFF = 5
    OFFER_TYPE_VALUE_SPEND_THIS_GET_THIS = 6

    OFFER_TYPE_TEXT_Buy_One_Get_One_Free = "Buy One Get One Free"
    OFFER_TYPE_TEXT_SPEND_THIS_GET_THIS = "Spend This Get That"
    OFFER_TYPE_TEXT_PERCENTAGE_OFF = "% Off"
    OFFER_TYPE_TEXT_GIFT = "Gift"
    OFFER_TYPE_TEXT_PACKAGE = "Package"
    OFFER_TYPE_TEXT_FIX_PRICE_OFF = "Fixed Price Off"

    Voucher_Type_Image_URL_Prefix = "https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_types/voucher_type_"
    Voucher_Restriction_Image_URL_Prefix = "https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_restrictions/voucher_restriction_"  # noqa: E501
    Party_Size_Image_URL_Prefix = "https://s3.amazonaws.com/entertainer-app-assets/icons/party_size/"
    Voucher_Type_Image_URL_Prefix_HS = "https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_types/hs/voucher_type_"  # noqa: E501
    Voucher_Type_Image_URL_Prefix_GEM = "https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_types/gem/voucher_type_"  # noqa: E501
    Voucher_Restriction_Image_URL_Prefix_GEMS = "https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_restrictions/gems/voucher_restriction_"   # noqa: E501
    Party_Size_Image_URL_Prefix_GEMS = "https://s3.amazonaws.com/entertainer-app-assets/icons/party_size/gems/"

    Redeemability_all = "all"
    Redeemability_not_redeemable = "not_redeemable"
    Redeemability_redeemed = "redeemed"
    Redeemability_redeemable = "redeemable"
    Redeemability_reusable = "reusable"
    Redeemability_redeemable_reusable = "redeemable_reusable"

    Maximum_Offer_Savings_Limit_For_Onboarding_User = 100
    Maximum_Offer_Savings_Limit_For_Onboarding_User_Durban = 1

    new_offers_additional_products = []
    valid_channels = 'Mobile'

    FEATURED_CATEGORY_BEAUTY_AND_FITNESS = "Beauty & Fitness"
    FEATURED_CATEGORY_FOOD_AND_DRINK = "Food & Drink"
    FEATURED_CATEGORY_ATTRACTIONS_AND_LEISURE = "Attractions & Leisure"
    FEATURED_CATEGORY_RETAIL_AND_SERVICES = "Retail & Services"
    FEATURED_CATEGORY_Travel = "Hotels Worldwide"
    FEATURED_CATEGORY_CHEERS = "Cheers"
    FEATURED_CATEGORY_MONTHLY = "Monthly"
    FEATURED_CATEGORY_NEW = "New"
    FEATURED_CATEGORY_Delivery = "Delivery"

    Category_Body = 'Body'
    Category_Kids = 'Kids'
    Category_Leisure = 'Leisure'
    Category_RestaurantsAndBars = 'Restaurants and Bars'
    Category_Services = 'Services'
    Category_Retail = 'Retail'
    Category_Travel = 'Travel'

    Image_Type_Voucher_Type = 1
    Image_Type_Voucher_Restriction = 2
    Image_Type_Party_Size = 3

    def find_by_id(self, offer_id, product_id):
        """
        Find offers on the basis offer id
        :param int offer_id: offer id
        :param int product_id: product id
        :rtype: dict
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select([
            'o.id', 'o.sf_id', 'o.type', 'o.merchant_id', 'o.savings_estimate_local_currency',
            'o.redemptions_limit_in_x_hours', 'o.hours_to_consider_for_redemption_cap', 'o.gems_points',
            'o.is_point_based_offer', 'o.valid_from', 'o.valid_to', 'o.type', 'o.quantity'
        ])
        sql_dal.from_(['offer_wl_active'], ['o'])
        sql_dal.inner_join('product_offer_wl_active AS po', 'o.id', 'po.offer_id')
        sql_dal.inner_join('product AS p', 'po.product_id', 'p.id')
        sql_dal.where({'o.id': offer_id, 'p.id': product_id})
        offer = sql_dal.get_one(default={})

        if offer:
            return offer

    def find_by_outlets(
            self, company, outlet_ids, is_cuckoo, purchasable_product_ids, category, offer_categories,
            offer_sub_categories, customer={}, locale='en', user_include_cheers=False,
            show_point_based_offers=False
    ):
        """
        Finds offer information by outlets
        :param str company: company
        :param list outlet_ids: outlet ids
        :param bool is_cuckoo: is cuckoo
        :param list purchasable_product_ids: purchasable product ids
        :param str category: category
        :param list offer_categories: offer categories
        :param list offer_sub_categories: offer sub categories
        :param dict customer: customer
        :param str locale: language
        :param bool user_include_cheers: user include cheers flag
        :param bool show_point_based_offers: show point based offers flag
        :rtype: list
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select([
            'distinct o.id', 'GROUP_CONCAT(distinct ot.id) outlet_ids', 'MAX(t.name) name',
            'MAX(t.description) details', 'o.merchant_category', 'o.sub_category', 'o.voucher_type',
            'o.spend', 'o.reward', 'o.percentage_off', 'COALESCE(t.merchant_rules_of_use, "") as conditions',
            'COALESCE(t.merchant_rules_of_use, "") as voucher_restrictions', 'o.type', 'o.quantity',
            'COALESCE(t.card_line, "") as card_line', 'o.voucher_restriction1', 'voucher_restriction2',
            'o.savings_estimate', 'COALESCE(o.local_currency, "") as local_currency',
            'o.savings_estimate_local_currency',
            'o.valid_from as valid_from_date', 'o.valid_to as expiration_date',
            'GROUP_CONCAT(distinct p.id) product_id', 'GROUP_CONCAT(distinct p.sf_id) product_sku',
            'GROUP_CONCAT(distinct pt.name) product_name', 'MAX(p.is_cheers)', 'MAX(p.delivery_enabled) as is_delivery',
            'COALESCE(o.item_code, "") as item_code', 'o.is_point_based_offer', 'o.gems_points',
            ' \'\' as dcp_license', 'p.purchase_product_id', 'p.show_buy_mobile', 'p.product_type',
            'GROUP_CONCAT(DISTINCT Concat(p.id, "_", p.sf_Id, "_", pt.name)) as product_id_sku_name'
        ])
        sql_dal.from_(['outlet'], ['ot'])
        sql_dal.inner_join('outlet_offer AS ot_ofr', 'ot.id', 'ot_ofr.outlet_id')
        sql_dal.inner_join('offer_wl_active AS o', 'o.id', 'ot_ofr.offer_id')
        sql_dal.inner_join('offer_translation_wl_active AS t', 'o.id', 't.offer_id')
        sql_dal.inner_join('product_offer_wl_active as po', 'o.id', 'po.offer_id')
        sql_dal.inner_join('product AS p', 'po.product_id', 'p.id')
        sql_dal.inner_join('product_translation_wl_active AS pt', 'p.id', 'pt.product_id')
        sql_dal.where_in('p.id',
                         customer.get('product_ids') if customer.get('product_ids') else [''])
        sql_dal.where_in('ot.id', outlet_ids)
        sql_dal.where({"p.isactive": True, "o.status": "Active", "t.locale": locale, "pt.locale": locale})

        if is_cuckoo:
            sql_dal.where({'p.delivery_enabled': 0, 'p.is_cheers': 0})

        if not user_include_cheers:
            sql_dal.where({'p.is_cheers': 0})

        global_constant = GlobalConstants()
        if category in global_constant.get_valid_categories():
            sql_dal.where({'o.merchant_category': category})

        if show_point_based_offers:
            sql_dal.order_by({'o.is_point_based_offer': 'DESC'})

        else:
            sql_dal.where({'o.is_point_based_offer': 0})
        sql_dal.group_by(["o.id"])

        offers = sql_dal.get(default=[])
        product_offers = []

        for offer in offers:
            offer['expiration_date'] = self.fix_expiration_date(offer['expiration_date'])
            if offer['item_code'] == "":
                offer['is_barcode_enabled'] = False
            else:
                offer['is_barcode_enabled'] = True

            if not offer.get('merchant_category') in offer_categories:
                offer_categories.append(offer.get('merchant_category'))

            if (
                offer.get('sub_category') and
                offer.get('sub_category') != '' and
                not offer.get('sub_category') in offer_sub_categories
            ):
                offer_sub_categories.append(offer.get('sub_category'))

            if offer.get('is_cheers'):
                offer['is_cheers'] = True
            else:
                offer['is_cheers'] = False

            if offer.get('is_delivery'):
                offer['is_delivery'] = True
            else:
                offer['is_delivery'] = False

            product_id_sku_name_array = offer['product_id_sku_name'].split(',')
            product_id_sku_name_count = len(product_id_sku_name_array)

            # Need to check
            for i in range(product_id_sku_name_count):
                product_offers.append(copy.deepcopy(offer))
                product_id_sku_name = product_id_sku_name_array[i].split('_')
                product_offers[len(product_offers) - 1]['product_id'] = product_id_sku_name[0]
                product_offers[len(product_offers) - 1]['product_sku'] = product_id_sku_name[1]
                product_offers[len(product_offers) - 1]['product_name'] = product_id_sku_name[2]
                product_offers[len(product_offers) - 1]['offer_product'] = '{}_{}'.format(offer['id'],
                                                                                          product_id_sku_name[0])
                purchased_through_connect = False

                product_offers[len(product_offers) - 1]['purchased_through_connect'] = purchased_through_connect

        offers = product_offers
        redemption_quantities = {}
        redemption_repo = RedemptionRepositoryWhiteLabel()

        if len(offers) >= 0:
            # Need to check this function
            current_datetime = datetime.now()
            offer_valid_from_start_date = datetime(year=current_datetime.year, month=1, day=31)
            offer_valid_from_cut_off_date = current_datetime
            offer_valid_from_cut_off_date = offer_valid_from_cut_off_date.replace(
                hour=0, minute=0, second=0
            )
            offer_valid_from_cut_off_date = offer_valid_from_cut_off_date + timedelta(days=-30)

            if customer.get('is_user_logged_in', 0):
                redemption_quantities = redemption_repo.get_redeemed_quantities_for_customer(
                    customer_id=customer.get('customer_id', 0),
                    company=company
                )

            for offer in offers:
                if isinstance(offer.get('outlet_ids'), str):
                    offer['outlet_ids'] = list(set(list(map(int, offer['outlet_ids'].split(',')))))
                redeemability = OfferWlRepository().calculate_offer_redeemability_for_customer(
                    customer,
                    offer,
                    redemption_quantities,
                    purchasable_product_ids
                )
                offer['voucher_restrictions'] = '{voucher} {card}'.format(
                    voucher=offer.get('voucher_restrictions'),
                    card=offer.get('card_line')
                )
                offer['conditions'] = '{conditions}{card}'.format(
                    conditions=offer.get('conditions'),
                    card=offer.get('card_line')
                )
                offer['conditions'] = parse_voucher_restrictions(offer.get('conditions', {}))
                offer['is_redeemable'] = redeemability['is_redeemable']
                offer['redeemability'] = redeemability['redeemability']
                offer['is_purchased'] = redeemability['is_purchased']
                offer['is_offer_valid_in_future'] = redeemability['is_offer_valid_in_future']
                offer['is_offer_expired'] = redeemability['is_offer_expired']
                offer['quantity_redeemable'] = redeemability['quantity_redeemable']
                offer['quantity_redeemed'] = redeemability['quantity_redeemed']
                offer['quantity_not_redeemable'] = redeemability['quantity_not_redeemable']
                offer['is_show_purchase_button'] = redeemability['is_show_purchase_button']
                offer['is_monthly'] = offer['type'] == OfferWlRepository.TYPE_MEMBER

                if (
                    offer['type'] != OfferWlRepository.TYPE_MEMBER and
                    offer['valid_from_date'] > offer_valid_from_start_date and
                    offer['valid_from_date'] > offer_valid_from_cut_off_date
                ):
                    offer['is_new'] = True
                else:
                    offer['is_new'] = False

        return offers

    def calculate_offer_redeemability_for_customer(self, customer, offer, redemption_quantities,
                                                   purchasable_product_ids=[]):
        """
        Calculate offer redeemability for customer
        :param dict customer: customer
        :param dict offer: offer
        :param dict redemption_quantities: redemption quantities
        :param list purchasable_product_ids: purchasable product ids
        :rtype: dict
        """
        is_redeemable = False
        if (
            not customer.get('is_user_logged_in') and
            not customer.get('is_preactivated_app')
        ):
            return {
                'is_redeemable': is_redeemable,
                'redeemability': OfferWlRepository.NOT_REDEEMABLE,
                'is_purchased': False,
                'is_offer_valid_in_future': False,
                'is_offer_expired': False,
                'quantity_redeemable': 0,
                'quantity_redeemed': 0,
                'quantity_not_redeemable': offer['quantity'],
                'is_show_purchase_button': False
            }

        current_datetime = datetime.utcnow()
        date_from = current_datetime + timedelta(hours=self.Hours_Adjustment_For_Offer_Expiry_From)
        date_to = current_datetime + timedelta(hours=self.Hours_Adjustment_For_Offer_Expiry_To)

        num_purchased = 0
        num_redemptions = 0

        is_offer_valid_in_future = False
        is_offer_expired = False
        allowed_onboarding = False

        redeemability_value = OfferWlRepository.NOT_REDEEMABLE
        offer['quantity_display'] = offer.get('quantity')

        is_purchasable = offer['product_id'] in purchasable_product_ids
        is_purchased = offer['product_id'] in customer.get('product_ids')

        # Need to check
        if redemption_quantities:
            check = "{}_{}".format(offer.get('id'), offer.get('product_id'))
            if redemption_quantities.get(check):
                num_redemptions = redemption_quantities.get(check)
            else:
                num_redemptions = 0

        if offer['valid_from_date'] > date_from:
            is_offer_valid_in_future = True

        if offer['expiration_date'] < date_to:
            is_offer_expired = True

        if customer.get('non_depletable_offers_app') and is_purchasable:
            num_redemptions = 0
            num_purchased = 1
        else:
            num_purchased += int((customer.get('product_ids', []).count(offer.get('product_id', 0)) *
                                  int(offer.get('quantity', 0))))

        if offer['type'] == OfferWlRepository.TYPE_MEMBER and is_purchased:
            num_purchased = int(num_redemptions) + 1

        if (
            not is_offer_valid_in_future and
            not is_offer_expired and
            int(num_purchased) > int(num_redemptions) and
            int(num_purchased) > 0
        ):
            if offer['type'] == OfferWlRepository.TYPE_DEFAULT:
                redeemability_value = OfferWlRepository.REDEEMABLE
                is_redeemable = True
            else:
                redeemability_value = OfferWlRepository.REUSABLE
                is_redeemable = True

        elif int(num_redemptions) >= int(num_purchased) > 0:
            redeemability_value = OfferWlRepository.REDEEMED
        else:
            redeemability_value = OfferWlRepository.NOT_REDEEMABLE

        is_show_purchase_button = False

        redeemability = {
            'is_redeemable': is_redeemable,
            'redeemability': redeemability_value,
            'is_purchased': is_purchased,
            'is_offer_valid_in_future': is_offer_valid_in_future,
            'is_offer_expired': is_offer_expired,
            'quantity_redeemable': offer.get('quantity') if redeemability_value == self.REUSABLE else
            max(0, int(num_purchased) - int(num_redemptions)),
            'quantity_redeemed': 0 if redeemability_value == self.REUSABLE else num_redemptions,
            'quantity_not_redeemable': offer.get('quantity') if not is_purchased and not allowed_onboarding else 0,
            'is_show_purchase_button': is_show_purchase_button
        }
        return redeemability

    def calculate_offer_redeemability_for_redemption_controller(
            self, company, customer, offer_id, offer_valid_from_date, offer_expiration_date,
            offer_type, offer_quantity, product_id
    ):
        """
        Calculate offer redeemability
        :param str company: company
        :param dict customer: customer
        :param int offer_id: offer id
        :param date_time offer_valid_from_date: offer valid from date
        :param date_time offer_expiration_date: offer expiration date
        :param int offer_type: offer type
        :param int offer_quantity: offer quantity
        :param int product_id: product id
        :rtype: dict
        """
        redemption_repo = RedemptionRepositoryWhiteLabel()

        current_date = datetime.now()
        date_from_offset = OfferWlRepository.Hours_Adjustment_For_Offer_Expiry_From
        date_to_offset = OfferWlRepository.Hours_Adjustment_For_Offer_Expiry_To

        date_from = current_date + timedelta(hours=date_from_offset)
        date_to = current_date + timedelta(hours=date_to_offset)

        num_purchased = 0
        num_redemptions = 0
        is_offer_valid_in_future = False
        is_offer_expired = False
        is_redeemable = False
        is_purchased = False

        if offer_valid_from_date > date_from:
            is_offer_valid_in_future = True

        if offer_expiration_date < date_to:
            is_offer_expired = True

        # Need to check
        is_with_in_validity_period = not is_offer_valid_in_future and not is_offer_expired

        if not is_with_in_validity_period:
            return is_redeemable

        is_purchased = product_id if product_id in customer.get('product_ids', []) else is_purchased

        if not is_purchased:
            return is_redeemable

        if (
            offer_type == OfferWlRepository.TYPE_MEMBER or
            customer.get('non_depletable_offers_app')
        ):
            num_redemptions = 0
            num_purchased = 1
        else:
            redemptions_quantities = redemption_repo.get_redeemed_quantities_for_customer(
                customer_id=customer.get('customer_id'),
                company=company
            )
            if redemptions_quantities:
                index = "{}_{}".format(offer_id, product_id)
                if redemptions_quantities.get(index):
                    num_redemptions = redemptions_quantities.get(index)
                else:
                    num_redemptions = 0
            product_purchase_list = [prod_id for prod_id in customer.get('product_ids') if prod_id == product_id]
            num_purchased = len(product_purchase_list) * int(offer_quantity)

        is_redeemable = num_purchased > num_redemptions

        return is_redeemable

    def fix_expiration_date(self, date):
        """
        Fix expiration date
        :rtype date
        """
        current_date = datetime.now()
        expiration_date = current_date.replace(hour=12, minute=0, second=0)
        return expiration_date

    def find_offer_type_by_id(self, offer_id, locale='en'):
        """
        Finds Offer type by offer id
        :param int offer_id: offer id
        :param str locale: language
        :rtype: dict
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select(['t.name'])
        sql_dal.from_('offer_wl_active as o')
        sql_dal.left_join(
            'offer_translation_wl_active as t',
            'o.id',
            't.offer_id'
        )
        sql_dal.where({'o.id': offer_id, 't.locale': locale})
        offer_name = sql_dal.get_one(default={})

        if len(offer_name) < 1:
            return False

        return offer_name

    def get_outlet_ids_for_offer(self, offer_ids):
        """
        Gets offer outlet_ids
        :param list offer_ids: offer ids
        :rtype: list
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select(['o0_.id as offer_ids', 'GROUP_CONCAT(Distinct o1_.id) as outlet_ids'])
        sql_dal.from_(['offer_wl_active as o0_'])
        sql_dal.inner_join('outlet_offer as o2_', 'o0_.id', 'o2_.offer_id')
        sql_dal.inner_join('outlet as o1_', 'o1_.id', 'o2_.outlet_id')
        sql_dal.where_in('o0_.id', offer_ids.split(","))
        sql_dal.group_by(['o0_.id'])
        sql_dal.having('o1_.id', '0', '>')
        results = sql_dal.get(default=[])
        return results

    def _fix_expiration_date(self, date):
        if isinstance(date, str):
            date = datetime.strptime(date, '%Y-%m-%dT%H:%M:%S')
        return date.replace(hour=12, minute=0, second=0)

    def find_offers(self, data={}):
        sql_dal = SqlDal()
        sql_dal.select([
            "o.id", "o.merchant_category", "COALESCE(o.sub_category, '') as sub_category",
            "GROUP_CONCAT(DISTINCT ot.id) as outlet_ids", "o.valid_from valid_from_date",
            "o.valid_to expiration_date", "o.type",
            "CONCAT({}, '') redeemability".format(self.NOT_REDEEMABLE),
            "o.quantity", "0 as times_redeemed", "t.name as offer_name", "o.savings_estimate",
            "GROUP_CONCAT(DISTINCT p.id) product_id", "GROUP_CONCAT(DISTINCT p.sf_id) product_sku",
            "MAX(p.is_cheers) is_cheers", "MAX(p.delivery_enabled) is_delivery",
            "MAX(p.is_more_sa) is_more_sa", "MAX(p.ismember) is_monthly", "o.is_point_based_offer"
        ])
        sql_dal.from_(["outlet as ot"])
        sql_dal.inner_join('outlet_offer as of', 'of.outlet_id', 'ot.id')
        sql_dal.inner_join('offer_wl_active as o', 'o.id', 'of.offer_id')
        sql_dal.inner_join(
            'offer_translation_wl_active as t',
            'o.id', 't.offer_id'
        )
        sql_dal.where('t.locale', data['locale'])
        sql_dal.inner_join('product_offer_wl_active as po', 'o.id', 'po.offer_id')
        sql_dal.inner_join('product as p', 'po.product_id', 'p.id and p.isactive = true')
        sql_dal.where({'COALESCE(p.cashless_delivery_enabled, 0)': 0, "o.status": "Active"})

        if data['product_sku']:
            sql_dal.set_parenthesised_where_clause("p.sfId = {} ".format(data['product_sku']))
        else:
            # for locked / buy tab
            if data['offer_redeemability'] == self.Redeemability_not_redeemable:
                sql_dal.inner_join(
                    'product_wl_active as wla',
                    'wla.product_id',
                    'p.id and wla.is_active = true and wla.company = {}'.format(data['customer'].get('company')))
            else:
                sql_dal.where_in('p.id', data['customer'].get('product_ids'))
                if data['is_company_specific']:
                    if data['customer'].get('company') == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
                        company_skus = CommonHelpers().get_configured_sku_by_company(data['customer'].get('company'))
                        sql_dal.where_in('p.sf_id', company_skus)

        if data['show_only_core_product_offers']:
            sql_dal.where({
                'p.delivery_enabled': 0,
                'p.is_cheers': 0,
                'p.is_more_sa': 0,
                'p.ismember': 0
            })
        if data['is_cuckoo']:
            sql_dal.where({'p.delivery_enabled': 0, 'p.is_cheers': 0})
        if not data['is_cuckoo'] and data['is_delivery']:
            sql_dal.where({"p.delivery_enabled": True})
        if not data['is_cuckoo'] and data['is_cheers']:
            sql_dal.where({'p.is_cheers': True})
        # for monthly offers
        if data['show_monthly_offers']:
            sql_dal.where({'o.type': self.TYPE_MEMBER})
        # for new offers
        if data['show_new_offers']:
            parenthesized_query = "AND o.valid_from >'{offer_valid_from_start_date}' And o.valid_from >'{offer_valid_from_cut_off_date}' "   # noqa: E501
            params = dict(
                offer_valid_from_start_date=data.get('offer_valid_from_start_date'),
                offer_valid_from_cut_off_date=data.get('offer_valid_from_cut_off_date')
            )
            sql_dal.set_parenthesised_where_clause(parenthesized_query, params)
        if data['is_more_sa']:
            sql_dal.where({'p.is_more_sa': True})
        if not data['user_include_cheers']:
            sql_dal.where({"p.is_cheers": 0})
        if data['category'].lower() == 'all':  # For quick search
            sql_dal.set_parenthesised_where_clause("AND (p.location_id = {} OR p.istravel = true OR p.is_more_sa = true)".format(data['location_id']))  # noqa:E501
        elif data['category'] == GlobalConstants.category_API_Name_Travel:  # Only for Travel
            sql_dal.where({'p.istravel': True})
        else:  # For categories other than Travel
            sql_dal.set_parenthesised_where_clause("AND (p.location_id = {} OR p.is_more_sa = true)".format(data['location_id']))  # noqa:E501
        if data['_is_fuzzy_search_on']:
            sql_dal.where_in('ot.id', data['_fuzzy_search_outlet_ids'])
        # Apply Filter on Category
        if data['category'] and data['category'].lower() != "all":
            self.is_service_category_merged_company = WLCompany().is_service_category_merged_company(
                data['customer'].get('company')
            )
            if (
                self.is_service_category_merged_company and
                data['category'] == GlobalConstants.category_API_Name_Services
            ):
                sql_dal.set_parenthesised_where_clause("o.merchant_category in {}".format(
                    [GlobalConstants.category_API_Name_Retail, GlobalConstants.category_API_Name_Services]
                ))
            else:
                sql_dal.where({'o.merchant_category': data['category']})
        # Apply Filter on sub_category
        if (
            data['sub_category_filter'] and
            len(data['sub_category_filter'].strip()) > 0 and
            data['sub_category_filter'].strip().lower() != 'all'
        ):
            sql_dal.where({'o.sub_category': data['sub_category_filter']})
        if data['outlet_id']:
            sql_dal.where({'ot.id': data['outlet_id']})
        # exclude points based offers
        self.show_point_based_offers = False
        if (
            data['customer'].get('company') == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS and
            data['app_version'] > 1.3
        ):
            self.show_point_based_offers = True
        if not self.show_point_based_offers:
            sql_dal.where({"o.is_point_based_offer": 0})

        sql_dal.group_by(['o.id'])
        result = sql_dal.get(default=[])
        return result

    def get_offer_sub_detail_object(self, id='', image='', title='', color=''):
        """
        Gets offer sub detail object
        :return:
        """
        return {'id': id, 'image': image, 'title': title, 'color': color}
