"""
Delivery Menu Items Repository
"""

from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class DeliveryMenuItemsRepositoryWL(BaseRepository):
    """
    Returns the delivery_tutorials_info and menu_items
    """
    IMAGE_LINK = "https://s3.amazonaws.com/entertainer-app-assets/deliverable-active.png"

    @classmethod
    def get_delivery_tutorials_info(cls, locale='en', **kwargs):
        """
        Gets the delivery tutorial's information
        :param str locale: locale
        :rtype: list
        """
        SUPPORTED_LOCALES = ['en', 'ar', 'cn', 'el']
        if locale.lower() in SUPPORTED_LOCALES:
            tutorial_info = [
                "https://s3.amazonaws.com/entertainer-app-assets/delivery/{}/delivery_tutorial_01.png".format(locale),
                "https://s3.amazonaws.com/entertainer-app-assets/delivery/{}/delivery_tutorial_02.png".format(locale),
                "https://s3.amazonaws.com/entertainer-app-assets/delivery/{}/delivery_tutorial_03.png".format(locale),
                "https://s3.amazonaws.com/entertainer-app-assets/delivery/{}/delivery_tutorial_04.png".format(locale)
            ]
        return tutorial_info

    def get_menu_items(self, merchant_id, locale='en', **kwargs):
        """
        Gets menu items
        :param int merchant_id: id of merchant
        :param str locale: locale
        :rtype: dict
        """
        locale = locale.lower()
        sql_dal = SqlDal()
        sql_dal.select(["COALESCE(m.delivery_contact_no, '') AS delivery_contact_no"])
        sql_dal.from_(['merchant'], ['m'])
        sql_dal.where({'m.id': merchant_id})
        result = dict()
        delivery_contact_number = sql_dal.get_one(default={})
        if delivery_contact_number:
            result['delivery_contact_no'] = delivery_contact_number.get('delivery_contact_no')
        else:
            result['delivery_contact_no'] = None
        result['delivery_tutorials_info'] = self.get_delivery_tutorials_info(locale)
        sql_dal.select(['*'])
        sql_dal.from_(["delivery_menu_items"], ["dmi"])
        sql_dal.where({'dmi.merchant_id': merchant_id})
        items = sql_dal.get(default=[])
        categorized_menu = {}
        category_locale = 'category_{}'.format(locale)
        title_locale = 'title_{}'.format(locale)
        description_locale = 'description_{}'.format(locale)

        for item in items:
            categorized_menu[item[category_locale]] = item[category_locale]
            if item['is_entertainer']:
                icon = self.IMAGE_LINK
            else:
                icon = ''

            new_item = {
                'id': item.get('id'),
                'title': item.get(title_locale),
                'description': item.get(description_locale),
                'price': '{currency} {price}'.format(
                    currency=item.get('currency'),
                    price=item.get('price')
                ),
                'is_deliverable': item.get('is_entertainer'),
                'img': icon
            }
            # TODO need to confirm
            categorized_menu[item[category_locale]] = new_item

        output = []
        for key, value in categorized_menu.items():
            output.append({'title': key, 'menus': value})
        result.update({'menu_section': output})
        return result
