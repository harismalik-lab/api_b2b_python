"""
WL Company Repository and Common Helpers
"""
import datetime
import random

from flask import g

from repositories_white_label.base_repo import BaseRepository
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.wl_categories_repo import CategoriesRepositoryWl
from wrapper_white_labels.sql_dal import SqlDal

cache = g.cache


class WLCompany(BaseRepository):

    LOCATION_VERSION_HSBC = 1
    COMPANY_CODE_MASTER_CARDS = "mce"
    COMPANY_CODE_MASTER_CARDS_ASIA = "mca"
    COMPANY_CODE_DU = "due"
    COMPANY_CODE_DUT = "dut"
    COMPANY_CODE_DHL = "dhl"
    COMPANY_CODE_ALBILAD = "alb"
    COMPANY_CODE_SAMSUNG = "smg"
    COMPANY_CODE_ENTERTAINER_LIFE = "elf"
    COMPANY_CODE_OLD_MUTUAL_ENTERTAINER = "ome"
    COMPANY_CODE_ENTERTAINER_HUT = "hut"
    COMPANY_CODE_ENTERTAINER_MTN = "mtn"
    COMPANY_CODE_ENTERTAINER_MOTO = "mto"
    COMPANY_CODE_ENTERTAINER_SGK = "sgk"
    COMPANY_CODE_ENTERTAINER_GEMS = "gem"
    COMPANY_CODE_ENTERTAINER_KEL = "kel"
    COMPANY_CODE_ENTERTAINER_JGE = "jge"
    COMPANY_CODE_ENTERTAINER_QGIRCO = "qgi"
    COMPANY_CODE_ENTERTAINER_LAND_MARK_GROUP = "lmk"
    COMPANY_CODE_ENTERTAINER_CRG = "crg"
    COMPANY_CODE_ENTERTAINER_HSBC = "hs"
    COMPANY_CODE_ENTERTAINER_HSBC_CUCKOO = "hss"
    COMPANY_CODE_ENTERTAINER_BNE = "bne"
    COMPANY_CODE_ENTERTAINER_SENSODYNE = "sns"
    COMPANY_CODE_ENTERTAINER_CHANGI_REWARDS_ENTERTAINER = "cng"
    COMPANY_CODE_ENTERTAINER_NAAMA = "nma"
    COMPANY_CODE_ENTERTAINER_BATELCO = "btl"
    COMPANY_CODE_ENTERTAINER_EMAX = "emx"
    COMPANY_CODE_DUBAI_ENTERTAINMENTS = "dpr"
    COMPANY_CODE_AAG = "aag"
    COMPANY_CODE_LAK_ENTERTAINER = "lak"
    COMPANY_CODE_ZEINAH_ENTERTAINER = "zin"
    COMPANY_CODE_Commercial_Bank_ENTERTAINER = "cbq"
    COMPANY_CODE_ALJAWHAR_ENTERTAINER = "aje"
    COMPANY_CODE_ASALAH_ENTERTAINER = "bme"
    COMPANY_CODE_IGLOW_LIFESTYLE = "igl"
    company_code_HCS_Singapure = 6
    COMPANY_CODE_HCS_Singapure = "hcs"
    company_code_ENTERTAINER_VDF = "vdf"
    company_code_ENTERTAINER_EXPRESS = "exprs"
    company_code_SOLIDATIRy = "sol"
    COMPANY_CODE_EXPRESS = 'exp'

    def get_key_prefix_by_company(self, company):
        """
        Gets key prefix by company
        :param company: Wl company name
        """
        company = company.lower()
        prefix = 'te'
        prefixes = {
            self.COMPANY_CODE_ENTERTAINER_GEMS: 'ge',
            self.COMPANY_CODE_ENTERTAINER_CRG: 'ce',
            self.COMPANY_CODE_ENTERTAINER_NAAMA: 'nm',
            self.COMPANY_CODE_ENTERTAINER_EMAX: 'em',
            self.COMPANY_CODE_DUBAI_ENTERTAINMENTS: 'de',
            self.COMPANY_CODE_DHL: 'dh',
            self.COMPANY_CODE_EXPRESS: 'ex'
        }
        try:
            return prefixes[company]
        except KeyError:
            return prefix

    VALID_STATUS = 1
    ALREADY_USED_STATUS = 2
    INVALID_STATUS = 3
    INVOICE_STATUS_VALID_FOR_SIGN_IN_SIGN_UP_ONLY = 4
    INVOICE_STATUS_VALID_LINKING_THROUGH_PROFILE_ONLY = 5
    INVOICE_STATUS_OUTDATED_INVOICE = 6
    INVOICE_STATUS_INVALID_TRANSACTION_TYPE = 7
    INVOICE_STATUS_WRONG_AMOUNT = 8

    def get_company_multiple_status(self, wl_company_id):
        """
        Returns the status of wl companies
        :param int wl_company_id: id of wl_company
        :rtype: dict
        """
        if wl_company_id:
            sql_dal = SqlDal()
            sql_dal.select(['wl_company.is_multiple_allowed'])
            sql_dal.from_(['wl_company'])
            sql_dal.where({'wl_company.code': wl_company_id})
            company = sql_dal.get_one(default={})
            return company.get('is_multiple_allowed', False)
        return False

    def is_service_category_merged_company(self, company):
        """
        Is service category merged company
        :param c    ompany:
        """
        is_service_category_merged_company = False
        company = company.lower()
        if (
            company in
                [
                    WLCompany.COMPANY_CODE_ENTERTAINER_GEMS,
                    WLCompany.COMPANY_CODE_DUBAI_ENTERTAINMENTS
                ]
        ):
            is_service_category_merged_company = True
        return is_service_category_merged_company

    def get_company_name(self, company_id):
        """
        Gets the company name
        :param str company_id: company's id
        :rtype: str
        """
        company = dict()
        if company_id:
            sql_dal = SqlDal()
            sql_dal.select(['name'])
            sql_dal.from_(['wl_company'])
            sql_dal.where('id', company_id)
            company = sql_dal.get_one(default={})
        return company.get('id', 0)  # incorrect col

    def get_hsbc_love_dining_skus(self):
        """
        Get hsbc love dining skus
        :rtype: list
        """
        return (
            'L18DBHSDC', 'L19DBHSDC', 'L18ADHSDC', 'L19ADHSDC',
            'L18DBHSDB', 'L19DBHSDB', 'L18ADHSDB', 'L19ADHSDB'
        )

    def get_company_id(self, company):
        sql_dal = SqlDal()
        sql_dal.select(['w.id'])
        sql_dal.from_(['wl_company'], ['w'])
        sql_dal.where('w.code', company)
        company = sql_dal.get_one(default={})
        return company.get('id', 0)

    def is_required_to_pick_name_from_lookup(self, company=None):
        """
        Is required to pick first name and last name from lookup
        :param str company: White label client
        """
        is_required_to_pick_fname_lname_from_lookup_flag = False
        company = company.lower()
        if (
                company in
                [
                    self.COMPANY_CODE_ENTERTAINER_CRG,
                    self.COMPANY_CODE_ENTERTAINER_NAAMA,
                    self.COMPANY_CODE_DUBAI_ENTERTAINMENTS
                ]
        ):
            is_required_to_pick_fname_lname_from_lookup_flag = True
        return is_required_to_pick_fname_lname_from_lookup_flag

    def generate_unique_id(self, prefix, length):
        prefix = prefix + str(random.randint(1, 101) * 5)
        return ''.join(random.choice(prefix) for _ in range(length))

    def get_invoice_validation_message(self, validation_status, locale, is_user_upgraded=False):
        message = TranslationManager().get_translation(TranslationManager.invoice_validation_invalid_message, locale)
        if validation_status == WLCompany.VALID_STATUS:
            if is_user_upgraded:
                message = TranslationManager().get_translation(
                    TranslationManager.invoice_validation_success_message_upgraded,
                    locale
                )
            else:
                message = TranslationManager().get_translation(
                    TranslationManager.invoice_validation_success_message,
                    locale
                )
        if validation_status == WLCompany.ALREADY_USED_STATUS:
            message = TranslationManager().get_translation(
                TranslationManager.invoice_validation_already_linked_message,
                locale
            )
        if validation_status == WLCompany.INVOICE_STATUS_VALID_LINKING_THROUGH_PROFILE_ONLY:
            message = TranslationManager().get_translation(
                TranslationManager.invoice_validation_invalid_message,
                locale
            )
        if validation_status == WLCompany.INVOICE_STATUS_VALID_FOR_SIGN_IN_SIGN_UP_ONLY:
            message = TranslationManager().get_translation(
                TranslationManager.invoice_validation_invalid_message,
                locale
            )
        if validation_status == WLCompany.INVOICE_STATUS_OUTDATED_INVOICE:
            message = TranslationManager().get_translation(
                TranslationManager.invoice_validation_outdated_invoice,
                locale
            )
        if validation_status == WLCompany.INVOICE_STATUS_INVALID_TRANSACTION_TYPE:
            message = TranslationManager().get_translation(
                TranslationManager.invoice_validation_invalid_code_message,
                locale
            )
        if validation_status == WLCompany.INVOICE_STATUS_WRONG_AMOUNT:
            message = TranslationManager().get_translation(
                TranslationManager.invoice_validation_invalid_message_wrong_amount,
                locale
            )

        return message

    def is_lookup_based_company(self, company=None):
        """
        Checks company is lookup based or not
        :param str company: company
        :rtype: bool
        """
        is_lookup_based_company = False
        company = company.lower()
        if (
            company in
                [
                    WLCompany.COMPANY_CODE_ENTERTAINER_GEMS,
                    WLCompany.COMPANY_CODE_ENTERTAINER_CRG,
                    WLCompany.COMPANY_CODE_ENTERTAINER_NAAMA,
                    WLCompany.COMPANY_CODE_DUBAI_ENTERTAINMENTS,
                    WLCompany.COMPANY_CODE_DHL
                ]
        ):
            is_lookup_based_company = True
        return is_lookup_based_company

    def get_customer_device_limit_required_company(self, company):
        """
        Get customer device limit required company
        :return: limit
        """
        limits = {'WlCompany': WLCompany.company_code_HCS_Singapure}
        if limits.get(company):
            return limits.get(company)

    def is_analytics_enabled(self, company):
        """
        Checks is analytics enabled or not?
        :param str company: company
        :return:
        """
        return company in [
            self.COMPANY_CODE_ENTERTAINER_SENSODYNE,
            self.COMPANY_CODE_LAK_ENTERTAINER,
            self.COMPANY_CODE_ENTERTAINER_KEL,
            self.COMPANY_CODE_ENTERTAINER_LAND_MARK_GROUP,
            self.COMPANY_CODE_ZEINAH_ENTERTAINER,
            self.COMPANY_CODE_ENTERTAINER_BNE,
            self.COMPANY_CODE_ENTERTAINER_CHANGI_REWARDS_ENTERTAINER,
            self.COMPANY_CODE_ENTERTAINER_EMAX,
            self.COMPANY_CODE_ENTERTAINER_BATELCO,
            self.COMPANY_CODE_Commercial_Bank_ENTERTAINER,
            self.COMPANY_CODE_ENTERTAINER_QGIRCO,
            self.COMPANY_CODE_ALJAWHAR_ENTERTAINER,
            self.COMPANY_CODE_ASALAH_ENTERTAINER,
            self.COMPANY_CODE_ENTERTAINER_GEMS,
            self.COMPANY_CODE_ALBILAD,
            self.COMPANY_CODE_ENTERTAINER_HSBC,
            self.COMPANY_CODE_ENTERTAINER_CRG,
            self.COMPANY_CODE_ENTERTAINER_NAAMA,
            self.COMPANY_CODE_IGLOW_LIFESTYLE,
            self.COMPANY_CODE_ENTERTAINER_JGE
        ]

    def get_location_version(self, company='entertainer'):
        """
        Gets version of location
       :return:
        """
        location_version = 1
        if company and company == self.COMPANY_CODE_ENTERTAINER_HSBC:
            location_version = self.LOCATION_VERSION_HSBC
        return location_version

    def get_pre_activated_apps(self, company):
        """
        Gets pre activated apps
        :param str company: company
        :rtype: bool
        """
        return company in [
            self.COMPANY_CODE_SAMSUNG, self.COMPANY_CODE_ENTERTAINER_MOTO, self.COMPANY_CODE_ENTERTAINER_SGK
        ]

    def get_non_depletable_offers_app(self, company):
        """
        Gets non depletable offers app
        :param str company:
        :rtype: bool
        """
        return company == self.COMPANY_CODE_MASTER_CARDS

    @staticmethod
    def format_credit_card(cc):
        """
        Formats credit cart
        :param int cc: cc
        :rtype: int
        """
        new_credit_card = ""
        if cc:
            # Clean out extra data that might be in the cc
            cc = cc.replace('-', '').replace(' ', '')
            # Get the CC Length
            cc_length = len(cc)
            # Initialize the new credit card to contian the last four digits
            new_credit_card = cc[:-2]
            # Walk backwards through the credit card number and add a dash after every fourth digit
            for a in range(cc_length - 5, 1):
                if (a + 1 - cc_length) % 4 == 0:
                    new_credit_card = '-' + new_credit_card
                # Add the current character to the new credit card
                new_credit_card = cc[a].new_credit_card
                # Return the formatted credit card number
        return new_credit_card

    @staticmethod
    @cache.memoize(timeout=1800)
    def get_currencies(locale='en'):
        """
        Gets currencies
        :rtype: list
        """
        currencies = []
        if locale == "ar":
            currencies.append({
                "id": "AED",
                "name": "درهم إماراتي ",
                "translated_currency": "AED"
            })
            currencies.append({
                "id": "BHD",
                "name": "دينار بحريني ",
                "translated_currency": "BHD"
            })
            currencies.append({
                "id": "EGP",
                "name": "جنيه مصري ",
                "translated_currency": "EGP"
            })
            currencies.append({
                "id": "EUR",
                "name": "يورو",
                "translated_currency": "EUR"
            })
            currencies.append({
                "id": "GBP",
                "name": "جنيه استرليني",
                "translated_currency": "GBP"
            })
            currencies.append({
                "id": "HKD",
                "name": "دولار هونغ كونغي ",
                "translated_currency": "HKD"
            })
            currencies.append({
                "id": "JOD",
                "name": "دينار أردني",
                "translated_currency": "JOD"
            })
            currencies.append({
                "id": "KWD",
                "name": "دينار كويتي ",
                "translated_currency": "KWD"
            })
            currencies.append({
                "id": "LBP",
                "name": "ليرة لبنانية",
                "translated_currency": "LBP"
            })
            currencies.append({
                "id": "MYR",
                "name": "رينغيت ماليزي ",
                "translated_currency": "MYR"
            })
            currencies.append({
                "id": "OMR",
                "name": "ريال عماني",
                "translated_currency": "OMR"
            })
            currencies.append({
                "id": "QAR",
                "name": "ريال قطري",
                "translated_currency": "QAR"
            })
            currencies.append({
                "id": "SAR",
                "name": "ريال سعودي",
                "translated_currency": "SAR"
            })
            currencies.append({
                "id": "SGD",
                "name": "دولار سنغافوري",
                "translated_currency": "SGD"
            })
            currencies.append({
                "id": "USD",
                "name": "دولار أميركي ",
                "translated_currency": "USD"
            })
            currencies.append({
                "id": "ZAR",
                "name": "راند جنوب أفريقي ",
                "translated_currency": "ZAR"
            })
        else:
            currencies.append({
                "id": "AED",
                "name": "UAE Dirham",
                "translated_currency": "AED"
            })
            currencies.append({
                "id": "BHD",
                "name": "Bahraini Dinar",
                "translated_currency": "BHD"
            })
            currencies.append({
                "id": "EGP",
                "name": "Egyptian Pound",
                "translated_currency": "EGP"
            })
            currencies.append({
                "id": "EUR",
                "name": "Euro",
                "translated_currency": "EUR"
            })
            currencies.append({
                "id": "GBP",
                "name": "British Pound",
                "translated_currency": "GBP"
            })
            currencies.append({
                "id": "HKD",
                "name": "Hong Kong Dollar",
                "translated_currency": "HKD"
            })
            currencies.append({
                "id": "JOD",
                "name": "Jordanian Dinar",
                "translated_currency": "JOD"
            })
            currencies.append({
                "id": "KWD",
                "name": "Kuwaiti Dinar",
                "translated_currency": "KWD"
            })
            currencies.append({
                "id": "LBP",
                "name": "Lebanese Pound",
                "translated_currency": "LBP"
            })
            currencies.append({
                "id": "MYR",
                "name": "Malaysian Ringgit",
                "translated_currency": "MYR"
            })
            currencies.append({
                "id": "OMR",
                "name": "Omani Rial",
                "translated_currency": "OMR"
            })
            currencies.append({
                "id": "QAR",
                "name": "Qatar Rial",
                "translated_currency": "QAR"
            })
            currencies.append({
                "id": "SAR",
                "name": "Saudi Arabian Riyal",
                "translated_currency": "SAR"
            })
            currencies.append({
                "id": "SGD",
                "name": "Singapore Dollar",
                "translated_currency": "SGD"
            })
            currencies.append({
                "id": "USD",
                "name": "U.S Dollar",
                "translated_currency": "USD"
            })
            currencies.append({
                "id": "ZAR",
                "name": "South African Rand",
                "translated_currency": "ZAR"
            })
        return currencies

    def get_cheers_configurations(self, locale, company=''):
        """
        Gets cheers configurations
       :param str locale: locale
       :param str company: company
       :rtype: list
        """
        configuration_cheers = []
        if locale == "ar":
            configuration_cheers.append({
                "id": 4,
                "location_id": 1,
                "product_id": 1970,
                "product_sku": "D17DBCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 21,
                "cheers_logo_url": 'https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png',
                "redemption_message": "يرجى إدخال رقم التعريف الشخصي الخاص بك لتأكيد إستخدام العرض ،"
                                      " هذا إن كنت في سن الشرب القانوني و غير مسلم",
                "product_information": "مئات العروض اشتري  واحد واحصل على الأخر  مجاناً للمشروبات في أفضل "
                                       " المطاعم والحانات والملاهي الليلية في أبوظبي والعين \n",
                "message_for_legal_terms": "من أجل الإستمرار يجب أن يكون سنك قانوني للشرب و أن تتفهم "
                                           "إن هذا المنتج يحتوي على الكحول.فبالإستمرار  أنت تؤكد انك تتفهم "
                                           "هذا وتوافق على اتفاقية ترخيص المستخدم النهائي لدينا",
                "consent_confirmation_message": "         أؤكد اني في سن الشرب القانوني و غير مسلم"
                                                " تاريخ ميلادي هو DD/MM/YYYY",
                "age_restriction_message": "هذا العرض يهدف الأشخاص الذين هم من سن "
                                           "الشرب القانوني وغير مسلمين \n",
                "redemption_confirm_message": "تأكد من رقمك السري المكون من ٤ أرقام ، وانك في سن "
                                              "الشرب القانوني وغير مسلم\n",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 7,
                "location_id": 2,
                "product_id": 1971,
                "product_sku": "D17ADCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 21,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "يرجى إدخال رقم التعريف الشخصي الخاص بك لتأكيد إستخدام العرض ،"
                                      " هذا إن كنت في سن الشرب القانوني و غير مسلم",
                "product_information": "مئات العروض اشتري  واحد واحصل على الأخر  مجاناً للمشروبات في أفضل "
                                       " المطاعم والحانات والملاهي الليلية في أبوظبي والعين \n",
                "message_for_legal_terms": "من أجل الإستمرار يجب أن يكون سنك قانوني للشرب و أن تتفهم "
                                           "إن هذا المنتج يحتوي على الكحول.فبالإستمرار  أنت تؤكد انك تتفهم "
                                           "هذا وتوافق على اتفاقية ترخيص المستخدم النهائي لدينا",
                "consent_confirmation_message": "         أؤكد اني في سن الشرب القانوني و غير مسلم"
                                                " تاريخ ميلادي هو DD/MM/YYYY",
                "age_restriction_message": "هذا العرض يهدف الأشخاص الذين هم من سن "
                                           "الشرب القانوني وغير مسلمين \n",
                "redemption_confirm_message": "تأكد من رقمك السري المكون من ٤ أرقام ، وانك في سن "
                                              "الشرب القانوني وغير مسلم\n",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 13,
                "location_id": 4,
                "product_id": 2074,
                "product_sku": "D17SACT",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for "
                                       "drinks in the best restaurants,"
                                       " bars and nightspots across Cape Town.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age "
                                           "and understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this "
                                           "and agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal drinking age "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d'))
            })
            configuration_cheers.append({
                "id": 16,
                "location_id": 11,
                "product_id": 2282,
                "product_sku": "D17SPCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption,"
                                      " that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Singapore.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol.By continuing,"
                                           " you confirm that you understand this and agree to our End "
                                           "User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n "
                                                "drinking age \n\nDD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d'))
            })
            configuration_cheers.append({
                "id": 19,
                "location_id": 13,
                "product_id": 2262,
                "product_sku": "D17HKCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Hong Kong.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n "
                                                "drinking age \n\nDD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 23,
                "location_id": 14,
                "product_id": 2177,
                "product_sku": "D17SAJB",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, "
                                       "bars and nightspots across Johannesburg & Pretoria.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age "
                                                "\n\n DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 21 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 22,
                "location_id": 15,
                "product_id": 2068,
                "product_sku": "D17MYMY",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 21,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Malaysia.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and"
                                           " understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age & "
                                                "\n\n DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 21 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 10,
                "location_id": 17,
                "product_id": 2339,
                "product_sku": "D17LDCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across London.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and"
                                           " understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and"
                                           " agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age"
                                                " \n\n DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 26,
                "location_id": 20,
                "product_id": 2216,
                "product_sku": "D17SADB",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Durban.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age "
                                                "\n\n DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 21 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 56,
                "location_id": 3,
                "product_id": 2128,
                "product_sku": "D17BHBH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 21,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "دخِل الرقم الخاص لاستخدام العرض وتأكيد"
                                      " أنك قد بلغت السن القانونية لتناول المشروبات الكحولية"
                                      " وأنه يُسمح لك بموجب القانون استخدام هذا المنتج",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Bahrain for 2018",
                "message_for_legal_terms": "من أجل الاستمرار، ينبغي "
                                           "أن تكون قد بلغت السن القانونية لتناول المشروبات الكحولية وأن تدرك بأن هذا "
                                           "المنتج قد يتضمن إشارات إلى مشروبات كحولية."
                                           " في حال اخترت الاستمرار، فإنك تؤكد بأنك تدرك ذلك بشكل تام "
                                           "وتوافق على أحكام اتفاقية الترخيص للمستخدم النهائي.",
                "consent_confirmation_message": "أنا أتعهد بأني قد بلغت السن القانونية لتناول المشروبات  \n "
                                                "الكحولية وأنه يُسمح لي بموجب القانون استخدام هذا المنتج\
                n الذي يتضمن إشارات إلى مشروبات كحولية:\n\n تاريخ ميلادي هو DD/MM/YYYY",
                "age_restriction_message": "Sorry, you must be 21 years or over and "
                                           "legally permitted to use this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 68,
                "location_id": 21,
                "product_id": 3959,
                "product_sku": "D17MTCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 17,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Malta.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age "
                                                "\n\n DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 17 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 71,
                "location_id": 5,
                "product_id": 2079,
                "product_sku": "D17CYCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 17,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Cyprus.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and"
                                           " understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age "
                                                "\n\n DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 17 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
        if locale == "cn":
            configuration_cheers.append({
                "id": 4,
                "location_id": 1,
                "product_id": 1970,
                "product_sku": "D17DBCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 21,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "請輸入你的私人密碼確認兌換，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Dubai.",
                "message_for_legal_terms": "閣下必須已達到合法飲用酒精飲品年齡及明白此產品內容有機會含有與酒精相"
                                           "關的資料才可繼續瀏覽。如要繼續，請確認已明白以上及同意我們的終端用戶許可協議。",
                "consent_confirmation_message": "我確認本人已達到合法飲用酒精飲品年齡及非\n 伊斯蘭教教徒 "
                                                "\n\nDD/MM/YYYY 我的出生日期是",
                "age_restriction_message": "对不起，您必须年满21周岁才能访问此产品。",
                "redemption_confirm_message": "確認你的四位數字私人密碼，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 7,
                "location_id": 2,
                "product_id": 1971,
                "product_sku": "D17ADCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 21,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "請輸入你的私人密碼確認兌換，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Abu Dhabi & Al Ain.",
                "message_for_legal_terms": "閣下必須已達到合法飲用酒精飲品年齡及明白此產品內容有機會含有與酒精相關的資料"
                                           "才可繼續瀏覽。如要繼續，請確認已明白以上及同意我們的終端用戶許可協議。",
                "consent_confirmation_message": "我確認本人已達到合法飲用酒精飲品年齡及非\n 伊斯蘭教教徒 "
                                                "\n\nDD/MM/YYYY 我的出生日期是",
                "age_restriction_message": "对不起，您必须年满21周岁才能访问此产品。",
                "redemption_confirm_message": "確認你的四位數字私人密碼，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 13,
                "location_id": 4,
                "product_id": 2074,
                "product_sku": "D17SACT",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "請輸入你的私人密碼確認兌換，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Cape Town.",
                "message_for_legal_terms": "閣下必須已達到合法飲用酒精飲品年齡及明白此產品內容有機會含有與酒精相關的資料"
                                           "才可繼續瀏覽。 如要繼續，請確認已明白以上及同意我們的終端用戶許可協議。",
                "consent_confirmation_message": "我確認本人已達到合法飲用酒精飲品年齡及非\n 伊斯蘭教教徒"
                                                " \n\nDD/MM/YYYY 我的出生日期是",
                "age_restriction_message": "对不起，您必须年满18周岁才能访问此产品。",
                "redemption_confirm_message": "確認你的四位數字私人密碼，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 16,
                "location_id": 11,
                "product_id": 2282,
                "product_sku": "D17SPCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "請輸入你的私人密碼確認兌換，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Singapore.",
                "message_for_legal_terms": "閣下必須已達到合法飲用酒精飲品年齡及明白此產品內容有機會含有與酒精相關的資料"
                                           "才可繼續瀏覽。 如要繼續，請確認已明白以上及同意我們的終端用戶許可協議。",
                "consent_confirmation_message": "我確認本人已達到合法飲用酒精飲品年齡及非\n 伊斯蘭教教徒"
                                                " \n\nDD/MM/YYYY 我的出生日期是",
                "age_restriction_message": "对不起，您必须年满18周岁才能访问此产品。",
                "redemption_confirm_message": "確認你的四位數字私人密碼，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 19,
                "location_id": 13,
                "product_id": 2262,
                "product_sku": "D17HKCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "請輸入你的私人密碼確認兌換，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Hong Kong.",
                "message_for_legal_terms": "閣下必須已達到合法飲用酒精飲品年齡及明白此產品內容有機會含有與酒精相關的資料"
                                           "才可繼續瀏覽。 如要繼續，請確認已明白以上及同意我們的終端用戶許可協議。",
                "consent_confirmation_message": "我確認本人已達到合法飲用酒精飲品年齡及非\n 伊斯蘭教教徒"
                                                " \n\nDD/MM/YYYY 我的出生日期是",
                "age_restriction_message": "对不起，您必须年满18周岁才能访问此产品。",
                "redemption_confirm_message": "確認你的四位數字私人密碼，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 23,
                "location_id": 14,
                "product_id": 2177,
                "product_sku": "D17SAJB",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "請輸入你的私人密碼確認兌換，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Johannesburg & Pretoria.",
                "message_for_legal_terms": "閣下必須已達到合法飲用酒精飲品年齡及明白此產品內容有機會含有與酒精相關的資料"
                                           "才可繼續瀏覽。 如要繼續，請確認已明白以上及同意我們的終端用戶許可協議。",
                "consent_confirmation_message": "我確認本人已達到合法飲用酒精飲品年齡及非\n 伊斯蘭教教徒"
                                                " \n\nDD/MM/YYYY 我的出生日期是",
                "age_restriction_message": "对不起，您必须年满18周岁才能访问此产品。",
                "redemption_confirm_message": "確認你的四位數字私人密碼，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 22,
                "location_id": 15,
                "product_id": 2068,
                "product_sku": "D17MYMY",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 21,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "請輸入你的私人密碼確認兌換，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Malaysia.",
                "message_for_legal_terms": "閣下必須已達到合法飲用酒精飲品年齡及明白此產品內容有機會含有與酒精相關的資料"
                                           "才可繼續瀏覽。 如要繼續，請確認已明白以上及同意我們的終端用戶許可協議。",
                "consent_confirmation_message": "我確認本人已達到合法飲用酒精飲品年齡及非\n 伊斯蘭教教徒"
                                                " \n\nDD/MM/YYYY 我的出生日期是",
                "age_restriction_message": "对不起，您必须年满21周岁才能访问此产品。",
                "redemption_confirm_message": "確認你的四位數字私人密碼，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 10,
                "location_id": 17,
                "product_id": 2339,
                "product_sku": "D17LDCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "請輸入你的私人密碼確認兌換，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across London.",
                "message_for_legal_terms": "閣下必須已達到合法飲用酒精飲品年齡及明白此產品內容有機會含有與酒精相關的資料"
                                           "才可繼續瀏覽。 如要繼續，請確認已明白以上及同意我們的終端用戶許可協議。",
                "consent_confirmation_message": "我確認本人已達到合法飲用酒精飲品年齡及非\n 伊斯蘭教教徒"
                                                " \n\nDD/MM/YYYY 我的出生日期是",
                "age_restriction_message": "对不起，您必须年满18周岁才能访问此产品。",
                "redemption_confirm_message": "確認你的四位數字私人密碼，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d'))
            })
            configuration_cheers.append({
                "id": 26,
                "location_id": 20,
                "product_id": 2216,
                "product_sku": "D17SADB",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "請輸入你的私人密碼確認兌換，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Durban.",
                "message_for_legal_terms": "閣下必須已達到合法飲用酒精飲品年齡及明白此產品內容有機會含有與酒精相關的資料"
                                           "才可繼續瀏覽。 如要繼續，請確認已明白以上及同意我們的終端用戶許可協議。",
                "consent_confirmation_message": "我確認本人已達到合法飲用酒精飲品年齡及非\n 伊斯蘭教教徒"
                                                " \n\nDD/MM/YYYY 我的出生日期是",
                "age_restriction_message": "对不起，您必须年满18周岁才能访问此产品。",
                "redemption_confirm_message": "確認你的四位數字私人密碼，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 56,
                "location_id": 3,
                "product_id": 2128,
                "product_sku": "D17BHBH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 21,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age and legally permitted to use this product",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Bahrain for 2018",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and"
                                           " understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal drinking age & \n "
                                                "legally permitted to use this product\n "
                                                "which contains references to alcohol: \n\n "
                                                "My date of birth is: DD/MM/YYYY",
                "age_restriction_message": "Sorry, you must be 21 years or over and "
                                           "legally permitted to use this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 68,
                "location_id": 21,
                "product_id": 3959,
                "product_sku": "D17MTCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 17,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Malta.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 17 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d'))
            })
            configuration_cheers.append({
                "id": 71,
                "location_id": 5,
                "product_id": 2079,
                "product_sku": "D17CYCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 17,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Cyprus.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 17 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
        if locale == "el":
            configuration_cheers.append({
                "id": 4,
                "location_id": 1,
                "product_id": 1970,
                "product_sku": "D17DBCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 21,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age and non-Muslim",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Dubai.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal drinking age & \n non - Muslim \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 21 years or over and non-Muslim to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and "
                                              "that you are of legal drinking age and non-Muslim",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 7,
                "location_id": 2,
                "product_id": 1971,
                "product_sku": "D17ADCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 21,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption,"
                                      " that you are of legal drinking age and non-Muslim",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Abu Dhabi & Al Ain.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and"
                                           " understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal drinking age & \n non - Muslim \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 21 years or over and non-Muslim to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, "
                                              "and that you are of legal drinking age and non-Muslim",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 13,
                "location_id": 4,
                "product_id": 2074,
                "product_sku": "D17SACT",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption,"
                                      " that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Cape Town.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and"
                                           " understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and"
                                           " agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d'))
            })
            configuration_cheers.append({
                "id": 16,
                "location_id": 11,
                "product_id": 2282,
                "product_sku": "D17SPCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Singapore.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and"
                                           " understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and"
                                           " agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d'))
            })
            configuration_cheers.append({
                "id": 19,
                "location_id": 13,
                "product_id": 2262,
                "product_sku": "D17HKCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Hong Kong.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and"
                                           " understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and"
                                           " agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 23,
                "location_id": 14,
                "product_id": 2177,
                "product_sku": "D17SAJB",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, "
                                       "bars and nightspots across Johannesburg & Pretoria.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol.By continuing, "
                                           "you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 21 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d'))
            })
            configuration_cheers.append({
                "id": 22,
                "location_id": 15,
                "product_id": 2068,
                "product_sku": "D17MYMY",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 21,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption,"
                                      " that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Malaysia.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and"
                                           " understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and"
                                           " agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age & \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 21 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",
            })
            configuration_cheers.append({
                "id": 10,
                "location_id": 17,
                "product_id": 2339,
                "product_sku": "D17LDCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across London.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 26,
                "location_id": 20,
                "product_id": 2216,
                "product_sku": "D17SADB",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, "
                                       "bars and nightspots across Durban.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 21 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d'))
            })
            configuration_cheers.append({
                "id": 56,
                "location_id": 3,
                "product_id": 2128,
                "product_sku": "D17BHBH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 21,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age and legally permitted to use this product",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Bahrain for 2018",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal drinking age & \n "
                                                "legally permitted to use this product\n "
                                                "which contains references to alcohol: \n\n "
                                                "My date of birth is: DD/MM/YYYY",
                "age_restriction_message": "Sorry, you must be 21 years or over and "
                                           "legally permitted to use this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 68,
                "location_id": 21,
                "product_id": 3959,
                "product_sku": "D17MTCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 17,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Malta.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and"
                                           " understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 17 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 71,
                "location_id": 5,
                "product_id": 2079,
                "product_sku": "D17CYCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 17,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, "
                                       "bars and nightspots across Cyprus.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 17 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
        else:
            configuration_cheers.append({
                "id": 4,
                "location_id": 1,
                "product_id": 1970,
                "product_sku": "D17DBCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 21,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age and non-Muslim",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, "
                                       "bars and nightspots across Dubai for 2018",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal drinking age & \n non - Muslim \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 21 years or over and non-Muslim to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age and"
                                              " non-Muslim",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 7,
                "location_id": 2,
                "product_id": 1971,
                "product_sku": "D17ADCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 21,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age and non-Muslim",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Abu Dhabi & Al Ain.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and"
                                           " understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal drinking age & \n non - Muslim \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 21 years or over and non-Muslim to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age and"
                                              " non-Muslim",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 13,
                "location_id": 4,
                "product_id": 2074,
                "product_sku": "D17SACT",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, "
                                       "bars and nightspots across Cape Town.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 16,
                "location_id": 11,
                "product_id": 2282,
                "product_sku": "D17SPCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, "
                                       "bars and nightspots across Singapore.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 19,
                "location_id": 13,
                "product_id": 2262,
                "product_sku": "D17HKCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Hong Kong.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and"
                                           " understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 23,
                "location_id": 14,
                "product_id": 2177,
                "product_sku": "D17SAJB",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Johannesburg & Pretoria.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 21 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 22,
                "location_id": 15,
                "product_id": 2068,
                "product_sku": "D17MYMY",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 21,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, "
                                       "bars and nightspots across Malaysia.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age & \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 21 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 10,
                "location_id": 17,
                "product_id": 2339,
                "product_sku": "D17LDCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption,"
                                      " that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across London.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 26,
                "location_id": 20,
                "product_id": 2216,
                "product_sku": "D17SADB",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 18,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption,"
                                      " that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Durban.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and"
                                           " understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 21 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 56,
                "location_id": 3,
                "product_id": 2128,
                "product_sku": "D17BHBH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 21,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption,"
                                      " that you are of legal drinking age and legally permitted to use this product",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Bahrain for 2018",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and"
                                           " understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal drinking age & \n "
                                                "legally permitted to use this product \n "
                                                "which contains references to alcohol: \n\n "
                                                "My date of birth is: DD/MM/YYYY",
                "age_restriction_message": "Sorry, you must be 21 years or over and "
                                           "legally permitted to use this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 68,
                "location_id": 21,
                "product_id": 3959,
                "product_sku": "D17MTCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 17,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption,"
                                      " that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, "
                                       "bars and nightspots across Malta.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 17 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
            configuration_cheers.append({
                "id": 71,
                "location_id": 5,
                "product_id": 2079,
                "product_sku": "D17CYCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 17,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption, "
                                      "that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Cyprus.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and "
                                           "understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 17 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"

            })
            configuration_cheers.append({
                "id": 75,
                "location_id": 46,
                "product_id": 5967,
                "product_sku": "L18BAIGCH",
                "category_id": 1,
                "category": "Food & Drink",
                'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                "age_limit": 21,
                "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                "redemption_message": "Please enter your PIN to confirm redemption,"
                                      " that you are of legal drinking age",
                "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants,"
                                       " bars and nightspots across Bali.",
                "message_for_legal_terms": "In order to continue you must be of legal drinking age and"
                                           " understand this product may contain references to alcohol."
                                           "By continuing, you confirm that you understand this and "
                                           "agree to our End User License Agreement",
                "consent_confirmation_message": "I confirm I am of legal \n drinking age & \n\n "
                                                "DD/MM/YYYY is my date of birth",
                "age_restriction_message": "Sorry, you must be 21 years or over to access this product",
                "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                "date_today": str(datetime.datetime.now().strftime('%Y/%m/%d')),
                "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",
                "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                "error_message_to_select_an_option": "Please select an option to continue"
            })
        if company == self.COMPANY_CODE_ENTERTAINER_GEMS:
            for configuration_cheer in configuration_cheers:
                configuration_cheer['cheers_logo_url'] = "https://s3-us-west-2.amazonaws.com/app-assets-whitelabel/logo-cheers-gems.png"  # noqa
                configuration_cheer['not_interested_in_cheers_offers_message'] = "I do not want Clink but thanks anyway."
                configuration_cheer['category'] = configuration_cheer['api_name']
                if configuration_cheer['location_id'] in [1, 2]:
                    configuration_cheer['product_information'] = "Hundreds of Buy One Get One Free offers for" \
                                                                 " drinks in the best restaurants, bars and " \
                                                                 "nightspots across the UAE."
        return configuration_cheers
