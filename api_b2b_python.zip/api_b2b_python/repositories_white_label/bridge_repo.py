from urllib.parse import urlparse

from flask import current_app, request
from requests import Request, Session
from requests.auth import HTTPBasicAuth

from app_configurations_white_label.security_credentials import PHP_BASIC_AUTH_CREDENTIALS
from repositories_white_label.base_repo import BaseRepository


class BridgeRepository(BaseRepository):
    """
    Repo for APIs working as connector/bridge
    """

    def replace_request_path(self, api_path):
        """
        returns parsed url obj with replaced url path
        """
        if request.full_path:
            request_path = request.full_path
            return urlparse(request_path)._replace(path=api_path)
        return False

    def get_request_data(self):
        """
        returns request_data obtained from request obj
        """
        request_data = {}
        if request.json:
            request_data.update(request.json)
        if request.form:
            request_data.update(request.form)
        if request.args:
            request_data.update(request.args)
        return request_data

    def set_new_request(self, request_data, new_path):
        """
        returns new request obj created from:
        - request_data
        - php api path
        - basic auth for php api
        """
        return Request(
            request.method,
            url='{}{}'.format(current_app.config.get('PHP_WL_BASE_URL'), new_path.geturl()),
            data=request_data,
            auth=HTTPBasicAuth('prototype', PHP_BASIC_AUTH_CREDENTIALS.get('prototype'))
        )

    def get_response_from_request(self, _request):
        """
        send request and returns response obj
        """
        session_obj = Session()
        prepared_request = _request.prepare()
        return session_obj.send(prepared_request)
