"""
Offer Coupon Code Repository
"""
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal

__author__ = "Zaheer"


class OfferCouponCodeRepository(BaseRepository):
    """
    Repo for offer coupon code API which holds all the helper methods required.
    """

    def get_item_code(self, offer_id):
        """
        Gets Item Code
        :param int offer_id: offer id
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select(["item_code"])
        sql_dal.from_(['offer_wl_active'])
        sql_dal.where({'id': offer_id})
        item_code = sql_dal.get_one(default={})
        return item_code.get('item_code')

    def get_coupon_code(self, item_code, offer_id, redemption_id):
        """
        Gets the coupon code.
        :param str item_code: item code of item
        :param int offer_id: id of the offer
        :param int redemption_id: id of redemption
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select(['coupon_code'])
        sql_dal.from_(['offer_coupon_code'])
        sql_dal.where({
            'item_code': item_code,
        })
        sql_dal.set_parenthesised_where_clause(' AND redemption_id is Null')
        coupon = sql_dal.get_one(default={})
        coupon = coupon.get("coupon_code")
        sql_dal.clear()

        # Update coupon code table
        data = {
            'redemption_id': redemption_id,
            'offer_id': offer_id
        }
        sql_dal.where({'coupon_code': coupon})
        sql_dal.update('offer_coupon_code', data)
        return coupon
