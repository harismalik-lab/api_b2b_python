"""
WL Tabs Repository
"""
from collections import OrderedDict
from operator import itemgetter

from common_white_label.common_helpers import check_value_true_or_false, get_hsbc_fine_dining_skus
from repositories_white_label.base_repo import BaseRepository
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.wl_categories_repo import CategoriesRepositoryWl
from wrapper_white_labels.sql_dal import SqlDal


class WlTabsRepository(BaseRepository):
    """
    Tabs repository for outlets
    """
    TAB_UID_ALL_OFFERS = "all_offers"
    TAB_UID_DELIVERY = "delivery"
    TAB_UID_CHEERS = "cheers"
    TAB_UID_MONTHLY = "monthly"
    TAB_UID_MORESA = "more_sa"
    TAB_UID_BUY_MORE = "buy_more"
    TAB_UID_COMPANY_SPECIFIC = "company_specific"

    TAB_SECTION_TYPE_ALL_OFFERS = 1
    TAB_ORDER_ALL_OFFERS = 1

    VALUE = ["1", 1, "true", True]
    NEGATIVE_VALUE = ["0", 0, "false", False]
    TRANSLATION_MANGER = TranslationManager()

    def get_outlet_tabs(self, company, category, is_cuckoo, locale, location_id, product_ids, show_buy_more_tab,
                        hsbc_black_card_holder):
        """
        Contains list of all tabs associated with company and outlet
        :param str company: company name shortcode
        :param str category: category of outlet
        :param boolean is_cuckoo:
        :param str locale: language shortcode
        :param str location_id: location information
        :param list product_ids: list of products
        :param boolean show_buy_more_tab: to display more products
        :param boolean hsbc_black_card_holder: check against hsbc card
        :rtype: object info of tab
        """
        tabs = []
        tabs_list = []
        sql_dal = SqlDal()
        sql_dal.select(['*'])
        sql_dal.from_(['wl_tabs'], ['t'])
        where_dict_clause = OrderedDict()
        where_dict_clause['t.wl_company'] = company
        where_dict_clause['t.locale'] = locale
        sql_dal.where(where_dict_clause)
        sql_dal.order_by({'t.order': 'ASC'})
        tab_names = sql_dal.get(default=[])
        if tab_names:
            sql_dal = SqlDal()
            sql_dal.select([
                'MAX(p.ismember) as is_member',
                'MAX(p.is_cheers) as is_cheers',
                'MAX(p.delivery_enabled) as is_delivery',
                'MAX(p.is_more_sa) as is_more_sa'
            ])
            sql_dal.from_(['product'], ['p'])
            sql_dal.inner_join('wlproducts as wl', 'wl.product_sku', 'p.sf_id')
            if product_ids:
                sql_dal.where_in('p.id', product_ids)
            where_dict_clause = OrderedDict()
            where_dict_clause['p.isactive'] = True
            where_dict_clause['wl.active'] = True
            where_dict_clause['wl.wl_company'] = company

            if category == CategoriesRepositoryWl.category_API_Name_Travel:
                where_dict_clause['p.location_id'] = 0
                show_buy_more_tab = False
            else:
                where_dict_clause['p.location_id'] = location_id

            if is_cuckoo or category != CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars:
                where_dict_clause['p.is_cheers'] = 0
                where_dict_clause['p.delivery_enabled'] = 0
            sql_dal.where(where_dict_clause)
            product_types = sql_dal.get_one(default={})

            for tab_name in tab_names:
                if product_types:
                    if (
                        check_value_true_or_false(product_types.get('is_member')) and
                        tab_name.get('type') == self.TAB_UID_MONTHLY
                    ):
                        tabs_list.append(tab_name)
                    if (
                        check_value_true_or_false(product_types.get('is_cheers')) and
                        tab_name.get('type') == self.TAB_UID_CHEERS
                    ):
                        tabs_list.append(tab_name)
                    if (
                        check_value_true_or_false(product_types.get('is_delivery')) and
                        tab_name.get('type') == self.TAB_UID_DELIVERY
                    ):
                        tabs_list.append(tab_name)
                    if (
                        check_value_true_or_false(product_types.get('is_more_sa')) and
                        tab_name.get('type') == self.TAB_UID_MORESA
                    ):
                        tabs_list.append(tab_name)
                    if (
                        show_buy_more_tab and
                        tab_name.get('type') == self.TAB_UID_BUY_MORE
                    ):
                        tabs_list.append(tab_name)

                if tab_name.get('type') not in [
                    self.TAB_UID_MONTHLY, self.TAB_UID_CHEERS, self.TAB_UID_DELIVERY,
                    self.TAB_UID_MORESA, self.TAB_UID_BUY_MORE
                ]:
                    tabs_list.append(tab_name)
                    if (
                            hsbc_black_card_holder and
                            location_id == 1 and
                            category == CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars
                    ):
                        sku_list = '|'.join(get_hsbc_fine_dining_skus())
                        tab_list = dict()
                        tab_list["locale"] = locale
                        tab_list["name"] = "FINE DINING"
                        tab_list["order"] = 3
                        tab_list["params"] = "redeemability=redeemable_reusable,is_delivery=False,product_sku={sku_list}".format(sku_list=sku_list)  # noqa : E501
                        tab_list["type"] = self.TAB_UID_ALL_OFFERS
                        tab_list["type_id"] = self.TAB_SECTION_TYPE_ALL_OFFERS
                        tabs_list.append(tab_list)

        if not tabs_list:
            tab_list = OrderedDict()
            tab_list["locale"] = locale
            tab_list["name"] = self.TRANSLATION_MANGER.get_translation(self.TRANSLATION_MANGER.tab_name_all_offers)
            tab_list["order"] = self.TAB_ORDER_ALL_OFFERS
            tab_list["params"] = "redeemability=redeemable_reusable"
            tab_list["type"] = self.TAB_UID_ALL_OFFERS
            tab_list["type_id"] = self.TAB_SECTION_TYPE_ALL_OFFERS
            tabs_list.append(tab_list)

        tabs_list = sorted(tabs_list, key=itemgetter('order'))

        for tab_list in tabs_list:
            params = dict()
            params_array = tab_list["params"].split(",")
            for param_array in params_array:
                param = param_array.split("=")
                if len(param):
                    param[1] = check_value_true_or_false(param[1])
                    params[param[0]] = param[1]
            tabs.append({
                'section_type': tab_list.get("type_id"),
                'order': tab_list.get("order"),
                'uid': tab_list.get("type"),
                'name': tab_list.get("name"),
                'params': params
            })
        return tabs
