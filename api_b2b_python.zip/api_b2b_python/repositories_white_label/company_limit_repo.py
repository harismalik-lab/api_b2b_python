from flask import g, request
from flask_jwt_extended.view_decorators import ctx_stack

from common_white_label.db import DEFAULT as ENTERTAINER_WEB
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal

cache = g.cache


class CompanyLimit(BaseRepository):
    """
    Repo for company_limit for app's all APIs.
    """
    def set_jwt_identity(self):
        """
        decode jwt identity from jwt token and set ctx_stack with jwt_identity
        """
        from user_authentication_white_label.authentication import decode_jwt_from_header
        # if auth type is basic, skip jwt decoding
        if not request.authorization:
            jwt_data = decode_jwt_from_header()
            ctx_stack.top.jwt_identity = jwt_data
            if jwt_data.get('error_msg'):
                return False
        return True

    def get_company_limit_from_stack(self):
        """

        :return:
        """
        try:
            return getattr(ctx_stack.top, 'jwt_identity').get('company_limit')
        except:
            return 0

    def get_company_code(self):
        """
        :return: company code from ctx_stack else return from request.args
        """
        try:
            return ctx_stack.top.jwt_identity.get('wlcompany')
        except:
            return

    @cache.memoize(timeout=300)  # cache for 5 minutes
    def get_company_limit(self, company_code):
        """
        Returns company limit
        :param str company_code: company
        """
        if company_code:
            sql_dal = SqlDal()
            sql_dal.select(['per_minute'])
            sql_dal.from_(['wl_company_api_configuration'])
            sql_dal.where({'company_code': company_code})
            result = sql_dal.get_one(default={})
            if result:
                return result.get('per_minute')
        return 0

    def validate_company_by_api_token(self, wlcompany="", api_token=""):
        """
        validates a company
        :param str wlcompany: company code
        :param str api_token: api token
        """
        if wlcompany and api_token:
            sql_dal = SqlDal(connection=ENTERTAINER_WEB)
            sql_dal.select('is_active')
            sql_dal.from_('wl_company_api_configuration')
            sql_dal.where({
                "company_code": wlcompany,
                "api_token": api_token
            })
            result = sql_dal.get_one(default={})
            if result:
                return result.get('is_active')
        return False

    def get_api_token(self, wlcompany=""):
        """
        Returns api_token from wl_company_limit table
        :param str wlcompany: company code
        :param str api_token: api token
        """
        if wlcompany:
            sql_dal = SqlDal(connection=ENTERTAINER_WEB)
            sql_dal.select('api_token')
            sql_dal.from_('wl_company_api_configuration')
            sql_dal.where({
                "company_code": wlcompany,
                "is_active": 1
            })
            result = sql_dal.get_one(default={})
            return result.get('api_token')
        return False

    @staticmethod
    # @cache.memoize(timeout=300)
    def validate_company(wlcompany, api_token):
        """
        Returns Secret Key and company limit based on wlcompany and api token
        :param str wlcompany: company code
        :param str api_token: api token
        :rtype str
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        if wlcompany:
            sql_dal.select(['secret_key', 'per_minute'])
            sql_dal.from_('wl_company_api_configuration')
            sql_dal.where({
                "company_code": wlcompany,
                "is_active": 1,
                "api_token": api_token
            })
            result = sql_dal.get_one(default={})
            return result
        return False
