"""
Feed AppBoy Repository
"""
from common_white_label.db import CONSOLIDATION
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class FeedRepository(BaseRepository):
    """
    Feed Repository
    """

    def add_appboy_feed(self, data):
        """
        Inserts the data in the app boy table
        :param str company: company of the user
        :param int user_id: id of customer
        :param str platform: platform from where user logged in.
        :rtype: bool
        """
        if data:
            sql_dal = SqlDal(connection=CONSOLIDATION)
            columns = list(data.keys())
            data = list(data.values())
            sql_dal.insert('appboy_data', columns=columns, values=data)
            return True
        else:
            return False
