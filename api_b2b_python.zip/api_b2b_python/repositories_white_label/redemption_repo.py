"""
Redemption Repository
"""
import math

from flask import current_app

from common_white_label.common_helpers import list_to_str_tuple
from common_white_label.db import DEFAULT as ENTERTAINER_WEB
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class RedemptionRepositoryWhiteLabel(BaseRepository):
    """
    Redemption repository white label
    """
    TYPE_DEFAULT = 1
    TYPE_DELIVERY = 2

    ACTIVE = 1
    IN_PROGRESS = 2
    INACTIVE = 3

    def get_root_code(self, product_id, offer_id):
        """
        Gets the root code based on product_id and offer_id.
        :param int product_id: Id of product
        :param int offer_id: Id of offer
        :return: str root_code
        :rtype: str
        """
        sql_dal = SqlDal()
        sql_dal.select(['root_code'])
        sql_dal.from_(['product_offer_wl_active'])
        sql_dal.where({'product_id': product_id, 'offer_id': offer_id})
        return sql_dal.get_one(default={}).get('root_code', '')

    def find_redemptions_count_by_customer(self, *args, **kwargs):
        """
        Find count of redemption made by a customer.
        :param args: []
        :param kwargs: customer_id, company.
        :rtype: int
        """
        if kwargs.get('customer_id', 0):
            sql_dal = SqlDal()
            sql_dal.select(['COUNT(id) as redemptions'])
            sql_dal.from_('redemption')
            sql_dal.where({'customer_id': kwargs.get('customer_id', 0)})
            # sql_dal.where_in('status', [self.ACTIVE, self.IN_PROGRESS], sql_safe=True)
            sql_dal.like('company', kwargs.get('company', ''), enable_start_wild_card=False)
            return sql_dal.get_one(default={}).get('redemptions', 0)
        return 0

    def get_code(self, transaction_id, customer_id):
        """
        Gets code on the basis of transaction_id and customer_id.
        :param str transaction_id: Id of transaction
        :param int customer_id: Id of customer
        :rtype: str
        """
        sql_dal = SqlDal()
        sql_dal.select(['code'])
        sql_dal.from_(['redemption'])
        sql_dal.where({'transaction_id': transaction_id, 'customer_id': customer_id})
        return sql_dal.get_one(default={}).get('code', '')

    def get_redeemed_quantities_for_customer(self, customer_id, company=''):
        """
        Gets the redeemed quantities for customer
        :param int customer_id: Id of customer
        :param str company: Company
        :rtype: dict
        """
        if customer_id:
            sql_dal = SqlDal()
            sql_dal.select(["offer_id", "product_id", "quantity as qty"])
            sql_dal.from_(["redemption"])
            sql_dal.where({"customer_id": customer_id, "company": company})
            sql_dal.where_gt({"quantity": 0})
            redemption_results = sql_dal.get(default=[])
            redemption_quantities = {}
            for redemption in redemption_results:
                # TODO: Improve
                index = "{}_{}".format(redemption['offer_id'], redemption['product_id'])
                if not redemption_quantities.get(index):
                    redemption_quantities[index] = int(redemption['qty'])
                else:
                    redemption_quantities[index] = redemption_quantities.get(index) + int(redemption['qty'])
            return redemption_quantities
        return {}

    def get_code_for_offline_redemption(self, transaction_id, codes):
        """
        Gets code for offline redemption
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select(['code'])
        sql_dal.from_('redemption')
        sql_dal.where({'transaction_id': transaction_id})
        sql_dal.where({'code': codes}, optional=True)
        result = sql_dal.get_one(default={})
        return result.get('code', False)

    def get_redemptions_in_last_xhours_for_offer_for_customer(self, *args, **kwargs):
        """
        Get the redemption by time.
        :param args:
        :param kwargs:
        int customer_id: Customer Id
        int offer_id: Offer Id
        str company: Company
        int number_of_hours: Number of hours
        :rtype: int
        """
        redemptions_count = 0
        try:
            sql_dal = SqlDal()
            sql_dal.select(['id'])
            sql_dal.from_(['redemption'])
            sql_dal.where({
                'customer_id': kwargs.get('customer_id', 0),
                'offer_id': kwargs.get('offer_id', 0)
            })
            sql_dal.like('company', kwargs.get('company', ''))
            sql_dal.set_parenthesised_where_clause(
                'AND DATE_ADD(date_created, INTERVAL {number_of_hours} hour) > CURRENT_TIMESTAMP()'.format(
                    number_of_hours=kwargs.get('number_of_hours', 24)
                )
            )
            return sql_dal.get_count()
        except Exception:
            pass
        return redemptions_count

    def insert_redemption_instance_data(self, data={}):
        """
        Insert data in the redemption table
        :param: data in the dictionary format
        :rtype: int | bool
        """
        try:
            sql_dal = SqlDal(connection=ENTERTAINER_WEB)
            columns = list(data.keys())
            _values = list(data.values())
            last_row_id = sql_dal.insert('redemption', columns=columns, values=_values, last_row_id=True)
            return last_row_id
        except Exception:
            return False

    def get_redeemed_quantites_for_customer(
            self, customer_id, is_onboarding=False, offer_id=None, company=None, primary_user_id=0, family_id=0
    ):
        """
        Gets redeemed quantities
        :param int customer_id: Customer id
        :param bool is_onboarding: Is onboarding flag
        :param int offer_id: Offer id
        :param str company: White label client
        :param int primary_user_id: Primary user id
        :param int family_id: Family id
        :rtype: list
        """
        assert (family_id and primary_user_id) or customer_id, 'Insufficient params'
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select(["r.offer_id", "SUM(r.quantity) qty"])
        sql_dal.from_(["redemption"], ["r"])
        if current_app.config.get('IS_PRODUCTION'):
            sql_dal.where_gte('r.id', 31820843)
        sql_dal.like("r.company", "entertainer", enable_start_wild_card=False)
        if primary_user_id == customer_id:
            sql_dal.set_parenthesised_where_clause(' AND (r.primary_user_id={customer_id} OR'
                                                   ' (r.customer_id={customer_id} AND'
                                                   ' COALESCE(r.primary_user_id, 0) = 0)) AND'
                                                   ' r.is_shared=0', {'customer_id': customer_id}
                                                   )
        elif primary_user_id:
            # To handle birthday case
            sql_dal.set_parenthesised_where_clause(
                " AND r.is_shared=0 AND "
                "coalesce(r.is_birthday_offer,0) = 0 AND"
                " (r.primary_user_id = {primary_user_id} or"
                " (r.customer_id  = {primary_user_id} and  coalesce(r.primary_user_id,0) = 0))  ",
                {"primary_user_id": primary_user_id}
            )
        else:
            sql_dal.set_parenthesised_where_clause(' AND (r.primary_user_id={customer_id} OR '
                                                   '(r.customer_id={customer_id} AND'
                                                   ' COALESCE(r.primary_user_id, 0)=0)) AND'
                                                   ' r.is_shared=0', {'customer_id': customer_id}
                                                   )
        if not is_onboarding:
            sql_dal.where("r.is_onboarding", 0)
        if offer_id:
            if isinstance(offer_id, list):
                sql_dal.where_in('r.offer_id', offer_id, sql_safe=True)
            else:
                sql_dal.where('r.offer_id', offer_id)
        if company:
            sql_dal.like('r.company', company, enable_start_wild_card=False)
        sql_dal.where_in('r.status', [self.ACTIVE, self.IN_PROGRESS], sql_safe=True)
        sql_dal.group_by(["r.offer_id"])
        redemption_quantities = {}
        redemption_results = sql_dal.get(default=[])
        for redemption in redemption_results:
            redemption_quantities[redemption['offer_id']] = int(redemption['qty'])
        return redemption_quantities

    def get_redemption_code(self, initial_code):
        """
        Handle scenario when index exceeds 25
        """
        alphabets = [
            "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",
            "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"
        ]
        if initial_code > 25:
            return 'A' + alphabets[initial_code % 26]
        else:
            return alphabets[initial_code]

    def generate_redemption_code(self, redemption_id, redemption_type=1, code_prefix=None):
        """
        Generates redemption code
        """
        code = "Invalid Id."
        if redemption_id and redemption_id > 0:
            factor = 999999999
            initial_code = math.floor((redemption_id - 1) / factor)

            if redemption_id % factor == 0:
                code = factor
            else:
                code = '%09d' % (redemption_id % factor)

            if redemption_type == self.TYPE_DELIVERY:
                code_prefix = "DLC"
            else:
                code_prefix = code_prefix or self.get_redemption_code(initial_code)
            code = str(code)
            code = '{}-{}-{}-{}'.format(code_prefix, code[0:3], code[3:6], code[6:9])
        return code

    def get_code_for_offline_redemption_list(self, transaction_ids, codes):
        """
        Gets the codes for offline redemption
        :param transaction_ids: ids of transaction
        :param codes: codes
        :param customer_id: customer id
        :param get_new_code: if new code needed
        :return: Codes
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select(['GROUP_CONCAT(code) as codes'])
        sql_dal.from_('redemption')
        sql_dal.set_parenthesised_where_clause(
            "(transaction_id in {transaction_ids} OR code in {codes})",
            {
                'transaction_ids': list_to_str_tuple(transaction_ids),
                'codes': list_to_str_tuple(codes)
            }
        )
        result = sql_dal.get_one(default={})
        if result:
            codes = result.get('codes', '')
            if codes:
                result = list(set(codes.split(',')))
                return result
        return []

    def insert_redemption(self, db_connection=None, redemption_data={}, table='redemption'):
        """
        Inserts redemption data in redemption table
        """
        if db_connection:
            self.db_connection = db_connection
        sql_dal = SqlDal(connection=self.db_connection)
        redemption_id = sql_dal.insert(
            table,
            columns=list(redemption_data.keys()),
            values=list(redemption_data.values()),
            last_row_id=True
        )
        return redemption_id

    def update_redemption_code(self, redemption_id=None, redemption_changes={}):
        """
        Update redemption code after redeeming offer
        :param int redemption_id: redemption id
        :param dict redemption_changes: redemption update
        :return:
        """

        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        if redemption_id and redemption_changes:
            sql_dal.where({'id': redemption_id})
            sql_dal.update('redemption', changes=redemption_changes)
