"""
Outlet repository public api white labels
"""
import math
from collections import OrderedDict
from operator import itemgetter

from flask import g

from common_white_label.common_helpers import CommonHelpers, OfferManager
from common_white_label.constants import GlobalConstants
from repositories_white_label.base_repo import BaseRepository
from repositories_white_label.merchant_repo import MerchantRepositoryWl
from repositories_white_label.wl_categories_repo import CategoriesRepositoryWl
from repositories_white_label.wl_company_repo import WLCompany
from wrapper_white_labels.sql_dal import SqlDal

cache = g.cache


class OutletRepositoryWl(BaseRepository):
    """
    Gets Outlet attribute values for outlets associated
    """
    MAX_OUTLETS = 60

    CATEGORY_NAME_RESTAURANTS_AND_BARS = 'Restaurants and Bars'
    ANALYTICS_CATEGORY_CODE_RESTAURANTS_AND_BARS = "FD"

    ANALYTICS_CATEGORY_CODES_DICT = {
        CATEGORY_NAME_RESTAURANTS_AND_BARS.lower(): ANALYTICS_CATEGORY_CODE_RESTAURANTS_AND_BARS
    }

    DEALS_SECTION = 'deals'

    def find_by_merchant(self, merchant_id, location_id=0, latlong='0,0', locale='en', **kwargs):
        """
        Find active outlets by merchant and other optional criteria.
        :param int merchant_id: id of merchant
        :param int location_id: id of location
        :param str latlong: String of latitude and longitude appended by coma
        :param str locale: locale language
        :rtype: list
        """
        sql_dal = SqlDal()
        columns = [
            'o.id', 't.name', 't.description', 'o.email', 'o.telephone', 'o.lat', 'o.lng',
            'COALESCE(o.delivery_telephone, "") as delivery_telephone',
            't.human_location', 't.neighborhood', 't.mall', 't.hotel', "'0' distance",
            "COALESCE(o.merlin_url, '') as merlin_url"
        ]
        sql_dal.select(columns)
        sql_dal.from_(['outlet'], ['o'])
        sql_dal.left_join('outlet_translation AS t', 'o.id', 't.outlet_id')
        sql_dal.inner_join('outlet_offer', 'outlet_offer.outlet_id', 'o.id')
        sql_dal.inner_join('offer AS offers', 'offers.id', 'outlet_offer.offer_id')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['o.merchant_id'] = merchant_id
        ordered_where_clause['o.active'] = 1
        ordered_where_clause['t.locale'] = locale
        # Filter down by location
        if location_id:
            ordered_where_clause['o.location_id'] = location_id
        sql_dal.where(ordered_where_clause)
        sql_dal.group_by(['o.id'])
        sql_dal.order_by({'t.name': "ASC"})
        outlets = sql_dal.get(default=[])
        self.inject_distances_and_sort(outlets, latlong)
        return sorted(outlets, key=itemgetter('distance'))

    def parse_list(self, __categories, cuisine=False):
        _categories_processed = []
        try:
            _categories = __categories.split(';')
            for _category in _categories:
                if _category:
                    _categories_processed.append(_category)
        except Exception:
            return []
        if cuisine:
            return _categories_processed
        _categories_processed = OfferManager().sort_categories(_categories_processed)
        return _categories_processed

    def inject_distances_and_sort(self, outlets, target_lat_long='0,0'):
        """
        Here we do some calculations on latitude and longitude and sort result on basis of that calculation.
        :param list outlets: List of outlet dicts
        :param str target_lat_long: String of latitude and longitude appended by coma
        """
        if target_lat_long and target_lat_long not in ['0,0', '0.0,0.0']:
            target_lat_long = list(map(float, target_lat_long.split(',')))
            for outlet in outlets:
                outlet['lat'], outlet['lng'] = (float(outlet['lat'] if outlet['lat'] is not None else 0),
                                                float(outlet['lng'] if outlet['lng'] is not None else 0))
                # Distance between outlet and target in meters
                outlet['distance'] = round(
                    math.acos(
                        math.cos(math.radians(90.0 - target_lat_long[0])) *
                        math.cos(math.radians(90.0 - outlet['lat'])) +
                        math.sin(math.radians(90.0 - target_lat_long[0])) *
                        math.sin(math.radians(90.0 - outlet['lat'])) *
                        math.cos(math.radians((target_lat_long[1] - outlet['lng'])))
                    ) * 6371.0 * 1000.0
                )

    def find_by_criteria_merchant_attributes(self, merchant_criteria={}, locale='en', **kwargs):
        """
        Gets merchant against a given criteria.
        :param merchant_criteria: criteria to find merchant
        :param str locale: locale language
        :param kwargs: key word arguments
        :rtype: list
        """
        criteria = {
            'lat': 0,
            'lng': 0,
            'radius': 5000,
            'category': 'All',
            'cuisine': 'All',
            'sort': 'default',
            'query': False,
            'query_type': 'name',
            'neighborhood': False,
            'mall': False,
            'hotel': False,
            'billing_country': False,
            'outlet_ids': False
        }
        filtered_outlets = []
        criteria.update(merchant_criteria)
        category = criteria['category']
        cuisine_filter = criteria['cuisine_filter']
        filters_selected_for_yes = criteria['filters_selected_for_yes']
        filters_selected_for_no = criteria['filters_selected_for_no']
        merchant_attributes = []
        lat_lng_exists = False
        if all([criteria['lat'], criteria['lat'] != '0,0', criteria['lng'], criteria['lng'] != ',']):
            lat_lng_exists = True

        sql_dal = SqlDal()
        sql_dal.select([
            'o.id', 'o.sf_id AS sfId', 't.name', 'o.email', 'o.telephone', 'o.lat', 'o.lng', 't.human_location',
            't.neighborhood', 't.mall', 't.hotel',
            "CASE WHEN o.ta_location_id is null THEN 0 ELSE o.ta_location_id END as tripadvisor_id"  # check this
        ])
        if lat_lng_exists:
            select_lat_lng = "acos(cos(radians(90.0-({lat}))) * cos(radians(90.0-(o.lat))) " \
                             "+ sin(radians(90.0-({lat}))) * sin(radians(90.0-(o.lat))) " \
                             "* cos(radians(({lng})-(o.lng))))*6371000.0 distance"
            select_lat_lng = select_lat_lng.format(lat=criteria['lat'], lng=criteria['lng'])
            sql_dal.select([select_lat_lng])
        else:
            sql_dal.select(['"0" distance'])
        sql_dal.select([
            'm.id as merchant_id', 'mt.name as merchant_name', 'mt.name as merchant_name_for_outlet',
            'm.category as merchant_category', 'm.categories as merchant_categories',
            'COALESCE(mt.cuisine, "") as merchant_cuisine', 'm.cuisines as merchant_cuisines',
            '"" as merchant_ad_travel_country', 'true as merchant_ad_active_status',
            'm.logo_retina_url as merchant_logo_url', 'm.logo_non_retina_url as merchant_logo_small_url',
            'm.photo_retina_url as merchant_photo_url', 'm.photo_non_retina_url as merchant_photo_small_url',
        ])
        sql_dal.from_(['outlet'], ['o'])
        sql_dal.inner_join('outlet_translation AS t', 'o.id', 't.outlet_id')
        sql_dal.inner_join('merchant AS m', 'o.merchant_id', 'm.id')
        sql_dal.inner_join('merchant_translation AS mt', 'm.id', 'mt.merchant_id')
        sql_dal.where({'o.active': 1, 't.locale': locale, 'mt.locale': locale})
        include_merchant_attributes = False
        if any([(filters_selected_for_yes and filters_selected_for_yes[0] != ''), (
                filters_selected_for_no and filters_selected_for_no[0] != '')]):
            include_merchant_attributes = True

        is_category_matched = False
        if include_merchant_attributes and category:
            inner_join_table = ''
            if category == CategoriesRepositoryWl.category_API_Name_Body:
                is_category_matched = True
                merchant_attributes = MerchantRepositoryWl.merchant_attributes_body
                inner_join_table = 'merchant_attributes_body AS ma'
            elif category == CategoriesRepositoryWl.Leisure:
                is_category_matched = True
                merchant_attributes = MerchantRepositoryWl.merchant_attributes_leisure
                inner_join_table = ' merchant_attributes_leisure AS ma'
            elif category == CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars:
                is_category_matched = True
                merchant_attributes = MerchantRepositoryWl.merchant_attributes_restaurants_and_bars
                inner_join_table = ' merchant_attributes_restaurants_and_bars AS ma'
            elif category == CategoriesRepositoryWl.category_API_Name_Services:
                is_category_matched = True
                merchant_attributes = MerchantRepositoryWl.merchant_attributes_services
                inner_join_table = ' merchant_attributes_services AS ma'
            elif category == CategoriesRepositoryWl.category_API_Name_Travel:
                is_category_matched = True
                merchant_attributes = MerchantRepositoryWl.merchant_attributes_travel
                inner_join_table = 'merchant_attributes_travel AS ma'

            if inner_join_table:
                sql_dal.inner_join(inner_join_table, 'ma.merchant_id', 'm.id')

            if is_category_matched:
                for include_filter in filters_selected_for_yes:
                    if include_filter in merchant_attributes:
                        sql_dal.where_in('ma.{}'.format(include_filter), [1, 2])

                for exclude_filter in filters_selected_for_no:
                    if exclude_filter in merchant_attributes:
                        sql_dal.where_in('ma.{}'.format(exclude_filter), [0, 2])

        if criteria['outlet_ids']:
            sql_dal.where_in('o.id', criteria['outlet_ids'], sql_safe=True)
        if criteria['billing_country']:
            sql_dal.where('o.billing_country', criteria['billing_country'])
        if criteria['neighborhood']:
            sql_dal.where('t.neighborhood', criteria['neighborhood'])
        if criteria['mall']:
            sql_dal.where('t.mall', criteria['mall'])
        if criteria['hotel']:
            sql_dal.where('t.hotel', criteria['hotel'])

        #  Filter down by radius around latlong
        if lat_lng_exists and criteria['radius']:
            sql_dal.having('distance', criteria['radius'], '<=')
        outlets = sql_dal.get(default=[])
        merchant_fields = [
            'id', 'name', 'name_for_outlet', 'description', 'category', 'categories', 'cuisine', 'cuisines',
            'categories_analytics', 'ad_travel_country', 'ad_active_status', 'logo_url', 'logo_small_url', 'photo_url',
            'photo_small_url'
        ]

        for outlet in outlets:
            outlet['merchant_categories'] = self.parse_list(outlet.get('merchant_categories', []))
            outlet['merchant_cuisines'] = self.parse_list(outlet.get('merchant_cuisines', []), cuisine=True)
            outlet['merchant_categories_analytics'] = CategoriesRepositoryWl().get_analytics_codes_against_categories(
                outlet['merchant_categories']
            )
            outlet['tripadvisor_id'] = str(outlet.get('tripadvisor_id'))
            merchant = {}
            outlet['description'] = ""
            outlet['merchant_description'] = ""

            for field in merchant_fields:
                merchant[field] = outlet['merchant_{}'.format(field)]
                if field == 'ad_active_status':
                    merchant[field] = merchant.get(field, 0) > 0
                del outlet['merchant_{}'.format(field)]
            if outlet.get('name') and 'Ritz-Carlton' not in outlet.get('name'):
                outlet_name_parts = outlet['name'].split('-')
                outlet['name'] = outlet_name_parts[-1].strip()

            if category:
                if all([category in merchant['categories'], category in CategoriesRepositoryWl().get_valid_categories()]):
                    merchant['category'] = category

            merchant['name_for_outlet'] = merchant['name']
            outlet['merchant_name'] = merchant['name']
            outlet['merchant'] = merchant
            if outlet.get('distance'):
                # implicit cast to int, as value is in meters
                outlet['distance'] = round(int(outlet.get('distance', 0)))
            else:
                outlet['distance'] = 0
            if outlet['id'] in criteria['fuzzy_search_outlet_id_score']:
                outlet['fuzzy_relevance'] = criteria['fuzzy_search_outlet_id_score'][outlet['id']]
            else:
                outlet['fuzzy_relevance'] = 0

            # updated cuisine filter to merchant level
            if cuisine_filter and cuisine_filter[0]:
                is_cuisine_matched = False
                for cuisine in cuisine_filter:
                    # change merchant_cuisines to lower case
                    if cuisine.strip().lower() in map(lambda x: x.lower(), outlet['merchant']['cuisines']):
                        is_cuisine_matched = True
                        break
                if not is_cuisine_matched:
                    continue
            filtered_outlets.append(outlet)
        return filtered_outlets

    def get_country_areas(self, location_id=False, locale='en', search_keyword="", category="", product_sku=None):
        """
        Grab Outlet attribute values for Outlets associated with Active Offers for the Products that
        are assigned for the supplied Location.
        """
        sql_dal = SqlDal()
        sql_dal.select([
            "DISTINCT CONCAT(ott.neighborhood,', ', ct.name) AS item", "ott.neighborhood", "ct.name"
        ])
        sql_dal.from_(['offer_wl_active'], ['o'])
        sql_dal.inner_join('product_offer_wl_active AS po', 'o.id', 'po.offer_id')
        sql_dal.inner_join('product as p', 'po.product_id', 'p.id')
        sql_dal.inner_join('outlet_offer AS ot', 'o.id', 'ot.offer_id')
        sql_dal.inner_join('outlet AS otl', 'otl.id', 'ot.outlet_id')
        sql_dal.inner_join('outlet_translation AS ott', 'ot.outlet_id', 'ott.outlet_id')
        sql_dal.inner_join('country AS c', 'c.shortname', 'otl.billing_country')
        sql_dal.inner_join('country_translation AS ct', 'ct.country_id', 'c.id')
        sql_dal.inner_join('merchant AS m', 'o.merchant_id', 'm.id')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['o.status'] = 'Active'
        ordered_where_clause['p.isactive'] = 1
        ordered_where_clause['ott.locale'] = locale
        ordered_where_clause['ct.locale'] = locale
        if product_sku:
            sql_dal.where_in('p.sf_id', product_sku)
        # Determine bundled Product if we're supplied a Location
        # Bundled Products are usually Travel books/bundle given for free with a regular Product
        # Remember: Travel Products have NULL for location_id
        if category.lower() != "all":
            ordered_where_clause['m.category'] = category
        if location_id:
            ordered_where_clause['otl.location_id'] = location_id
            ordered_where_clause['p.location_id'] = location_id
        if search_keyword:
            sql_dal.like('ott.neighborhood', search_keyword)
        sql_dal.where(ordered_where_clause)
        sql_dal.order_by({'item': 'ASC'})
        records = sql_dal.get_distinct(default=[])
        items = []

        for record in records:
            if record['neighborhood']:
                if record['item'].startswith(', ') or record['item'].endswith(', '):
                    record['item'] = record['item'].replace(', ', '')

                if record['neighborhood'] in record['name']:
                    record['item'] = record['neighborhood']
                items.append({'name': record['item'], 'value': record['neighborhood']})
        return items

    def get_country_hotels(self, product_sku, locale='en', search_keyword=""):
        """
        Grab Outlet attribute values for Outlets associated with Active Offers for the Products that are assigned
        for the supplied Location.
        """
        sql_dal = SqlDal()
        sql_dal.select(["DISTINCT CONCAT(ott.hotel,', ', ct.name) AS item", "ott.hotel", "ct.name"])
        sql_dal.from_(['offer_wl_active'], ['o'])
        sql_dal.inner_join('product_offer_wl_active AS po', 'o.id', 'po.offer_id')
        sql_dal.inner_join('product as p', 'po.product_id', 'p.id')
        sql_dal.inner_join('outlet_offer AS ot', 'o.id', 'ot.offer_id')
        sql_dal.inner_join('outlet AS otl', 'otl.id', 'ot.outlet_id')
        sql_dal.inner_join('outlet_translation AS ott', 'ot.outlet_id', 'ott.outlet_id')
        sql_dal.inner_join('merchant AS m', 'o.merchant_id', 'm.id')
        sql_dal.inner_join('country AS c', 'c.shortname', 'otl.billing_country')
        sql_dal.inner_join('country_translation AS ct', 'ct.country_id', 'c.id')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['ott.locale'] = locale
        ordered_where_clause['ct.locale'] = locale
        ordered_where_clause['m.category'] = GlobalConstants.category_API_Name_Travel
        ordered_where_clause['p.isactive'] = 1

        if search_keyword:
            sql_dal.like('ott.hotel', search_keyword)

        ordered_where_clause['o.status'] = 'Active'
        sql_dal.where(ordered_where_clause)
        sql_dal.where_in('p.sf_id', product_sku)
        sql_dal.order_by({'item': 'ASC'})
        records = sql_dal.get_distinct(default=[])
        items = []

        for record in records:
            if record['hotel']:
                if record['item'].startswith(', ') or record['item'].endswith(', '):
                    record['item'] = record['item'].replace(', ', '')

                if record['name'] in record['hotel']:
                    record['item'] = record['hotel']
                items.append({'name': record['item'], 'value': record['hotel']})
        return items

    def get_attribute_values(self, attribute, product_ids, location_id=False, locale='en', search_keyword="", category=""):
        """
        Grab Outlet attribute values for Outlets associated with Active Offers for the Products that are assigned
        for the supplied Location.
        """
        sql_dal = SqlDal()
        sql_dal.select(['ott.{} AS item'.format(attribute)])
        sql_dal.from_(['offer_wl_active'], ['o'])
        sql_dal.inner_join('product_offer_wl_active AS po', 'o.id', 'po.offer_id')
        sql_dal.inner_join('product as p', 'po.product_id', 'p.id')
        sql_dal.inner_join('outlet_offer AS ot', 'o.id', 'ot.offer_id')
        sql_dal.inner_join('outlet AS otl', 'otl.id', 'ot.outlet_id')
        sql_dal.inner_join('outlet_translation AS ott', 'ot.outlet_id', 'ott.outlet_id')
        sql_dal.inner_join('merchant AS m', 'o.merchant_id', 'm.id')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['ott.locale'] = locale
        ordered_where_clause['p.isactive'] = 1

        if category:
            ordered_where_clause['m.category'] = category

        if location_id:
            ordered_where_clause['p.location_id'] = location_id

        if search_keyword:
            sql_dal.like('ott.{}'.format(attribute), search_keyword)

        ordered_where_clause['o.status'] = 'Active'
        sql_dal.where(ordered_where_clause)

        if product_ids:
            sql_dal.where_in('p.id', product_ids)

        sql_dal.order_by({'item': 'ASC'})
        records = sql_dal.get_distinct(default=[])
        items = [record['item'] for record in records]
        return items

    @staticmethod
    @cache.memoize(timeout=1800)
    def get_outlet_attribute_values(company, attribute, location_id=False, locale='en', search_keyword="", category=""):  # noqa E501
        """
        Grab Outlet attribute values for Outlets associated with Active Offers for the Products that are assigned
        for the supplied Location.
        """
        sql_dal = SqlDal()
        sql_dal.select(['ott.{} AS item'.format(attribute)])
        sql_dal.from_(['offer_wl_active'], ['o'])
        sql_dal.inner_join('product_offer_wl_active AS po', 'o.id', 'po.offer_id')
        sql_dal.inner_join('product as p', 'po.product_id', 'p.id')
        sql_dal.inner_join('outlet_offer AS ot', 'o.id', 'ot.offer_id')
        sql_dal.inner_join('outlet AS otl', 'otl.id', 'ot.outlet_id')
        sql_dal.inner_join('outlet_translation AS ott', 'ot.outlet_id', 'ott.outlet_id')
        sql_dal.inner_join('wlproducts AS wp', 'wp.product_sku', 'p.sf_id')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['ott.locale'] = locale
        ordered_where_clause['p.isactive'] = 1
        ordered_where_clause['wp.wl_company'] = company

        if category:
            ordered_where_clause['m.category'] = category

        if location_id:
            ordered_where_clause['p.location_id'] = location_id

        if search_keyword:
            sql_dal.like('ott.{}'.format(attribute), search_keyword)

        ordered_where_clause['o.status'] = 'Active'
        sql_dal.where(ordered_where_clause)
        sql_dal.order_by({'item': 'ASC'})
        records = sql_dal.get_distinct(default=[])
        items = []
        for record in records:
            if record['item'] is not None and record['item'] != '':
                items.append(record['item'])
        return items

    def is_search_string_found(self, search_in, search_string, is_search_words=False):
        """
        Search the presence of word in string.
        :param str search_in: string in which need to search
        :param str search_string: string to find
        :param bool is_search_words: let us know that search string is single word or combination of words
        :rtype: bool
        """
        search_string = search_string.strip().lower()
        if not is_search_words:
            return search_string in search_in
        else:
            search_words = search_string.split()
            # if search_in i.e offer_name is None then set it to empty string so that code doesn't break
            if not search_in:
                search_in = ''
            for word in search_words:
                if word.strip() and word.strip() not in search_in.lower():
                    return False
            return True

    def get_outlet_info(self, outlet_id):
        """
        Get outlet info
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select(['o.sf_id', ])
        sql_dal.from_(['outlet'], ['o'])
        sql_dal.where({'o.id': outlet_id})
        return sql_dal.get_one(default={})

    def find_by_id_with_country_info(self, outlet_id, locale='en'):
        """
        Finds the outlet by the outlet id on the basis of country
        :param int outlet_id: outlet's id
        :param str locale: language of applicant
        :rtype dict
        """
        sql_dal = SqlDal()
        sql_dal.select(['o.id', 't.name', 't.description', 'o.email', 'o.telephone', 'o.lat', 'o.lng',
                        't.human_location', '"0" distance', 't.neighborhood',
                        'c.name as country'])
        sql_dal.from_('outlet AS o')
        sql_dal.inner_join('outlet_translation as t', 'o.id', 't.outlet_id')
        sql_dal.left_join('country as c', 'o.billing_country', 'c.shortname')
        sql_dal.where({
            't.locale': locale,
            'o.id': outlet_id,
        })
        return sql_dal.get_one(default={})

    def set_images_and_attributes(self, company, outlet, categories, selected_category=''):
        """
        Sets images and attributes
        """
        outlet['attributes'] = []
        self.is_love_dining_outlet = False
        if company == WLCompany.COMPANY_CODE_ENTERTAINER_HSBC:
            get_love_dining_skus = CommonHelpers().get_hsbc_love_dining_skus()

            for sku in outlet['product_sku']:
                if sku in get_love_dining_skus:
                    self.is_love_dining_outlet = True

        if self.is_love_dining_outlet:
            outlet['attributes'].append({
                'type': 'image',
                'value': 'https://s3.amazonaws.com/entertainer-app-assets/icons/ios_63x63.png'
            })

        if company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
            if outlet['is_point_based_offer'] == 1:
                outlet['attributes'].append({
                    'type': 'image',
                    'value': 'https://s3-us-west-2.amazonaws.com/app-assets-whitelabel/gem_point_offer_icon.png'
                })

            if outlet['is_company_specific'] and not outlet['is_monthly']:
                outlet['attributes'].append({
                    'type': 'image',
                    'value': 'https://s3.amazonaws.com/entertainer-app-assets/icons/gem-logo.png'
                })

        if outlet.get('is_new'):
            outlet['attributes'].append({
                'type': 'image',
                'value': 'https://s3.amazonaws.com/entertainer-app-assets/icons/badge_new.png'
            })

        if outlet.get('is_monthly'):
            if company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
                outlet['attributes'].append({
                    'type': 'image',
                    'value': 'https://s3.amazonaws.com/entertainer-app-assets/icons/gem-logo.png'
                })

            else:
                outlet['attributes'].append({
                    'type': 'image',
                    'value': 'https://s3.amazonaws.com/entertainer-app-assets/icons/badge_monthly.png'
                })

        if outlet.get('is_cheers'):
            outlet['attributes'].append({
                'type': 'image',
                'value': 'https://s3.amazonaws.com/entertainer-app-assets/icons/badge_cheers.png'
            })

        if outlet.get('is_delivery'):
            outlet['attributes'].append({
                'type': 'image',
                'value': 'https://s3.amazonaws.com/entertainer-app-assets/icons/badge_delivery.png'
            })

        if outlet.get('is_more_sa'):
            outlet['attributes'].append({
                'type': 'image',
                'value': 'https://s3.amazonaws.com/entertainer-app-assets/icons/badge_more_sa.png'
            })

        if outlet.get('is_shared'):
            outlet['attributes'].append({
                'type': 'image',
                'value': 'https://s3.amazonaws.com/entertainer-app-assets/icons/badge_pinged.png'
            })

        if not outlet.get('ca'):
            for category in outlet['categories']:
                if category != selected_category:
                    outlet['attributes'].append({
                        'type': 'image',
                        'value': OutletRepositoryWl().get_category_badge(category, categories, selected_category)
                    })
                if category == GlobalConstants.category_API_Name_Restaurants_and_Bars:
                    for cuisine in outlet['merchant']['cuisines']:
                        outlet['attributes'].append({
                            'type': 'text',
                            'value': cuisine
                        })

                if category == GlobalConstants.category_API_Name_Travel:
                    # we have list in outlet['sub_categories'] and we need to get index against specific category
                    category_index = [index for index, value in enumerate(outlet['sub_categories']) if value == category]
                    if category_index:
                        outlet['attributes'].append({
                            'type': 'image',
                            'value': outlet['sub_categories'][category_index[0]]
                        })

        if outlet.get('is_featured'):
            outlet['attributes'].append({
                'type': 'image',
                'value': OutletRepositoryWl().get_featured_ribbon_image(outlet['category']),
                'is_featured': True
            })

        if not outlet.get('is_redeemable'):
            if outlet.get('is_purchased'):
                outlet['locked_image_url'] = 'https://s3.amazonaws.com/entertainer-app-assets/icons/locked_outlet_golden.png'  # noqa: E501
            else:
                if company == WLCompany.COMPANY_CODE_MASTER_CARDS:
                    outlet['locked_image_url'] = 'https://s3.amazonaws.com/entertainer-app-assets/icons/locked_outlet_grey_gems.png'  # noqa: E501
                else:
                    outlet['locked_image_url'] = 'https://s3.amazonaws.com/entertainer-app-assets/icons/locked_outlet_grey.png'  # noqa: E501

    def get_category_badge(self, category, categories, selected_category):
        """
        Gets category badge
        """
        for cat in categories:
            if category == cat['api_name'] and selected_category != cat['api_name']:
                return cat['image']
        return ''

    def get_featured_ribbon_image(self, category):
        """
        Gets featured ribbon image
        """
        if category:
            if category == GlobalConstants.category_API_Name_Body:
                return CategoriesRepositoryWl.Featured_Merchant_Icon_URL_Body
            elif category == GlobalConstants.category_API_Name_Leisure:
                return CategoriesRepositoryWl.Featured_Merchant_Icon_URL_Leisure
            elif category == GlobalConstants.category_API_Name_Restaurants_and_Bars:
                return CategoriesRepositoryWl.Featured_Merchant_Icon_URL_RestaurantsandBars
            elif category == GlobalConstants.category_API_Name_Retail:
                return CategoriesRepositoryWl.Featured_Merchant_Icon_URL_Retail
            elif category == GlobalConstants.category_API_Name_Services:
                return CategoriesRepositoryWl.Featured_Merchant_Icon_URL_Services
            elif category == GlobalConstants.category_API_Name_Travel:
                return CategoriesRepositoryWl.Featured_Merchant_Icon_URL_Travel

        else:
            return ""

    @cache.memoize(timeout=900)
    def get_offer_array(self, location_id, category='Restaurants and Bars', locale='en', section='nearby'):
        """
        Returns offers and outlets in a location for a category
        :param int location_id: Location Id
        :param str category: Merchant category
        :param str locale: Locale
        :param str section: section
        :rtype: list
        """
        sql_dal = SqlDal()
        sql_dal.select([
            'o.id', 'o.merchant_category', 'COALESCE(o.sub_category, "") as sub_category', 't.title', 'o.valid_to',
            'o.valid_from valid_from_date', 'o.valid_to expiration_date', 'o.type',
            'o.quantity', 'p.id product_id', 'p.sf_id product_sku', 't.name as offer_name',
            'o.savings_estimate', 'p.is_cheers', 'p.delivery_enabled as is_delivery',
            'p.is_ent as is_entertainer', 'p.is_dummy_product', 'p.show_offers_if_purchased',
            'p.is_freemium', 'p.is_more_sa', 'p.product_type', 'GROUP_CONCAT(DISTINCT ot.id) as outlet_ids',
            '0 AS is_shared', '0 AS top_up_offer', '0 AS is_redeemable', '"not_redeemable" AS redeemability',
            '0 AS times_redeemed', '0 AS is_purchased', 'p.purchase_product_id', 'm.is_for_members_only',
            'p.cashless_delivery_enabled'
        ]).from_(['offer_wl_active'], ['o'])
        sql_dal.inner_join('offer_translation_wl_active AS t', 'o.id', 't.offer_id')
        sql_dal.inner_join('product_offer_wl_active AS po', 'o.id', 'po.offer_id')
        sql_dal.inner_join('product as p', 'po.product_id', 'p.id')
        sql_dal.inner_join('outlet_offer', 'outlet_offer.offer_id', 'o.id')
        sql_dal.inner_join('outlet AS ot', 'ot.id', 'outlet_offer.outlet_id')
        sql_dal.inner_join('merchant AS m', 'o.merchant_id', 'm.id')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['o.merchant_category'] = category
        ordered_where_clause['p.isactive'] = 1
        ordered_where_clause['t.locale'] = locale
        ordered_where_clause['p.location_id'] = location_id
        if section == self.DEALS_SECTION:
            ordered_where_clause['p.is_deals_product'] = 1
        sql_dal.where(ordered_where_clause)
        sql_dal.group_by(['o.id'])
        sql_dal.order_by({'o.type': 'DESC'})
        return sql_dal.get(default=[])

    @cache.memoize(timeout=900)
    def get_outlet_array(self, location_id, category='Restaurants and Bars', locale='en'):
        """
        Returns list of outlets
        :param str category: Merchant category
        :param str locale: Locale
        :rtype: list
        """
        hashed_outlets = {}
        sql_dal = SqlDal()
        sql_dal.select([
            'o.id', 'o.sf_id AS sfId', 't.name', 'o.email',
            'o.telephone', 'o.lat', 'o.lng', 't.human_location', 'mt.address AS merchant_address',
            't.neighborhood', 't.mall', 't.hotel', 'coalesce(o.ta_location_id, 0) AS tripadvisor_id',
            'm.id as merchant_id', 'mt.name merchant_name', 'mt.name as merchant_name_for_outlet',
            'COALESCE(mt.cuisine, "") as merchant_cuisine', 'm.cuisines as merchant_cuisines',
            'COALESCE(m.ad_travel_country, "") as merchant_ad_travel_country',
            'm.ad_active_status as merchant_ad_active_status', 'logo_retina_url AS merchant_logo_url',
            'm.logo_non_retina_url as merchant_logo_small_url', 'm.photo_retina_url as merchant_photo_url',
            'm.photo_non_retina_url as merchant_photo_small_url', 'm.digital_section AS merchant_digital_section'
        ]).from_(['outlet'], ['o'])
        sql_dal.inner_join('outlet_translation AS t', 'o.id', 't.outlet_id')
        sql_dal.inner_join('merchant AS m', 'o.merchant_id', 'm.id')
        sql_dal.inner_join('merchant_translation AS mt', 'm.id', 'mt.merchant_id')
        sql_dal.inner_join('outlet_offer as outlet_offer', 'outlet_offer.outlet_id', 'o.id')
        sql_dal.inner_join('offer_wl_active as offer', 'offer.id', 'outlet_offer.offer_id')
        sql_dal.inner_join('product_offer_wl_active AS po', 'offer.id', 'po.offer_id')
        sql_dal.inner_join('product as p', 'po.product_id', 'p.id')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['o.active'] = 1
        ordered_where_clause['offer.merchant_category'] = category
        ordered_where_clause['p.isactive'] = 1
        ordered_where_clause['mt.locale'] = locale
        ordered_where_clause['t.locale'] = locale
        ordered_where_clause['p.location_id'] = location_id
        sql_dal.where(ordered_where_clause)
        sql_dal.group_by(['o.id'])
        outlets = sql_dal.get(default=[])
        merchant_fields = [
            'id', 'name', 'name_for_outlet', 'cuisine',
            'digital_section', 'ad_travel_country', 'ad_active_status',
            'logo_url', 'logo_small_url', 'photo_url', 'photo_small_url'
        ]
        for outlet in outlets:
            outlet['cuisines'] = self.parse_list(outlet['merchant_cuisines'], cuisine=True)
            outlet['categories'] = self.parse_list(category)

            merchant = {
                'merchant_categories_analytics': self.ANALYTICS_CATEGORY_CODES_DICT.get(
                    category.lower(), ''
                )
            }
            for field in merchant_fields:
                merchant[field] = outlet['merchant_{}'.format(field)]
                del outlet['merchant_{}'.format(field)]

            if outlet.get('name') and 'Ritz-Carlton' not in outlet.get('name'):
                outlet_name_parts = outlet['name'].split('-')
                outlet['name'] = outlet_name_parts[-1].strip()
            merchant['name_for_outlet'] = merchant['name']
            outlet['merchant_name'] = merchant['name']
            merchant['category'] = category
            merchant['categories'] = outlet['categories']
            outlet['merchant'] = merchant
            outlet['distance'] = 0
            outlet['tripadvisor_id'] = str(outlet['tripadvisor_id'])
            hashed_outlets[outlet['id']] = outlet
        return outlets, hashed_outlets
