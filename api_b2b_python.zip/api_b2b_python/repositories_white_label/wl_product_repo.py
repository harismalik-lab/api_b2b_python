"""
WL Product Repository
"""
from datetime import datetime

from flask import current_app, g

from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal

cache = g.cache


class WLProductRepository(BaseRepository):
    MORE_SA_PRODUCT_SKU = 'D18CTMA'
    PRODUCT_SKU_HOT_SUMMMER_NIGHTS = 'D18TRSCCP'
    PRODUCT_TYPE_BIRTHDAY = 1
    MORE_SA_LOCATIONS = [4, 14, 20]

    @staticmethod
    def get_configured_products(company, user_groups=[]):
        """
        Gets the configured products
        :param company: Company of the user
        :param user_groups: user groups
        :return:
        """
        sql_dal = SqlDal()
        product_ids = []
        group_products = dict()
        if user_groups:
            sql_dal.select(['p.id', 's.user_group'])
            sql_dal.from_(['wlproducts'], ['s'])
            sql_dal.inner_join('product as p', 'p.sf_id', 's.product_sku')
            sql_dal.where({'p.isactive': True, 's.wl_company': company})
            sql_dal.where_in('s.user_group', user_groups)
            results = sql_dal.get(default=[])
            for result in results:
                if result.get('user_group') not in group_products.keys():
                    group_products[result.get('user_group')] = [result.get('id')]
                else:
                    group_products[result.get('user_group')].append(result.get('id'))
            for user_group in user_groups:
                product_ids.extend(group_products.get(user_group, []))
        return product_ids

    def get_buy_page_message_url(self, locale, host, platform='ios'):
        """
        Gets the URL for buy page.
        :param str locale: Locale
        :param str host: API Host
        :param str platform: Platform
        :return: dict object: Buy page title and URL
        :rtype: dict
        """
        buy_page_url = current_app.config.get('BUY_PAGE_URL', '')
        if platform.lower() == 'android':
            platform = 'and'
        buy_page_title = "buy_page_title_{locale}".format(locale=locale)
        return {
            'buy_page_title': buy_page_title,
            'buy_page_url': '{buy_page_url}{platform}?{time}&pay_options=true'.format(
                buy_page_url=buy_page_url, platform=platform, time=datetime.now()
            )
        }

    def get_product_price_details(self, company, product_sku, locale, exchange_rates, platform, currency, host):
        """
        Gets the product's price details.
        :param str company: Company
        :param str product_sku: Product sku
        :param str locale: Locale
        :param list exchange_rates: List of exchange rates
        :param str platform: Platform
        :param str currency: Currency
        :param str host: Host
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select(['p.id', 'wlp.price', 'p.currency'])
        sql_dal.from_(['product'], ['p'])
        sql_dal.inner_join('product_wl_active as wlp', 'wlp.product_id', 'p.id')
        sql_dal.where({'p.sf_id': product_sku, 'wlp.company': company})
        product_summary = sql_dal.get(default=[])
        if len(product_summary) < 1:
            return False
        product_summary = product_summary[0]
        buy_page = self.get_buy_page_message_url(locale, host, platform)
        product_summary['buy_page_title'] = buy_page['buy_page_title']
        product_summary['buy_page_url'] = buy_page['buy_page_url']
        product_summary['currency'] = ''

        return product_summary
