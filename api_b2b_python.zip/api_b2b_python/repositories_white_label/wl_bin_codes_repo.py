"""
WL Bin Codes Repository
"""
from common_white_label.db import DEFAULT as ENTERTAINER_WEB
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class WlBinCodesRepository(BaseRepository):
    """
    Repo for wl bin codes repository.
    """
    def get_key_info(self, key, company='MCE'):
        """
        Get key info from table
        :param int key: Key
        :param str company: company of the user
        :rtype: dict
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.from_(['wl_bin_codes'])
        sql_dal.where({'bin': key, 'wl_company': company})
        return sql_dal.get_one(default={})
