"""
Contains OutletRepositoryV67's changed methods for white label apps
"""
from collections import OrderedDict

from flask import g

from python_api.common.common_helpers import list_to_str_tuple
from python_api.repositories.categories_repo import CategoriesRepository
from python_api.repositories.product_ent_active_repo import ProductEntActiveRepository
from python_api.repositories.product_repo import ProductRepository
from python_api.repositories.v_6.outlet_repo import OutletRepositoryV6
from python_api.repositories.v_67.outlet_repo import OutletRepositoryV67
from python_api.wrapper.sql_dal import SqlDal

cache = g.cache


class OutletRepositoryWhiteLabelV67(OutletRepositoryV67):

    @staticmethod
    @cache.memoize(timeout=900)
    def get_offer_array(location_id, category, locale='en', api_version='v67'):
        """
        Returns offers and outlets in a location for a category
        :param int location_id: Location Id
        :param str category: Merchant category
        :param str locale: Locale
        :rtype: list
        """
        sql_dal = SqlDal()
        sql_dal.select([
            'o.id', 'o.merchant_category', 'COALESCE(o.sub_category, "") as sub_category',
            'o.valid_from valid_from_date', 'o.valid_to expiration_date', 'o.type',
            'o.quantity', 'p.id product_id', 'p.sf_id product_sku', 't.name as offer_name',
            'o.savings_estimate', 'p.is_cheers', 'p.delivery_enabled as is_delivery',
            'p.is_ent as is_entertainer', 'p.is_dummy_product', 'p.show_offers_if_purchased',
            'p.is_freemium', 'p.is_more_sa', 'p.product_type', 'GROUP_CONCAT(DISTINCT ot.id) as outlet_ids',
            '0 AS is_shared', '0 AS top_up_offer', '0 AS is_redeemable', '"not_redeemable" AS redeemability',
            '0 AS times_redeemed', '0 AS is_purchased', 'p.purchase_product_id', 'm.is_for_members_only',
            'p.cashless_delivery_enabled'
        ]).from_(['offer_wl_active'], ['o'])
        sql_dal.inner_join('offer_translation_wl_active AS t', 'o.id', 't.offer_id')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['o.merchant_category'] = category
        ordered_where_clause['p.isactive'] = 1
        ordered_where_clause['t.locale'] = locale
        sql_dal.inner_join('product_offer_wl_active AS po', 'o.id', 'po.offer_id')
        sql_dal.inner_join('product as p', 'po.product_id', 'p.id')
        sql_dal.inner_join('outlet_offer', 'outlet_offer.offer_id', 'o.id')
        sql_dal.inner_join('outlets AS ot', 'ot.id', 'outlet_offer.outlet_id')
        sql_dal.inner_join('merchant AS m', 'o.merchant_id', 'm.id')

        if location_id in ProductRepository.MORE_SA_LOCATIONS:
            sql_dal.set_parenthesised_where_clause(
                " AND (p.location_id={location_id} OR p.is_more_sa=1)",
                params_dict={'location_id': location_id}
            )
        else:
            ordered_where_clause['p.location_id'] = location_id

        sql_dal.where(ordered_where_clause)
        sql_dal.group_by(['o.id'])
        sql_dal.order_by({'o.type': 'DESC'})
        return sql_dal.get(default=[])

    @staticmethod
    @cache.memoize(timeout=900)
    def get_outlet_array(location_id, category, locale='en', api_version='v67'):
        """
        Returns list of outlets
        :param str category: Merchant category
        :param str locale: Locale
        :rtype: list
        """
        hashed_outlets = {}
        sql_dal = SqlDal()
        sql_dal.select([
            'o.id', 'o.sf_id AS sfId', 't.name', 'o.email',
            'o.telephone', 'o.lat', 'o.lng', 't.human_location',
            't.neighborhood', 't.mall', 't.hotel', 'coalesce(o.ta_location_id, 0) AS tripadvisor_id',
            'm.id as merchant_id', 'mt.name merchant_name', 'mt.name as merchant_name_for_outlet',
            'COALESCE(mt.cuisine, "") as merchant_cuisine', 'm.cuisines as merchant_cuisines',
            'COALESCE(m.ad_travel_country, "") as merchant_ad_travel_country',
            'm.ad_active_status as merchant_ad_active_status', 'logo_retina_url AS merchant_logo_url',
            'm.logo_non_retina_url as merchant_logo_small_url', 'm.photo_retina_url as merchant_photo_url',
            'm.photo_non_retina_url as merchant_photo_small_url', 'm.digital_section AS merchant_digital_section',
            'd_o_s.disabled as cashless_outlet_settings_enabled'
        ]).from_(['outlets'], ['o'])
        sql_dal.inner_join('outlet_translation AS t', 'o.id', 't.outlet_id')
        sql_dal.inner_join('merchant AS m', 'o.merchant_id', 'm.id')
        sql_dal.inner_join('merchant_translation AS mt', 'm.id', 'mt.merchant_id')
        sql_dal.inner_join('outlet_offer as outlet_offer', 'outlet_offer.outlet_id', 'o.id')
        sql_dal.inner_join('offer as offer', 'offer.id', 'outlet_offer.offer_id')
        sql_dal.inner_join('product_offer_wl_active AS po', 'offer.id', 'po.offer_id')
        sql_dal.inner_join('product as p', 'po.product_id', 'p.id')
        sql_dal.left_join(
            'dm_outlet_setting AS d_o_s', 'd_o_s.outlet_id', "o.id AND d_o_s.disabled=0 AND d_o_s.status=1"
        )
        ordered_where_clause = OrderedDict()
        ordered_where_clause['o.active'] = 1
        ordered_where_clause['offer.merchant_category'] = category
        ordered_where_clause['p.isactive'] = 1
        ordered_where_clause['mt.locale'] = locale
        ordered_where_clause['t.locale'] = locale

        if location_id in ProductRepository.MORE_SA_LOCATIONS:
            sql_dal.set_parenthesised_where_clause(
                " AND (p.location_id={location_id} OR p.is_more_sa=1)",
                params_dict={'location_id': location_id}
            )
        else:
            ordered_where_clause['p.location_id'] = location_id

        sql_dal.where(ordered_where_clause)
        sql_dal.group_by(['o.id'])
        outlets = sql_dal.get(default=[])
        merchant_fields = [
            'id', 'name', 'name_for_outlet', 'cuisine',
            'digital_section', 'ad_travel_country', 'ad_active_status',
            'logo_url', 'logo_small_url', 'photo_url', 'photo_small_url'
        ]
        outlet_repo = OutletRepositoryV6()
        for outlet in outlets:
            outlet['cuisines'] = outlet_repo.parse_list(outlet['merchant_cuisines'], cuisine=True)
            outlet['categories'] = outlet_repo.parse_list(category)

            merchant = {
                'merchant_categories_analytics': CategoriesRepository.ANALYTICS_CATEGORY_CODES_DICT.get(
                    category.lower(), ''
                )
            }
            for field in merchant_fields:
                merchant[field] = outlet['merchant_{}'.format(field)]
                del outlet['merchant_{}'.format(field)]

            if outlet.get('name') and 'Ritz-Carlton' not in outlet.get('name'):
                outlet_name_parts = outlet['name'].split('-')
                outlet['name'] = outlet_name_parts[-1].strip()
            merchant['name_for_outlet'] = merchant['name']
            outlet['merchant_name'] = merchant['name']
            merchant['category'] = category
            merchant['categories'] = outlet['categories']
            outlet['merchant'] = merchant
            outlet['distance'] = 0
            outlet['tripadvisor_id'] = str(outlet['tripadvisor_id'])
            hashed_outlets[outlet['id']] = outlet
        return outlets, hashed_outlets

    def get_country_areas(self, location_id=False, locale='en', search_keyword="", category=""):
        """
        Grab Outlet attribute values for Outlets associated with Active Offers for the Products that
        are assigned for the supplied Location.
        """
        sql_dal = SqlDal()
        sql_dal.select([
            "Concat(Concat(ott.neighborhood,', '), ct.name) AS item", "ott.neighborhood", "ct.name"
        ])
        sql_dal.from_(['offer_wl_active'], ['o'])
        sql_dal.inner_join('product_offer_wl_active AS po', 'o.id', 'po.offer_id')
        sql_dal.inner_join('product as p', 'po.product_id', 'p.id')
        sql_dal.inner_join('outlet_offer AS ot', 'o.id', 'ot.offer_id')
        sql_dal.inner_join('outlets AS otl', 'otl.id', 'ot.outlet_id')
        sql_dal.inner_join('outlet_translation AS ott', 'ot.outlet_id', 'ott.outlet_id')
        sql_dal.inner_join('country AS c', 'c.shortname', 'otl.billing_country')
        sql_dal.inner_join('country_translation AS ct', 'ct.country_id', 'c.id')
        sql_dal.inner_join('merchant AS m', 'o.merchant_id', 'm.id')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['m.category'] = category
        ordered_where_clause['o.status'] = 'Active'
        ordered_where_clause['p.isactive'] = 1
        ordered_where_clause['ott.locale'] = locale
        ordered_where_clause['ct.locale'] = locale
        # Determine bundled Product if we're supplied a Location
        # Bundled Products are usually Travel books/bundle given for free with a regular Product
        # Remember: Travel Products have NULL for location_id
        if location_id:
            ordered_where_clause['otl.location_id'] = location_id
            ordered_where_clause['p.location_id'] = location_id
        if search_keyword:
            sql_dal.like('ott.neighborhood', search_keyword)
        sql_dal.where(ordered_where_clause)
        sql_dal.order_by({'item': 'ASC'})
        records = sql_dal.get_distinct(default=[])
        items = []

        for record in records:
            if record['neighborhood']:
                if record['item'].startswith(', ') or record['item'].endswith(', '):
                    record['item'] = record['item'].replace(', ', '')

                if record['neighborhood'] in record['name']:
                    record['item'] = record['neighborhood']
                items.append({'name': record['item'], 'value': record['neighborhood']})
        return items

    def get_country_hotels(self, location_id=0, locale='en', search_keyword="", category=""):
        """
        Grab Outlet attribute values for Outlets associated with Active Offers for the Products that are assigned
        for the supplied Location.
        """
        sql_dal = SqlDal()
        sql_dal.select(["Concat(Concat(ott.hotel,', '), ct.name) AS item", "ott.hotel", "ct.name"])
        sql_dal.from_(['offer_wl_active'], ['o'])
        sql_dal.inner_join('product_offer_wl_active AS po', 'o.id', 'po.offer_id')
        sql_dal.inner_join('product as p', 'po.product_id', 'p.id')
        sql_dal.inner_join('outlet_offer AS ot', 'o.id', 'ot.offer_id')
        sql_dal.inner_join('outlets AS otl', 'otl.id', 'ot.outlet_id')
        sql_dal.inner_join('outlet_translation AS ott', 'ot.outlet_id', 'ott.outlet_id')
        sql_dal.inner_join('country AS c', 'c.shortname', 'otl.billing_country')
        sql_dal.inner_join('country_translation AS ct', 'ct.country_id', 'c.id')
        sql_dal.inner_join('merchant AS m', 'o.merchant_id', 'm.id')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['ott.locale'] = locale
        ordered_where_clause['ct.locale'] = locale
        ordered_where_clause['p.isactive'] = 1
        if category:
            ordered_where_clause['m.category'] = category
        if str(location_id).isdigit() and int(location_id):
            ordered_where_clause['otl.location_id'] = location_id
            bundled_product_skus = ProductEntActiveRepository().find_bundled_product_skus_by_location(location_id)
            bundled_product_skus = list(set(bundled_product_skus))
            if bundled_product_skus:
                sql_dal.set_parenthesised_where_clause(" AND (p.location_id = {location_id} OR p.sf_id IN {skus})",
                                                       {"location_id": location_id,
                                                        "skus": list_to_str_tuple(bundled_product_skus)})
            else:
                ordered_where_clause['p.location_id'] = location_id

        if search_keyword:
            sql_dal.like('ott.hotel', search_keyword)

        ordered_where_clause['o.status'] = 'Active'
        sql_dal.where(ordered_where_clause)
        sql_dal.order_by({'item': 'ASC'})
        records = sql_dal.get_distinct(default=[])
        items = []

        for record in records:
            if record['hotel']:
                if record['item'].startswith(', ') or record['item'].endswith(', '):
                    record['item'] = record['item'].replace(', ', '')

                if record['name'] in record['hotel']:
                    record['item'] = record['hotel']
                items.append({'name': record['item'], 'value': record['hotel']})
        return items

    def get_attribute_values(self, attribute, location_id=False, locale='en', search_keyword="", category=""):
        """
        Grab Outlet attribute values for Outlets associated with Active Offers for the Products that are assigned
        for the supplied Location.
        """
        sql_dal = SqlDal()
        sql_dal.select(['ott.{} AS item'.format(attribute)])
        sql_dal.from_(['offer_wl_active'], ['o'])
        sql_dal.inner_join('product_offer_wl_active AS po', 'o.id', 'po.offer_id')
        sql_dal.inner_join('product as p', 'po.product_id', 'p.id')
        sql_dal.inner_join('outlet_offer AS ot', 'o.id', 'ot.offer_id')
        sql_dal.inner_join('outlets AS otl', 'otl.id', 'ot.outlet_id')
        sql_dal.inner_join('outlet_translation AS ott', 'ot.outlet_id', 'ott.outlet_id')
        sql_dal.inner_join('merchant AS m', 'o.merchant_id', 'm.id')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['ott.locale'] = locale
        ordered_where_clause['p.isactive'] = 1
        if category:
            ordered_where_clause['m.category'] = category

        if location_id:
            ordered_where_clause['otl.location_id'] = location_id
            ordered_where_clause['p.location_id'] = location_id
            bundled_product_skus = ProductEntActiveRepository().find_bundled_product_skus_by_location(location_id)
            bundled_product_skus = list(set(bundled_product_skus))
            if bundled_product_skus:
                sql_dal.where_in('p.sf_id', bundled_product_skus, sql_safe=True)

        if search_keyword:
            sql_dal.like('ott.{}'.format(attribute), search_keyword)

        ordered_where_clause['o.status'] = 'Active'
        sql_dal.where(ordered_where_clause)
        sql_dal.order_by({'item': 'ASC'})
        records = sql_dal.get_distinct(default=[])
        items = [record['item'] for record in records]
        return items

    def get_attribute_values_malls(self, attribute, location_id=False, locale='en', search_keyword="", category=""):
        """
        Grab Outlet attribute values for Outlets associated with Active Offers for the Products that are assigned
        for the supplied Location.
        """
        sql_dal = SqlDal()
        sql_dal.select(['ott.{} AS item'.format(attribute)])
        sql_dal.from_(['offer_wl_active'], ['o'])
        sql_dal.inner_join('product_offer_wl_active AS po', 'o.id', 'po.offer_id')
        sql_dal.inner_join('product as p', 'po.product_id', 'p.id')
        sql_dal.inner_join('outlet_offer AS ot', 'o.id', 'ot.offer_id')
        sql_dal.inner_join('outlets AS otl', 'otl.id', 'ot.outlet_id')
        sql_dal.inner_join('outlet_translation AS ott', 'ot.outlet_id', 'ott.outlet_id')
        sql_dal.inner_join('merchant AS m', 'o.merchant_id', 'm.id')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['ott.locale'] = locale
        ordered_where_clause['p.isactive'] = 1
        if category:
            ordered_where_clause['m.category'] = category

        if location_id:
            ordered_where_clause['otl.location_id'] = location_id
            bundled_product_skus = ProductEntActiveRepository().find_bundled_product_skus_by_location(location_id)
            bundled_product_skus = list(set(bundled_product_skus))
            if bundled_product_skus:
                sql_dal.set_parenthesised_where_clause(" AND (p.location_id = {location_id} OR p.sf_id IN {skus})",
                                                       {"location_id": location_id,
                                                        "skus": list_to_str_tuple(bundled_product_skus)})
            else:
                ordered_where_clause['p.location_id'] = location_id

        if search_keyword:
            sql_dal.like('ott.{}'.format(attribute), search_keyword)

        ordered_where_clause['o.status'] = 'Active'
        sql_dal.where(ordered_where_clause)
        sql_dal.order_by({'item': 'ASC'})
        records = sql_dal.get_distinct(default=[])
        items = [record['item'] for record in records]
        return items

    def get_outlet_info(self, outlet_id):
        """
        Get outlet info
        :return:
        """
        sql_dal = SqlDal()
        sql_dal.select(['o.sf_id', ])
        sql_dal.from_(['outlet'], ['o'])
        sql_dal.where({'o.id': outlet_id})
        result = sql_dal.get_one(default={})

        return result
