"""
Contains OutletRepositoryWhiteLabel's changed methods for version 67
"""
import math
from collections import OrderedDict
from operator import itemgetter

from python_api.repositories.categories_repo import CategoriesRepository
from python_api.repositories.v_6.merchant_repo import MerchantRepositoryV6
from python_api.wrapper.sql_dal import SqlDal
from repositories_white_label.outlet_repo import OutletRepositoryWhiteLabel


class OutletRepositoryWhiteLabelV67(OutletRepositoryWhiteLabel):

    def find_by_merchant(self, merchant_id, location_id=0, latlong='0,0', locale='en', **kwargs):
        """
        Find active outlets by merchant and other optional criteria.
        :param int merchant_id: id of merchant
        :param int location_id: id of location
        :param str latlong: String of latitude and longitude appended by coma
        :param str locale: locale language
        :rtype: list
        """
        sql_dal = SqlDal()
        columns = [
            'o.id', 't.name', 't.description', 'o.email', 'o.telephone', 'o.lat', 'o.lng',
            'COALESCE(o.delivery_telephone, "") as delivery_telephone',
            't.human_location', 't.neighborhood', 't.mall', 't.hotel', "'0' distance"
        ]
        sql_dal.select(columns)
        sql_dal.from_(['outlet'], ['o'])
        sql_dal.left_join('outlet_translation AS t', 'o.id', 't.outlet_id')
        sql_dal.inner_join('outlet_offer', 'outlet_offer.outlet_id', 'o.id')
        sql_dal.inner_join('offer AS offers', 'offers.id', 'outlet_offer.offer_id')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['o.merchant_id'] = merchant_id
        ordered_where_clause['o.active'] = 1
        ordered_where_clause['t.locale'] = locale
        # Filter down by location
        if location_id:
            ordered_where_clause['o.location_id'] = location_id
        sql_dal.where(ordered_where_clause)
        sql_dal.group_by(['o.id'])
        sql_dal.order_by({'t.name': "ASC"})
        outlets = sql_dal.get(default=[])
        self.inject_distances_and_sort(outlets, latlong)
        return sorted(outlets, key=itemgetter('distance'))

    def inject_distances_and_sort(self, outlets, target_lat_long='0,0'):
        """
        Here we do some calculations on latitude and longitude and sort result on basis of that calculation.
        :param list outlets: List of outlet dicts
        :param str target_lat_long: String of latitude and longitude appended by coma
        """
        if target_lat_long and target_lat_long not in ['0,0', '0.0,0.0']:
            target_lat_long = list(map(float, target_lat_long.split(',')))
            for outlet in outlets:
                outlet['lat'], outlet['lng'] = (float(outlet['lat'] if outlet['lat'] is not None else 0),
                                                float(outlet['lng'] if outlet['lng'] is not None else 0))
                # Distance between outlet and target in meters
                outlet['distance'] = round(
                    math.acos(
                        math.cos(math.radians(90.0 - target_lat_long[0])) *
                        math.cos(math.radians(90.0 - outlet['lat'])) +
                        math.sin(math.radians(90.0 - target_lat_long[0])) *
                        math.sin(math.radians(90.0 - outlet['lat'])) *
                        math.cos(math.radians((target_lat_long[1] - outlet['lng'])))
                    ) * 6371.0 * 1000.0
                )

    def find_by_criteria_merchant_attributes(self, merchant_criteria={}, locale='en', **kwargs):
        """
        Gets merchant against a given criteria.
        :param merchant_criteria: criteria to find merchant
        :param str locale: locale language
        :param kwargs: key word arguments
        :rtype: list
        """
        criteria = {
            'lat': 0,
            'lng': 0,
            'radius': 5000,
            'category': 'All',
            'cuisine': 'All',
            'sort': 'default',
            'query': False,
            'query_type': 'name',
            'neighborhood': False,
            'mall': False,
            'hotel': False,
            'billing_country': False,
            'outlet_ids': False
        }
        filtered_outlets = []
        criteria.update(merchant_criteria)
        category = criteria['category']
        cuisine_filter = criteria['cuisine_filter']
        filters_selected_for_yes = criteria['filters_selected_for_yes']
        filters_selected_for_no = criteria['filters_selected_for_no']
        merchant_attributes = []
        lat_lng_exists = False
        if all([criteria['lat'], criteria['lat'] != '0,0', criteria['lng'], criteria['lng'] != ',']):
            lat_lng_exists = True

        sql_dal = SqlDal()
        sql_dal.select([
            'o.id', 'o.sf_id AS sfId', 't.name', 'o.email', 'o.telephone', 'o.lat', 'o.lng', 't.human_location',
            't.neighborhood', 't.mall', 't.hotel',
            "CASE WHEN o.ta_location_id is null THEN 0 ELSE o.ta_location_id END as tripadvisor_id"  # check this
        ])
        if lat_lng_exists:
            select_lat_lng = "acos(cos(radians(90.0-({lat}))) * cos(radians(90.0-(o.lat))) " \
                             "+ sin(radians(90.0-({lat}))) * sin(radians(90.0-(o.lat))) " \
                             "* cos(radians(({lng})-(o.lng))))*6371000.0 distance"
            select_lat_lng = select_lat_lng.format(lat=criteria['lat'], lng=criteria['lng'])
            sql_dal.select([select_lat_lng])
        else:
            sql_dal.select(['"0" distance'])
        sql_dal.select([
            'm.id as merchant_id', 'mt.name as merchant_name', 'mt.name as merchant_name_for_outlet',
            'm.category as merchant_category', 'm.categories as merchant_categories',
            'COALESCE(mt.cuisine, "") as merchant_cuisine', 'm.cuisines as merchant_cuisines',
            '"" as merchant_ad_travel_country', 'true as merchant_ad_active_status',
            'm.logo_retina_url as merchant_logo_url', 'm.logo_non_retina_url as merchant_logo_small_url',
            'm.photo_retina_url as merchant_photo_url', 'm.photo_non_retina_url as merchant_photo_small_url',
        ])
        sql_dal.from_(['outlet'], ['o'])
        sql_dal.inner_join('outlet_translation AS t', 'o.id', 't.outlet_id')
        sql_dal.inner_join('merchant AS m', 'o.merchant_id', 'm.id')
        sql_dal.inner_join('merchant_translation AS mt', 'm.id', 'mt.merchant_id')
        sql_dal.where({'o.active': 1, 't.locale': locale, 'mt.locale': locale})
        include_merchant_attributes = False
        if any([(filters_selected_for_yes and filters_selected_for_yes[0] != ''), (
                filters_selected_for_no and filters_selected_for_no[0] != '')]):
            include_merchant_attributes = True

        is_category_matched = False
        if include_merchant_attributes and category:
            inner_join_table = ''
            if category == CategoriesRepository.category_API_Name_Body:
                is_category_matched = True
                merchant_attributes = MerchantRepositoryV6.merchant_attributes_body
                inner_join_table = 'merchant_attributes_body AS ma'
            elif category == CategoriesRepository.Leisure:
                is_category_matched = True
                merchant_attributes = MerchantRepositoryV6.merchant_attributes_leisure
                inner_join_table = ' merchant_attributes_leisure AS ma'
            elif category == CategoriesRepository.category_API_Name_Restaurants_and_Bars:
                is_category_matched = True
                merchant_attributes = MerchantRepositoryV6.merchant_attributes_restaurants_and_bars
                inner_join_table = ' merchant_attributes_restaurants_and_bars AS ma'
            elif category == CategoriesRepository.category_API_Name_Services:
                is_category_matched = True
                merchant_attributes = MerchantRepositoryV6.merchant_attributes_services
                inner_join_table = ' merchant_attributes_services AS ma'
            elif category == CategoriesRepository.category_API_Name_Travel:
                is_category_matched = True
                merchant_attributes = MerchantRepositoryV6.merchant_attributes_travel
                inner_join_table = 'merchant_attributes_travel AS ma'

            if inner_join_table:
                sql_dal.inner_join(inner_join_table, 'ma.merchant_id', 'm.id')

            if is_category_matched:
                for include_filter in filters_selected_for_yes:
                    if include_filter in merchant_attributes:
                        sql_dal.where_in('ma.{}'.format(include_filter), [1, 2])

                for exclude_filter in filters_selected_for_no:
                    if exclude_filter in merchant_attributes:
                        sql_dal.where_in('ma.{}'.format(exclude_filter), [0, 2])

        if criteria['outlet_ids']:
            sql_dal.where_in('o.id', criteria['outlet_ids'], sql_safe=True)
        if criteria['billing_country']:
            sql_dal.where('o.billing_country', criteria['billing_country'])
        if criteria['neighborhood']:
            sql_dal.where('t.neighborhood', criteria['neighborhood'])
        if criteria['mall']:
            sql_dal.where('t.mall', criteria['mall'])
        if criteria['hotel']:
            sql_dal.where('t.hotel', criteria['hotel'])

        #  Filter down by radius around latlong
        if lat_lng_exists and criteria['radius']:
            sql_dal.having('distance', criteria['radius'], '<=')
        outlets = sql_dal.get(default=[])
        merchant_fields = [
            'id', 'name', 'name_for_outlet', 'description', 'category', 'categories', 'cuisine', 'cuisines',
            'categories_analytics', 'ad_travel_country', 'ad_active_status', 'logo_url', 'logo_small_url', 'photo_url',
            'photo_small_url'
        ]

        for outlet in outlets:
            outlet['merchant_categories'] = self.parse_list(outlet.get('merchant_categories', []))
            outlet['merchant_cuisines'] = self.parse_list(outlet.get('merchant_cuisines', []), cuisine=True)
            outlet['merchant_categories_analytics'] = CategoriesRepository().get_analytics_codes_against_categories(
                outlet['merchant_categories']
            )
            merchant = {}
            outlet['description'] = ""
            outlet['merchant_description'] = ""

            for field in merchant_fields:
                merchant[field] = outlet['merchant_{}'.format(field)]
                del outlet['merchant_{}'.format(field)]

            if outlet.get('name') and 'Ritz-Carlton' not in outlet.get('name'):
                outlet_name_parts = outlet['name'].split('-')
                outlet['name'] = outlet_name_parts[-1].strip()

            if category:
                if all([category in merchant['categories'], category in CategoriesRepository().get_valid_categories()]):
                    merchant['category'] = category

            merchant['name_for_outlet'] = merchant['name']
            outlet['merchant_name'] = merchant['name']
            outlet['merchant'] = merchant
            if outlet.get('distance'):
                # implicit cast to int, as value is in meters
                outlet['distance'] = round(int(outlet.get('distance', 0)))
            else:
                outlet['distance'] = 0
            if outlet['id'] in criteria['fuzzy_search_outlet_id_score']:
                outlet['fuzzy_relevance'] = criteria['fuzzy_search_outlet_id_score'][outlet['id']]
            else:
                outlet['fuzzy_relevance'] = 0

            # updated cuisine filter to merchant level
            if cuisine_filter and cuisine_filter[0]:
                is_cuisine_matched = False
                for cuisine in cuisine_filter:
                    # change merchant_cuisines to lower case
                    if cuisine.strip().lower() in map(lambda x: x.lower(), outlet['merchant_cuisines']):
                        is_cuisine_matched = True
                        break
                if not is_cuisine_matched:
                    continue
            filtered_outlets.append(outlet)
        return filtered_outlets

    def get_country_areas(self, product_sku, location_id=False, locale='en', search_keyword="", category=""):
        """
        Grabs outlet attribute values for outlets associated with active offers for the products that
        are assigned for the supplied location.
        :param product_sku: list of product sf_id
        :param location_id: id of location
        :param locale: locale language
        :param search_keyword: keyword to search
        :param category: category of merchant
        :rtype: list
        """
        sql_dal = SqlDal()
        sql_dal.select(["CONCAT(CONCAT(ott.neighborhood,', '), ct.name) AS item", "ott.neighborhood", "ct.name"])
        sql_dal.from_(['offer_wl_active'], ['o'])
        sql_dal.inner_join('product_offer_wl_active AS po', 'o.id', 'po.offer_id')
        sql_dal.inner_join('product as p', 'po.product_id', 'p.id')
        sql_dal.inner_join('outlet_offer AS ot', 'o.id', 'ot.offer_id')
        sql_dal.inner_join('outlet AS otl', 'otl.id', 'ot.outlet_id')
        sql_dal.inner_join('outlet_translation AS ott', 'ot.outlet_id', 'ott.outlet_id')
        sql_dal.inner_join('merchant AS m', 'o.merchant_id', 'm.id')
        sql_dal.inner_join('country AS c', 'c.shortname', 'otl.billing_country')
        sql_dal.inner_join('country_translation AS ct', 'ct.country_id', 'c.id')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['ott.locale'] = locale
        ordered_where_clause['ct.locale'] = locale
        sql_dal.where_in('p.sf_id', product_sku)

        if category != 'All':
            ordered_where_clause['m.category'] = category
        # Determine bundled Product if we're supplied a Location
        # Bundled Products are usually Travel books/bundle given for free with a regular Product
        # Remember: Travel Products have NULL for location_id
        if location_id:
            ordered_where_clause['p.location_id'] = location_id
        if search_keyword:
            sql_dal.like('ott.neighborhood', search_keyword)
        sql_dal.where(ordered_where_clause)
        sql_dal.order_by({'item': 'ASC'})
        records = sql_dal.get_distinct(default=[])
        items = []

        for record in records:
            if record['neighborhood']:
                if record['item'].startswith(', ') or record['item'].endswith(', '):
                    record['item'] = record['item'].replace(', ', '')

                if record['neighborhood'] in record['name']:
                    record['item'] = record['neighborhood']
                items.append({'name': record['item'], 'value': record['neighborhood']})
        return items

    def get_country_hotels(self, product_sku, locale='en', search_keyword=''):
        """
        Grabs outlet attribute values for outlets associated with active offers for the products that are assigned
        for the supplied location.
        :param product_sku: list of product sf_id
        :param locale: locale language
        :param search_keyword: keyword to search
        :rtype: list
        """
        sql_dal = SqlDal()
        sql_dal.select(["CONCAT(CONCAT(ott.hotel,', '), ct.name) AS item", "ott.hotel", "ct.name"])
        sql_dal.from_(['offer_wl_active'], ['o'])
        sql_dal.inner_join('product_offer_wl_active AS po', 'o.id', 'po.offer_id')
        sql_dal.inner_join('product as p', 'po.product_id', 'p.id')
        sql_dal.inner_join('outlet_offer AS ot', 'o.id', 'ot.offer_id')
        sql_dal.inner_join('outlet AS otl', 'otl.id', 'ot.outlet_id')
        sql_dal.inner_join('outlet_translation AS ott', 'ot.outlet_id', 'ott.outlet_id')
        sql_dal.inner_join('merchant AS m', 'o.merchant_id', 'm.id')
        sql_dal.inner_join('country AS c', 'c.shortname', 'otl.billing_country')
        sql_dal.inner_join('country_translation AS ct', 'ct.country_id', 'c.id')
        sql_dal.where_in('p.sf_id', product_sku)
        ordered_where_clause = OrderedDict()
        ordered_where_clause['m.category'] = 'Travel'
        ordered_where_clause['ott.locale'] = locale
        ordered_where_clause['ct.locale'] = locale
        if search_keyword:
            sql_dal.like('ott.hotel', search_keyword)
        sql_dal.where(ordered_where_clause)
        sql_dal.order_by({'item': 'ASC'})
        records = sql_dal.get_distinct(default=[])
        items = []

        for record in records:
            if record['hotel']:
                if record['item'].startswith(', ') or record['item'].endswith(', '):
                    record['item'] = record['item'].replace(', ', '')
                if record['name'] in record['hotel']:
                    record['item'] = record['hotel']
                items.append({'name': record['item'], 'value': record['hotel']})
        return items

    def get_attribute_values(self, attribute, product_ids, location_id=False, locale='en', search_keyword="", category=""):
        """
        Grabs outlet attribute values for outlets associated with active offers for the products that are assigned
        for the supplied location.
        :param attribute: attribute to select
        :param product_ids: list of product ids
        :param location_id: id of location
        :param locale: locale language
        :param search_keyword: keyword to search
        :param category: category of merchant
        :rtype: list
        """
        sql_dal = SqlDal()
        sql_dal.select(['ott.{} AS item'.format(attribute)])
        sql_dal.from_(['offer_wl_active'], ['o'])
        sql_dal.inner_join('product_offer_wl_active AS po', 'o.id', 'po.offer_id')
        sql_dal.inner_join('product as p', 'po.product_id', 'p.id')
        sql_dal.inner_join('outlet_offer AS ot', 'o.id', 'ot.offer_id')
        sql_dal.inner_join('outlet AS otl', 'otl.id', 'ot.outlet_id')
        sql_dal.inner_join('outlet_translation AS ott', 'ot.outlet_id', 'ott.outlet_id')
        sql_dal.inner_join('merchant AS m', 'o.merchant_id', 'm.id')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['ott.locale'] = locale
        sql_dal.where_in('p.id', product_ids)
        if category != 'All':
            ordered_where_clause['m.category'] = category
        if location_id:
            ordered_where_clause['p.location_id'] = location_id
        if search_keyword:
            sql_dal.like('ott.{}'.format(attribute), search_keyword)
        sql_dal.where(ordered_where_clause)
        sql_dal.order_by({'item': 'ASC'})
        records = sql_dal.get_distinct(default=[])
        items = [record['item'] for record in records]
        return items

    def is_search_string_found(self, search_in, search_string, is_search_words=False):
        """
        Search the presence of word in string.
        :param str search_in: string in which need to search
        :param str search_string: string to find
        :param bool is_search_words: let us know that search string is single word or combination of words
        :rtype: bool
        """
        search_string = search_string.strip()
        if not is_search_words:
            return search_string in search_in
        else:
            search_words = search_string.split()
            for word in search_words:
                if word.strip() and word.strip() not in search_in:
                    return False
            return True

    def get_outlet_info(self, outlet_id):
        """
        Returns outlet info against outlet id.
        :param int outlet_id: id of outlet
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select(['o.sf_id'])
        sql_dal.from_(['outlet'], ['o'])
        sql_dal.where({'o.id': outlet_id})
        outlet = sql_dal.get_one(default={})
        return outlet
