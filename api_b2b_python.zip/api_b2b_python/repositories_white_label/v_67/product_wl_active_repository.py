"""
File contains methods related to white label active products.
"""
from python_api.repositories.base_repo import BaseRepository
from python_api.wrapper.sql_dal import SqlDal


class ProductWLActiveRepositoryWhiteLabelV67(BaseRepository):
    """
    Contains methods related to product wl active table.
    """
    def get_purchasable_products(self, company, location_id):
        """
        Gets all purchasable products and also purchasable product at the location id of a company.
        :param company: company of the customer
        :param location_id: id of location
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select(['product_id, location_id'])
        sql_dal.from_(['product_wl_active'])
        sql_dal.where({'company': company, 'is_active': 1})
        sql_dal.order_by({'location_id': 'ASC'})
        results = sql_dal.get(default=[])

        purchasable_products_all = []
        purchasable_products_this_location = []
        for result in results:
            purchasable_products_all.append(result.get('product_id'))
            if result.get('location_id') == location_id:
                purchasable_products_this_location.append(result.get('product_id'))
        return {
            'purchasable_products_all': purchasable_products_all,
            'purchasable_products_this_location': purchasable_products_this_location
        }
