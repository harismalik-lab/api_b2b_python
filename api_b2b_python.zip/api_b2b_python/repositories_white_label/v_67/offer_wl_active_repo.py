"""
Offer White Label Active Repository
"""
import datetime

import pytz

from python_api.common.common_helpers import get_formated_date, list_to_str_tuple, parse_voucher_restrictions
from python_api.common.constants import (
    COLOR_BODY, COLOR_LEISURE, COLOR_RESTAURANTS_AND_BARS, COLOR_RETAIL, COLOR_SERVICES, COLOR_TRAVEL, IMAGE_BODY,
    IMAGE_LEISURE, IMAGE_RESTAURANTS_AND_BARS, IMAGE_RETAIL, IMAGE_SERVICES, IMAGE_TRAVEL
)
from python_api.repositories.categories_repo import CategoriesRepository
from python_api.repositories.customer_repo import CustomerProfile
from python_api.repositories.more_location_repo import MoreLocationRepository
from python_api.repositories.product_repo import ProductRepository
from python_api.repositories.redemption_repo import RedemptionRepository
from python_api.repositories.v_65.redemption_repo import RedemptionRepositoryV65
from python_api.repositories.v_67.offer_ent_active import OfferEntActiveRepositoryV67
from python_api.wrapper.sql_dal import SqlDal
from repositories_white_label.v_67.redemption_repo import RedemptionRepositoryWL67


class OfferWlRepositoryV67(OfferEntActiveRepositoryV67):

    def find_by_outlets(self, *args, **kwargs):
        """
        finds offers based on outlets
        :param args:
        :param kwargs:
        :return: list of offers
        """
        delivery_offers_count = 0
        only_delivery = kwargs.get('only_delivery', False)
        primary_user_id = kwargs['primary_user_id']
        is_active_family_member = kwargs['is_active_family_member']
        shared_offers_received_personal = kwargs['shared_offers_received']
        show_cheer_offers = kwargs['show_cheer_offers']
        personal_cheer_offers = kwargs.get('personal_cheer_offers', [])
        shared_offers_sent = kwargs['shared_offers_sent']
        pings_received_offer_ids = []
        for offer_received in kwargs['shared_offers_received']:
            if offer_received['offer_id'] not in pings_received_offer_ids:
                pings_received_offer_ids.append(offer_received['offer_id'])
        if kwargs.get('offers_es'):
            offers_es = kwargs['offers_es']
            offer_id = 0
            if kwargs.get('offer_id', 0):
                offer_id = kwargs.get('offer_id', 0)
            category = None
            if kwargs.get('selected_category') and kwargs.get('selected_category').lower() in self.get_valid_categories():
                category = kwargs.get('selected_category', '')
            if kwargs.get('customer'):
                product_ids = kwargs['customer'].get('product_ids', [])
                filtered = []
                for offer in offers_es:
                    if category and offer['category'] != category:
                        continue
                    if not kwargs.get('is_merlin_offers_to_show') and offer['is_merlin_offer'] == 1:
                        continue
                    if offer_id and offer['id'] != kwargs['offer_id']:
                        continue
                    if not ((offer['is_ent'] == 1 and
                             offer['is_dummy_product'] != 1 and
                             offer['show_offers_if_purchased'] != 1 and offer['is_freemium'] != 1) or
                            (offer['product_id'] in product_ids or offer['id'] in pings_received_offer_ids)):
                        continue
                    filtered.append(offer)
                offers_es = filtered
            else:
                filtered = []
                for offer in offers_es:
                    if category and offer['category'] != category:
                        continue
                    if not kwargs.get('is_merlin_offers_to_show') and offer['is_merlin_offer'] == 1:
                        continue
                    if offer_id and offer['id'] != kwargs['offer_id']:
                        continue
                    if not (offer['is_ent'] == 1 and
                            offer['is_dummy_product'] != 1 and
                            offer['show_offers_if_purchased'] != 1 and
                            offer['is_cheers'] != 1 and
                            offer['is_freemium'] != 1):
                        continue
                    filtered.append(offer)
                offers_es = filtered
            offers = offers_es
        else:
            sql_dal = SqlDal()
            select_clause = "o.id, GROUP_CONCAT(ot.id) outlet_ids, '' as merlin_title," \
                            "p.has_merlin_offers as is_merlin_offer,t.name name, t.description details," \
                            "o.merchant_category as category, o.sub_category, o.type, o.quantity, o.voucher_type," \
                            "o.spend,o.reward,o.percentage_off, o.no_of_people,o.voucher_restrictions as conditions," \
                            "o.voucher_restriction1,o.voucher_restriction2,'' as dcp_license," \
                            "t.merchant_rules_of_use as voucher_restrictions," \
                            "COALESCE(o.savings_estimate, 0) as savings_estimate," \
                            "COALESCE(o.local_currency,'') as local_currency, m.category AS merchant_category," \
                            "COALESCE(o.savings_estimate_local_currency, 0) as savings_estimate_local_currency, " \
                            "o.valid_from valid_from_date, o.valid_to expiration_date, p.id as product_id, " \
                            "p.sf_id as product_sku, pt.name as product_name, p.is_purchaseable as is_purchasable," \
                            "p.is_cheers, p.delivery_enabled as is_delivery, p.is_ent, " \
                            "p.purchase_product_id, p.show_buy_mobile, p.is_freemium, p.product_type," \
                            "CASE WHEN p.product_type=1 THEN 1 ELSE 0  END AS is_birthday_offer, " \
                            "COALESCE(o.offer_sequence, 1) as offer_sequence,p.cashless_delivery_enabled," \
                            "COALESCE(o.percentage_off, 0) percentage_off, m.is_for_members_only"
            sql_dal.set_complex_select_clause(select_clause)
            sql_dal.from_(['offer_wl_active'], ['o'])
            sql_dal.inner_join('product_offer_wl_active AS po', 'o.id', 'po.offer_id')
            sql_dal.inner_join('product AS p', 'po.product_id', 'p.id')
            sql_dal.inner_join('product_translation AS pt', 'p.id', 'pt.product_id')
            sql_dal.inner_join('offer_translation_wl_active AS t', 'o.id', 't.offer_id')
            sql_dal.where({
                # 'pt.locale': kwargs.get('locale', 'en'),
                # 't.locale': kwargs.get('locale', 'en'),
                'p.isactive': 1
            })
            sql_dal.inner_join('outlet_offer', 'outlet_offer.offer_id', 'o.id')
            sql_dal.inner_join('outlet AS ot', 'ot.id', 'outlet_offer.outlet_id')
            sql_dal.inner_join('merchant as m', 'm.id', 'ot.merchant_id')
            if kwargs.get('outlet_ids'):
                sql_dal.where_in('ot.id', kwargs.get('outlet_ids'))
            if not kwargs.get('is_merlin_offers_to_show'):
                sql_dal.where_ne('p.has_merlin_offers', 1)
            if kwargs.get('offer_id'):
                sql_dal.where('o.id', kwargs.get('offer_id'))
            else:
                if kwargs.get('customer', {}) and not only_delivery:
                    product_ids = kwargs['customer'].get('product_ids')
                    extra_query = ''
                    product_query = "AND ((p.is_ent = 1 AND p.is_dummy_product <> 1 and  " \
                                    "p.show_offers_if_purchased <> 1 and p.is_freemium <> 1) " \
                                    "OR p.id in {product_ids} OR o.id in {offer_ids} {extra_query})"

                    if kwargs.get('location_id', 0) == 1 and kwargs.get('outlet_id'):
                        extra_query = 'OR p.cashless_delivery_enabled=1'
                    sql_dal.set_parenthesised_where_clause(
                        product_query.format(
                            extra_query=extra_query,
                            product_ids=list_to_str_tuple(product_ids) if product_ids else '(0)',
                            offer_ids=list_to_str_tuple(pings_received_offer_ids) if pings_received_offer_ids else '(0)'
                        )
                    )
                elif not only_delivery:
                    sql_dal.set_parenthesised_where_clause(
                        "AND (p.is_ent = 1 AND p.is_dummy_product <> 1 and p.show_offers_if_purchased <> 1 and "
                        "p.is_cheers <> 1 and p.is_freemium <> 1)"
                    )
            if kwargs.get('selected_category') and kwargs.get(
                    'selected_category').lower() in self.get_valid_categories():
                sql_dal.where('o.merchant_category', kwargs.get('selected_category'))
            if not show_cheer_offers:
                if personal_cheer_offers:
                    sql_dal.set_parenthesised_where_clause(
                        " AND (p.is_cheers<>1 OR (p.is_cheers=1 AND o.id IN {}))".format(
                            list_to_str_tuple(personal_cheer_offers)
                        )
                    )
                else:
                    sql_dal.where_ne('p.is_cheers', 1)
            if kwargs.get('location_id', 0) == 1:
                if only_delivery and kwargs.get('customer', {}):
                    sql_dal.set_parenthesised_where_clause(' AND (p.cashless_delivery_enabled=1)')
                    # elif kwargs.get('customer', {}):
                    #     sql_dal.set_parenthesised_where_clause(
                    #         ' AND ((p.cashless_delivery_enabled=0 OR p.cashless_delivery_enabled is null) AND'
                    #         ' p.delivery_enabled=0)'
                    #     )
            sql_dal.group_by(['o.id'])
            offers = sql_dal.get(default=[])
        offer_ids = []
        for offer in offers:
            offer_ids.append(offer['id'])
        redemption_quantities = []
        if kwargs.get('customer'):
            redemption_repo = RedemptionRepositoryWL67()
            customer = kwargs['customer']
            if customer.get('family_is_active') and customer.get('is_user_in_family'):
                redemption_quantities = redemption_repo.get_redeemed_quantites_for_customer(
                    customer_id=customer.get('customer_id', 0),
                    family_id=customer.get('family_info', {}).get('id'),
                    primary_user_id=primary_user_id,
                    offer_id=offer_ids,
                    company=customer.get('company', '')
                )
                if primary_user_id != customer['customer_id']:
                    secondary_birthday_redemptions = redemption_repo\
                        .get_birthday_redeemed_quantites_for_secondary_customer(customer.get('customer_id', 0))
                    redemption_quantities.update(secondary_birthday_redemptions)
            else:
                redemption_quantities = redemption_repo.get_redeemed_quantites_for_customer(
                    customer_id=kwargs.get('customer').get('customer_id', 0),
                    is_onboarding=kwargs.get('customer').get('is_using_trial', 0),
                    offer_id=offer_ids, company=customer.get('company', '')
                )
        offer_categories = kwargs['offer_categories']
        offer_sub_categories = kwargs['offer_sub_categories']
        ids = []
        offers_to_delete = []
        for offer_index, offer in enumerate(offers):
            # for normal merchant and dubai location
            if not only_delivery and kwargs.get('location_id', 0) == 1:
                if kwargs.get('outlet_id'):
                    # for dubai location we will exclude the offers for merchant details screen to show view
                    # delivery offers button this will be instantiated from delivery cashless merchant details screen
                    # https://entertainerproducts.atlassian.net/browse/DC-34
                    if offer.get('cashless_delivery_enabled', False):
                        delivery_offers_count += 1
                        offers_to_delete.append(offer_index)
                        continue
                    elif offer.get('is_delivery', False):
                        offers_to_delete.append(offer_index)
                        continue
                else:
                    # for global search and dubai location if outlets is not part of delivery_cashless then exclude
                    # cashless_delivery_enabled and is_delivery offers
                    if any([
                        offer.get('cashless_delivery_enabled', False),
                        offer.get('is_delivery', False)
                    ]):
                        offers_to_delete.append(offer_index)
                        continue

            if kwargs.get('is_merlin_offers_to_show'):
                offer['merlin_title'] = kwargs.get('merchant_name')
            if offer.get('category', '') not in offer_categories:
                offer_categories.append(offer.get('category'))
            if offer.get('sub_category', '') and offer.get('sub_category', '') not in offer_sub_categories:
                offer_sub_categories.append(offer.get('sub_category'))
            if isinstance(offer.get('outlet_ids'), list):
                outlet_ids = offer['outlet_ids']
            else:
                outlet_ids = list(set(map(int, offer.get('outlet_ids').split(','))))
            offer.update({
                'conditions': parse_voucher_restrictions(offer.get('conditions', {})),
                'redeemability': 0,
                'is_purchased': False,
                'allowed_onboarding': False,
                'is_offer_valid_in_future': False,
                'is_offer_expired': False,
                'quantity_redeemable': 0,
                'quantity_redeemed': 0,
                'quantity_not_redeemable': offer.get('quantity'),
                'shared_sent_count': 0,
                'shared_received_count': 0,
                'shared_redemptions_count': 0,
                'is_show_purchase_button': False,
                'is_monthly': offer['type'] == self.TYPE_MEMBER,
                'is_new': offer['type'] == self.TYPE_NEW_OFFER,
                "is_pingable": self.is_offer_allowed_to_ping(
                    is_ent=offer['is_ent'],
                    offer_type=offer['type'],
                    category=offer['category'],
                    is_freemium=offer['is_freemium'],
                    is_merlin_offer=offer['is_merlin_offer']
                ),
                'outlet_ids': outlet_ids,
                'merlin_title': offer['merlin_title'],
                'is_merlin_offer': bool(offer['is_merlin_offer']),
                'valid_from_date': self._set_hours(offer['valid_from_date'], 4),
                'expiration_date': self._set_hours(offer['expiration_date'], 14)
            })
            if offer.get('is_merlin_offer'):
                offer['outlet_merlin_urls'] = kwargs['outlet_merlin_urls']
            elif not offer.get('is_merlin_offer'):
                offer['outlet_merlin_urls'] = []

            if kwargs.get('customer', {}):
                is_top_up_offer = False
                top_up_offer_count = 0

                for top_up_offer in kwargs.get('top_up_offers'):
                    if top_up_offer.get('offer_id') == offer.get('id'):
                        is_top_up_offer = True
                        top_up_offer_count = top_up_offer_count + 1
                redeemability = self.calculate_offer_redeemability_for_customer_in_merchant_controller(
                    offer=offer, customer=kwargs.get('customer'), member_group=kwargs.get('member_group'),
                    shared_offers_sent_family=kwargs['shared_offers_sent_family'],
                    shared_offers_received_family=kwargs['shared_offers_received_family'],
                    location_id=kwargs.get('location_id'),
                    redemptions_quantities=redemption_quantities, is_top_up_offer=is_top_up_offer,
                    offer_redeemability=kwargs.get('offer_redeemability'),
                    is_on_trial=kwargs.get('is_on_trial', False),
                    onboarding_redemption_count=kwargs.get('onboarding_redemption_count', 0),
                    is_active_family_member=is_active_family_member,
                    primary_user_id=primary_user_id,
                    shared_offers_sent=shared_offers_sent,
                    shared_offers_received=shared_offers_received_personal,
                    company=kwargs.get('customer', {}).get('company', '')
                )
                offer.update({
                    'redeemability': redeemability.get('redeemability'),
                    'is_purchased': redeemability.get('is_purchased'),
                    'allowed_onboarding': redeemability.get('allowed_onboarding'),
                    'is_offer_valid_in_future': redeemability.get('is_offer_valid_in_future'),
                    'is_offer_expired': redeemability.get('is_offer_expired'),
                    'quantity_redeemable': redeemability.get('quantity_redeemable'),
                    'quantity_redeemed': redeemability.get('quantity_redeemed'),
                    'quantity_not_redeemable': redeemability.get('quantity_not_redeemable'),
                    'shared_sent_count': redeemability.get('shared_sent_count'),
                    'shared_received_count': redeemability.get('shared_received_count'),
                    'shared_redemptions_count': redeemability.get('shared_redemptions_count'),
                    'is_show_purchase_button': redeemability.get('is_show_purchase_button'),
                    'personal_shared_received_count': redeemability.get('personal_shared_received_count', 0),
                    'personal_shared_redemptions_count': redeemability.get('personal_shared_redemptions_count', 0)
                })
            if kwargs.get('return_outlet_ids'):
                ids.extend(offer['outlet_ids'])
        for offer_index in sorted(offers_to_delete, reverse=True):
            try:
                del offers[offer_index]
            except IndexError:
                pass
        if kwargs.get('return_outlet_ids'):
            return offers, ids, offer_categories, offer_sub_categories, offer_ids, delivery_offers_count
        return offers, [], offer_categories, offer_sub_categories, offer_ids, delivery_offers_count

    def find_offers(self, data={}):
        """
        Finds offers according to the given criteria as data
        :param dict data: Offer criteria dict
        :rtype: list
        """
        location_id = data.get('location_id', 0)
        sql_dal = SqlDal()
        sql_dal.select([
            'o.id', 'o.merchant_category', 'COALESCE(o.sub_category, "") as sub_category',
            'o.valid_from as valid_from_date', 'o.valid_to as expiration_date', 'o.type',
            'CONCAT({}, "") redeemability'.format(self.NOT_REDEEMABLE), 'o.quantity',
            '0 as times_redeemed', 'p.id as product_id', 'p.sf_id as product_sku',
            't.name as offer_name', 'o.savings_estimate', 'm.is_for_members_only',
            'p.is_cheers', 'p.delivery_enabled as is_delivery', 'p.is_ent is_entertainer',
            'p.is_more_sa', 'p.cashless_delivery_enabled', 'p.product_type'
        ])
        if data['isshared']:
            sql_dal.select(['MIN(otl.id) as outlet_ids'])
        else:
            sql_dal.select(['GROUP_CONCAT(DISTINCT otl.id) as outlet_ids'])

        sql_dal.from_(['offer_wl_active'], ['o'])
        sql_dal.inner_join('offer_translation_wl_active AS t', 'o.id', 't.offer_id')
        sql_dal.inner_join('product_offer_wl_active AS po', 'o.id', 'po.offer_id')
        sql_dal.inner_join('product AS p', 'po.product_id', 'p.id')
        sql_dal.inner_join('outlet_offer AS ot', 'o.id', 'ot.offer_id')
        sql_dal.inner_join('outlet AS otl', 'otl.id', 'ot.outlet_id')
        sql_dal.inner_join('merchant AS m', 'm.id', 'o.merchant_id')
        sql_dal.where({'t.locale': data['locale'], 'p.isactive': 1})

        common_query = " (p.is_ent=1 AND" \
                       " p.is_dummy_product<>1 AND" \
                       " p.show_offers_if_purchased<>1 AND" \
                       " p.is_freemium<>1)"

        cashless_delivery_enabled_include = False
        if data.get('customer'):
            if data.get('cashless_delivery_enabled', False) and data.get('location_id', 0) == 1:
                cashless_delivery_enabled_include = True
                sql_dal.where('p.cashless_delivery_enabled', 1)
            elif data['received_offer_ids']:
                parenthesized_query = "AND ({common_query} OR p.id in {product_ids} OR" \
                                      " o.id in {received_offer_ids}) "
                if data['customer']['product_ids']:
                    params = dict(product_ids=list_to_str_tuple(data['customer']['product_ids']),
                                  received_offer_ids=list_to_str_tuple(data.get('received_offer_ids')))
                else:
                    params = dict(product_ids='(0)',
                                  received_offer_ids=list_to_str_tuple(data.get('received_offer_ids')))
                params.update(common_query=common_query)
                sql_dal.set_parenthesised_where_clause(parenthesized_query, params)
            else:
                parenthesized_query = "AND ({common_query} OR p.id in {product_ids})"
                if data['customer']['product_ids']:
                    params = dict(product_ids=list_to_str_tuple(data['customer']['product_ids']))
                else:
                    params = dict(product_ids='(0)')
                params.update(common_query=common_query)
                sql_dal.set_parenthesised_where_clause(parenthesized_query, params)
        else:
            common_query = " (p.is_ent=1 AND" \
                           " p.is_dummy_product<>1 AND" \
                           " p.show_offers_if_purchased<>1 AND" \
                           " p.is_freemium<>1 AND" \
                           " p.is_cheers <> 1)"
            parenthesized_query = "AND {common_query} "
            sql_dal.set_parenthesised_where_clause(parenthesized_query, params_dict={'common_query': common_query})

        if data['isshared']:
            if data.get('received_offer_ids'):
                sql_dal.where_in('o.id', data['received_offer_ids'])
            else:
                sql_dal.where_in('o.id', [0], sql_safe=True)
        else:
            if data['offer_types_selected']:
                sql_dal.where_in('o.voucher_type', data['offer_types_selected'])

            if data['offer_redeemability'] == self.Redeemability_not_redeemable:
                sql_dal.where_gt('p.purchase_product_id', 0)

            if data['is_cheers']:
                if location_id == 1:
                    sql_dal.set_parenthesised_where_clause(
                        " AND (p.is_cheers = 1 OR p.cashless_delivery_enabled=1)"
                    )
                else:
                    sql_dal.where('p.is_cheers', 1)

            if data['is_more_sa']:
                sql_dal.where('p.is_more_sa', 1)

            if data['is_birthday']:
                if location_id == 1:
                    # for dubai location we will always open delivery_cashless screen first if merchant is part of
                    # birthday and cashless_delivery_enabled products
                    sql_dal.set_parenthesised_where_clause(
                        " AND (p.product_type={product_type} OR p.cashless_delivery_enabled=1)",
                        params_dict={'product_type': ProductRepository.PRODUCT_TYPE_BIRTHDAY}
                    )
                else:
                    sql_dal.where('p.product_type', ProductRepository.PRODUCT_TYPE_BIRTHDAY)

            #  for skip mode
            if data.get('location_id', 0) == 1:
                if data.get('cashless_delivery_enabled', False) and not cashless_delivery_enabled_include:
                    sql_dal.where('p.cashless_delivery_enabled', 1)
            else:
                if data.get('is_delivery', False):
                    sql_dal.where('p.delivery_enabled', 1)

            if data['product_sku']:
                sql_dal.where('p.sf_id', data['product_sku'])
            elif data['outlet_id']:
                sql_dal.where('otl.id', data['outlet_id'])
            elif data['category'] == 'Travel':
                sql_dal.where('p.istravel', 1)
            else:
                locations = MoreLocationRepository.MoreSA_Locations
                query = " AND (p.location_id = {}".format(data['location_id'])
                if data['category'] == 'All':
                    query += " OR p.istravel=1"
                if data['location_id'] in locations:
                    query += " OR p.is_more_sa = 1"
                sql_dal.set_parenthesised_where_clause(query + ")")
        if data['_is_elastic_search_on'] and data['_fuzzy_search_outlet_ids']:
            sql_dal.where_in('otl.id', data['_fuzzy_search_outlet_ids'])
        if data.get('customer', {}).get('is_using_trial', False):
            sql_dal.set_parenthesised_where_clause(
                " AND (o.type<>{offer_type_member} OR p.has_merlin_offers = 1)",
                params_dict={'offer_type_member': self.TYPE_MEMBER}
            )
        # Apply Filter on Category
        if data.get('category') and data['category'].strip().lower() != 'all':
            sql_dal.where('o.merchant_category', data['category'])

        # Apply Filter on Subcategory
        if data['sub_categories_selected']:
            sql_dal.where_in('o.sub_category', data['sub_categories_selected'])

        # Apply offer attributes
        if data['offer_attributes_selected']:
            valid_offer_attributes = self.get_valid_offer_attributes(data['offer_attributes_selected'])
            if valid_offer_attributes:
                sql_dal.inner_join('offer_attributes AS oa', 'o.id', 'oa.offer_id')
                attributes_where_condition_dict = dict(
                    [('oa.{attr}'.format(attr=attr), 1) for attr in valid_offer_attributes]
                )
                sql_dal.where(attributes_where_condition_dict)

        sql_dal.group_by(['o.id'])
        records = sql_dal.get(default=[])
        return records

    def get_offer_details(self, offer_ids):
        if offer_ids:
            sql_dal = SqlDal()
            sql_dal.select(
                ['o.valid_from AS valid_from_date', 'o.valid_to AS expiration_date',
                 'o.*', 'po.product_id', 'po.root_code']
            ).from_('offer_wl_active AS o')
            sql_dal.inner_join('product_offer_wl_active AS po', 'o.id', 'po.offer_id')
            sql_dal.where_in('o.id', offer_ids)
            return {row['id']: row for row in sql_dal.get(default=[])}
        return {}

    def cashless_delivery_outlets(self, outlets_ids=[]):
        """
        Calculate cashless_delivery_enabled based on outlets_ids
        :param outlets_ids:
        :return:
        """
        records = {}
        if outlets_ids:
            sql_dal = SqlDal()
            sql_dal.select(['p.cashless_delivery_enabled', 'outl.id as outlet_id'])
            sql_dal.from_(['outlet'], ['outl'])
            sql_dal.inner_join('outlet_offer AS ot_of', 'ot_of.outlet_id', 'outl.id')
            sql_dal.inner_join('product_offer_wl_active AS p_ent_off', 'p_ent_off.offer_id', 'ot_of.offer_id')
            sql_dal.inner_join('product_wl_active AS p', 'p.id', 'p_ent_off.product_id')
            sql_dal.where_in('outl.id', outlets_ids)
            sql_dal.where({'p.cashless_delivery_enabled': 1})
            return {row['outlet_id']: row for row in sql_dal.get(default=[])}
        return records

    def find_by_id(self, *args):
        """
        find offers by offer_id
        :param args: int offer_id
        :return: offer
        """
        sql_dal = SqlDal()
        sql_dal.select([
            'o.id', 'o.redemptions_limit_in_x_hours', 'o.hours_to_consider_for_redemption_cap', 'o.type',
            'o.merchant_id as merchant_id', 'o.sf_id', 'o.savings_estimate as savings_estimate',
            'o.valid_from valid_from_date', 'o.valid_to expiration_date', 'o.quantity', 'o.has_red_custom_code'
        ])
        sql_dal.from_(['offer_wl_active'], ['o'])
        sql_dal.where({'o.id': args[0], 'o.status': 'Active'})
        return sql_dal.get_one(default={})

    def get_product_id_by_offer_id(self, offer_id, default=[]):
        sql_dal = SqlDal()
        sql_dal.select(['p.id', 'po.offer_id'])
        sql_dal.from_(['product_wl_active AS p'])
        sql_dal.inner_join('product_offer_wl_active AS po', 'p.id', 'po.product_id')
        if isinstance(offer_id, list):
            sql_dal.where_in('po.offer_id', offer_id)
            record = sql_dal.get(default=[])
            record = {product['offer_id']: product for product in record}
        else:
            sql_dal.where('po.offer_id', offer_id)
            record = sql_dal.get_one(default={})
            if record:
                return record.get('id', 0)
        return record if record else default

    def get_offer_merchant_details(self, offer_id, locale='en', group_by=False):
        if not offer_id:
            return []
        sql_dal = SqlDal()
        sql_dal.select([
            'o.id AS offer_id',
            'MAX(t.name) AS offer_name',
            'o.valid_to AS offer_valid_to',
            'MAX(mt.name) AS merchant_name',
            'm.logo_retina_url AS logoUrl',
            'm.logo_non_retina_url AS logoSmallUrl',
            'o.merchant_category AS category',
            '"" AS category_image',
            '"" AS category_color'
        ])
        sql_dal.from_(['offer_wl_active'], ['o'])
        sql_dal.inner_join('offer_translation_wl_active AS t', 'o.id', 't.offer_id')
        sql_dal.inner_join('merchant AS m', 'm.id', 'o.merchant_id')
        sql_dal.inner_join('merchant_translation AS mt', 'mt.merchant_id', 'm.id')
        sql_dal.where({'mt.locale': locale, 't.locale': locale})
        if isinstance(offer_id, list):
            sql_dal.where_in('o.id', offer_id, sql_safe=True)
            if group_by:
                sql_dal.group_by(['o.id'])
        else:
            sql_dal.where({'o.id': offer_id})
        offers = sql_dal.get(default=[])
        grouped_offers = {}
        for offer in offers:
            if offer['category'].lower() == CategoriesRepository.ResturantsAndBars:
                offer['category_image'] = IMAGE_RESTAURANTS_AND_BARS
                offer['category_color'] = COLOR_RESTAURANTS_AND_BARS
            elif offer['category'].lower() == CategoriesRepository.Body:
                offer['category_image'] = IMAGE_BODY
                offer['category_color'] = COLOR_BODY
            elif offer['category'].lower() == CategoriesRepository.Leisure:
                offer['category_image'] = IMAGE_LEISURE
                offer['category_color'] = COLOR_LEISURE
            elif offer['category'].lower() == CategoriesRepository.Travel:
                offer['category_image'] = IMAGE_TRAVEL
                offer['category_color'] = COLOR_TRAVEL
            elif offer['category'].lower() == CategoriesRepository.Services:
                offer['category_image'] = IMAGE_SERVICES
                offer['category_color'] = COLOR_SERVICES
            elif offer['category'].lower() == CategoriesRepository.Retail:
                offer['category_image'] = IMAGE_RETAIL
                offer['category_color'] = COLOR_RETAIL
            # grouping by o.id in case of list of offer ids
            if group_by:
                if offer['offer_valid_to']:
                    offer['offer_valid_to'] = get_formated_date(offer['offer_valid_to'])
                grouped_offers.update({offer['offer_id']: offer})

        return grouped_offers if group_by else offers

    def count_offer_redemptions_by_customer(
            self, customer_id, company, offer_id=None, group_by=False, is_shared=None, primary_user_id=None
    ):
        sql_dal = SqlDal()
        sql_dal.select(['r.offer_id', 'SUM(r.quantity) as quantity'])
        sql_dal.from_(['redemption'], ['r'])

        if offer_id:
            if isinstance(offer_id, list):
                sql_dal.where_in('r.offer_id', offer_id, sql_safe=True)
            else:
                sql_dal.where('r.offer_id', offer_id)
        sql_dal.where({'r.customer_id': customer_id})
        sql_dal.where({'r.primary_user_id': primary_user_id})
        if is_shared is not None:
            sql_dal.where({'r.is_shared': is_shared})
        sql_dal.like('r.company', company)
        sql_dal.where_in('r.status', [RedemptionRepository.ACTIVE, RedemptionRepository.IN_PROGRESS], sql_safe=True)
        if group_by:
            sql_dal.group_by(['r.offer_id'])
        records = sql_dal.get(default=0 if not group_by else [])
        if records:
            if group_by:
                return {record['offer_id']: record['quantity'] for record in records}
            else:
                return records[0].get('quantity', 0) or 0
        return records

    def count_offer_redemptions_by_customer_primary(
            self, customer_id, company, offer_id=None, group_by=False, is_shared=None
    ):
        sql_dal = SqlDal()
        sql_dal.select(['r.offer_id', 'SUM(r.quantity) as quantity'])
        sql_dal.from_(['redemption'], ['r'])

        if offer_id:
            if isinstance(offer_id, list):
                sql_dal.where_in('r.offer_id', offer_id, sql_safe=True)
            else:
                sql_dal.where('r.offer_id', offer_id)
        sql_dal.set_parenthesised_where_clause(
            'AND (case when r.primary_user_id is NULL '
            'then r.customer_id else r.primary_user_id end)={customer_id} '.format(customer_id=customer_id)
        )
        if is_shared is not None:
            sql_dal.where({'r.is_shared': is_shared})
        sql_dal.like('r.company', company)
        sql_dal.where_in('r.status', [RedemptionRepository.ACTIVE, RedemptionRepository.IN_PROGRESS], sql_safe=True)
        if group_by:
            sql_dal.group_by(['r.offer_id'])
        records = sql_dal.get(default=0 if not group_by else [])
        if records:
            if group_by:
                return {record['offer_id']: record['quantity'] for record in records}
            else:
                return records[0].get('quantity', 0) or 0
        return records

    def count_offer_redemptions_by_customer_shared_offers_primary(
            self, customer_id, company, offer_id=None, group_by=False, count=False
    ):
        redemptions_count_dict = {}
        sql_dal = SqlDal()
        sql_dal.select(['r.offer_id, SUM(r.quantity) as quantity'])
        sql_dal.from_(['redemption'], ['r'])
        sql_dal.where({'r.is_shared': 1})
        sql_dal.like('r.company', company)
        sql_dal.set_parenthesised_where_clause(
            'AND (case when r.primary_user_id is NULL '
            'then r.customer_id else r.primary_user_id end)={customer_id} '.format(customer_id=customer_id)
        )

        if offer_id:
            if isinstance(offer_id, list):
                sql_dal.where_in('r.offer_id', offer_id, sql_safe=True)
            else:
                sql_dal.where('r.offer_id', offer_id)
        sql_dal.where_in('r.status', [RedemptionRepository.ACTIVE, RedemptionRepository.IN_PROGRESS], sql_safe=True)
        if group_by:
            sql_dal.group_by(['r.offer_id'])
        records = sql_dal.get(default=[])
        if records and group_by:
            redemptions_count_dict = {record['offer_id']: record['quantity'] for record in records}
        if not isinstance(offer_id, list) and count:
            return int(redemptions_count_dict.get(offer_id, 0))
        return redemptions_count_dict

    def find_name_by_id(self, offer_id, locale='en'):
        """
        This method returns offer dict with it's name in it
        :param offer_id:
        :param locale:
        :return:
        """
        sql_dal = SqlDal()
        sql_dal.select(['t.name'])
        sql_dal.from_(['offer_wl_active'], ['o'])
        sql_dal.inner_join('offer_translation_wl_active as t', 'o.id', 't.offer_id')
        sql_dal.where({
            't.locale': locale,
            'o.id': offer_id
        })
        offer = sql_dal.get_one(default={})
        return offer

    def any_offer_monthly_or_not_pingable(self, offer_ids):
        """
        Returns True if any offer is monthly or it's merchant doesn't allow pings
        :param list offer_ids: Offer Ids
        :rtype: bool
        """
        if offer_ids:
            sql_dal = SqlDal()
            sql_dal.from_(['offer_wl_active'], ['o'])
            sql_dal.inner_join('merchant AS m', 'm.id', 'o.merchant_id')
            sql_dal.where_in('o.id', offer_ids)
            sql_dal.set_parenthesised_where_clause("AND (m.is_pingable != 1 OR o.type = {})".format(self.TYPE_MEMBER))
            return bool(sql_dal.get_count(default=0))
        return False

    def get_offer_quantities(self, offer_ids):
        """
        Returns offer quantities
        :param list offer_ids: Offer Ids
        :rtype: dict
        """
        if offer_ids:
            sql_dal = SqlDal()
            sql_dal.select(["o.id", "o.quantity"])
            sql_dal.from_(['offer_wl_active'], ['o'])
            sql_dal.where_in('o.id', offer_ids)
            offers = sql_dal.get(default=[])
            quantities = {}
            for offer in offers:
                quantities.update({
                    offer['id']: quantities.get(offer['id'], 0) + offer['quantity']
                })
            return quantities
        return {}

    def count_offer_redemptions_by_customer_shared_offers(
            self, customer_id, company, offer_id=None, group_by=False, count=False, primary_user_id=0,
            is_active_family_member=False
    ):
        redemptions_count_dict = {}
        sql_dal = SqlDal()
        sql_dal.select(['r.offer_id, SUM(r.quantity) as quantity'])
        sql_dal.from_(['redemption'], ['r'])
        sql_dal.like('r.company', company)
        if primary_user_id and is_active_family_member:
            sql_dal.where({'r.primary_user_id': primary_user_id, 'r.is_shared': 1})
        else:
            where_clause = " AND (r.primary_user_id={customer_id} OR (r.customer_id={customer_id} AND " \
                           "COALESCE(r.primary_user_id,0) = 0)) AND r.is_shared=1"
            sql_dal.set_parenthesised_where_clause(where_clause, {'customer_id': customer_id})

        if offer_id:
            if isinstance(offer_id, list):
                sql_dal.where_in('r.offer_id', offer_id, sql_safe=True)
            else:
                sql_dal.where('r.offer_id', offer_id)
        sql_dal.where_in('r.status', [RedemptionRepositoryV65.ACTIVE, RedemptionRepositoryV65.IN_PROGRESS],
                         sql_safe=True)
        if group_by:
            sql_dal.group_by(['r.offer_id'])
        records = sql_dal.get(default=[])
        if records and group_by:
            redemptions_count_dict = {record['offer_id']: record['quantity'] for record in records}
        if not isinstance(offer_id, list) and count:
            return int(redemptions_count_dict.get(offer_id, 0))
        return redemptions_count_dict

    def count_offer_redemptions_by_customer_shared_offers_personal(
            self, customer_id, company, offer_id=None, group_by=False, count=False
    ):
        redemptions_count_dict = {}
        sql_dal = SqlDal()
        sql_dal.select(['r.offer_id, SUM(r.quantity) as quantity'])
        sql_dal.from_(['redemption'], ['r'])
        sql_dal.like('r.company', company)
        where_clause = " AND (r.customer_id={customer_id} AND COALESCE(r.primary_user_id,0) = 0) AND r.is_shared=1"
        sql_dal.set_parenthesised_where_clause(where_clause, {'customer_id': customer_id})

        if offer_id:
            if isinstance(offer_id, list):
                sql_dal.where_in('r.offer_id', offer_id, sql_safe=True)
            else:
                sql_dal.where('r.offer_id', offer_id)
        sql_dal.where_in(
            'r.status', [RedemptionRepositoryV65.ACTIVE, RedemptionRepositoryV65.IN_PROGRESS], sql_safe=True
        )
        if group_by:
            sql_dal.group_by(['r.offer_id'])
        records = sql_dal.get(default=[])
        if records and group_by:
            redemptions_count_dict = {record['offer_id']: record['quantity'] for record in records}
        if not isinstance(offer_id, list) and count:
            return int(redemptions_count_dict.get(offer_id, 0))
        return redemptions_count_dict

    def get_offer_types(self, _type, offer_ids):
        """
        Returns offer types against offers ids
        :param str _type: Column name
        :param list offer_ids: Offer ids
        :rtype: dict
        """
        assert _type and isinstance(offer_ids, list), "Invalid params; got {}, {}".format(_type, offer_ids)
        sql_dal = SqlDal()
        sql_dal.select(['p.{} AS `type`'.format(_type), 'o.id']).from_(['product_wl_active AS p'])
        sql_dal.inner_join('product_offer_wl_active AS po', 'po.product_id', 'p.id')
        sql_dal.inner_join('offer_wl_active AS o', 'po.offer_id', 'o.id')
        sql_dal.where_in('o.id', offer_ids)
        rows = sql_dal.get(default=[])
        offers_types = {}
        for row in rows:
            offers_types.update({row['id']: row['type']})
        return offers_types

    def calculate_offer_redeemability_for_customer_in_merchant_controller(
            self, offer, customer, member_group, shared_offers_sent, shared_offers_received, location_id,
            redemptions_quantities=False, is_top_up_offer=False, offer_redeemability='redeemable',
            is_on_trial=False, onboarding_redemption_count=0, shared_offers_received_family=list(),
            shared_offers_sent_family=list(), is_active_family_member=False, primary_user_id=0, company=''
    ):
        tz = pytz.timezone('Asia/Dubai')
        date_from = datetime.datetime.now(tz) + datetime.timedelta(
            hours=self.Hours_Adjustment_For_Offer_Expiry_From_V52
        )
        date_to = datetime.datetime.now(tz) + datetime.timedelta(
            hours=self.Hours_Adjustment_For_Offer_Expiry_To_V52
        )
        category = offer['merchant_category']
        num_purchased = 0
        shared_sent_count = 0
        shared_received_count = 0
        personal_shared_received_count = 0
        shared_redemptions_count = 0
        personal_shared_redemptions_count = 0
        is_offer_valid_in_future = False
        is_offer_expired = False
        offer['quantity_display'] = offer.get('quantity')
        is_purchased = offer.get('product_id') in customer.get('product_ids')
        if is_active_family_member:
            for shared_offer_sent in shared_offers_sent_family:
                if shared_offer_sent.get('offer_id') == offer.get('id'):
                    shared_sent_count = shared_sent_count + 1
        else:
            for shared_offer_sent in shared_offers_sent:
                if shared_offer_sent.get('offer_id') == offer.get('id'):
                    shared_sent_count = shared_sent_count + 1

        for shared_offer_received in shared_offers_received_family:
            if shared_offer_received.get('offer_id') == offer.get('id'):
                shared_received_count = shared_received_count + 1
        if shared_received_count:
            shared_redemptions_count = self.count_offer_redemptions_by_customer_shared_offers(
                customer_id=customer.get('customer_id', 0), offer_id=offer.get('id', 0), count=True, group_by=True,
                is_active_family_member=is_active_family_member, primary_user_id=primary_user_id, company=company
            )
        # For received pings when not a member of family
        for shared_offer_received in shared_offers_received:
            if shared_offer_received.get('offer_id') == offer.get('id'):
                personal_shared_received_count += 1
        if personal_shared_received_count:
            if is_active_family_member:
                personal_shared_redemptions_count = self.count_offer_redemptions_by_customer_shared_offers_personal(
                    customer_id=customer.get('customer_id', 0), offer_id=offer.get('id', 0), count=True, group_by=True,
                    company=company
                )
            else:
                personal_shared_redemptions_count = self.count_offer_redemptions_by_customer_shared_offers(
                    customer_id=customer.get('customer_id', 0), offer_id=offer.get('id', 0), count=True, group_by=True,
                    company=company
                )
        if isinstance(redemptions_quantities, list):
            num_redemptions = redemptions_quantities[offer.get('id')] if redemptions_quantities[offer.get('id')] else 0
        elif isinstance(redemptions_quantities, dict):
            num_redemptions = redemptions_quantities.get(offer.get('id', 0), 0)
        else:
            num_redemptions = self.count_offer_redemptions_by_customer(
                customer_id=customer.get('customer_id'), offer_id=offer.get('id'), company=company
            )
        valid_from_date = offer.get('valid_from_date')
        expiration_date = offer.get('expiration_date')
        if isinstance(offer.get('valid_from_date'), str):
            if 'T' in offer.get('valid_from_date'):
                valid_from_date = datetime.datetime.strptime(offer.get('valid_from_date'), '%Y-%m-%dT%H:%M:%S%z')
            else:
                valid_from_date = datetime.datetime.strptime(offer.get('valid_from_date'), '%Y-%m-%d%H:%M:%S%z')
        if isinstance(offer.get('expiration_date'), str):
            if 'T' in offer.get('expiration_date'):
                expiration_date = datetime.datetime.strptime(offer.get('expiration_date'), '%Y-%m-%dT%H:%M:%S%z')
            else:
                expiration_date = datetime.datetime.strptime(offer.get('expiration_date'), '%Y-%m-%d%H:%M:%S%z')
        if valid_from_date > date_from:
            is_offer_valid_in_future = True
        if expiration_date < date_to:
            is_offer_expired = True

        is_on_trial = self.allowed_onboarding(
            is_user_onboard=is_on_trial, category=category, is_for_members_only=offer['is_for_members_only'],
            offer_type=offer['type'], is_offer_valid_in_future=is_offer_valid_in_future,
            is_offer_expired=is_offer_expired, is_cheers=offer['is_cheers']
        )
        if is_on_trial:
            redeemability_value = self.REDEEMABLE
            num_purchased = offer['quantity']
        else:
            purchased_offers_count = customer.get('product_ids', []).count(int(offer.get('product_id', 0)))
            num_purchased += purchased_offers_count * int(offer.get('quantity', 0))
            if shared_sent_count:
                num_purchased = num_purchased - shared_sent_count

            if offer.get('type') == self.TYPE_MEMBER and member_group == CustomerProfile.MEMBERSTATUS_MEMBER and\
                    is_purchased:
                num_purchased = num_redemptions + 1
            if is_top_up_offer and num_redemptions:
                num_redemptions = num_redemptions - 1

            if not is_offer_valid_in_future and not is_offer_expired and num_purchased > num_redemptions and num_purchased:
                redeemability_value = self.REUSABLE if offer.get('type') == self.TYPE_MEMBER else self.REDEEMABLE
            elif num_redemptions > num_purchased and num_purchased:
                redeemability_value = self.REDEEMED
            else:
                redeemability_value = self.NOT_REDEEMABLE

        is_show_purchase_button = bool(
            not is_purchased and not is_offer_expired and offer.get('purchase_product_id', 0)
        )
        is_redeemable = redeemability_value in [self.REDEEMABLE, self.REUSABLE]

        return {
            'is_redeemable': is_redeemable,
            'redeemability': redeemability_value,
            'is_purchased': is_purchased,
            'allowed_onboarding': is_on_trial,
            'is_offer_valid_in_future': is_offer_valid_in_future,
            'is_offer_expired': is_offer_expired,
            'quantity_redeemable': offer.get('quantity') if redeemability_value == self.REUSABLE else
            max(0, num_purchased - num_redemptions),
            'quantity_redeemed': 0 if redeemability_value == self.REUSABLE else num_redemptions,
            'quantity_not_redeemable': offer.get('quantity') if not is_purchased and not is_on_trial else 0,
            'shared_sent_count': shared_sent_count,
            'shared_received_count': shared_received_count,
            'shared_redemptions_count': shared_redemptions_count,
            'is_show_purchase_button': is_show_purchase_button,
            'personal_shared_redemptions_count': personal_shared_redemptions_count,
            'personal_shared_received_count': personal_shared_received_count
        }
