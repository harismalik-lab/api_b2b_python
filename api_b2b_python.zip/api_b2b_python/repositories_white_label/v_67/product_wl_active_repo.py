"""
Contains ProductEntActiveRepository's changed methods for white label apps
"""
from collections import OrderedDict

from repositories_white_label.base_repo import BaseRepository
from repositories_white_label.product_repo import ProductRepositoryWhiteLabel
from wrapper_white_labels.sql_dal import SqlDal


class ProductWlActiveRepository(BaseRepository):
    """
    Class for product_wl_active entity
    """

    def find_by_product_id(self, product_id):
        sql_dal = SqlDal()
        sql_dal.select(['p.sf_id', 'p.is_ent', 'p.delivery_enabled', 'p.product_type'])
        sql_dal.from_(['product'], ['p'])
        sql_dal.where('p.magento_product_id', product_id)
        outlet = sql_dal.get_one(default={})
        return outlet

    def find_by_id(self, product_id):
        sql_dal = SqlDal()
        sql_dal.select(['p.sf_id', 'p.is_ent', 'p.delivery_enabled', 'p.product_type'])
        sql_dal.from_(['product'], ['p'])
        sql_dal.where('p.id', product_id)
        return sql_dal.get_one(default={})

    def get_birthday_products(self, location_id, column_to_get=None, convert_to_string=False):
        sql_dal = SqlDal()
        if column_to_get:
            sql_dal.select([column_to_get])
        else:
            sql_dal.select(['p.sf_id'])
        sql_dal.from_(['product'], ['p'])
        ordered_where_clause = OrderedDict()
        ordered_where_clause['p.product_type'] = ProductRepositoryWhiteLabel.PRODUCT_TYPE_BIRTHDAY

        if location_id:
            ordered_where_clause['p.location_id'] = location_id
        sql_dal.where(ordered_where_clause)
        records = sql_dal.get(default=[])
        alias = 'sf_id'
        if column_to_get:
            alias = column_to_get
        return [str(record[alias]) if convert_to_string else record[alias] for record in records]

    def find_bundled_product_skus_by_location(self, location_id=None):
        sql_dal = SqlDal()
        sql_dal.select(["GROUP_CONCAT(p.bundled_product_sku) AS bundled_product_sku"])
        sql_dal.from_(["product"], ["p"])
        if location_id is not None:
            sql_dal.where("location_id", location_id)
        records = sql_dal.get_one(default={})
        if records and records['bundled_product_sku']:
            records = records['bundled_product_sku'].split(',')
        return records

    def get_product_location(self, product_sku, product_id):
        """
        This method returns location_id against product_sku or product_id, 0 is defaults
        :param str product_sku: Product sf_id
        :param int product_id: Product Id
        :rtype: int
        """
        sql_dal = SqlDal()
        sql_dal.select(['p.location_id'])
        sql_dal.from_(['product'], ['p'])
        if product_sku:
            sql_dal.where('p.sf_id', product_sku)
        elif product_id:
            sql_dal.where('p.id', product_id)
        result = sql_dal.get_one(default={})
        return result.get('location_id', 0)

    def get_product_location_by_product_ids(self, product_ids):
        """
        This method returns location_ids against product_ids
        :param list product_ids: Product Id
        :rtype: list
        """
        if product_ids:
            product_ids = list(set(map(int, filter(None, product_ids))))
            sql_dal = SqlDal()
            sql_dal.select(['group_concat(distinct p.location_id) AS location_ids'])
            sql_dal.from_(['product'], ['p'])
            sql_dal.where_in('p.id', product_ids, sql_safe=True)
            result = sql_dal.get_one(default={})
            return map(int, result.get('location_ids', '').split(','))
        return []

    def get_product_pm_price(self, product_sku, locale, exchange_rates, platform, currency, request):
        """
        This returns product summary.
        :param str product_sku: Product name
        :param str locale: Locale
        :param list exchange_rates: List of exchange rates
        :param str platform: Platforrm e.g android, ios etc
        :param str currency: Desired currency
        :param flask.request request: Request object
        :rtype: dict
        """
        if not product_sku:
            return False
        sql_dal = SqlDal()
        sql_dal.select(['p.product_id'])
        sql_dal.from_(['product'], ['p'])
        sql_dal.where('p.sf_id', product_sku)
        product_summary = sql_dal.get_one(default={})
        if not product_summary:
            return False
        buy_page = self.get_buy_page_message_url(locale, request, platform)
        product_summary['buy_page_title'] = buy_page['buy_page_title']
        product_summary['buy_page_url'] = buy_page['buy_page_url']
        return product_summary

    def get_freemium_product_skus(self):
        """
        Gets the freemium product skus
        :rtype: list
        """
        product_skus = []
        sql_dal = SqlDal()
        sql_dal.select(['p.sf_id'])
        sql_dal.from_(['product'], ['p'])
        sql_dal.where({'p.is_freemium': 1, 'p.isactive': 1})
        results = sql_dal.get(default=[])
        for result in results:
            product_skus.append(result['sf_id'])
        return product_skus

    def get_freemium_product_name(self, location_id, product_ids, locale):
        """
        This returns freemium product name
        :param int location_id: Localtion Id
        :param list product_ids: Product Ids
        :param str locale: Locale
        :rtype: str
        """
        product_name = ""
        sql_dal = SqlDal()
        sql_dal.select(['p.is_purchaseable', 'p.is_freemium', 't.name'])
        sql_dal.from_(['product'], ['p']).inner_join(
            'product_translation_wl_active AS t', 't.product_id', 'p.id'
        )
        ordered_where_clause = OrderedDict()
        ordered_where_clause['p.location_id'] = location_id
        ordered_where_clause['p.isactive'] = 1
        ordered_where_clause['t.locale'] = locale
        sql_dal.set_parenthesised_where_clause(" AND (p.is_purchaseable = 1 OR p.is_freemium = 1)")
        if product_ids:
            sql_dal.where_in('p.id', product_ids)
        sql_dal.where(ordered_where_clause)
        products_owned_in_location = sql_dal.get_one(default={})
        if products_owned_in_location:
            if products_owned_in_location['is_purchaseable']:
                return ""
            if products_owned_in_location['is_freemium']:
                return products_owned_in_location['name']
        return product_name

    def get_cheers_product_by_product_ids(self, product_ids=[], convert_to_string=False):
        """
        This method returns location_ids against product_ids
        :param list product_ids: Product Id
        :rtype: list
        """
        filtered_product_ids = []
        product_ids = list(filter(None, product_ids))
        if product_ids:
            product_ids = list(set(map(int, filter(None, product_ids))))
            sql_dal = SqlDal()
            sql_dal.select(['p.id'])
            sql_dal.from_(['product'], ['p'])
            sql_dal.where('p.is_cheers', 1)
            sql_dal.where_in('p.id', product_ids, sql_safe=True)
            records = sql_dal.get(default=[])
            for record in records:
                product_id = record.get('id', 0)
                if convert_to_string:
                    product_id = str(product_id)
                filtered_product_ids.append(product_id)
        return filtered_product_ids
