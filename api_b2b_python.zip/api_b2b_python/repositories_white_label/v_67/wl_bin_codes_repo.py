"""
File contains methods related to wl bin codes.
"""
from python_api.repositories.base_repo import BaseRepository
from python_api.wrapper.sql_dal import SqlDal


class WlBinCodesRepositoryWhiteLabelV67(BaseRepository):
    """
    Wl bin codes repository houses all the methods related to bin codes.
    """
    def get_key_info(self, key, company='MCE'):
        """
        Gets key info of a company against the bin code.
        :param key: bin code
        :param company: company code
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select(['*'])
        sql_dal.from_(['wl_bin_codes'])
        sql_dal.where({'bin': key, 'wl_company': company})
        return sql_dal.get_one(default={})
