"""
Redemption Repository
"""
from collections import OrderedDict

from flask import current_app

from python_api.repositories.v_67.redemption_repo import RedemptionRepositoryV67
from python_api.wrapper.sql_dal import SqlDal


class RedemptionRepositoryWL67(RedemptionRepositoryV67):

    def get_redeemed_quantites_for_customer(
            self, customer_id, is_onboarding=False, offer_id=None, company='hs', primary_user_id=0, family_id=0
    ):
        """
        Get redeemed quantities
        :param int customer_id: Customer Id
        :param bool is_onboarding: Boolean flag to manipulate results
        :param int offer_id: Offer Id
        :param str company: Company
        :param int primary_user_id: Primary User Id
        :param int family_id: Family Id
        """
        assert (family_id and primary_user_id) or customer_id, 'Insufficient params'
        sql_dal = SqlDal(single_connection=self.single_connection, connection=self.db_connection)
        sql_dal.select(["r.offer_id", "SUM(r.quantity) qty"])
        sql_dal.from_(["redemption"], ["r"])
        if current_app.config.get('IS_PRODUCTION'):
            sql_dal.where_gte('r.id', 31820843)
        sql_dal.like("r.company", company, enable_start_wild_card=False)
        if primary_user_id == customer_id:
            where_clause = "AND (r.primary_user_id={customer_id} OR (r.customer_id={customer_id}" \
                           " AND COALESCE(r.primary_user_id,0) = 0)) AND r.is_shared=1"
            sql_dal.set_parenthesised_where_clause(where_clause, {'customer_id': customer_id})
        elif primary_user_id:
            # To handle birthday case
            where_clause = "AND r.is_shared=0 AND coalesce(r.is_birthday_offer,0) = 0 AND" \
                           " (r.primary_user_id = {primary_user_id} or (r.customer_id = {primary_user_id}" \
                           " and coalesce(r.primary_user_id,0) = 0))"
            sql_dal.set_parenthesised_where_clause(where_clause, {"primary_user_id": primary_user_id})
        else:
            where_clause = "AND (r.primary_user_id = {customer_id} OR (r.customer_id = {customer_id}" \
                           " AND COALESCE(r.primary_user_id, 0) = 0)) AND r.is_shared=0"
            sql_dal.set_parenthesised_where_clause(where_clause, {'customer_id': customer_id})
        if not is_onboarding:
            sql_dal.where("r.is_onboarding", 0)
        if offer_id:
            if isinstance(offer_id, list):
                sql_dal.where_in('r.offer_id', offer_id, sql_safe=True)
            else:
                sql_dal.where('r.offer_id', offer_id)
        if company:
            sql_dal.like('r.company', company, enable_start_wild_card=False)
        sql_dal.where_in('r.status', [self.ACTIVE, self.IN_PROGRESS], sql_safe=True)
        sql_dal.group_by(["r.offer_id"])
        redemption_quantities = {}
        redemption_results = sql_dal.get(default=[])
        for redemption in redemption_results:
            redemption_quantities[redemption['offer_id']] = int(redemption['qty'])
        return redemption_quantities

    def get_birthday_redeemed_quantites_for_secondary_customer(
            self, customer_id, is_onboarding=False, offer_id=None, company='hs'
    ):
        """
        Get birthday redeemed quantities
        :param int customer_id: Customer Id
        :param bool is_onboarding: Boolean flag to manipulate results
        :param int offer_id: Offer Id
        :param str company: Company
        """
        sql_dal = SqlDal(single_connection=self.single_connection, connection=self.db_connection)
        sql_dal.select(["r.offer_id", "SUM(r.quantity) qty"])
        sql_dal.from_(["redemption"], ["r"])
        sql_dal.like("r.company", company, enable_start_wild_card=False)
        if customer_id:
            # To handle birthday case
            ordered_where_clause = OrderedDict()
            ordered_where_clause['r.customer_id'] = customer_id
            ordered_where_clause['r.primary_user_id'] = customer_id
            ordered_where_clause['r.is_shared'] = 0
            ordered_where_clause['r.is_birthday_offer'] = 1
            sql_dal.where(ordered_where_clause)
        if not is_onboarding:
            sql_dal.where("r.is_onboarding", 0)
        if offer_id:
            sql_dal.where('r.offer_id', offer_id)
        sql_dal.where_in('r.status', [self.ACTIVE, self.IN_PROGRESS], sql_safe=True)
        sql_dal.group_by(["r.offer_id"])
        redemption_quantities = {}
        redemption_results = sql_dal.get(default=[])
        for redemption in redemption_results:
            redemption_quantities[redemption['offer_id']] = int(redemption['qty'])
        return redemption_quantities

    def get_redeemed_quantites_for_customer_vc01(self, **kwargs):
        """
        Get redeemed quantities for rewards user
        :param args:
        :param kwargs:
        int customer_id: Customer Id
        str company: Company
        """
        sql_dal = SqlDal(single_connection=self.single_connection, connection=self.db_connection)
        sql_dal.select(["r.offer_id", "SUM(r.quantity) qty"])
        sql_dal.from_(["redemption"], ["r"])
        ordered_where_clause = OrderedDict()
        ordered_where_clause['r.customer_id'] = kwargs.get('customer_id', 0)
        ordered_where_clause['r.company'] = kwargs.get('company', 'slice')
        ordered_where_clause['r.is_shared'] = False
        sql_dal.where(ordered_where_clause)
        sql_dal.group_by(["r.offer_id"])
        redemption_quantities = {}
        redemption_results = sql_dal.get(default=[])
        for redemption in redemption_results:
            # TODO: Improve
            redemption_quantities[redemption['offer_id']] = int(redemption['qty'])
        return redemption_quantities

    def get_root_code_by_offer_base_table(self, offer_id=0, product_id=0):
        """
        Get the root codes.
        :param int offer_id: Offer Id
        :param int product_id: Product Id
        :return: list result: Root codes.
        :rtype: list
        """
        sql_dal = SqlDal(single_connection=self.single_connection, connection=self.db_connection)
        sql_dal.select(['po.root_code'])
        sql_dal.from_('product as p')
        sql_dal.inner_join('product_offer_wl_active as po', 'p.id', 'po.product_id')
        if int(product_id) > 0:
            sql_dal.where({
                'po.product_id': product_id,
                'po.offer_id': offer_id
            })
        else:
            sql_dal.set_parenthesised_where_clause(
                "AND (p.type = 'Digital' OR p.type = 'Other')"
            )
            sql_dal.where({'po.offer_id': offer_id})
        result = sql_dal.get(default=[])
        return result

    def get_redemptions_in_last_xhours_for_offer_for_customer(self, *args, **kwargs):
        """
        Get the redemption by time.
        :param args:
        :param kwargs:
        int customer_id: Customer Id
        int offer_id: Offer Id
        str company: Company
        int number_of_hours: Number of hours
        :return: redemption
        """
        redemptions_count = 0
        try:
            sql_dal = SqlDal(single_connection=self.single_connection, connection=self.db_connection)
            sql_dal.select(['r.id'])
            sql_dal.from_(['redemption AS r'])
            sql_dal.where({'r.customer_id': kwargs.get('customer_id', 0), 'offer_id': kwargs.get('offer_id', 0)})
            sql_dal.like('r.company', kwargs.get('company', 'hs'))
            sql_dal.set_parenthesised_where_clause(
                'AND DATE_ADD(r.date_created, INTERVAL {number_of_hours} hour) > CURRENT_TIMESTAMP()'.format(
                    number_of_hours=kwargs.get('number_of_hours', 24)
                )
            )
            return sql_dal.get_count()
        except Exception:
            pass
        return redemptions_count

    def get_root_code_by_offer(self, offer_id):
        """
        Get the root code by offer.
        :param int offer_id: Offer Id
        :return: records: Root code.
        """
        sql_dal = SqlDal(single_connection=self.single_connection, connection=self.db_connection)
        sql_dal.select(['po.root_code'])
        sql_dal.from_(['product_wl_active AS p'])
        sql_dal.inner_join('product_offer_wl_active AS po', 'p.id', 'po.product_id')
        sql_dal.where('po.offer_id', offer_id)
        records = sql_dal.get(default=[])
        return records

    def get_redeemed_quantites_for_customer_primary(
            self, customer_id, is_onboarding=False, offer_id=None, company='hs',
    ):
        """
        Get redeemed quantites
        :param int customer_id: Customer Id
        :param bool is_onboarding: Boolean flag to manipulate results
        :param int offer_id: Offer Id
        :param str company: Company
        """
        if customer_id:
            sql_dal = SqlDal(single_connection=self.single_connection, connection=self.db_connection)
            sql_dal.select(["r.offer_id", "SUM(r.quantity) qty"])
            sql_dal.from_(["redemption"], ["r"])
            sql_dal.where({"r.is_shared": False})
            sql_dal.like("r.company", company, enable_start_wild_card=False)
            sql_dal.set_parenthesised_where_clause(
                ' AND (case when r.primary_user_id is NULL '
                'then r.customer_id else r.primary_user_id end)={customer_id} '.format(customer_id=customer_id)
            )
            if not is_onboarding:
                sql_dal.where("r.is_onboarding", 0)
            if offer_id:
                if isinstance(offer_id, list):
                    sql_dal.where_in('r.offer_id', offer_id)
                else:
                    sql_dal.where('r.offer_id', offer_id)
            sql_dal.where_in('r.status', [self.ACTIVE, self.IN_PROGRESS], sql_safe=True)
            sql_dal.group_by(["r.offer_id"])
            redemption_quantities = {}
            redemption_results = sql_dal.get(default=[])
            for redemption in redemption_results:
                # TODO: Improve
                redemption_quantities[redemption['offer_id']] = int(redemption['qty'])
            return redemption_quantities
        return {}

    def find_redemptions_count_by_customer(self, **kwargs):
        """
        Find redemption count by customer.
        :param args:
        :param kwargs:
         int customer_id: Customer Id
         str company: Company
        :return: count
        """
        if kwargs.get('customer_id', 0):
            sql_dal = SqlDal(single_connection=self.single_connection, connection=self.db_connection)
            sql_dal.select(['COUNT(id) as redemptions'])
            sql_dal.from_('redemption')
            sql_dal.where({'customer_id': kwargs.get('customer_id', 0)})
            sql_dal.where_in('status', [self.ACTIVE, self.IN_PROGRESS], sql_safe=True)
            sql_dal.like('company', kwargs.get('company', 'hs'), enable_start_wild_card=False)
            result = sql_dal.get_one(default={}).get('redemptions')
            if result:
                return result
        return 0
