"""
Contains valid mobile os repository methods.
"""
from python_api.repositories.base_repo import BaseRepository
from python_api.wrapper.sql_dal import SqlDal


class ValidateMobileOsRepositoryWhiteLabelV67(BaseRepository):
    """
    Contains methods related to mobile os validation.
    """
    def validate_model(self, model, company):
        """
        Validates mobile os against company code.
        :param model: model of device
        :param company: company of the customer
        :rtype: bool
        """
        sql_dal = SqlDal()
        sql_dal.select(['device_model'])
        sql_dal.from_(['validate_mobile_os'])
        sql_dal.where({
            'device_model': model,
            'wl_company': company,
            'active': 1
        })
        result = sql_dal.get_one(default={})
        if result:
            return True
        return False
