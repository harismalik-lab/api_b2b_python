"""
Merchant repository v67 for White label apps
"""

from collections import OrderedDict

from flask import g

from python_api.common.common_helpers import TranslationManager
from python_api.repositories.categories_repo import CategoriesRepository
from python_api.repositories.product_repo import ProductRepository
from python_api.repositories.v67.merchant_repo import MerchantRepositoryV67
from python_api.wrapper.sql_dal import SqlDal

cache = g.cache


class MerchantRepositoryWl67(MerchantRepositoryV67):

    @staticmethod
    @cache.memoize(timeout=3600)
    def get_featured_merchants_cached(locale, category, location_id, api_version='v65'):
        featured_merchants = []
        sql_dal = SqlDal()
        sql_dal.select([
            'DISTINCT m.id', 't.name', 't.description', 'm.category', 'm.digital_section',
            'COALESCE(t.cuisine, "") AS cuisine', 'COALESCE(m.ad_travel_country, "") as ad_travel_country',
            'm.is_featured', 'm.ad_active_status', '"FEATURED" as featured_title', "'' as featured_image",
            'm.logo_retina_url as logo_url', 'm.logo_non_retina_url as logo_small_url',
            'm.photo_retina_url as photo_url', 'm.photo_non_retina_url as photo_small_url',
            'COALESCE(f.featured_category, "") AS featuredCategory', 'count(distinct otl.id) as outlets_count',
            '"" as outlets_info', 'GROUP_CONCAT(DISTINCT otl.id) as outlet_ids'
        ])
        sql_dal.from_(['offer_wl_active'], ['ofr'])
        sql_dal.inner_join('outlet_offer AS o', 'ofr.id', 'o.offer_id')
        sql_dal.inner_join('outlets AS otl', 'otl.id', 'o.outlet_id')
        sql_dal.inner_join('merchant AS m', 'm.id', 'ofr.merchant_id')
        sql_dal.inner_join('merchant_translation AS t', 't.merchant_id', 'm.id')
        sql_dal.where('t.locale', locale)
        sql_dal.inner_join('featured_merchant AS f', 'f.merchant_id', 'm.id')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['otl.active'] = 1
        ordered_where_clause['otl.location_id'] = location_id
        ordered_where_clause['ofr.merchant_category'] = category
        ordered_where_clause['f.is_featured_for_home_screen'] = 0
        ordered_where_clause['f.is_active'] = 1
        sql_dal.where(ordered_where_clause)
        sql_dal.where_lt('f.valid_from', 'CURRENT_TIMESTAMP()', sql_safe=True)
        sql_dal.where_gt("DATE_ADD(f.valid_to, INTERVAL 1 DAY )", "CURRENT_TIMESTAMP()", sql_safe=True)
        sql_dal.group_by([
            'm.id', 't.name', 't.description', 'm.category', 'm.digital_section', 't.cuisine', 'm.ad_travel_country',
            'm.is_featured', 'm.ad_active_status', 'm.logo_retina_url', 'm.logo_non_retina_url', 'm.photo_retina_url',
            'm.photo_non_retina_url'
        ])
        sql_dal.order_by({'m.position': 'ASC'})
        records = sql_dal.get(default=[])

        outlet_label_singular = TranslationManager().get_translation(
            TranslationManager.OUTLET_COUNT_SINGULAR,
            locale
        )
        outlet_label_plural = TranslationManager().get_translation(
            TranslationManager.OUTLET_COUNT_PLURAL,
            locale
        )

        for record in records:
            record['is_featured'] = bool(record.get('is_featured', 0))
            record['featured_image'] = CategoriesRepository.FEATURED_HOMES_IMAGE.get(category)
            record['outlets_count'] = int(record.get('outlets_count', 0))
            if record['outlets_count']:
                record['outlets_info'] = '{outlets_count} {label}'.format(
                    outlets_count=record['outlets_count'],
                    label=outlet_label_singular if record['outlets_count'] == 1 else outlet_label_plural
                )
            if record.get('id') and int(record.get('id', 0)):
                featured_merchants.append(record)
        return featured_merchants

    def get_voucher_merchant_name(self, offer_id, locale='en'):
        sql_dal = SqlDal()
        sql_dal.select(['ot.name AS merchant_name', 't.name AS offer_name'])
        sql_dal.from_(['merchant'], ['m'])
        sql_dal.inner_join('merchant_translation AS t', 't.merchant_id', 'm.id')
        sql_dal.where('t.locale', locale)
        sql_dal.inner_join('offer_wl_active AS o', 'o.merchant_id', 'm.id')
        sql_dal.inner_join('offer_translation_wl_active AS ot', 'o.id', 'ot.offer_id')
        sql_dal.where({'ot.locale': locale, 'o.id': offer_id})
        merchants = sql_dal.get_one(default={})
        if not merchants:
            return ''
        merchant = '{merchant_name} ( {offer_name} )'.format(
            merchant_name=merchants['merchant_name'],
            offer_name=merchants['offer_name']
        )
        return merchant

    def get_featured_merchants(
            self, location_id, category, featured_category, billing_country='',
            locale='en', is_cheers=False, is_customer_own_cheers_for_location=False,
            add_future_check=True
    ):
        featured_merchants = []

        if is_cheers and not is_customer_own_cheers_for_location:
            return featured_merchants
        sql_dal = SqlDal()
        sql_dal.select([
            'm.id', 't.name', 'm.position', 't.description', 'm.category', 'm.digital_section',
            't.cuisine', 'COALESCE(m.ad_travel_country, "") as ad_travel_country', 'm.is_featured',
            'm.ad_active_status', 'm.logo_retina_url as logo_url',
            'm.logo_non_retina_url as logo_small_url', 'm.photo_retina_url as photo_url',
            'm.photo_non_retina_url as photo_small_url', 'count(distinct otl.id) as outlets_count',
            '"" as outlets_info', 'GROUP_CONCAT(DISTINCT otl.id) as outlet_ids'
        ])
        sql_dal.from_(['offer_wl_active'], ['ofr'])
        sql_dal.inner_join('outlet_offer AS o', 'ofr.id', 'o.offer_id')
        sql_dal.inner_join('outlets AS otl', 'otl.id', 'o.outlet_id')
        sql_dal.inner_join('merchant AS m', 'm.id', 'ofr.merchant_id')
        sql_dal.inner_join('merchant_translation AS t', 't.merchant_id', 'm.id')
        sql_dal.inner_join('featured_merchant AS f', 'f.merchant_id', 'm.id')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['t.locale'] = locale
        ordered_where_clause['f.featured_category'] = featured_category
        ordered_where_clause['otl.active'] = 1
        ordered_where_clause['f.is_featured_for_home_screen'] = 0
        ordered_where_clause['ofr.merchant_category'] = category
        ordered_where_clause['f.is_active'] = 1
        sql_dal.where(ordered_where_clause)
        sql_dal.where_lt('f.valid_from', 'CURRENT_TIMESTAMP()', sql_safe=True)

        if add_future_check:
            sql_dal.where_gt("DATE_ADD(f.valid_to, INTERVAL 1 DAY )", "CURRENT_TIMESTAMP()", sql_safe=True)

        if location_id and category.lower() != 'travel':
            sql_dal.where('otl.location_id', location_id)

        if category.lower() == 'travel' and billing_country:
            sql_dal.where('otl.billing_country', billing_country)

        sql_dal.group_by([
            'm.id', 't.name', 't.description', 'm.category', 'm.digital_section', 't.cuisine', 'm.ad_travel_country',
            'm.is_featured', 'm.ad_active_status', 'm.logo_retina_url', 'm.logo_non_retina_url', 'm.photo_retina_url',
            'm.photo_non_retina_url'
        ])
        sql_dal.order_by({'m.position': 'ASC'})
        records = sql_dal.get(default=[])
        outlet_label_plural = ''

        if category == 'Travel':
            outlet_label_singular = TranslationManager().get_translation(TranslationManager.TRAVEL_LOCATION, locale)
        else:
            outlet_label_singular = TranslationManager().get_translation(
                TranslationManager.OUTLET_COUNT_SINGULAR,
                locale
            )
            outlet_label_plural = TranslationManager().get_translation(
                TranslationManager.OUTLET_COUNT_PLURAL,
                locale
            )

        for record in records:
            if record.get('id'):
                if record['category'] == 'Travel':
                    record['outlets_info'] = outlet_label_singular
                elif record['outlets_count'] > 0:
                    record['outlets_info'] = '{outlets_count} {label}'.format(
                        outlets_count=record['outlets_count'],
                        label=outlet_label_singular if record['outlets_count'] == 1 else outlet_label_plural
                    )
                featured_merchants.append(record)
        return featured_merchants

    def get_merchants(self, locale, product_id, product_sku, location_id, merchant_id, categories, offset, limit):
        inline_query = "SELECT COUNT(*) " \
                       "FROM product_ent_active AS pa " \
                       "WHERE pa.sf_id = '{sf_id}' " \
                       "AND pa.id=MAX(p.id)".format(sf_id=ProductRepository.MORE_SA_PRODUCT_SKU)
        sql_dal = SqlDal()
        sql_dal.select([
            'm.id', 'MAX(t.name) name', 't.description', 'm.category',
            'm.logo_retina_url AS logo_url', 'm.logo_non_retina_url AS logo_small_url',
            'm.logo_offer_retina_url AS logo_offer_url',
            'm.logo_offer_non_retina_url AS logo_offer_small_url', 'm.photo_retina_url AS photo_url',
            'm.photo_non_retina_url AS photo_small_url', 'MAX(t.cuisine) cuisine', 'm.digital_section',
            'MAX(p.is_cheers) is_cheers', 'MAX(p.delivery_enabled) as is_delivery',
            'GROUP_CONCAT(outlets.id) AS outlet_ids',
            '(CASE WHEN ({}) > 0 THEN True ELSE False END) AS is_more_sa'.format(inline_query)
        ])
        sql_dal.from_(['offer_wl_active'], ['ofr'])
        sql_dal.inner_join('product_offer_wl_active AS po', 'ofr.id', 'po.offer_id')
        sql_dal.inner_join('product_wl_active AS p', 'po.product_id', 'p.id')
        sql_dal.inner_join('outlet_offer', 'ofr.id', 'outlet_offer.offer_id')
        sql_dal.inner_join('outlets', 'outlets.id', 'outlet_offer.outlet_id')
        sql_dal.inner_join('merchant AS m', 'ofr.merchant_id', 'm.id')
        sql_dal.inner_join('merchant_translation AS t', 't.merchant_id', 'm.id')
        sql_dal.left_join('product AS prd', 'prd.id', 'p.product_id')
        sql_dal.where({'t.locale': locale, 'outlets.active': 1})
        if product_id:
            sql_dal.where('p.id', product_id)
        elif product_sku:
            sql_dal.where('prd.sf_id', product_sku)
        # Filter down by location
        if location_id:
            sql_dal.where('outlets.location_id', location_id)
        if merchant_id:
            sql_dal.where('m.id', merchant_id)
        # Filter down by category
        if len(categories) > 1 or (len(categories) == 1 and categories[0] != 'All'):
            sql_dal.where_in('m.category', categories)
        sql_dal.group_by(['m.id'])
        # Sort Alphabetically
        sql_dal.order_by({'MAX(t.name)': 'ASC'})
        start = offset
        if offset is None or offset < 0:
            start = 0
        if limit and limit < 0:
            limit = None
        end = start + limit if isinstance(limit, int) else None
        sql_dal.limit(end if end else 1000)
        merchants = sql_dal.get(default=[])[start:end if end and end - start <= 999 else start + 999]
        return merchants

    def get_dm_merchant_details(self, merchant_ids=[], locale='en'):
        """
        Gets all the details of the merchants
        :param list merchant_ids: list of merchant ids
        :param str locale: language of user
        :rtype: dict
        """
        if merchant_ids:
            merchant_ids_list = []
            for _merchant_id in merchant_ids:
                merchant_ids_list.append(_merchant_id.get('id'))

            sql_dal = SqlDal()
            sql_dal.select([
                'DISTINCT otl.id as outlet_id', 'ott.name as outlet_name', 'otl.sf_id as outlet_sf_id',
                'm.sf_id as merchant_sf_id', 'm.id as merchant_id'
            ])
            sql_dal.from_(['offer_wl_active'], ['o'])
            sql_dal.inner_join('product_offer_wl_active AS po', 'o.id', 'po.offer_id')
            sql_dal.inner_join('product_wl_active AS p', 'po.product_id', 'p.id')
            sql_dal.inner_join('outlet_offer AS ot', 'o.id', 'ot.offer_id')
            sql_dal.inner_join('outlets AS otl', 'otl.id', 'ot.outlet_id')
            sql_dal.inner_join('outlet_translation AS ott', 'ot.outlet_id', 'ott.outlet_id')
            sql_dal.inner_join('merchant AS m', 'o.merchant_id', 'm.id')
            sql_dal.left_join('product AS prd', 'prd.id', 'p.product_id')
            sql_dal.where_in('m.id', merchant_ids_list)
            ordered_where_clause = OrderedDict()
            ordered_where_clause['ott.locale'] = locale
            ordered_where_clause['prd.delivery_enabled'] = 1
            sql_dal.where(ordered_where_clause)
            merchant_details = sql_dal.get(default=[])

            merchants = []
            if merchant_details:
                for _i, merchant_id in enumerate(merchant_ids):
                    merchant_outlets = []
                    for _index in merchant_details:
                        if _index['merchant_id'] == merchant_id.get('id'):
                            merchant_outlets.append({
                                'outlet_id': _index['outlet_id'],
                                'outlet_name': _index['outlet_name'],
                                'outlet_sf_id': _index['outlet_sf_id']
                            })
                    if merchant_outlets:
                        merchants.append({
                            'merchant_id': merchant_id.get('id'),
                            'merchant_outlets': merchant_outlets,
                            'merchant_sf_id': merchant_id.get('sf_id'),
                            'merchant_name': merchant_id.get('name')
                        })
            return merchants
