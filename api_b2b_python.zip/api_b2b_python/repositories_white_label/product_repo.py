"""
Product Repository
"""
from datetime import datetime

from flask import current_app

from common_white_label.common_helpers import CommonHelpers
from common_white_label.constants import VALID_CURRENCIES
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class ProductRepositoryWhiteLabel(BaseRepository):
    PRODUCT_TYPE_BIRTHDAY = 1

    def get_buy_page_message_url(self, locale, host, platform='ios'):
        """
        Gets the URL for buy page.
        :param str locale: Locale
        :param str host: API Host
        :param str platform: Platform
        :return: dict object: Buy page title and URL
        :rtype: dict
        """
        buy_page_url = current_app.config.get('BUY_PAGE_URL', '')
        if platform.lower() == 'android':
            platform = 'and'
        buy_page_title = "buy_page_title_{locale}".format(locale=locale)
        return {
            'buy_page_title': buy_page_title,
            'buy_page_url': '{buy_page_url}{platform}?{time}&pay_options=true'.format(
                buy_page_url=buy_page_url, platform=platform, time=datetime.now()
            )
        }

    def find_by_id(self, product_id=0):
        """
        Finds the product by id.
        :param product_id: product id.
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select(['delivery_enabled'])
        sql_dal.from_(['product'])
        sql_dal.where('id', product_id)
        return sql_dal.get_one(default={})

    def get_product_ids(self, company='entertainer'):
        """
        Gets the product ids.
        :param str company: company name
        :rtype: list
        """
        sql_dal = SqlDal()
        sql_dal.select(['p.edition as section_name', 'GROUP_CONCAT(p.id) as product_ids'])
        sql_dal.from_(['location'], ['l'])
        sql_dal.inner_join('product as p', 'l.id', 'p.location_id')
        sql_dal.inner_join('product_wl_active as wlp', 'wlp.product_id', 'p.id')
        sql_dal.where({'wlp.company': company})
        sql_dal.order_by({'p.edition': 'DESC'})
        sql_dal.group_by(['p.edition'])
        return sql_dal.get(default=[])

    def get_products_by_id(self, company, locale, location_id=0, product_ids=[]):
        """
        Get the products by id.
        :param str company: company name
        :param str locale: locale
        :param int location_id: location id
        :param list product_ids: product ids
        :rtype: list
        """
        sql_dal = SqlDal()
        columns = [
            'p.id', 'p.sf_id as sku', 't.name', 'wlp.price', 'p.currency',
            'wlp.image as image', 'p.location_id as location_id', 'p.categories',
            'p.valid_to as valid_to', 'coalesce ( t.offer_summary, "") as offer_summary',
            'p.is_cheers', 'COALESCE(p.color_code, "") as color_code',
            'COALESCE(p.title_color, "") as title_color', 'p.location_id as order_id'
        ]
        if location_id > 0:
            columns.append('CASE WHEN p.location_id = {location_id} THEN 1 ELSE 2 END'.format(location_id=location_id))
        else:
            columns.append('COALESCE(p.location_id, 0)')

        sql_dal.select(columns)
        sql_dal.from_(['product'], ['p'])
        sql_dal.inner_join('product_wl_active as wlp', 'wlp.product_id', 'p.id')
        sql_dal.inner_join('product_translation as t', 't.product_id', 'p.id')
        sql_dal.where({'wlp.is_active': 1, 'wlp.company': company, 't.locale': locale})
        sql_dal.where_in('p.id', product_ids)
        sql_dal.order_by({
            'order_id': 'ASC',
            'p.location_id': 'ASC',
            't.name': 'ASC',
            'p.sequence': 'DESC'
        })
        return sql_dal.get(default=[])

    def get_conversion_rate(self, exchange_rates, price, to_currency):
        """
        Gets the conversion rate for desired currency
        :param list exchange_rates: List of exchange rates
        :param int|float price: Price to be converted
        :param str to_currency: Currency to be converted
        :rtype: int|float
        """
        if price:
            to_rate = 1
            for exchange_rate in exchange_rates:
                if exchange_rate.get('currency', '') == to_currency:
                    to_rate = exchange_rate.get('rate', '')
                    # TODO: may be break loop here
            return price * to_rate

    def get_product_price_json(self, product_price, currency, exchange_rates):
        """
        Gets the dict of converted prices.
        :param int|float product_price: Product price
        :param str currency: Currency
        :param list exchange_rates: List of exchange rates
        :rtype: dict
        """
        product_price_aed = product_price
        if currency != "AED" and product_price_aed:
            product_price_aed = self.get_conversion_rate(exchange_rates, product_price, currency)
            to_rate = 1
            for exchange_rate in exchange_rates:
                if exchange_rate.get('currency', '') == currency:
                    to_rate = exchange_rate.get('rate', '')
                    # TODO: may be break loop here
            product_price_aed = product_price / to_rate
        prices_json = dict()
        for curr in VALID_CURRENCIES:
            if curr == 'AED':
                continue
            if curr == currency:
                price = product_price
            else:
                price = self.get_conversion_rate(
                    exchange_rates,
                    product_price_aed,
                    curr
                )
            prices_json[curr] = CommonHelpers.number_format(price, 2) if price else None
        prices_json["AED"] = CommonHelpers.number_format(product_price_aed, 2) if product_price_aed else None
        return prices_json

    def calculate_product_price(self, products, exchange_rates):
        """
        Calculates the product price.
        :param list products: Products
        :param list exchange_rates: Exchange rates
        :rtype: dict
        """
        for product in products:
            product['categories'] = product.get('categories', None)
            prices_json = self.get_product_price_json(
                product.get('price'), product.get('currency'), exchange_rates
            )
            product['prices'] = prices_json
        return products

    def get_product_details(self, company, product_id, locale, exchange_rates):
        """
        Gets the details of a product
        :param str company: Company name
        :param int product_id: Product id
        :param str locale: Locale
        :param list exchange_rates: List of exchange rates
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select([
            'p.id', 'p.sf_id', 'wlp.price', 'p.currency', 't.name',
            'COALESCE( t.product_summary, "" ) product_summary',
            'COALESCE( t.offer_summary, "" ) offer_summary',
            'COALESCE( t.category_summary, "" ) category_summary',
            'COALESCE( t.savings_summary, "" ) savings_summary',
            'COALESCE( t.travel_summary, "" ) travel_summary'
        ])
        sql_dal.from_(['product'], ['p'])
        sql_dal.inner_join('product_wl_active as wlp', 'wlp.product_id', 'p.id')
        sql_dal.inner_join('product_translation as t', 't.product_id', 'p.id')
        sql_dal.where({
            'wlp.is_active': 1,
            'wlp.company': company,
            't.product_id': product_id,
            't.locale': locale
        })
        product_summary = sql_dal.get_one(default={})
        product_summary['prices'] = self.get_product_price_json(
            product_summary.get('price'),
            product_summary.get('currency'),
            exchange_rates
        )
        return product_summary

    def get_product_price_details(self, company, product_sku, locale, exchange_rates, platform, currency, host):
        """
        Gets the product's price details.
        :param str company: Company
        :param str product_sku: Product sku
        :param str locale: Locale
        :param list exchange_rates: List of exchange rates
        :param str platform: Platform
        :param str currency: Currency
        :param str host: Host
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select(['p.id', 'wlp.price', 'p.currency'])
        sql_dal.from_(['product'], ['p'])
        sql_dal.inner_join('product_wl_active as wlp', 'wlp.product_id', 'p.id')
        sql_dal.where({'p.sf_id': product_sku, 'wlp.company': company})
        product_summary = sql_dal.get_one(default={})
        buy_page = self.get_buy_page_message_url(locale, host, platform)
        product_summary['buy_page_title'] = buy_page['buy_page_title']
        product_summary['buy_page_url'] = buy_page['buy_page_url']
        try:
            del product_summary['currency']
        except KeyError:
            pass
        return product_summary
