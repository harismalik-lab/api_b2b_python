"""
Exchange Rates Repository
"""
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class ExchangeRatesRepositoryWL(BaseRepository):
    """
    Returns list of conversion rates and exchange rates
    """
    def get_conversion_rate(self, price, currency_from, currency_to, **kwargs):
        """
        Returns list of conversion rate
        :param str currency_from: currency to convert from
        :param int|float price: price
        :param str currency_to: currency to convert to
        :param bool is_analytics: whether the is being called by analytics api or not
        :rtype: float
        """
        from_rate, to_rate = 1, 1
        sql_dal = SqlDal(single_connection=self.single_connection, connection=self.db_connection)
        sql_dal.select(['e.currency', 'e.rate'])
        sql_dal.from_(['exchange_rate'], ['e'])
        results = sql_dal.get(default=[])
        for result in results:
            if result.get('currency') == currency_from:
                from_rate = result['rate']
            if result.get('currency') == currency_to:
                to_rate = result['rate']
        result = round(price / from_rate * to_rate, 2)
        return result

    def get_exchange_rates(self):
        """
        Returns list of exchange rates
        :rtype: list
        """
        sql_dal = SqlDal(single_connection=self.single_connection, connection=self.db_connection)
        sql_dal.select(['e.currency', 'e.rate'])
        sql_dal.from_(['exchange_rate'], ['e'])
        return sql_dal.get(default=[])
