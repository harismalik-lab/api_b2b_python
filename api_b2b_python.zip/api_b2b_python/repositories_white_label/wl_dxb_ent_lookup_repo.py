"""
WL Crg Lookup Repository
"""
from collections import OrderedDict

from common_white_label.db import CONSOLIDATION
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class WlDxbEntRepository(BaseRepository):
    """
    Database helper for dxb_ent_lookup database.
    """
    def find_customer(self, customer_id):
        """
        find customer from dxb_ent_lookup table according to customer_id
        :param customer_id:
        :return:
        """
        sql_dal = SqlDal(connection=CONSOLIDATION)
        sql_dal.select(['*'])
        sql_dal.from_(['dxb_ent_lookup'])
        ordered_where_clause = OrderedDict()
        ordered_where_clause['user_id'] = customer_id
        ordered_where_clause['is_active'] = True
        sql_dal.where(ordered_where_clause)
        sql_dal.limit(1)
        return sql_dal.get_one(default={})
