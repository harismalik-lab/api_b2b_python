"""
UI Configurations Repository
"""
import datetime

from repositories_white_label.base_repo import BaseRepository


class UiConfigs(BaseRepository):

    EXIT_CONFIRMATION_ALERT_TEXT = "Are you sure you want to navigate away from ENTERTAINER express?"
    MAX_DAYS_LIMIT = 90
    UI_CONFIGURATIONS = {
        "filter_selection_background_color": "1795ba",
        "filter_unselection_background_color": "ffffff",
        "filter_show_more_option_image_url": "https://cdngtwys.theentertainerme.com/chevron-Forward.png",  # noqa: E501
        "home_unselected_currency_title": "Please select Currency",
        "home_unselected_destination_message": "Please select location",
        "home_unselected_check_in_out_date_message": "Please select date",
        "home_selected_destination_title": "",
        "home_unselected_check_in_out_date_title": "Select Date",
        "hotel_attribute_unselected_text_color": "000000",
        "hotel_attribute_selected_text_color": "ffffff",
        "hotel_attribute_unselected_background_color": "ffffff",
        "hotel_attribute_selected_background_color": "1795ba",
        "travellers_detail_button_text": "APPLY DETAILS",
        "travellers_detail_button_update_text": "Update",
        "right_arrow": "https://cdngtwys.theentertainerme.com/chevron-Right.png",
        "sort_option_title": "Sort by",
        "app_corporate_color_dark": "1795ba",
        "app_corporate_color_light": "23ccfc",
        "calendar_selection_color": "1795ba",
        "calendar_topbar_text_color": "282828",
        "calendar_topbar_border_color": "999999",
        "hotel_Booking_fields_border_color": "dcdcdc",
        "calendar_bottombar_text_color": "ffffff",
        "placeholder_image": "https://cdngtwys.theentertainerme.com/107957263-hotel-vector-icon-isolated-on-transparent-background-hotel-logo-concept.png",  # noqa: E501
        "app_corporate_image_url": "https://cdngtwys.theentertainerme.com/gradient-img.png",
        "destination_icon": "https://cdngtwys.theentertainerme.com/ic-Search-Locaiton-Pin-3x.png",  # noqa: E501
        "calender_icon": "https://cdngtwys.theentertainerme.com/ic-Calendar-Dates-3x.png",
        "guest_icon": "https://cdngtwys.theentertainerme.com/people-Adult.png",
        "drop_arrow_dark": "https://cdngtwys.theentertainerme.com/chevron-Down.png",
        "drop_arrow_light": "https://cdngtwys.theentertainerme.com/chevron-Down-Gray.png",
        "back_navigation_arrow": "https://cdngtwys.theentertainerme.com/chevron-Back.png",
        "search_icon": "https://cdngtwys.theentertainerme.com/ic-Calendar-Dates-3x.png",
        "close_icon_dark": "https://cdngtwys.theentertainerme.com/close-dark.png",
        "close_icon_light": "https://cdngtwys.theentertainerme.com/ic-Calendar-Dates-3x.png",
        "selection_tick": "https://cdngtwys.theentertainerme.com/check-mark.png",
        "location_dark_icon": "https://cdngtwys.theentertainerme.com/location.png",
        "location_light_icon": "https://cdngtwys.theentertainerme.com/location-Pin-White.png",  # noqa: E501
        "merchant_map_icon": "https://cdngtwys.theentertainerme.com/ic-Location-Pin-Maps.png",  # noqa: E501
        "back_icon": "https://cdngtwys.theentertainerme.com/chevron-Back.png",
        "call_icon": "https://cdngtwys.theentertainerme.com/ic-Call-Map-3x.png",
        "edit_icon": "https://cdngtwys.theentertainerme.com/ic-Edit-Listing-3x.png",
        "vertical_gradiant_icon": "https://cdngtwys.theentertainerme.com/vertical_gradiant_icon.png",  # noqa: E501
        "merchant_hotel_direction_icon": "https://cdngtwys.theentertainerme.com/location-Pin-White.png",  # noqa: E501
        "room_info_section_title_text_color": "00aa7f",
        "review_section_rating_text_color": "00aa7f",
        "review_count_title_text_color": "0095bc",
        "search_icon_dark": "https://cdngtwys.theentertainerme.com/ic-Search-No-Results-3x.png",  # noqa: E501
        "search_result_search_bar_placeholder_text": "Search your destination here",
        "date_picker_apply_date_button_title": "APPLY DATES",
        "home_search_button_title": "SEARCH",
        "filter_title": "Filters",
        "filter_show_results_button_title": "SHOW RESULTS",
        "add_room_button_title": "Add room",
        "add_room_image_url": "https://cdngtwys.theentertainerme.com/icBed-3x.png",
        "remove_room_button_title": "Remove",
        "remove_room_image_url": "https://cdngtwys.theentertainerme.com/ic-Remove-3x.png",
        "add_room_unselected_button_title_color": "e6e6e6",
        "add_room_unselected_image_url": "https://cdngtwys.theentertainerme.com/add_room_unselected_image_url.png",  # noqa:E501
        "calendar_check_out_maximum_days": MAX_DAYS_LIMIT,
        "hotel_loading_progress_label": "Please hold on … we’re getting the best available offers for you",
        "hotel_loading_progress_image_url": "https://cdngtwys.theentertainerme.com/loading%403x.png",
        "hotel_outlet_listing_empty_view_top_image": "https://cdngtwys.theentertainerme.com/ic_search_no_results_gta.png"  # noqa:E501
    }
