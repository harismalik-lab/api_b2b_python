from repositories_white_label.customer_repo import CustomerProfileWhiteLabel


class CustomerProfileAAG(CustomerProfileWhiteLabel):

    def set_currency_and_default_currency(self, changes):
        """
        Sets the currency nd default currency
        :param changes:
        :rtype dict
        """
        changes['currency'] = "SGD"
        changes['default_currency'] = 44
        return changes
