"""
Phone Verification Repository
"""
import datetime
from collections import OrderedDict

from common_white_label.db import CONSOLIDATION, get_db_settings_from_app
from repositories_white_label.base_repo import BaseRepository
from repositories_white_label.translations_repo import TranslationManager
from wrapper_white_labels.sql_dal import SqlDal

__author__ = "Zaheer"


class PhoneVerificationRepository(BaseRepository):
    """
    Repo for phone verification API which holds all the helper methods required.
    """
    Maximum_Allowed_Verification_Codes_To_Send = 1000
    Maximum_Allowed_Attempts_To_Verify_Code = 1000
    Maximum_Allowed_Attempts_To_Verify_Code_du = 1000
    Phone_Number_Not_Found = 0
    Phone_Number_Verified = 1
    Phone_Number_Already_Verified = 2
    Invalid_Verification_Code_Entered = 3
    Maximum_Limit_Exceeded_For_Code_Verification = 4
    Failed_To_Verify_Code = 5
    Try_To_Attempt_Code = 1

    def generate_verification_code(self, user_id, phone_number,
                                   company_code, email='', verification_code='', locale='en'):
        """
        Generates verification code
        :param int user_id: id of user
        :param str email: email
        :param str phone_number: phone number
        :param str verification_code: verification code
        :param str locale: locale
        :param str company_code: company code
        :rtype: dict
        """
        try:
            # verification_code = 9999
            phone_verification = {}
            phone_verification['user_id'] = user_id
            phone_verification['email'] = email
            phone_verification['verification_code'] = verification_code
            phone_verification['phone_number'] = phone_number
            phone_verification['company_code'] = company_code
            # phoneVerification['code_creation_date'] = datetime.datetime.now()
            columns = list(phone_verification.keys())
            values = list(phone_verification.values())
            sql_dal = SqlDal()
            phone_verification = sql_dal.insert('phone_verification', columns=columns, values=values, last_row_id=True)
            phone_verification_id = phone_verification
            return phone_verification_id
        except Exception as e:
            return {}

    def validate_verification_code(self, user_id, email, phone_number, code_to_verify, locale='en', company_code=''):
        """
        Validates verification code
        :param user_id: id of user
        :param email: email
        :param phone_number: phone number
        :param code_to_verify: code to verify
        :param locale: locale
        :param company_code: company code
        :rtype: dict
        """
        phone_verification_repository = PhoneVerificationRepository()
        try:
            sql_dal = SqlDal()
            verification_response = {
                'is_code_verified': False,
                'response_code_for_code_verification': -1,
                'message': ''
            }
            verification_code = self.get_verification_code(phone_number, user_id, company_code)
            if not verification_code:
                verification_response['is_code_verified'] = False
                # verification_response['message'] = 'Phone number not found'
                verification_response['message'] = TranslationManager().get_translation(
                    TranslationManager.du_phone_number_not_found, locale)
                verification_response['response_code_for_code_verification'] = \
                    phone_verification_repository.Phone_Number_Not_Found
                return verification_response
            else:
                if verification_code['is_code_verified'] == 1:
                    verification_response['is_code_verified'] = False
                    # $verification_response['message'] = 'Phone number already verified';
                    verification_response['message'] = TranslationManager().get_translation(
                        TranslationManager.du_phone_number_already_verified,
                        locale
                    )
                    verification_response['response_code_for_code_verification'] = \
                        phone_verification_repository.Phone_Number_Already_Verified
                    return verification_response
                if verification_code['attempts_made_to_verify'] >= \
                        phone_verification_repository.Maximum_Allowed_Attempts_To_Verify_Code:
                    verification_response['is_code_verified'] = False
                    # $verification_response['message'] = 'You have exceeded limit to verify code';
                    verification_response['message'] = TranslationManager().get_translation(
                        TranslationManager.du_exceeded_limit_verify_code, locale
                    )
                    verification_response['response_code_for_code_verification'] = \
                        phone_verification_repository.Maximum_Limit_Exceeded_For_Code_Verification
                    return verification_response
                if verification_code['verification_code'] != code_to_verify:
                    sql_dal.where({'id': verification_code['id']})
                    changes = {
                        'attempts_made_to_verify':
                            verification_code['attempts_made_to_verify'] +
                            phone_verification_repository.Try_To_Attempt_Code
                    }
                    sql_dal.update('phone_verification', changes)
                    verification_response['is_code_verified'] = False
                    verification_response['message'] = TranslationManager().get_translation(
                        TranslationManager.du_invalid_code_entered, locale)
                    # $verification_response['message'] = 'Invalid code entered'; break;
                    verification_response['response_code_for_code_verification'] =\
                        phone_verification_repository.Invalid_Verification_Code_Entered
                    return verification_response
                elif verification_code['verification_code'] == code_to_verify:
                    data = {
                        'is_code_verified': 1,
                        'code_verification_time': datetime.datetime.now()
                    }
                    sql_dal.where({'pv.id': verification_code['id']})
                    sql_dal.update('phone_verification as pv', data)
                    verification_response['is_code_verified'] = True
                    verification_response['response_code_for_code_verification'] = \
                        phone_verification_repository.Phone_Number_Verified
                    return verification_response
        except Exception:
            verification_response['is_code_verified'] = False
            # verification_response['message'] = 'An error encountered while verifying the code'
            verification_response['message'] = TranslationManager().get_translation(
                TranslationManager.du_error_encountered_verifying_code, locale)
            verification_response['response_code_for_code_verification'] = \
                phone_verification_repository.Failed_To_Verify_Code
            return verification_response

    def is_code_request_limit_exceeded(self, user_id, email, phone_number, locale='en', company_code=''):
        """
        Checks is limit for code request exceeded or not
        :param int user_id: id of user
        :param str email: email
        :param str phone_number: phone number
        :param str locale: locale
        :param int company_code: company code
        :rtype: bool
        """
        phone_verification_repository = PhoneVerificationRepository()
        sql_dal = SqlDal()
        sql_dal.select(['COUNT(phone_verification) as number_of_codes_requested'])
        sql_dal.from_(['phone_verification'])
        ordered_where_clause = OrderedDict()
        ordered_where_clause['user_id'] = user_id
        ordered_where_clause['company_code'] = company_code
        sql_dal.where(ordered_where_clause)
        number_of_codes_requested = sql_dal.get_count(default=0)
        if number_of_codes_requested >= phone_verification_repository.Maximum_Allowed_Attempts_To_Verify_Code:
            return True
        return False

    def is_code_verified_with_other_account(self, user_id, email, phone_number, locale='en', company_code=''):
        """
        Checks that is code verified from any other account.
        :param int user_id: id of user
        :param str email: email
        :param str phone_number: phone number
        :param str locale: locale
        :param int company_code: company code
        :rtype: bool
        """
        consolidation_db = get_db_settings_from_app(connection_name=CONSOLIDATION)['database']
        sql_dal = SqlDal()
        sql_dal.select(['*'])
        sql_dal.from_(['{}.ent_customer_profile'.format(consolidation_db)])
        sql_dal.set_parenthesised_where_clause(" AND user_id <> {user_id}", {'user_id': user_id})
        ordered_where_clause = OrderedDict()
        ordered_where_clause['is_phone_verified'] = 1
        ordered_where_clause['verified_phone_number'] = phone_number
        sql_dal.where(ordered_where_clause)
        customer_profile = sql_dal.get_one(default={})
        if customer_profile:
            return True
        return False

    def is_code_verification_attempts_limit_exceeded(self, user_id, email, phone_number,
                                                     locale='en', company_code=''):
        """
        Checks limit for code verification is exceeded or not
        :param int user_id: id of user
        :param str email: email
        :param str phone_number: phone number
        :param str locale: locale
        :param str company_code: company code
        :rtype: bool
        """
        phone_verification_repository = PhoneVerificationRepository()
        verification_code = self.get_verification_code(
            user_id=user_id, phone_number=phone_number, company_code=company_code)
        if (verification_code and
                verification_code['attempts_made_to_verify'] >=
                phone_verification_repository.Maximum_Allowed_Attempts_To_Verify_Code):
            return True
        return False

    def is_phone_verified(self, phone_number, user_id, company_code=''):
        """
        Verify phone number
        :param str phone_number: phone number
        :param int user_id: id of user
        :param str company_code: company code
        :rtype: bool
        """
        sql_dal = SqlDal()
        sql_dal.select(['*'])
        sql_dal.from_(['phone_verification'])
        ordered_where_clause = OrderedDict()
        ordered_where_clause['user_id'] = user_id
        ordered_where_clause['is_code_verified'] = 1
        ordered_where_clause['phone_number'] = phone_number
        ordered_where_clause['company_code'] = company_code
        sql_dal.where(ordered_where_clause)
        sql_dal.order_by({'id': 'DESC'})
        verification_code = sql_dal.get_one(default={})
        if verification_code:
            return True
        return False

    def get_verification_code(self, phone_number, user_id, company_code=''):
        """
        Gets verification code
        :param str phone_number: phone number
        :param int user_id: id of user
        :param str company_code: company code
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select(['*'])
        sql_dal.from_(['phone_verification'])
        ordered_where_clause = OrderedDict()
        ordered_where_clause['user_id'] = user_id
        ordered_where_clause['phone_number'] = phone_number
        ordered_where_clause['company_code'] = company_code
        sql_dal.where(ordered_where_clause)
        sql_dal.order_by({'id': 'DESC'})
        return sql_dal.get_one(default={})
