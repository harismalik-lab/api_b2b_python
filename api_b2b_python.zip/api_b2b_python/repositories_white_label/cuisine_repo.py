"""
Cuisine repository
"""
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class CuisineRepository(BaseRepository):

    def get_cuisines_for_merchant_filters(self, locale='en', location_id=0):
        """
        Returns cuisines for merchant attributes
        :param str locale: locale
        :param int location_id: id of location
        :rtype: list
        """
        sql_dal = SqlDal()
        sql_dal.select(['mt.cuisine'])
        sql_dal.from_(['offer_wl_active'], ['o'])
        sql_dal.inner_join('product_offer_wl_active AS po', 'o.id', 'po.offer_id')
        sql_dal.inner_join('product AS p', 'po.product_id', 'p.id')
        sql_dal.inner_join('wlproducts AS wl', 'wl.product_sku', 'p.sf_id')
        sql_dal.inner_join('merchant AS m', 'o.merchant_id', 'm.id')
        sql_dal.inner_join('merchant_translation AS mt', 'm.id', 'mt.merchant_id')
        sql_dal.where({'mt.locale': locale})
        sql_dal.where_ne({'mt.cuisine': ''})
        if location_id:
            sql_dal.where({'p.location_id': location_id})
        sql_dal.order_by({'mt.cuisine': 'ASC'})
        return sql_dal.get_distinct(default=[])
