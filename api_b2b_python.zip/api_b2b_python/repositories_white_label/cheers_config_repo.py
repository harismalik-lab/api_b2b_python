"""
Cheers configuration repository white label
"""
import datetime

from flask import g

from common_white_label.constants import GlobalConstants
from repositories_white_label.base_repo import BaseRepository
from repositories_white_label.wl_categories_repo import CategoriesRepositoryWl
from repositories_white_label.wl_company_repo import WLCompany

cache = g.cache


class CheersConfigsRepositoryWL(BaseRepository):
    """
    Cheers configs repo of white label
    """

    @staticmethod
    @cache.memoize(timeout=1800)
    def get_cheers_configuration(locale='en', company=''):
        """
        Get cheers configuration
        :param locale: language of the user
        :param company: company of the user
        :rtype: list
        """
        configuration_cheers = []
        if locale == 'ar':
            configuration_cheers.extend(
                (
                    {
                        "id": 4,
                        "location_id": 1,
                        "product_id": 1970,
                        "product_sku": "D17DBCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 21,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "يرجى إدخال رقم التعريف الشخصي الخاص بك لتأكيد إستخدام العرض ، هذا إن كنت في سن الشرب القانوني و غير مسلم",  # noqa: E501
                        "product_information": "مئات العروض اشتري  واحد واحصل على الأخر  مجاناً للمشروبات في أفضل  المطاعم والحانات والملاهي الليلية في دبي \n",  # noqa: E501
                        "message_for_legal_terms": "من أجل الإستمرار يجب أن يكون سنك قانوني للشرب و أن تتفهم إن هذا المنتج يحتوي على الكحول.فبالإستمرار  أنت تؤكد انك تتفهم هذا وتوافق على اتفاقية ترخيص المستخدم النهائي لدينا",  # noqa: E501
                        "consent_confirmation_message": "         أؤكد اني في سن الشرب القانوني       \n              و غير  مسلم         \n\nتاريخ ميلادي هو DD/MM/YYYY",    # noqa: E501
                        "age_restriction_message": "هذا العرض يهدف الأشخاص الذين هم من سن الشرب القانوني وغير مسلمين \n",
                        "redemption_confirm_message": "تأكد من رقمك السري المكون من ٤ أرقام ، وانك في سن الشرب القانوني وغير مسلم\n",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 7,
                        "location_id": 2,
                        "product_id": 1971,
                        "product_sku": "D17ADCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 21,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "يرجى إدخال رقم التعريف الشخصي الخاص بك لتأكيد إستخدام العرض ، هذا إن كنت في سن الشرب القانوني و غير مسلم",  # noqa: E501
                        "product_information": "مئات العروض اشتري  واحد واحصل على الأخر  مجاناً للمشروبات في أفضل  المطاعم والحانات والملاهي الليلية في أبوظبي والعين \n",  # noqa: E501
                        "message_for_legal_terms": "من أجل الإستمرار يجب أن يكون سنك قانوني للشرب و أن تتفهم إن هذا المنتج يحتوي على الكحول.فبالإستمرار  أنت تؤكد انك تتفهم هذا وتوافق على اتفاقية ترخيص المستخدم النهائي لدينا",  # noqa: E501
                        "consent_confirmation_message": "         أؤكد اني في سن الشرب القانوني       \n              و غير  مسلم         \n\nتاريخ ميلادي هو DD/MM/YYYY",  # noqa: E501
                        "age_restriction_message": "هذا العرض يهدف الأشخاص الذين هم من سن الشرب القانوني وغير مسلمين \n",
                        "redemption_confirm_message": "تأكد من رقمك السري المكون من ٤ أرقام ، وانك في سن الشرب القانوني وغير مسلم\n",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 13,
                        "location_id": 4,
                        "product_id": 2074,
                        "product_sku": "D17SACT",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d'))
                    },
                    {
                        "id": 16,
                        "location_id": 11,
                        "product_id": 2282,
                        "product_sku": "D17SPCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d'))
                    },
                    {
                        "id": 19,
                        "location_id": 13,
                        "product_id": 2262,
                        "product_sku": "D17HKCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 23,
                        "location_id": 14,
                        "product_id": 2177,
                        "product_sku": "D17SAJB",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 22,
                        "location_id": 15,
                        "product_id": 2068,
                        "product_sku": "D17MYMY",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 21,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 21 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 10,
                        "location_id": 17,
                        "product_id": 2339,
                        "product_sku": "D17LDCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 26,
                        "location_id": 20,
                        "product_id": 2216,
                        "product_sku": "D17SADB",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 56,
                        "location_id": 3,
                        "product_id": 2128,
                        "product_sku": "D17BHBH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 21,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 21 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 68,
                        "location_id": 21,
                        "product_id": 3959,
                        "product_sku": "D17MTCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 17,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 17 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 71,
                        "location_id": 5,
                        "product_id": 2079,
                        "product_sku": "D17CYCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 17,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 17 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    }
                )
            )
        elif locale == 'cn':
            configuration_cheers.extend(
                (
                    {
                        "id": 4,
                        "location_id": 1,
                        "product_id": 1970,
                        "product_sku": "D17DBCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 21,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "請輸入你的私人密碼確認兌換，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "閣下必須已達到合法飲用酒精飲品年齡及明白此產品內容有機會含有與酒精相關的資料才可繼續瀏覽。 如要繼續，請確認已明白以上及同意我們的終端用戶許可協議。",  # noqa: E501
                        "consent_confirmation_message": "       我確認本人已達到合法飲用酒精飲品年齡及非\n       伊斯蘭教教徒 \n\nDD/MM/YYYY 我的出生日期是",  # noqa: E501
                        "age_restriction_message": "对不起，您必须年满21周岁才能访问此产品。",
                        "redemption_confirm_message": "確認你的四位數字私人密碼，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 7,
                        "location_id": 2,
                        "product_id": 1971,
                        "product_sku": "D17ADCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 21,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "請輸入你的私人密碼確認兌換，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "閣下必須已達到合法飲用酒精飲品年齡及明白此產品內容有機會含有與酒精相關的資料才可繼續瀏覽。 如要繼續，請確認已明白以上及同意我們的終端用戶許可協議。",  # noqa: E501
                        "consent_confirmation_message": "       我確認本人已達到合法飲用酒精飲品年齡及非\n       伊斯蘭教教徒 \n\nDD/MM/YYYY 我的出生日期是",  # noqa: E501
                        "age_restriction_message": "对不起，您必须年满21周岁才能访问此产品。",
                        "redemption_confirm_message": "確認你的四位數字私人密碼，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 13,
                        "location_id": 4,
                        "product_id": 2074,
                        "product_sku": "D17SACT",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "請輸入你的私人密碼確認兌換，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "閣下必須已達到合法飲用酒精飲品年齡及明白此產品內容有機會含有與酒精相關的資料才可繼續瀏覽。 如要繼續，請確認已明白以上及同意我們的終端用戶許可協議。",  # noqa: E501
                        "consent_confirmation_message": "       我確認本人已達到合法飲用酒精飲品年齡及非\n       伊斯蘭教教徒 \n\nDD/MM/YYYY 我的出生日期是",  # noqa: E501
                        "age_restriction_message": "对不起，您必须年满18周岁才能访问此产品。",
                        "redemption_confirm_message": "確認你的四位數字私人密碼，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 16,
                        "location_id": 11,
                        "product_id": 2282,
                        "product_sku": "D17SPCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "請輸入你的私人密碼確認兌換，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "閣下必須已達到合法飲用酒精飲品年齡及明白此產品內容有機會含有與酒精相關的資料才可繼續瀏覽。 如要繼續，請確認已明白以上及同意我們的終端用戶許可協議。",  # noqa: E501
                        "consent_confirmation_message": "       我確認本人已達到合法飲用酒精飲品年齡及非\n       伊斯蘭教教徒 \n\nDD/MM/YYYY 我的出生日期是",  # noqa: E501
                        "age_restriction_message": "对不起，您必须年满18周岁才能访问此产品。",
                        "redemption_confirm_message": "確認你的四位數字私人密碼，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 19,
                        "location_id": 13,
                        "product_id": 2262,
                        "product_sku": "D17HKCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "請輸入你的私人密碼確認兌換，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "閣下必須已達到合法飲用酒精飲品年齡及明白此產品內容有機會含有與酒精相關的資料才可繼續瀏覽。 如要繼續，請確認已明白以上及同意我們的終端用戶許可協議。",  # noqa: E501
                        "consent_confirmation_message": "       我確認本人已達到合法飲用酒精飲品年齡及非\n       伊斯蘭教教徒 \n\nDD/MM/YYYY 我的出生日期是",  # noqa: E501
                        "age_restriction_message": "对不起，您必须年满18周岁才能访问此产品。",
                        "redemption_confirm_message": "確認你的四位數字私人密碼，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 23,
                        "location_id": 14,
                        "product_id": 2177,
                        "product_sku": "D17SAJB",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "請輸入你的私人密碼確認兌換，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "閣下必須已達到合法飲用酒精飲品年齡及明白此產品內容有機會含有與酒精相關的資料才可繼續瀏覽。 如要繼續，請確認已明白以上及同意我們的終端用戶許可協議。",  # noqa: E501
                        "consent_confirmation_message": "       我確認本人已達到合法飲用酒精飲品年齡及非\n       伊斯蘭教教徒 \n\nDD/MM/YYYY 我的出生日期是",  # noqa: E501
                        "age_restriction_message": "对不起，您必须年满18周岁才能访问此产品。",
                        "redemption_confirm_message": "確認你的四位數字私人密碼，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 22,
                        "location_id": 15,
                        "product_id": 2068,
                        "product_sku": "D17MYMY",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 21,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "請輸入你的私人密碼確認兌換，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "閣下必須已達到合法飲用酒精飲品年齡及明白此產品內容有機會含有與酒精相關的資料才可繼續瀏覽。 如要繼續，請確認已明白以上及同意我們的終端用戶許可協議。",  # noqa: E501
                        "consent_confirmation_message": "       我確認本人已達到合法飲用酒精飲品年齡及非\n       伊斯蘭教教徒 \n\nDD/MM/YYYY 我的出生日期是",  # noqa: E501
                        "age_restriction_message": "对不起，您必须年满21周岁才能访问此产品。",
                        "redemption_confirm_message": "確認你的四位數字私人密碼，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 10,
                        "location_id": 17,
                        "product_id": 2339,
                        "product_sku": "D17LDCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "請輸入你的私人密碼確認兌換，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "閣下必須已達到合法飲用酒精飲品年齡及明白此產品內容有機會含有與酒精相關的資料才可繼續瀏覽。 如要繼續，請確認已明白以上及同意我們的終端用戶許可協議。",  # noqa: E501
                        "consent_confirmation_message": "       我確認本人已達到合法飲用酒精飲品年齡及非\n       伊斯蘭教教徒 \n\nDD/MM/YYYY 我的出生日期是",  # noqa: E501
                        "age_restriction_message": "对不起，您必须年满18周岁才能访问此产品。",
                        "redemption_confirm_message": "確認你的四位數字私人密碼，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d'))
                    },
                    {
                        "id": 26,
                        "location_id": 20,
                        "product_id": 2216,
                        "product_sku": "D17SADB",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "請輸入你的私人密碼確認兌換，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "閣下必須已達到合法飲用酒精飲品年齡及明白此產品內容有機會含有與酒精相關的資料才可繼續瀏覽。 如要繼續，請確認已明白以上及同意我們的終端用戶許可協議。",  # noqa: E501
                        "consent_confirmation_message": "       我確認本人已達到合法飲用酒精飲品年齡及非\n       伊斯蘭教教徒 \n\nDD/MM/YYYY 我的出生日期是",  # noqa: E501
                        "age_restriction_message": "对不起，您必须年满18周岁才能访问此产品。",
                        "redemption_confirm_message": "確認你的四位數字私人密碼，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 56,
                        "location_id": 3,
                        "product_id": 2128,
                        "product_sku": "D17BHBH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 21,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "請輸入你的私人密碼確認兌換，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "閣下必須已達到合法飲用酒精飲品年齡及明白此產品內容有機會含有與酒精相關的資料才可繼續瀏覽。 如要繼續，請確認已明白以上及同意我們的終端用戶許可協議。",  # noqa: E501
                        "consent_confirmation_message": "       我確認本人已達到合法飲用酒精飲品年齡及非\n       伊斯蘭教教徒 \n\nDD/MM/YYYY 我的出生日期是",  # noqa: E501
                        "age_restriction_message": "对不起，您必须年满21周岁才能访问此产品。",
                        "redemption_confirm_message": "確認你的四位數字私人密碼，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 68,
                        "location_id": 21,
                        "product_id": 3959,
                        "product_sku": "D17MTCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 17,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 17 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d'))
                    },
                    {
                        "id": 71,
                        "location_id": 5,
                        "product_id": 2079,
                        "product_sku": "D17CYCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 17,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "請輸入你的私人密碼確認兌換，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "閣下必須已達到合法飲用酒精飲品年齡及明白此產品內容有機會含有與酒精相關的資料才可繼續瀏覽。 如要繼續，請確認已明白以上及同意我們的終端用戶許可協議。",  # noqa: E501
                        "consent_confirmation_message": "       我確認本人已達到合法飲用酒精飲品年齡及非\n       伊斯蘭教教徒 \n\nDD/MM/YYYY 我的出生日期是",  # noqa: E501
                        "age_restriction_message": "对不起，您必须年满17周岁才能访问此产品。",
                        "redemption_confirm_message": "確認你的四位數字私人密碼，同時確認閣下已達到合法飲用酒精飲品年齡及非伊斯蘭教教徒。",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    }
                )
            )
        elif locale == 'el':
            configuration_cheers.extend(
                (
                    {
                        "id": 4,
                        "location_id": 1,
                        "product_id": 1970,
                        "product_sku": "D17DBCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 21,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 21 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 7,
                        "location_id": 2,
                        "product_id": 1971,
                        "product_sku": "D17ADCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 21,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 21 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 13,
                        "location_id": 4,
                        "product_id": 2074,
                        "product_sku": "D17SACT",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d'))
                    },
                    {
                        "id": 16,
                        "location_id": 11,
                        "product_id": 2282,
                        "product_sku": "D17SPCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d'))
                    },
                    {
                        "id": 19,
                        "location_id": 13,
                        "product_id": 2262,
                        "product_sku": "D17HKCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 23,
                        "location_id": 14,
                        "product_id": 2177,
                        "product_sku": "D17SAJB",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d'))
                    },
                    {
                        "id": 22,
                        "location_id": 15,
                        "product_id": 2068,
                        "product_sku": "D17MYMY",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 21,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 21 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                    },
                    {
                        "id": 10,
                        "location_id": 17,
                        "product_id": 2339,
                        "product_sku": "D17LDCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 26,
                        "location_id": 20,
                        "product_id": 2216,
                        "product_sku": "D17SADB",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d'))
                    },
                    {
                        "id": 56,
                        "location_id": 3,
                        "product_id": 2128,
                        "product_sku": "D17BHBH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 21,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 68,
                        "location_id": 21,
                        "product_id": 3959,
                        "product_sku": "D17MTCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 17,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 17 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 71,
                        "location_id": 5,
                        "product_id": 2079,
                        "product_sku": "D17CYCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 17,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 17 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    }
                )
            )
        else:
            configuration_cheers.extend(
                (
                    {
                        "id": 4,
                        "location_id": 1,
                        "product_id": 1970,
                        "product_sku": "D17DBCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 21,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 21 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 7,
                        "location_id": 2,
                        "product_id": 1971,
                        "product_sku": "D17ADCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 21,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 21 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 13,
                        "location_id": 4,
                        "product_id": 2074,
                        "product_sku": "D17SACT",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 16,
                        "location_id": 11,
                        "product_id": 2282,
                        "product_sku": "D17SPCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 19,
                        "location_id": 13,
                        "product_id": 2262,
                        "product_sku": "D17HKCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 23,
                        "location_id": 14,
                        "product_id": 2177,
                        "product_sku": "D17SAJB",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 22,
                        "location_id": 15,
                        "product_id": 2068,
                        "product_sku": "D17MYMY",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 21,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 21 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 10,
                        "location_id": 17,
                        "product_id": 2339,
                        "product_sku": "D17LDCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 26,
                        "location_id": 20,
                        "product_id": 2216,
                        "product_sku": "D17SADB",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 18,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 18 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 56,
                        "location_id": 3,
                        "product_id": 2128,
                        "product_sku": "D17BHBH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 21,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 21 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 68,
                        "location_id": 21,
                        "product_id": 3959,
                        "product_sku": "D17MTCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 17,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 17 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 71,
                        "location_id": 5,
                        "product_id": 2079,
                        "product_sku": "D17CYCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 17,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 17 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    },
                    {
                        "id": 75,
                        "location_id": 46,
                        "product_id": 5967,
                        "product_sku": "L18BAIGCH",
                        "category_id": 1,
                        "category": "Food & Drink",
                        'api_name': CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                        "age_limit": 21,
                        "cheers_logo_url": "https://s3.amazonaws.com/entertainer-app-assets/cheers-logo_inter.png",
                        "redemption_message": "Please enter your PIN to confirm redemption, that you are of legal drinking age",  # noqa: E501
                        "product_information": "Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across Cape Town.",  # noqa: E501
                        "message_for_legal_terms": "In order to continue you must be of legal drinking age and understand this product may contain references to alcohol.By continuing, you confirm that you understand this and agree to our End User License Agreement",  # noqa: E501
                        "consent_confirmation_message": "       I confirm I am of legal \n      drinking age \n        \nDD/MM/YYYY is my date of birth",  # noqa: E501
                        "age_restriction_message": "Sorry, you must be 21 years or over to access this product",
                        "redemption_confirm_message": "Confirm your 4-digit PIN, and that you are of legal drinking age",  # noqa: E501
                        "date_today": str(datetime.date.today().strftime('%Y/%m/%d')),
                        "drinking_age_confirmation_message": "I confirm I am of legal drinking age in the GCC & non-Muslim",  # noqa: E501
                        "not_interested_in_cheers_offers_message": "I do not want Cheers, but thanks anyways",
                        "error_message_to_select_an_option": "Please select an option to continue"
                    }
                )
            )
        if company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
            for configuration_cheer in configuration_cheers:
                configuration_cheer['cheers_logo_url'] = GlobalConstants.CHEERS_LOGO_URL
                configuration_cheer['not_interested_in_cheers_offers_message'] = GlobalConstants.NOT_INTERESTED_CHEERS_OFFER_MESSAGE  # noqa: E501
                configuration_cheer['category'] = configuration_cheer['api_name']
                if GlobalConstants.CHEERS_LOCATION_CHECK in configuration_cheer['location_id']:
                    configuration_cheer['product_information'] = GlobalConstants.PRODUCT_INFORMATION
        return configuration_cheers
