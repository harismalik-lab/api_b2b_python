"""
Send Email constants
"""
from repositories_white_label.base_repo import BaseRepository


class SendEmailsRepository(BaseRepository):
    ORDER_CREATION = 2
    FORGOT_PASSWORD = 3
    ACTIVATION_OF_TRIAL = 4
    PROCCESSED_EMAIL = 5
    GIFT_PURCHASE_PRODUCT = 6
    OFFER_PING = 7
    VIP_Key_ACTIVATION_ENGLISH = 22
    OFFER_SHARE_FOR_REGISTERED_CUSTOMER = 23
    BOOKING_ENQUIRY_Merchant = 148
    BOOKING_ENQUIRY_Customer = 106
    VIP_KEY_ACTIVATION_SLICE = 153
    VIP_KEY_ACTIVATION_REWARD_PLUS = 225

    Priority_High = 1
    Priority_Medium = 2
    Priority_Low = 3

    FAMILY_PROSPECT_TYPE = 540
    FAMILY_SECONDARY_TYPE = 542
    Fresh_Start_Forgot_Password = 545
    EMAIL_VERIFICATION_ID = 547
