"""
WL Crg Lookup Repository
"""
from collections import OrderedDict

from common_white_label.db import CONSOLIDATION
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class WlNaamaLookupRepository(BaseRepository):
    """
    Database helper for naama repository
    """
    def find_naama(self, email):
        """
        Get user's naama entry
        :param email:
        :return:
        """
        sql_dal = SqlDal(connection=CONSOLIDATION)
        sql_dal.select(['*'])
        sql_dal.from_(['consolidation.ent_nama_lookup'])
        ordered_where_clause = OrderedDict()
        ordered_where_clause['email'] = email
        ordered_where_clause['is_active'] = True
        sql_dal.where(ordered_where_clause)
        return sql_dal.get_one(default={})
