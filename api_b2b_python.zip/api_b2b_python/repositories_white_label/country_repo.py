"""
Country repository
"""
from collections import OrderedDict

from flask import g

from common_white_label.constants import GlobalConstants
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal

cache = g.cache


class CountryRepository(BaseRepository):
    """
    Repo for country API which holds all the helper methods required.
    """
    @staticmethod
    @cache.memoize(timeout=1800)
    def get_country(locale):
        """
        Gets country
        :param str locale: locale
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select(['distinct c.id', 'c.shortname', 't.name', 'c.position'])
        sql_dal.from_(['country as c'])
        sql_dal.inner_join('country_translation as t', 'c.id', 't.country_id')
        sql_dal.where({'t.locale': locale})
        sql_dal.order_by({'c.position': 'ASC', 't.name': 'ASC'})
        result = sql_dal.get(default=[])
        return result

    def get_country_by_region(self, company, product_ids=[], locale='en'):
        """
        Gets country by region
        :param str company: company
        :param list[int] Product_ids: id's of products
        :param str locale: locale
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select([
            'distinct  c.id', 'c.shortname', 't.name', "CASE WHEN rt.name is null then '' else rt.name END as region"
        ])
        sql_dal.from_(['country as c'])
        sql_dal.inner_join('country_translation as t', 'c.id', 't.country_id')
        sql_dal.inner_join('region_translation as rt', 'c.region_id', 'rt.region_id')
        sql_dal.inner_join('outlet as o', 'c.shortname', 'o.billing_country')
        sql_dal.inner_join('merchant as m', 'o.merchant_id', 'm.id')
        sql_dal.inner_join('offer_wl_active as ofr', 'm.id', 'ofr.merchant_id')
        sql_dal.inner_join('product_offer_wl_active as po', 'ofr.id', 'po.offer_id')
        sql_dal.inner_join('product as p', 'po.product_id', 'p.id')
        ordered_where_clause = OrderedDict()
        ordered_where_clause['ofr.merchant_category'] = GlobalConstants.category_API_Name_Travel
        ordered_where_clause['rt.locale'] = locale
        ordered_where_clause['t.locale'] = locale
        sql_dal.where(ordered_where_clause)
        sql_dal.where_in('p.id', product_ids)
        sql_dal.order_by({'rt.region_id': 'ASC'})
        result = sql_dal.get(default=[])
        return result
