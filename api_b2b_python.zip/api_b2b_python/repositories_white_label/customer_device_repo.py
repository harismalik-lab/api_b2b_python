"""
Customer device repository white label
"""
import datetime

from common_white_label.db import CONSOLIDATION
from common_white_label.db import DEFAULT as ENTERTAINER_WEB
from common_white_label.db import get_db_settings_from_app
from repositories_white_label.base_repo import BaseRepository
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from wrapper_white_labels.sql_dal import SqlDal


class CustomerDeviceRepositoryWl(BaseRepository):
    """
    Gets customer device information against given customer id
    """
    def find_one_by_device_id_and_customer_id(self, *args, **kwargs):
        """
        Finds customer devices by providing customer and device id
        :rtype: dict
        """
        customer_id = kwargs.get('customer_id')
        device_id = kwargs.get('device_id')
        company = kwargs.get('company')
        result = None
        if device_id:
            sql_dal = SqlDal()
            sql_dal.select(["cd.customer_id", "cd.device_os",
                            "cd.device_model", "cd.device_install_token", "cd.device_id"])
            sql_dal.from_(["customer_devices"], aliases=["cd"])
            sql_dal.inner_join('session AS s', 'cd.session_id', 's.id')
            sql_dal.like('company', company)
            sql_dal.where({
                'cd.customer_id': customer_id,
                'cd.device_id': device_id,
                's.isactive': 1
            })
            result = sql_dal.get_one(default={})
        return result

    def count_devices_by_customer_id(self, *args, **kwargs):
        customer_id = kwargs.get('customer_id')
        company = kwargs.get('company')
        if not customer_id:
            return False
        sql_dal = SqlDal()
        sql_dal.select(["COUNT(cd.device_id) as total_devices"])
        sql_dal.from_(["customer_devices"], aliases=["cd"])
        sql_dal.inner_join('session AS s', 'cd.session_id', 's.id')
        sql_dal.like("s.company", company)
        sql_dal.where({"cd.customer_id": customer_id, "s.isactive": 1})
        result = sql_dal.get(default=[])
        if result:
            return result[0].get('total_devices')
        else:
            return 0

    def create_new_record(
            self, customer_id, device_install_token, device_os, device_model, session, primary, device_id
    ):
        """
        Creates new record
        :param customer_id: Id of customer
        :param device_install_token: Device install token
        :param device_os: Device operating system
        :param device_model: Model of device
        :param session: Session of the logged in user
        :param primary: Primary user
        :param device_id: Device id
        :rtype: bool
        """
        if device_id:
            try:
                sql_dal = SqlDal(connection=ENTERTAINER_WEB)
                date = datetime.datetime.now()
                columns = [
                    'device_install_token', 'device_model', 'device_os', 'device_first_used', 'customer_id',
                    'session_id', 'primary_device', 'device_id', 'is_black_listed'
                ]
                data = [
                    device_install_token, device_model, device_os,
                    datetime.datetime.strftime(date, '%Y-%m-%d %H:%M:%S'),
                    customer_id, session.get('id'), primary, device_id, 0
                ]
                return sql_dal.insert('customer_devices', columns=columns, values=data, last_row_id=True)
            except Exception:
                return False

    def is_device_linked_to_blacklisted_user(self, device_id):
        if not device_id:
            return False
        consolidation_db = get_db_settings_from_app(connection_name=CONSOLIDATION)['database']
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select(["c.id"])
        sql_dal.from_(['{c_db}.user'.format(c_db=consolidation_db)], aliases=['c'])
        sql_dal.inner_join('customer_devices AS cd', 'c.id', 'cd.customer_id')
        sql_dal.where({
            "cd.device_id": device_id,
            "c.status": CustomerProfileWhiteLabel.STATUS_BLACKLISTED
        })
        result = sql_dal.get_one(default={})
        if result:
            return True
        else:
            return False

    def find_one_by_customer_id_and_session_id(self, customer_id, session_id, device_id):
        """
        Finds the device on the base of customer id , session id and the device id
        :param int customer_id: customer's id
        :param str session_id: session's id
        :param str device_id: device id
        :rtype: dict
        """
        result = {}
        if session_id:
            sql_dal = SqlDal(connection=ENTERTAINER_WEB)
            sql_dal.select(["*"])
            sql_dal.from_(["customer_devices"], aliases=["cd"])
            sql_dal.where({
                'cd.customer_id': customer_id,
                'cd.session_id': session_id,
                'cd.device_id': device_id
            })
            result = sql_dal.get_one(default={})
        return result
