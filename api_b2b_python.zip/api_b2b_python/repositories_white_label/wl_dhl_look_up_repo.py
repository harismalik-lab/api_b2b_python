"""
WL DHL Lookup Repository
"""
from collections import OrderedDict

from common_white_label.db import CONSOLIDATION
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class WlDhlEntRepository(BaseRepository):
    """
    Dhl ent lookup white label
    """
    def find_customer(self, customer_id):
        """
        Finds customer from dhl_lookup table according to customer_id
        :param str customer_id: Customer id
        :rtype: dict
        """
        sql_dal = SqlDal(connection=CONSOLIDATION)
        sql_dal.select(['*'])
        sql_dal.from_(['dhl_lookup'])
        ordered_where_clause = OrderedDict()
        ordered_where_clause['user_id'] = customer_id
        ordered_where_clause['is_active'] = True
        sql_dal.where(ordered_where_clause)
        result = sql_dal.get_one(default={})
        return result
