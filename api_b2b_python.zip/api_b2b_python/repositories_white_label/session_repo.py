"""
Session Repository for White Labels.
"""
import time
import uuid

from common_white_label.common_helpers import get_current_date_time
from common_white_label.db import DEFAULT as ENTERTAINER_WEB
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.dal_exceptions import (InvalidUsage,
                                                 WhereConditionRequired)
from wrapper_white_labels.sql_dal import SqlDal


class SessionRepositoryWhiteLabel(BaseRepository):
    Session_Refresh_Time_In_Secs = 86400
    Session_Refresh_Time_In_Secs_V21 = 86400
    Session_Refresh_Time_In_Secs_UPDATED = 604800
    GDPR_DEFAULT_VERSION = "v14.5.18"

    def update_session(self, session_token, company, customer_data, app_version):
        """
        Updates the customer Session
        :param session_token: user's session token
        :param company: company of the customer
        :param customer_data: customer's data
        :param app_version: app version
        """
        session = self.find_by_token(session_token=session_token)
        if session:
            sql_dal = SqlDal(connection=ENTERTAINER_WEB)
            sql_dal.where({'id': session['id']})
            session_changes = {
                'company': company,
                'data': self.dumps(customer_data),
                'date_cached': time.time()
            }

            if app_version:
                session_changes['app_version'] = app_version
            sql_dal.update('session', changes=session_changes)
            session.update(session_changes)
            return session
        else:
            return False

    def find_by_id(self, *args, **kwargs):
        company = kwargs.get('company')
        session_id = kwargs.get('session_id')
        session = {}
        if session_id:
            sql_dal = SqlDal(connection=ENTERTAINER_WEB)
            sql_dal.select(['*'])
            sql_dal.from_(['session'])
            sql_dal.where({'id': session_id, 'isactive': True, 'company': company})
            session = sql_dal.get_one(default=session)
        return session

    def find_by_token(self, **kwargs):
        company = kwargs.get('company')
        session_token = kwargs.get('session_token')
        session = {}
        if session_token:
            sql_dal = SqlDal(connection=ENTERTAINER_WEB)
            sql_dal.from_('session')
            sql_dal = SqlDal()
            sql_dal.from_(['session'])
            sql_dal.where({
                'session_token': session_token,
                'isactive': '1',
                'company': company
            })
            session = sql_dal.get_one(default={})
        return session

    def update_session_product_ids(self, *args, **kwargs):
        """
        Updates the session Product ids
        :param session_id: session id
        :param product_ids: list of product ids
        :param date_cached: date cached of the session
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        changes = {}
        if kwargs.get('product_ids'):
            changes = {'product_ids': kwargs.get('product_ids')}
        if kwargs.get('date_cached'):
            changes.update({'date_cached': kwargs.get('date_cached')})
        changes.update({'refresh_required': 0})
        sql_dal.where({'id': kwargs.get('session_id'), 'isactive': 1})
        sql_dal.update('session', changes=changes)

    def update_all_sessions_for_customer(self, customer_id, product_ids, company):
        """
        Updates all the sessions of the customer on the base of the company and id
        :param int customer_id: id of customer
        :param list product_ids: list of product ids
        :param str company: company of the customer
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        date_cached = time.time()
        if product_ids:
            changes = {'product_ids': product_ids, 'date_cached': date_cached}
        else:
            changes = {'date_cached': date_cached}
        changes.update({'refresh_required': 0})
        sql_dal.where({'company': company, 'customer_id': customer_id})
        sql_dal.update('session', changes=changes)

    def mark_all_sessions_for_customer_date_cached(self, customer_id, company):
        """
        Marks is active flag as 1
        :param int customer_id: id of the customer
        :param str company: company of the user
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        changes = {'date_cached': 1}
        sql_dal.where({
            'company': company,
            'customer_id': customer_id,
            'isactive': 1
        })
        sql_dal.update('session', changes=changes)

    def generate_session(self, *args, **kwargs):
        """
        Generates new session for white label company users
        """
        customer_id = kwargs.get('customer_id')
        product_ids = kwargs.get('product_ids')
        app_version = kwargs.get('app_version')
        company = kwargs.get('company')
        last_row = kwargs.get('last_row')
        date_cached = time.time()

        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        session_token = str(uuid.uuid4())
        columns = [
            'customer_id', 'session_token', 'product_ids',
            'date_cached', 'company', 'isagreed', 'date_agreed'
        ]
        data = [
            customer_id, session_token, str(product_ids), date_cached,
            company, True, get_current_date_time()
        ]
        if app_version:
            columns.append('app_version')
            data.append(app_version)
        row_id = sql_dal.insert('session', columns=columns, values=data, last_row_id=last_row)
        if row_id:
            return session_token

    def update_customer_company_sessions(self, company, customer_id):
        """
        Updated the customer session
        :param company:
        :param customer_id:
        :return:
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        changes = {'isactive': 0}
        sql_dal.where({'company': company, 'customer_id': customer_id})
        sql_dal.update('session', changes=changes)

    def adding_entry_in_session_addendum_table(self, *args, **kwargs):
        """
        Adding entry in session_addendum table
        :rtype bool
        """
        session_id = kwargs.get('session_id')
        user_id = kwargs.get('user_id')
        device_key = kwargs.get('device_key')
        device_os = kwargs.get('device_os')
        device_model = kwargs.get('device_model')
        device_language = kwargs.get('device_language')
        lat = kwargs.get('lat')
        lng = kwargs.get('lng')
        company = kwargs.get('company')

        if session_id and user_id:
            sql_dal = SqlDal(connection=ENTERTAINER_WEB)
            columns = [
                'session_id', 'user_id', 'is_eula_agreed', 'is_gdpr_agreed', 'device_key',
                'device_os', 'device_model', 'device_language', 'lat', 'lng', 'company', 'consent_version'
            ]
            data = [
                session_id, user_id, 1, 1, device_key, device_os,
                device_model, device_language, lat, lng, company, self.GDPR_DEFAULT_VERSION
            ]
            sql_dal.insert('session_addendum', columns=columns, values=data)
            return True

    def find_latest_token_by_user_id(self, user_id=None, isactive=True):
        """
        Finds latest token on the basis of user id
        :param int user_id: user id
        :param bool isactive: is active
        :rtype dict
        """
        session = {}
        if user_id:
            sql_dal = SqlDal()
            sql_dal.where({"customer_id": user_id})
            if isactive:
                sql_dal.where("isactive", 1)
            sql_dal.from_(['session'])
            sql_dal.like('company', 'entertainer', enable_start_wild_card=False)
            sql_dal.order_by({'id': 'DESC'})
            sql_dal.limit(1)
            session = sql_dal.get_one(default=session)
        return session

    def update_app_version(self, session_token=None, session=None, app_version=None):
        """
        Updates the app version.
        :param session_token: User Session Token
        :param session:  User Session
        :param app_version:  User App Version
        :rtype: bool
        """
        if not session and session_token:
            session = self.find_by_token(session_token=session_token)
        try:
            if session and app_version:
                sql_dal = SqlDal(connection=ENTERTAINER_WEB)
                sql_dal.where({'id': session['id']})
                sql_dal.update('session', changes={'app_version': app_version})
                session['app_version'] = app_version
                return session
        except (InvalidUsage, WhereConditionRequired):
            pass
        return False

    def remove_session(self, session_id):
        """
        Removes Session from db
        :param int session_id:  session id
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        changes = {'isactive': 0}
        sql_dal.where({
            'id': session_id,
            'isactive': 1
        })
        sql_dal.update('session', changes=changes)

    def get_api_version(self, request=None):
        if not request or not request.url:
            return "exprs"
        else:
            try:
                blueprint = getattr(request, 'blueprint', '')
                # example if blueprint is api_v59
                api_version = blueprint.split('_')[1]  # v59
                return "exprs-{api_version}".format(api_version=api_version)
            except Exception:
                return "exprs"

    def get_all_user_sessions(self, customer_id):
        session = []
        if customer_id:
            sql_dal = SqlDal()
            sql_dal.where({"customer_id": customer_id, "isactive": 1})
            sql_dal.from_(['session'])
            sql_dal.like('company', 'exp', enable_start_wild_card=False)
            session = sql_dal.get(default=session)
        return session

    def expire_all_current_user_sessions(self, customer_id):
        sql_dal = SqlDal()
        if customer_id:
            changes = {'isactive': 0}
            sql_dal.where({
                'customer_id': customer_id,
                'isactive': 1
            })
            sql_dal.like('company', 'exp', enable_start_wild_card=False)
            sql_dal.update('session', changes=changes)
