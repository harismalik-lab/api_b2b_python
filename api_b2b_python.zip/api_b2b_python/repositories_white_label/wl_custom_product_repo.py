"""
WL Custom Product Repository
"""
from collections import OrderedDict

from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal

__author__ = "Zaheer"


class WLCustomProductRepository(BaseRepository):
    """
    Repo for wl customer product API which holds all the helper methods required.
    """
    def get_custom_product_for_user_group(self, company='', user_group_id=0, locale='en'):
        """
        Gets custom products for user group id
        :param str company: company
        :param int user_group_id: id of user group
        :param str locale: locale
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select([
            'id', 'product_code', 'title', 'description', 'price_aed', 'currency', 'image_url', '0 as user_id'
        ])
        sql_dal.from_(['wl_custom_product'])
        ordered_where_clause = OrderedDict()
        ordered_where_clause['user_group_id'] = user_group_id
        ordered_where_clause['company'] = company
        sql_dal.where(ordered_where_clause)
        products = sql_dal.get_one(default={})
        if products:
            products['user_id'] = 0
            if locale == 'ar':
                products['description'] = 'نعم، أريد الإستفادة بعروض 2 بسعر 1 من DU'
            return products
        return False

    def get_custom_product_by_product_id(self, company='', product_id=0):
        """
        Gets custom product by product id
        :param str company: company
        :param int product_id: id of product
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select(['*'])
        sql_dal.from_(['wl_custom_product'])
        ordered_where_clause = OrderedDict()
        ordered_where_clause['id'] = product_id
        ordered_where_clause['company'] = company
        sql_dal.where(ordered_where_clause)
        products = sql_dal.get_one(default={})
        return products
