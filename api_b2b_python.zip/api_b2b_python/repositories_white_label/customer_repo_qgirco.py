from repositories_white_label.customer_repo import CustomerProfileWhiteLabel


class CustomerProfileQGIRCO(CustomerProfileWhiteLabel):
    def set_currency_and_default_currency(self, changes):
        """
        Sets the currency nd default currency
        :param changes:
        :rtype dict
        """
        changes['currency'] = "QAR"
        changes['default_currency'] = 42
        return changes
