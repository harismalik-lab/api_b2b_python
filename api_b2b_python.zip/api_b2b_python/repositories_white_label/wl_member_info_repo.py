"""
WL Member Info Repository
"""
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class WlMemberInfoRepository(BaseRepository):

    def get_wl_member_info(self, email, company=''):
        """
        Returns list of wl_members_info
        :param str company: company
        :param str email: email
        :rtype: list
        """
        sql_dal = SqlDal()
        sql_dal.select(['*'])
        sql_dal.from_(['wl_members_info'])
        sql_dal.where({'wl_members_info.company': company, 'wl_members_info.email': email})
        result = sql_dal.get_one(default={})
        return result
