from python_api.wrapper.sql_dal import SqlDal
from repositories_white_label.customer_repo import CustomerProfileWhiteLabel
from repositories_white_label.wl_gem_points_repo import WlGemPointsRepository


class CustomerProfileGEM(CustomerProfileWhiteLabel):

    def get_password_hash(self, *args, **kwargs):
        """
        Gets the password hash of the user for GEM
        :param str email: email of the user
        :param str company: company of the user
        :rtype dict
        """
        email = kwargs.get('email')
        company = kwargs.get('company', 'entertainer')
        sql_dal = SqlDal()
        sql_dal.select(['uci.password_hash'])
        sql_dal.from_(['user'], ['c'])
        sql_dal.inner_join('wl_user_custom_info as uci', 'c.id', 'uci.user_id')
        sql_dal.where({
            'c.email': email,
            'c.is_active': True,
            'uci.company': company,
            'c.is_customer': True
        })
        result = sql_dal.get_one(default={})
        return result.get('password_hash')

    def set_savings(self, yearly_savings={}):
        """
        Sets the savings for GEM
        :param yearly_savings:
        :rtype: dict
        """
        yearly_savings['savings_this_year'] += yearly_savings['gems_savings']
        yearly_savings['savings_this_year_aed'] += yearly_savings['gems_savings']

    def get_user_gem_points(self, user_id, current_year, currency, locale='en'):
        user_savings_response = {
            'current_year': current_year,
            'points': 0,
            'yearly_points': 0
        }
        first_day_of_current_year = "{value}-01-01 00:00:00".format(value=current_year)
        wl_gem_points_repo = WlGemPointsRepository()
        all_points = wl_gem_points_repo.find_by(user_id=user_id)
        for point in all_points:
            user_savings_response['points'] += point.get('gems_points')
            created_date = point.get('created_date')
            created_date = created_date.strftime('%Y-%m-%d')
            if created_date >= first_day_of_current_year:
                user_savings_response['yearly_points'] += point.get('gems_points')
        return user_savings_response

    def set_user_savings(self, user_savings):
        """
        function is override for gems
        """
        user_savings['total_savings'] = user_savings['total_savings'] + int(user_savings.get('gems_savings', 0))
        user_savings['current_year_savings'] = (
            user_savings['current_year_savings'] + int(user_savings.get('gems_savings', 0))
        )
