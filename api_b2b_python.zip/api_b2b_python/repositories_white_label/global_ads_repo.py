"""
Global Ads Repository
"""
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class GlobalAdsRepositoryWl(BaseRepository):
    """
    Deals with the methods related to global ads for specific company
    """

    def get_global_ads(self, company='entertainer'):
        """
        Retrieves the ads for a specific company provided
        :param str company: name of the company for which ads are to be fetched
        :rtype: list of ads
        """
        sql_dal = SqlDal()
        sql_dal.select([
            'ga.id', 'ga.web_url', 'ga.client_name', 'ga.is_active', 'ga.valid_from', 'ga.valid_to',
            'COALESCE(ga.banner_url_ios_retina, "") AS banner_url_ios_retina',
            'COALESCE(ga.banner_url_ios_non_retina, "") AS banner_url_ios_non_retina',
            'COALESCE(ga.banner_url_android, "") AS banner_url_android, ga.is_deeplink'
        ])
        sql_dal.from_(['global_ads'], ['ga'])
        sql_dal.where({'ga.is_active': 1, 'ga.company': company})
        global_ads = sql_dal.get(default=[])
        return global_ads
