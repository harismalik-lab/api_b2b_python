"""
App Tutorials Repository.
File contains the details regarding application tutorials
"""
from collections import OrderedDict

from flask import g

from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal

cache = g.cache


class AppTutorialRepository(BaseRepository):
    PLATFORM = {
        "IOS": {"HS": {"2.1": 1}},
        "ANDROID": {"HS": {"2.1": 1}}
    }

    @staticmethod
    @cache.memoize(timeout=1800)
    def get_app_tutorials(company, platform, app_version, locale='en'):
        """
        Search database according to application's platform version, company and locale
        :param str company: company which user's application is attached.
        :param str platform: platform of device.
        :param str app_version: application version.
        :param str locale: language of application.
        :rtype: str
        """
        version = AppTutorialRepository.get_app_tutorial_version(company, platform, app_version)
        sql_dal = SqlDal()
        sql_dal.select([
            'at.id', 'at_t.version', 'CONCAT(at.identifier, "_", at_t.locale) as identifier', 'at_t.title',
            'at_t.description', 'at_t.image_url'
        ])
        sql_dal.from_(['app_tutorial'], ['at'])
        sql_dal.inner_join('app_tutorial_translation as at_t', 'at.id', ' at_t.app_tutorial_id')
        where_dict_clause = OrderedDict()
        where_dict_clause['at.is_active'] = 1
        where_dict_clause['at_t.is_active'] = 1
        where_dict_clause['at_t.version'] = version
        where_dict_clause['at.company'] = company
        where_dict_clause['at_t.locale'] = locale
        sql_dal.where(where_dict_clause)
        sql_dal.order_by({"at.order_id": "ASC"})
        results = sql_dal.get(default=[])
        return results

    @staticmethod
    def get_app_tutorial_version(company, platform, app_version):
        """
        Compares and gets specific tutorial version for an app
        :param str company: company which user's application is attached.
        :param str platform: platform of device.
        :param str app_version: application version.
        :rtype: str Application tutorial version
        """
        app_tutorial_version = 1
        company = company.upper()
        try:
            mappings = AppTutorialRepository.PLATFORM.get("{}".format(platform.upper()), {})
            if mappings.get(company):
                if mappings[company].get(app_version):
                    app_tutorial_version = mappings[company][app_version]
        except:
            pass
        return app_tutorial_version
