"""
Home Screen Configurations Repository
"""
from urllib.parse import urlencode

from flask import g
from rsa import encrypt

from common_white_label.constants import GlobalConstants
from common_white_label.db import DEFAULT as ENTERTAINER_WEB
from repositories_white_label.base_repo import BaseRepository
from repositories_white_label.location_repo import LocationRepositoryWhiteLabel
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.wl_categories_repo import CategoriesRepositoryWl
from repositories_white_label.wl_company_repo import WLCompany
from repositories_white_label.wl_user_group_repo import WlUserGroup
from repositories_white_label.wl_validtion_repo import WlValidationRepository
from wrapper_white_labels.sql_dal import SqlDal

cache = g.cache


class HomeScreenRepositoryWL(BaseRepository):

    # -*- coding: utf-8 -*-
    """
    This module contains Home Api related message constants
    """
    from gettext import gettext as _

    _author_ = 'kamal'

    MESSAGES_WHEN_SAVINGS_0 = [
        ("Haven't started saving yet? Use your offers today - go _UserName__!"),
        ("You have 0 savings _UserName__. Let's change that today, shall we?"),
        ("Hey _UserName__, today looks like a good day to start saving!")
    ]
    MESSAGES_WHEN_SAVINGS_FROM_1_TO_500 = [
        ("You’re off to a great start with _SAVINGS_VALUE_ saved. Keep at it _UserName__!"),
        ("Yay - you’ve saved _SAVINGS_VALUE_ so far! Carry on using your offers _UserName__!"),
        ("Woo-hoo, _SAVINGS_VALUE_ is in the bag! Save some more today _UserName__!"),
        ("You’re on a roll with _SAVINGS_VALUE_ saved up. More savings coming your way _UserName__!"),
        ("Congratulations for saving _SAVINGS_VALUE_! Here’s to more milestones with your offers.")
    ]
    MESSAGES_WHEN_SAVINGS_FROM_501_TO_2500 = [
        ("You’ve saved _SAVINGS_VALUE_ so far! Great going _UserName__!"),
        ("Savings worth _SAVINGS_VALUE_ in the bag! Keep at it _UserName__!"),
        ("Woot – you’re on to good things with _SAVINGS_VALUE_ saved so far!"),
        ("Yay – You’ve saved _SAVINGS_VALUE_ so far! Don’t stop now _UserName__!"),
        ("It’s raining _CURRENCY_ _UserName__ – you’ve saved _SAVINGS_VALUE_ so far, well done!")
    ]
    MESSAGES_WHEN_SAVINGS_FROM_2501_TO_5000 = [
        ("Ka-ching! You’ve saved _SAVINGS_VALUE_ so far, way to go _UserName__!"),
        ("_SAVINGS_VALUE_ saved so far! You’re on fire _UserName__!"),
        ("Whoa, _SAVINGS_VALUE_ worth SAVINGS! You should be proud of yourself _UserName__."),
        ("Ooh, your savings worth _SAVINGS_VALUE_ look so good! Keep 'em coming _UserName__!"),
        ("Where’s the party at _UserName__!? Cheers for saving _SAVINGS_VALUE_!")
    ]
    MESSAGES_WHEN_SAVINGS_FROM_5001_TO_1000000000 = [
        ("Word’s out that you’re a rainmaker with _SAVINGS_VALUE_ saved up. Way to go _UserName__!"),
        ("Holla _UserName__! _SAVINGS_VALUE_ in savings is something to brag about. Great going!"),
        ("Whoa - you’ve saved _SAVINGS_VALUE_ so far! Take a bow _UserName__."),
        ("Congratulations & celebrations for saving _SAVINGS_VALUE_ _UserName__!"),
        ("Cue the confetti – you’ve saved _SAVINGS_VALUE_! Cheers _UserName__!")
    ]
    #####################################################################
    # Category Translations, these are too small to be taken to .mo files
    #####################################################################
    FOOD_AND_DRINK = {
        "en": "FOOD & DRINK",
        'ar': "المطاعم",
        'el': "Φαγητό & Ποτό",
        'cn': "飲食",
    }
    BODY = {
        'en': "BEAUTY & FITNESS",
        'ar': "اللياقة والجمال",
        'el': "Ομορφιά & Ευεξία",
        'cn': "美容及健身",
    }
    LEISURE = {
        'en': "ATTRACTIONS & LEISURE",
        'ar': "الوجهات الترفيهية",
        'el': "Θεάματα & Αναψυχή",
        'cn': "景點及消閒"
    }
    FASHION_AND_RETAIL = {
        'en': "FASHION & RETAIL",
        'ar': "الموضة والتجزئة",
        'el': "Εμπόριο & Υπηρεσίες",
        'cn': "時尚&零售"
    }
    SERVICES = {
        'en': "RETAIL & SERVICES",
        'ar': "الخدمات اليومية",
        'el': "Εμπόριο & Υπηρεσίες",
        'cn': "零售及服務"
    }
    TRAVEL = {
        'en': "HOTELS WORLDWIDE",
        'ar': "فناق عالمية",
        'el': "Ξενοδοχεία Διεθνώς",
        'cn': "全球酒店"
    }
    TRAVEL_V6 = {
        'en': "TRAVEL",
        'ar': "السفر",
        'el': "Ταξιδέψτε",
        'cn': "旅遊"
    }
    #######################
    # Heading translations
    #######################
    EXTRA = {
        'en': "More to enjoy",
        'ar': "المزيد",
        'el': "Περισσότερα για να απολαύσετε",
        'cn': "更多"
    }
    FOR_THE_WEEKEND = {
        'en': "For the weekend",
        'ar': "لعطلة نهاية الأسبوع",
        'el': "Για το Σαββατοκύριακο",
        'cn': "週末使用"
    }
    FEATURED = {
        'en': "Featured",
        'ar': "عروض أساسية",
        'el': "Προτεινόμενα",
        'cn': "精選"
    }
    JUST_FOR_YOU = {
        'en': "Just For You",
        'ar': "عروض أساسية",
        'el': "Προτεινόμενα",
        'cn': "精選"
    }
    type_extra = "extra"
    type_for_the_weekend = "for_the_weekend"
    type_featured = "featured"
    type_birthday = "birthday"
    type_gems_referral = "gems_referral"

    NOT_REDEEMABLE = 0
    REDEEMABLE = 2
    TYPE_DEFAULT = 0
    TYPE_NEW_OFFER = 4
    OUTLETS_LIMIT = 6
    DEALS_SECTION = 'deals'

    DEALS_SECTION_IDENTIFIER = 'section_deals'
    DEALS_SECTION_NAME = 'Deals'
    NEARBY_SECTION_IDENTIFIER = 'section_nearby'
    NEARBY_SECTION_NAME = 'Nearby'
    SEE_ALL_BUTTON_TEXT = 'See all'
    SEE_ALL_BUTTON_TEXT_COLOR = 'fc471e'

    def get_all(self, locale='en', location_id=0, company=''):
        return self.get_configurations(locale, location_id, company)

    def get_gems_ambassador_program_url(self, gems_referral_url, gems_encryption_key, parent_id, BSU):
        """
        Get gems ambassador program url
        :param: gems_referral_url
        :param: gems_encryption_key
        :param: parent_id
        :param: BSU
        """
        parent_id_encrypted = encrypt(gems_encryption_key, parent_id)
        BSU_encrypted = encrypt(gems_encryption_key, BSU)

        parent_id_encrypted = urlencode(parent_id_encrypted)
        BSU_encrypted = urlencode(BSU_encrypted)

        parent_id_encrypted = parent_id_encrypted.replace("%", "_")
        BSU_encrypted = BSU_encrypted.replace("%", "_")

        __url = gems_referral_url
        __url = __url.replace(GlobalConstants.PARAM_VALUE_GEMS_Student_Patent_Id, parent_id_encrypted, __url)
        __url = __url.replace(GlobalConstants.PARAM_VALUE_GEMS_BSU, BSU_encrypted, __url)

        return __url

    def get_configurations(self, locale='en', location_id=0, company='entertainer', api_version=65):
        """
        Returns home screen configuration
        :param  str  locale:      Language of the user
        :param  int  location_id: User location id
        :param  str  company:     User Company
        :rtype: list
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select([
            'hsc.id', 'hsc.location_id', 'hsc.order_id', 'hsc.link_type',
            'hsc.is_active', 'hsc.is_external_link',
            'coalesce(t.title, "") as title', 'coalesce(t.description, "") as description',
            'coalesce(hsc.deep_link, "") as deep_link', 'coalesce(hsc.image_url, "") as image_url',
            'coalesce(hsc.logo_url, "") as logo_url',
            'hsc.tile_bottom_banner_color',
            'hsc.title as kaligo_location_identifier'
        ])
        sql_dal.from_(['home_screen_configurations'], ['hsc'])
        sql_dal.inner_join('home_screen_configurations_translation as t', 'hsc.id', 't.config_id')
        sql_dal.where({
            'hsc.location_id': location_id,
            'hsc.company': company,
            't.locale': locale,
            'hsc.is_active': 1
        })
        sql_dal.order_by({'hsc.order_id': 'ASC'})
        return sql_dal.get(default=[])

    def get_savings_translation(self, message_list, savings, replacement_data):
        """
        Gets savings translations
        """
        translated_messages = []
        if replacement_data:
            for message_line in message_list:
                savings_value_str = '{currency} {savings}'.format(
                    currency=replacement_data.get('currency', ''),
                    savings=savings
                )
                message_line = message_line.replace('_UserName__', replacement_data.get('firstname', '').lower().title())  # noqa:E501
                message_line = message_line.replace('_SAVINGS_VALUE_', savings_value_str)
                message_line = message_line.replace('_CURRENCY_', replacement_data.get('currency', ''))
                translated_messages.append(message_line)
        return translated_messages

    def get_saving_messages(self, savings, locale='en', replacement_data=None):
        """
        Gets savings messages translated into desired locale
        """
        message = []
        self.translation_manager = TranslationManager()
        if savings == 0:
            message = self.get_savings_translation(
                HomeScreenRepositoryWL.MESSAGES_WHEN_SAVINGS_0,
                savings,
                replacement_data
            )
            return message
        elif 1 <= savings <= 500:
            message = self.get_savings_translation(
                HomeScreenRepositoryWL.MESSAGES_WHEN_SAVINGS_FROM_1_TO_500,
                savings,
                replacement_data
            )
            return message
        elif 501 <= savings <= 2500:
            message = self.get_savings_translation(
                HomeScreenRepositoryWL.MESSAGES_WHEN_SAVINGS_FROM_501_TO_2500,
                savings,
                replacement_data
            )
            return message
        elif 2501 <= savings <= 5000:
            message = self.get_savings_translation(
                HomeScreenRepositoryWL.MESSAGES_WHEN_SAVINGS_FROM_2501_TO_5000,
                savings,
                replacement_data
            )
            return message
        elif 5001 <= savings:
            message = self.get_savings_translation(
                HomeScreenRepositoryWL.MESSAGES_WHEN_SAVINGS_FROM_5001_TO_1000000000,
                savings,
                replacement_data
            )
            return message

    def get_heading(self, heading, locale='en'):
        """
        Gets the translated heading.
        :param str heading: Heading to be translated
        :param str locale: Locale
        :rtype: str
        """
        if heading == self.type_extra:
            return self.translation_manager.get_translation(self.translation_manager.EXTRA, locale)
        elif heading == self.type_for_the_weekend:
            return self.translation_manager.get_translation(self.translation_manager.FOR_THE_WEEKEND, locale)
        elif heading == self.type_featured:
            return self.translation_manager.get_translation(self.translation_manager.FEATURED, locale)
        elif heading == self.type_birthday:
            return self.translation_manager.get_translation(self.translation_manager.BIRTHDAY_OFFER, locale)
        return ''

    @staticmethod
    def get_categories(**kwargs):
        """
        Gets the categories.
        :param kwargs:
        is_user_logged_in
        company
        user_id
        location_id
        purchased_product_ids
        purchasable_product_ids
        locale
        :rtype: list
        """
        show_all_categories = False
        show_freemium_slider_icons = False

        if all([
            kwargs.get('is_user_logged_in', False),
            kwargs.get('purchasable_product_ids', []),
            kwargs.get('purchased_product_ids', [])
        ]):
            for purchasable_product_id in kwargs.get('purchasable_product_ids', []):
                if purchasable_product_id in kwargs.get('purchased_product_ids', []):
                    show_all_categories = True
                    break

        if show_all_categories:
            categories = [
                {
                    "tile_id": 1,
                    "category_id": 1,
                    "is_free": False,
                    "image": CategoriesRepositoryWl.Image_RestaurantsAndBars,
                    "banner_image": "",
                    "api_name": CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars,
                    "display_name": HomeScreenRepositoryWL.get_category_label(
                        category=CategoriesRepositoryWl.ResturantsAndBars, locale=kwargs.get('locale', 'en')
                    ),
                    "analytics_category_name": CategoriesRepositoryWl.Analytics_Category_Code_RestaurantsAndBars,
                    "featured_merchant_icon_url": CategoriesRepositoryWl.Featured_Merchant_Icon_URL_RestaurantsAndBars,
                    "category_color": CategoriesRepositoryWl.Color_RestaurantsAndBars,
                    "map_pin_url": CategoriesRepositoryWl.Map_Pin_RestaurantsAndBars,
                    "map_pin_invalid_url": CategoriesRepositoryWl.Map_Pin_Invalid_RestaurantsAndBars
                },
                {
                    "tile_id": 2,
                    "category_id": 2,
                    "is_free": False,
                    "image": CategoriesRepositoryWl.Image_Body,
                    "banner_image": "",
                    "api_name": CategoriesRepositoryWl.category_API_Name_Body,
                    "display_name": HomeScreenRepositoryWL.get_category_label(
                        category=CategoriesRepositoryWl.Body, locale=kwargs.get('locale', 'en')
                    ),
                    "analytics_category_name": CategoriesRepositoryWl.Analytics_Category_Code_Body,
                    "featured_merchant_icon_url": CategoriesRepositoryWl.Featured_Merchant_Icon_URL_Body,
                    "category_color": CategoriesRepositoryWl.Color_Body,
                    "map_pin_url": CategoriesRepositoryWl.Map_Pin_Body,
                    "map_pin_invalid_url": CategoriesRepositoryWl.Map_Pin_Invalid_Body
                },
                {
                    "tile_id": 3,
                    "category_id": 3,
                    "is_free": False,
                    "image": CategoriesRepositoryWl.Image_Leisure,
                    "banner_image": "",
                    "api_name": CategoriesRepositoryWl.category_API_Name_Leisure,
                    "display_name": HomeScreenRepositoryWL.get_category_label(
                        category=CategoriesRepositoryWl.Leisure, locale=kwargs.get('locale', 'en')
                    ),
                    "analytics_category_name": CategoriesRepositoryWl.Analytics_Category_Code_Leisure,
                    "featured_merchant_icon_url": CategoriesRepositoryWl.Featured_Merchant_Icon_URL_Leisure,
                    "category_color": CategoriesRepositoryWl.Color_Leisure,
                    "map_pin_url": CategoriesRepositoryWl.Map_Pin_Leisure,
                    "map_pin_invalid_url": CategoriesRepositoryWl.Map_Pin_Invalid_Leisure
                },
                {
                    "tile_id": 7,
                    "category_id": 7,
                    "is_free": show_freemium_slider_icons,
                    "image": CategoriesRepositoryWl.Image_Retail,
                    "banner_image": "",
                    "api_name": CategoriesRepositoryWl.category_API_Name_Retail,
                    "display_name": HomeScreenRepositoryWL.get_category_label(
                        category=CategoriesRepositoryWl.Retail, locale=kwargs.get('locale', 'en')
                    ),
                    "analytics_category_name": CategoriesRepositoryWl.Analytics_Category_Code_Retail,
                    "featured_merchant_icon_url": CategoriesRepositoryWl.Featured_Merchant_Icon_URL_Retail,
                    "category_color": CategoriesRepositoryWl.Color_Retail,
                    "map_pin_url": CategoriesRepositoryWl.Map_Pin_Retail,
                    "map_pin_invalid_url": CategoriesRepositoryWl.Map_Pin_Invalid_Retail,
                    "map_pin_selected_url": CategoriesRepositoryWl.Map_Pin_Selected_Retail,
                    "map_pin_selected_invalid_url": CategoriesRepositoryWl.Map_Pin_Selected_Invalid_Retail
                },
                {
                    "tile_id": 4,
                    "category_id": 4,
                    "is_free": False,
                    "image": CategoriesRepositoryWl.Image_Services,
                    "banner_image": "",
                    "api_name": CategoriesRepositoryWl.category_API_Name_Services,
                    "display_name": HomeScreenRepositoryWL.get_category_label(
                        category=CategoriesRepositoryWl.Services, locale=kwargs.get('locale', 'en')
                    ),
                    "analytics_category_name": CategoriesRepositoryWl.Analytics_Category_Code_Services,
                    "featured_merchant_icon_url": CategoriesRepositoryWl.Featured_Merchant_Icon_URL_Services,
                    "category_color": CategoriesRepositoryWl.Color_Services,
                    "map_pin_url": CategoriesRepositoryWl.Map_Pin_Services,
                    "map_pin_invalid_url": CategoriesRepositoryWl.Map_Pin_Invalid_Services
                },
                {
                    "tile_id": 5,
                    "category_id": 5,
                    "is_free": False,
                    "image": CategoriesRepositoryWl.Image_Travel,
                    "banner_image": "",
                    "api_name": CategoriesRepositoryWl.category_API_Name_Travel,
                    "display_name": HomeScreenRepositoryWL.get_category_label(
                        category=CategoriesRepositoryWl.Travel, locale=kwargs.get('locale', 'en')
                    ),
                    "analytics_category_name": CategoriesRepositoryWl.Analytics_Category_Code_Travel,
                    "featured_merchant_icon_url": CategoriesRepositoryWl.Featured_Merchant_Icon_URL_Travel,
                    "category_color": CategoriesRepositoryWl.Color_Travel,
                    "map_pin_url": CategoriesRepositoryWl.Map_Pin_Travel,
                    "map_pin_invalid_url": CategoriesRepositoryWl.Map_Pin_Invalid_Travel
                }
            ]
        else:
            location_repo = LocationRepositoryWhiteLabel()
            user_groups = []
            if kwargs.get('is_user_logged_in', False):
                wl_validation_repo = WlValidationRepository()
                user_groups = wl_validation_repo.get_user_groups(kwargs.get('company'), kwargs.get('user_id'))
            if not user_groups:
                user_groups.append(WlUserGroup.DEFAULT_USER_GROUP)
            # user_groups_ids = []
            # for groups in user_groups:
            # user_groups_ids.append(groups.get('user_group'))
            categories = location_repo.get_location_categories(
                kwargs.get('company'), kwargs.get('location_id'), user_groups, kwargs.get('locale', 'en')
            )
            for category in categories:
                api_name = category.get('api_name', '')
                category['banner_image'] = ''
                category["is_free"] = False
                category['title_color'] = GlobalConstants.TITLE_COLOR
                constant_name = category.get('api_name', '').replace(' ', '')
                category['analytics_category_name'] = getattr(
                    CategoriesRepositoryWl, 'Analytics_Category_Code_{}'.format(constant_name)
                )
                category['featured_merchant_icon_url'] = getattr(
                    CategoriesRepositoryWl, 'Featured_Merchant_Icon_URL_{}'.format(constant_name)
                )
                category['category_color'] = category.get('color_code', '').replace("#", '')
                category_name = CategoriesRepositoryWl().category_title_to_lower(api_name=api_name)
                if kwargs.get('company', '') == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
                    category['map_pin_url'] = \
                        CategoriesRepositoryWl.Map_Pin_GENERIC_PIN_GEMS.format(category=category_name)
                    category['map_pin_invalid_url'] = \
                        CategoriesRepositoryWl.Map_Pin_GENERIC_PIN_INVALID_GEMS.format(category=category_name)
                else:
                    category['map_pin_url'] = \
                        getattr(CategoriesRepositoryWl, 'Map_Pin_{}'.format(constant_name))
                    category['map_pin_invalid_url'] = \
                        getattr(CategoriesRepositoryWl, 'Map_Pin_Invalid_{}'.format(constant_name))
                try:
                    del category['color_code']
                except KeyError:
                    pass
                category['display_name'] = HomeScreenRepositoryWL.get_category_label(
                    category=api_name, locale=kwargs.get('locale', 'en'), company=kwargs.get('company')
                )
            if kwargs.get('purchasable_product_ids', []):
                has_travel_category = False
                for category in categories:
                    if category['api_name'] == CategoriesRepositoryWl.category_name_Travel:
                        has_travel_category = True
                        break
                if not has_travel_category:
                    travel_cat_img = CategoriesRepositoryWl.Image_Travel
                    if kwargs.get('company') == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
                        travel_cat_img = GlobalConstants.TRAVEL_CAT_IMG_GEM
                    elif kwargs.get('company') == WLCompany.COMPANY_CODE_ENTERTAINER_HSBC:
                        travel_cat_img = GlobalConstants.TRAVEL_CAT_IMG_HSBS

                    categories.append({
                        "tile_id": 5,
                        "category_id": 5,
                        "is_free": False,
                        "image": travel_cat_img,
                        "banner_image": "",
                        "api_name": CategoriesRepositoryWl.category_API_Name_Travel,
                        "display_name": HomeScreenRepositoryWL.get_category_label(
                            category=CategoriesRepositoryWl.category_API_Name_Travel,
                            locale=kwargs.get('locale', 'en'),
                            company=kwargs.get('company')
                        ),
                        "analytics_category_name": CategoriesRepositoryWl.Analytics_Category_Code_Travel,
                        "featured_merchant_icon_url": CategoriesRepositoryWl.Featured_Merchant_Icon_URL_Travel,
                        "category_color": CategoriesRepositoryWl.Color_Travel,
                        "map_pin_url": CategoriesRepositoryWl.Map_Pin_Travel,
                        "map_pin_invalid_url": CategoriesRepositoryWl.Map_Pin_Invalid_Travel
                    })
        return categories

    @staticmethod
    def get_category_label(**kwargs):
        """
        Gets the category label.
        :param kwargs:
        category, locale, company,
        :rtype: str
        """
        translation_manager = TranslationManager()
        category = kwargs.get('category', '').lower()
        locale = kwargs.get('locale', '')
        if category == CategoriesRepositoryWl.ResturantsAndBars:
            return translation_manager.get_translation(translation_manager.FOOD_AND_DRINK, locale)
        # Todo: Need to update the translation in the controller.
        elif category == CategoriesRepositoryWl.Body:
            if locale == 'ar':
                return 'تجميل ولياقة بدنية'
            else:
                return translation_manager.get_translation(translation_manager.BODY, locale)
        elif category == CategoriesRepositoryWl.Leisure:
            if locale == 'ar':
                return 'التسلية والترفيه'
            else:
                return translation_manager.get_translation(translation_manager.LEISURE, locale)
        elif category == CategoriesRepositoryWl.Retail:
            if locale == 'ar':
                return 'خدمات'
            else:
                return translation_manager.get_translation(translation_manager.FASHION_AND_RETAIL, locale)
        elif category == CategoriesRepositoryWl.Services:
            if locale == 'en':
                if kwargs.get('company', '') == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
                    return "RETAIL & SERVICES"
                else:
                    return "EVERYDAY SERVICES"
            elif locale == 'el':
                return 'Καθημερινές Υπηρεσίες'
            else:
                return translation_manager.get_translation(translation_manager.SERVICES, locale)
        elif category == 'travel':
            if kwargs.get('company', '') in (
                    WLCompany.COMPANY_CODE_ENTERTAINER_GEMS,
                    WLCompany.COMPANY_CODE_ENTERTAINER_HSBC,
                    WLCompany.COMPANY_CODE_DUBAI_ENTERTAINMENTS
            ):
                if locale == 'en':
                    return 'HOTELS'
                else:
                    return translation_manager.get_translation(translation_manager.TRAVEL, locale)
            else:
                return translation_manager.get_translation(translation_manager.TRAVEL, locale)
        return ''

    def get_sub_section(self, all_sections, sub_section_type, locale='en'):
        """
        Gets the list of sub sections.
        :param dict all_sections: List of all sections
        :param str sub_section_type: Subsection type
        :param str locale: Locale
        :rtype: list
        """
        sub_sections = []
        for section in all_sections:
            if section.get('link_type') == sub_section_type:
                is_external_link = section.get('is_external_link', False)
                sub_sections.append({
                    "tile_id": section.get('id'),
                    "image": section.get('image_url'),
                    "logo": section.get('logo_url'),
                    "message": section.get('title'),
                    "is_deep_link": bool(section.get('deep_link')),  # True If not None or not empty else False
                    "deep_link": section.get('deep_link'),
                    "is_external_link": bool(is_external_link),
                    "tile_bottom_banner_color": section.get('tile_bottom_banner_color'),
                })
        return sub_sections

    def get_kaligo_deeplink(self, *args, **kwargs):
        """
        Gets the kaligo deeplink.
        :param kwargs: locale, entity_type, company
        :rtype: dict
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select([
            'hsc.id', 'hsc.location_id', 'hsc.order_id', 'hsc.link_type',
            'hsc.is_active', 'hsc.is_external_link',
            'coalesce(t.title, "") as title', 'coalesce(t.description, "") as description',
            'coalesce(hsc.deep_link, "") as deep_link', 'coalesce(hsc.image_url, "") as image_url',
            'coalesce(hsc.logo_url, "") as logo_url',
            'hsc.title as kaligo_location_identifier'
        ])
        sql_dal.from_(['home_screen_configurations'], ['hsc'])
        sql_dal.inner_join('home_screen_configurations_translation as t', 'hsc.id', 't.config_id')
        sql_dal.where({
            'hsc.company': kwargs.get('company'),
            'hsc.link_type': 'kaligo',
            't.locale': kwargs.get('locale', 'en'),
            'hsc.title': kwargs.get('entity_type', '')
        })
        sql_dal.order_by({'hsc.order_id': 'ASC'})
        return sql_dal.get_one(default={})
