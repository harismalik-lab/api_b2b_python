"""
WL User Group Repository
"""
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class WlUserGroup(BaseRepository):

    GROUP_ID_DU_STAFF = 1
    GROUP_ID_DU_CUSTOMER = 2
    DEFAULT_USER_GROUP = 1

    def get_group_info(self, user_group, wl_company):
        """
         Returns the group info of company
        :param int user_group: user_group
        :param str wl_company: wl_company
        :return: dict
        """
        sql_dal = SqlDal()
        sql_dal.select(['wl_user_group.code', 'wl_user_group.logo', 'wl_user_group.number_of_offers'])
        sql_dal.from_(['wl_user_group'])
        sql_dal.where({
            'wl_user_group.user_group': user_group,
            'wl_user_group.wl_company': wl_company
        })
        result = sql_dal.get_one(default={})
        return result
