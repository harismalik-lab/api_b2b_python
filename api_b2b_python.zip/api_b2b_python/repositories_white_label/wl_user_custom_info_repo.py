"""
Wl User Custom Info Repository
"""
from collections import OrderedDict

from common_white_label.db import CONSOLIDATION, get_db_settings_from_app
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal

__author__ = "Zaheer"


class WLUserCustomInfoRepository(BaseRepository):
    """
    Repo for wl user custom information API which holds all the helper methods required.
    """
    def get_user_custom_info(self, user_id, company):
        """
        Gets user custom information
        :param int user_id: id of user
        :param str company: company
        :rtype: dict
        """
        consolidation_db = get_db_settings_from_app(connection_name=CONSOLIDATION)['database']
        sql_dal = SqlDal()
        sql_dal.select(['*'])
        sql_dal.from_(['{}.wl_user_custom_info'.format(consolidation_db)])
        ordered_where_clause = OrderedDict()
        ordered_where_clause['user_id'] = user_id
        ordered_where_clause['company'] = company
        sql_dal.where(ordered_where_clause)
        result = sql_dal.get_one(default={})
        return result

    def add_user_custom_info(self, user_id, company, password_hash):
        """
        Adds user custom information
        :param int user_id: id of user
        :param str company: company
        :param str password_hash: password hash
        :rtype:
        """
        user_custom_info = self.get_user_custom_info(user_id, company)
        if not user_custom_info:
            user_custom_info = {'user_id': user_id, 'company': company}
            user_custom_info['status'] = 1
        if user_custom_info:
            sql_dal = SqlDal(connection=CONSOLIDATION)
            user_custom_info['password_hash'] = password_hash
            columns = list(user_custom_info.keys())
            values = list(user_custom_info.values())
            user_custom_info = sql_dal.insert(
                'wl_user_custom_info', columns=columns, values=values, last_row_id=True
            )
            return user_custom_info

    def get_password_hash(self, user_id, company):
        """
        Get user's password hash
        :param user_id:
        :param company:
        :return:
        """
        consolidation_db = get_db_settings_from_app(connection_name=CONSOLIDATION)['database']
        sql_dal = SqlDal()
        sql_dal.select(['password_hashed'])
        sql_dal.from_(['{}.wl_user_custom_info'.format(consolidation_db)])
        ordered_where_clause = OrderedDict()
        ordered_where_clause['user_id'] = user_id
        ordered_where_clause['company'] = company
        sql_dal.where(ordered_where_clause)
        result = sql_dal.get_one(default={})
        return result
