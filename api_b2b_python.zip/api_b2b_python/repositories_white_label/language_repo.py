"""
White label language repository
"""
from repositories.customer_languages_repo import CustomerLanguageRepository


class CustomerLanguageRepositoryWhiteLabel(CustomerLanguageRepository):
    pass
