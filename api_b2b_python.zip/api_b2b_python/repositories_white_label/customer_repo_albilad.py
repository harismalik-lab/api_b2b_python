from repositories_white_label.customer_repo import CustomerProfileWhiteLabel


class CustomerProfileAlBilad(CustomerProfileWhiteLabel):
    def set_currency_and_default_currency(self, changes):
        """
        Sets the currency nd default currency
        :param changes:
        :rtype dict
        """
        changes['currency'] = "SAR"
        changes['default_currency'] = 43
        return changes
