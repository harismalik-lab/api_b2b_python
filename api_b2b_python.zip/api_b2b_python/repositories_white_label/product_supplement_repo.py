"""
Product Supplement Repository
"""
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class ProductSupplimentaryRepositoryWl(BaseRepository):

    def get_product_supplement_details_wl(self, product_id, locale):
        """
        Returns the product supplement details of wl
        :param int product_id:
        :param str locale: locale
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select(['ps.main_image', 'ps.thumbnail_image', 'ps.border_color', 'pst.title', 'pst.description'])
        sql_dal.from_(['product_supplement'], ['ps'])
        sql_dal.inner_join('product_supplement_translation AS pst', 'ps.id', 'pst.product_supplement_id')
        sql_dal.where({'ps.product_id': product_id, 'pst.locale': locale})
        product_supplements = sql_dal.get_one(default={})
        return product_supplements
