"""
WL Membership Cards Repo
"""
from common_white_label.db import DEFAULT as ENTERTAINER_WEB
from repositories_white_label.base_repo import BaseRepository
from repositories_white_label.user_savings_repo import UserSavingsRepositoryWhiteLabel
from repositories_white_label.wl_invoice_headers_repo import WlInvoiceHeadersRepository
from wrapper_white_labels.sql_dal import SqlDal


class WlMembershipCardRepository(BaseRepository):
    """
    Repo for wl membership card repository.
    """
    def validate_card_number(self, card_number, company, user_id=0):
        """
        Validates card number
        :param card_number: card number
        :param company: white label client
        :param user_id: user id
        :rtype: int
        """
        validation_status = WlInvoiceHeadersRepository.INVALID_STATUS
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select(['*'])
        sql_dal.from_(['wl_membership_cards'])
        sql_dal.where({'card_number': card_number, 'company': company})
        result = sql_dal.get_one(default={})
        if result:
            if result.get('user_id') == 0:
                validation_status = WlInvoiceHeadersRepository.VALID_STATUS
            else:
                if result.get('user_id') == user_id:
                    validation_status = WlInvoiceHeadersRepository.ALREADY_USED_STATUS
                else:
                    validation_status = WlInvoiceHeadersRepository.INVALID_STATUS
        return validation_status

    def add_card_to_user(self, card_number, company, user_id, email):
        """
        Add card number against user id
        :param card_number: card number
        :param company: white label client
        :param user_id: user_id
        :param email: email
        :rtype: dict
        """
        user_initial_savings = 0
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select(['*'])
        sql_dal.from_(['wl_membership_cards'])
        sql_dal.where({
            'card_number': card_number,
            'company': company,
            'user_id': 0,
            'status': True
        })
        card_lookup = sql_dal.get_one(default={})
        if card_lookup:
            card_lookup['user_id'] = user_id
            sql_dal.where({'id': card_lookup.get('id')})
            sql_dal.update('wl_membership_cards', card_lookup)

        invoice_header_repo = WlInvoiceHeadersRepository()
        invoice_lookup = invoice_header_repo.find_by_invoice_lookup(company, card_number, user_id=0)
        if invoice_lookup:
            user_savings_repo = UserSavingsRepositoryWhiteLabel()
            user_savings = user_savings_repo.get_user_savings(user_id, company)
            user_initial_savings = user_savings.get('total_points')
            for item in invoice_lookup:
                savings = int(item['transaction_total_price'])
                user_savings['total_points'] += savings
                item[user_id] = user_id
                sql_dal.where({'company': company, 'card_number': card_number})
                sql_dal.update('user_savings', item)

            sql_dal.where({'user_id': user_id, 'company': company})
            sql_dal.update('user_savings', user_savings)

        emax_user_group = invoice_header_repo.get_heighest_emax_user_group(user_id, company)
        user_group = invoice_header_repo.get_user_group_based_on_spend(
            emax_user_group,
            user_initial_savings
        )
        invoice_header_repo.assign_user_group_and_vip_key(user_id, email, company, user_group)
        return card_lookup
