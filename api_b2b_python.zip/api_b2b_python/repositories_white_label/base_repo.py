# App specific imports
from contextlib import contextmanager

# 3rd party imports
from mysql.connector.errors import IntegrityError

from common_white_label.db import DEFAULT, get_connection_for_db


class BaseRepository(object):
    db_connection = None
    close_connection = True
    logger = None
    single_connection = False

    def __init__(self, logger=None, single_connection=False, connection=None):
        self.logger = logger
        self.single_connection = single_connection
        self.db_connection = connection

    @contextmanager
    def _get_context_cursor(self, con):
        """
        The method handles opening and closing of cursor
        :param mysql.connector.pooling.MySQLConnection con: Db Connection
        """
        cursor = con.cursor(dictionary=True)
        yield cursor
        cursor.close()

    def get_connection(self, connection=DEFAULT):
        self.db_connection = get_connection_for_db(connection)
        return self.db_connection

    def fetch_all(self, connection=DEFAULT, default_if_no_records=[], query=''):
        self.get_connection(connection)
        if not self.db_connection:
            return default_if_no_records

        records = default_if_no_records
        try:
            with self._get_context_cursor(self.db_connection) as cursor:
                cursor.execute(query)
                records = cursor.fetchall() or default_if_no_records
        finally:
            if self.close_connection:
                self.db_connection.close()
            self.db_connection = None
        return records

    def fetch_one(self, connection=DEFAULT, default_if_no_records={}, query=''):
        self.get_connection(connection)
        if not self.db_connection:
            return default_if_no_records

        record = default_if_no_records
        try:
            with self._get_context_cursor(self.db_connection) as cursor:
                cursor.execute(query)
                record = cursor.fetchone() or default_if_no_records
        finally:
            if self.close_connection:
                self.db_connection.close()
            self.db_connection = None
        return record

    def commit(self, connection=DEFAULT, data={}, default_if_no_records=0, query=''):
        self.get_connection(connection)
        if not self.db_connection:
            return default_if_no_records

        record_id = default_if_no_records
        try:
            with self._get_context_cursor(self.db_connection) as cursor:
                if data:
                    cursor.execute(query, data)
                else:
                    cursor.execute(query)
                self.db_connection.commit()
                record_id = cursor.lastrowid
        except IntegrityError:
            self.db_connection.rollback()
            raise
        except Exception:
            raise
        finally:
            if self.close_connection:
                self.db_connection.close()
            self.db_connection = None
        return record_id
