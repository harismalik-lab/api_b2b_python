
"""
White Label Categories Repository
"""

from repositories_white_label.base_repo import BaseRepository


class CategoriesRepositoryWl(BaseRepository):

    """
    Categories Repository
    """
    Body = 'body'
    Kids = 'kids'
    Leisure = 'leisure'
    ResturantsAndBars = 'restaurants and bars'
    Retail = 'retail'
    Services = 'services'
    Travel = 'travel'

    category_name_Body = 'Body'
    category_name_Leisure = 'Leisure'
    category_name_Restaurants_and_Bars = 'Restaurants and Bars'
    category_name_Retail = 'Retail'
    category_name_Services = 'Services'
    category_name_Travel = 'Travel'

    category_API_Name_Body = 'Body'
    category_API_Name_Leisure = 'Leisure'
    category_API_Name_Restaurants_and_Bars = 'Restaurants and Bars'
    category_API_Name_Retail = 'Retail'
    category_API_Name_Services = 'Services'
    category_API_Name_Travel = 'Travel'
    category_API_Name_Kids = 'Kids'

    Body_Id = 1
    Kids_Id = 2
    Leisure_Id = 3
    RestaurantsAndBars_Id = 4
    Services_Id = 5
    Travel_Id = 6
    Retail_Id = 7

    Color_Body = "C7318C"
    Color_Leisure = "88C867"
    Color_RestaurantsAndBars = "4F99D2"
    Color_Retail = "9866AC"
    Color_Services = "20909A"
    Color_Travel = "B3995D"
    Color_Cheers = "F05D51"

    Analytics_Category_Code_Body = "BF"
    Analytics_Category_Code_Leisure = "AL"
    Analytics_Category_Code_RestaurantsAndBars = "FD"
    Analytics_Category_Code_Retail = "FR"
    Analytics_Category_Code_Services = "ES"
    Analytics_Category_Code_Travel = "HW"

    Image_Body = "https://s3.amazonaws.com/entertainer-app-assets/categories/body.png"
    Image_Leisure = "https://s3.amazonaws.com/entertainer-app-assets/categories/leisure.png"
    Image_RestaurantsAndBars = "https://s3.amazonaws.com/entertainer-app-assets/categories/food.png"
    Image_Retail = "https://s3.amazonaws.com/entertainer-app-assets/categories/retail.png"
    Image_Services = "https://s3.amazonaws.com/entertainer-app-assets/categories/services_2.png"
    Image_Travel = "https://s3.amazonaws.com/entertainer-app-assets/categories/travel.png"
    Image_Free_Retail = "https://s3.amazonaws.com/entertainer-app-assets/categories/retail_free.png"
    Image_Free_Services = "https://s3.amazonaws.com/entertainer-app-assets/categories/services_free.png"
    Image_Free_Travel = "https://s3.amazonaws.com/entertainer-app-assets/categories/travel_free.png"

    Map_Pin_Body = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_body@2x.png"
    Map_Pin_Leisure = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_leisure@2x.png"
    Map_Pin_RestaurantsAndBars = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_food@2x.png"
    Map_Pin_Retail = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_retail@2x.png"
    Map_Pin_Services = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_services@2x.png"
    Map_Pin_Travel = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_travel@2x.png"

    Map_Pin_Invalid_Body = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_invalid_body@2x.png"
    Map_Pin_Invalid_Leisure = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_invalid_leisure@2x.png"  # noqa : E501
    Map_Pin_Invalid_RestaurantsAndBars = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_invalid_food@2x.png"  # noqa : E501
    Map_Pin_Invalid_Retail = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_invalid_retail@2x.png"  # noqa : E501
    Map_Pin_Invalid_Services = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_invalid_services@2x.png"  # noqa : E501
    Map_Pin_Invalid_Travel = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_invalid_travel@2x.png"  # noqa : E501

    Map_Pin_Selected_Body = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_body@2x.png"  # noqa : E501
    Map_Pin_Selected_Leisure = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_leisure@2x.png"  # noqa : E501
    Map_Pin_Selected_RestaurantsAndBars = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_food@2x.png"  # noqa : E501
    Map_Pin_Selected_Retail = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_retail@2x.png"  # noqa : E501
    Map_Pin_Selected_Services = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_services@2x.png"  # noqa : E501
    Map_Pin_Selected_Travel = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_travel@2x.png"  # noqa : E501

    Map_Pin_Selected_Invalid_Body = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_invalid_body@2x.png"  # noqa : E501
    Map_Pin_Selected_Invalid_Leisure = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_invalid_leisure@2x.png"  # noqa : E501
    Map_Pin_Selected_Invalid_RestaurantsAndBars = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_invalid_food@2x.png"  # noqa : E501
    Map_Pin_Selected_Invalid_Retail = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_invalid_retail@2x.png"  # noqa : E501
    Map_Pin_Selected_Invalid_Services = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_invalid_services@2x.png"  # noqa : E501
    Map_Pin_Selected_Invalid_Travel = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_invalid_travel@2x.png"  # noqa : E501

    Featured_Merchant_Icon_URL_Body = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_body.png"  # noqa : E501
    Featured_Merchant_Icon_URL_Leisure = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_leisure.png"  # noqa : E501
    Featured_Merchant_Icon_URL_RestaurantsAndBars = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_food.png"  # noqa : E501
    Featured_Merchant_Icon_URL_Retail = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_retail.png"  # noqa : E501
    Featured_Merchant_Icon_URL_Services = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_services.png"  # noqa : E501
    Featured_Merchant_Icon_URL_Travel = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_travel.png"  # noqa : E501

    Featured_Merchant_Icon_URL_Category_HomeScreen_Body = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_body_category_home_screen.png"  # noqa : E501
    Featured_Merchant_Icon_URL_Category_HomeScreen_Leisure = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_leisure_category_home_screen.png"  # noqa : E501
    Featured_Merchant_Icon_URL_Category_HomeScreen_RestaurantsAndBars = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_food_category_home_screen.png"  # noqa : E501
    Featured_Merchant_Icon_URL_Category_HomeScreen_Retail = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_retail_category_home_screen.png"  # noqa : E501
    Featured_Merchant_Icon_URL_Category_HomeScreen_Services = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_services_category_home_screen.png"  # noqa : E501
    Featured_Merchant_Icon_URL_Category_HomeScreen_Travel = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_travel.png"  # noqa : E501

    Icon_URL_Body = "https://s3.amazonaws.com/entertainer-app-assets/icons/badge_body.png"
    Icon_URL_Leisure = "https://s3.amazonaws.com/entertainer-app-assets/icons/badge_leisure.png"
    Icon_URL_RestaurantsAndBars = "https://s3.amazonaws.com/entertainer-app-assets/icons/badge_restaurants_and_bars.png"
    Icon_URL_Retail = "https://s3.amazonaws.com/entertainer-app-assets/icons/badge_retail.png"
    Icon_URL_Services = "https://s3.amazonaws.com/entertainer-app-assets/icons/badge_services.png"
    Icon_URL_Travel = "https://s3.amazonaws.com/entertainer-app-assets/icons/badge_travel.png"

    Free_Category_Icon = "https://s3.amazonaws.com/entertainer-app-assets/icons/free_category_icon.png"

    Image_Leisure_Locked = "https://s3.amazonaws.com/entertainer-app-assets/categories/leisure_locked_for_onboarding.png"  # noqa : E501
    Image_Travel_Locked = "https://s3.amazonaws.com/entertainer-app-assets/categories/travel_locked_for_onboarding.png"
    Image_Body_Locked = "https://s3.amazonaws.com/entertainer-app-assets/categories/beauty_locked_for_onboarding.png"
    Image_Retail_Locked = "https://s3.amazonaws.com/entertainer-app-assets/categories/fashion_locked_for_onboarding.png"
    Image_Services_Locked = "https://s3.amazonaws.com/entertainer-app-assets/categories/everyday_services_locked_for_onboarding.png"  # noqa : E501

    Color_RestaurantsandBars = "4F99D2"  # "4d92c6"
    Color_Body_GEMS = "C7318C"  # "ba3281"
    Color_Leisure_GEMS = "88C867"  # "84bf66"
    Color_RestaurantsandBars_GEMS = "4F99D2"  # "4d92c6"
    Color_Retail_GEMS = "9866AC"  # "249584"
    Color_Services_GEMS = "20909A"  # "249584"
    Color_Travel_GEMS = "B3995D"  # "b09660"

    Analytics_Category_Code_RestaurantsandBars = "FD"
    Map_Pin_Invalid_RestaurantsandBars = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_invalid_food@2x.png"  # noqa:E501
    Image_RestaurantsandBars = "https://s3.amazonaws.com/entertainer-app-assets/categories/food.png"
    Map_Pin_RestaurantsandBars = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_food@2x.png"
    Map_Pin_Selected_RestaurantsandBars = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_food@2x.png"  # noqa:E501
    Map_Pin_Selected_Invalid_RestaurantsandBars = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_invalid_food@2x.png"  # noqa:E501
    Featured_Merchant_Icon_URL_Category_HomeScreen_RestaurantsandBars = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_food_category_home_screen.png"  # noqa:E501
    Icon_URL_RestaurantsandBars = "https://s3.amazonaws.com/entertainer-app-assets/icons/badge_restaurants_and_bars.png"  # noqa:E501

    Featured_Merchant_Icon_URL_RestaurantsandBars = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_food.png"  # noqa:E501
    Map_Pin_GENERIC_PIN_GEMS = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/gems/cat_pin_{category}@2x.png"  # noqa:E501
    Map_Pin_GENERIC_PIN_INVALID_GEMS = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/gems/cat_pin_invalid_{category}@2x.png"  # noqa:E501

    def category_title_to_lower(self, api_name):
        """
        Gets the category title in lower caps.
        :rtype: str
        """
        categories_title_mapping = {
            self.category_API_Name_Body: self.Body,
            self.category_API_Name_Kids: self.Kids,
            self.category_API_Name_Leisure: self.Leisure,
            self.category_API_Name_Restaurants_and_Bars: self.ResturantsAndBars,
            self.category_API_Name_Retail: self.Retail,
            self.category_API_Name_Services: self.Services,
            self.category_API_Name_Travel: self.Travel
        }
        return categories_title_mapping.get(api_name, None)

    ANALYTICS_CATEGORY_CODES_DICT = {
        category_name_Body.lower(): Analytics_Category_Code_Body,
        category_name_Leisure.lower(): Analytics_Category_Code_Leisure,
        category_name_Restaurants_and_Bars.lower(): Analytics_Category_Code_RestaurantsAndBars,
        category_name_Retail.lower(): Analytics_Category_Code_Retail,
        category_name_Services.lower(): Analytics_Category_Code_Services,
        category_name_Travel.lower(): Analytics_Category_Code_Travel
    }

    CATEGORY_BADGES = {
        category_name_Body: Image_Body,
        category_name_Leisure: Image_Leisure,
        category_name_Restaurants_and_Bars: Image_RestaurantsAndBars,
        category_name_Retail: Image_Retail,
        category_name_Services: Image_Services,
        category_name_Travel: Image_Travel
    }

    FEATURED_RIBBON_IMAGE = {
        category_name_Body: Featured_Merchant_Icon_URL_Body,
        category_name_Leisure: Featured_Merchant_Icon_URL_Leisure,
        category_name_Restaurants_and_Bars: Featured_Merchant_Icon_URL_RestaurantsAndBars,
        category_name_Retail: Featured_Merchant_Icon_URL_Retail,
        category_name_Services: Featured_Merchant_Icon_URL_Services,
        category_name_Travel: Featured_Merchant_Icon_URL_Travel
    }

    FEATURED_HOMES_IMAGE = {
        category_name_Body: Featured_Merchant_Icon_URL_Category_HomeScreen_Body,
        category_name_Leisure: Featured_Merchant_Icon_URL_Category_HomeScreen_Leisure,
        category_name_Restaurants_and_Bars: Featured_Merchant_Icon_URL_Category_HomeScreen_RestaurantsAndBars,
        category_name_Retail: Featured_Merchant_Icon_URL_Category_HomeScreen_Retail,
        category_name_Services: Featured_Merchant_Icon_URL_Category_HomeScreen_Services,
        category_name_Travel: Featured_Merchant_Icon_URL_Category_HomeScreen_Travel
    }

    CATEGORIES_LOWER_TO_TITLE = {
        Body: category_API_Name_Body,
        Kids: category_API_Name_Kids,
        Leisure: category_API_Name_Leisure,
        ResturantsAndBars: category_API_Name_Restaurants_and_Bars,
        Retail: category_API_Name_Retail,
        Services: category_API_Name_Services,
        Travel: category_API_Name_Travel
    }

    def category_lower_to_title(self, category):
        """
        Category title convert to lower
        """
        return self.CATEGORIES_LOWER_TO_TITLE.get(category, category)

    def get_valid_categories(self):
        return [
            self.category_API_Name_Body,
            self.category_API_Name_Leisure,
            self.category_API_Name_Restaurants_and_Bars,
            self.category_API_Name_Retail,
            self.category_API_Name_Services,
            self.category_API_Name_Travel
        ]

    def get_analytics_codes_against_categories(self, categories):
        """
        Gets analytics codes against given categories
        """
        codes = []
        for category in categories:
            value_against_category = self.ANALYTICS_CATEGORY_CODES_DICT.get(category.lower())
            if value_against_category:
                codes.append(value_against_category)
        return ','.join(codes)

    def get_category_color_code(self, category):
        """
        Gets category color code
        """
        if not category:
            return ""
        elif category == self.category_API_Name_Body:
            return self.Color_Body
        elif category == self.category_API_Name_Leisure:
            return self.Color_Leisure
        elif category == self.category_API_Name_Restaurants_and_Bars:
            return self.Color_RestaurantsAndBars
        elif category == self.category_API_Name_Retail:
            return self.Color_Retail
        elif category == self.category_API_Name_Services:
            return self.Color_Services
        elif category == self.category_API_Name_Travel:
            return self.Color_Travel
        return ""
