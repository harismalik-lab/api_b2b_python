"""
Offer Manager Repository
"""
from common_white_label.common_helpers import OfferManager
from repositories_white_label.base_repo import BaseRepository
from repositories_white_label.offer_wl_active_repo import OfferWlRepository
from repositories_white_label.translations_repo import TranslationManager
from repositories_white_label.wl_categories_repo import CategoriesRepositoryWl
from repositories_white_label.wl_company_repo import WLCompany


class WlOfferManagerRepository(BaseRepository):
    """
    White label offer manager repository
    """

    Image_Type_Voucher_Type = 1
    Image_Type_Voucher_Restriction = 2
    Image_Type_Party_Size = 3

    @classmethod
    def get_ping_section(cls):
        """
        Returns ping section dict
        :rtype: dict
        """
        return {
            'is_sender_info': False,
            'is_recipient_info': False,
            'can_user_ping': False,
            'can_user_receive_ping': False,
            'total_quota_to_send_pings': 0,
            'total_quota_to_receive_pings': 0,
            'total_pings_sent': 0,
            'total_pings_received': 0,
            'message': '',
            'background_color': ''
        }

    def get_voucher_restrictions(self):
        """
        Gets voucher restrictions
        :rtype: dict
        """
        return {
            "1": "Valid for Dine-in and Take-Away",
            "2": "Excluding Friday Brunch",
            "3": "Advance Booking is Required",
            "4": "Delivery only",
            "5": "Dine-in only",
            "6": "Excluding Brunch",
            "7": "Food only",
            "8": "No Corkage Allowed",
            "9": "Not Valid on Delivery",
            "10": "Not Valid on Public Holidays",
            "11": "Rack Rate Applies",
            # Must comply with applicable local laws
            "12": "To redeem you must be of legal drinking age and non-Muslim",
            "13": "Valid on All Packages",
            "14": "Valid on Delivery",
            "15": "Must comply with applicable local laws",
            "16": "Rate Includes Breakfast",
            "17": "Rate Room Only",
            "18": "Based on Best Available Rates",
            "19": "All Inclusive",
        }

    def get_voucher_restriction_id(self, voucher_restriction):
        """
        Gets voucher restriction id
        :param str voucher_restriction: Voucher Restriction
        :rtype: int
        """
        voucher_restrictions = self.get_voucher_restrictions()
        for voucher_restriction_id in voucher_restrictions:   # $voucher_restriction_id => $_voucher_restriction
            if voucher_restriction_id.lower() == voucher_restriction.lower():
                return voucher_restriction_id
        return 0

    def get_voucher_restriction_details(self, voucher_restriction_id, offer_category, locale='en'):
        """
        Gets voucher restriction details
        :param str voucher_restriction_id: Voucher Restriction Id
        :param str offer_category: Offer Category
        :param str locale: Language
        :rtype: str
        """
        _voucher_restrictions = self.get_voucher_restrictions()
        _voucher_restriction_key = ''
        translation_repo = TranslationManager()

        if _voucher_restrictions[str(voucher_restriction_id)]:
            if voucher_restriction_id == 1:
                _voucher_restriction_key = translation_repo.voucher_restriction_1
            if voucher_restriction_id == 2:
                _voucher_restriction_key = translation_repo.voucher_restriction_2
            if voucher_restriction_id == 3:
                _voucher_restriction_key = translation_repo.voucher_restriction_3
            if voucher_restriction_id == 4:
                _voucher_restriction_key = translation_repo.voucher_restriction_4
            if voucher_restriction_id == 5:
                _voucher_restriction_key = translation_repo.voucher_restriction_5
            if voucher_restriction_id == 6:
                _voucher_restriction_key = translation_repo.voucher_restriction_6
            if voucher_restriction_id == 7:
                _voucher_restriction_key = translation_repo.voucher_restriction_7
            if voucher_restriction_id == 8:
                _voucher_restriction_key = translation_repo.voucher_restriction_8
            if voucher_restriction_id == 9:
                _voucher_restriction_key = translation_repo.voucher_restriction_9
            if voucher_restriction_id == 10:
                _voucher_restriction_key = translation_repo.voucher_restriction_10
            if voucher_restriction_id == 11:
                _voucher_restriction_key = translation_repo.voucher_restriction_11
            if voucher_restriction_id == 12:
                _voucher_restriction_key = translation_repo.voucher_restriction_12
            if voucher_restriction_id == 13:
                _voucher_restriction_key = translation_repo.voucher_restriction_13
            if voucher_restriction_id == 14:
                _voucher_restriction_key = translation_repo.voucher_restriction_14

            if _voucher_restrictions[str(voucher_restriction_id)]:
                voucher_restriction_title = translation_repo.get_translation(_voucher_restriction_key, locale)
                if voucher_restriction_title:
                    return self.get_offer_sub_detail_object(
                        voucher_restriction_id,
                        self.get_image_url(
                            self.Image_Type_Voucher_Restriction,
                            offer_category,
                            0,
                            False,
                            voucher_restriction_id
                        ),
                        voucher_restriction_title, ''
                    )

        return None

    def get_offer_sub_detail_object(self, id='', image='', title='', color=''):
        """
        Gets offer sub detail object
        :param str id: Id
        :param str image: Image
        :param str title: Title
        :param str color: Color
        :rtype: dict
        """
        return {
            'id': str(id),
            'image': image,
            'title': title,
            'color': color
        }

    def get_image_url(self, image_type, category, voucher_type_id='', replace_241_type_with_141=False,
                      voucher_restriction_id='', is_monthly=False, company=''):
        """
        Gets image url
        :param int image_type: Image Type
        :param str category: Category
        :param str voucher_type_id: Voucher Type Id
        :param bool replace_241_type_with_141: Replace 241 Type With 141
        :param str voucher_restriction_id: Voucher Restriction ID
        :param bool is_monthly: Is Monthly
        :param str company: White label client
        :rtype: str
        """
        image_url = ""
        _category = None
        voucher_image_prefix = ""
        if category:
            if category == CategoriesRepositoryWl.category_API_Name_Body:
                _category = "body"

            if category == CategoriesRepositoryWl.category_API_Name_Leisure:
                _category = "leisure"

            if category == CategoriesRepositoryWl.category_API_Name_Restaurants_and_Bars:
                _category = "food"

            if category == CategoriesRepositoryWl.category_API_Name_Retail:
                _category = "retail"

            if category == CategoriesRepositoryWl.category_API_Name_Services:
                _category = "services"

            if category == CategoriesRepositoryWl.category_API_Name_Travel:
                _category = "travel"
        if _category:
            end_format = ""
            if voucher_type_id == OfferWlRepository.OFFER_TYPE_VALUE_Buy_One_Get_One_Free:
                end_format = "_1_for_1"
            if image_type:
                if image_type == self.Image_Type_Voucher_Type:
                    if is_monthly:
                        if replace_241_type_with_141:
                            image_url = "{}{}_{}{}.png".format(
                                OfferWlRepository.Voucher_Type_Image_URL_Prefix,
                                "monthly",
                                voucher_type_id,
                                end_format
                            )
                        else:
                            image_url = "{}{}_{}.png".format(
                                OfferWlRepository.Voucher_Type_Image_URL_Prefix,
                                "monthly",
                                voucher_type_id
                            )
                    else:
                        if (
                            company == WLCompany.COMPANY_CODE_ENTERTAINER_HSBC and
                            _category.lower() == CategoriesRepositoryWl.category_API_Name_Services.lower()
                        ):
                            voucher_image_prefix = OfferWlRepository.Voucher_Type_Image_URL_Prefix_HS
                        else:
                            if (
                                company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS and
                                    (
                                        _category.lower() == CategoriesRepositoryWl.category_API_Name_Services or
                                        _category.lower() == CategoriesRepositoryWl.Analytics_Category_Code_Travel
                                    )
                            ):
                                voucher_image_prefix = OfferWlRepository.Voucher_Restriction_Image_URL_Prefix
                            else:
                                voucher_image_prefix = OfferWlRepository.Voucher_Type_Image_URL_Prefix

                        if replace_241_type_with_141:
                            image_url = "{}{}_{}{}.png".format(
                                voucher_image_prefix,
                                _category,
                                voucher_type_id,
                                end_format
                            )
                        else:
                            image_url = "{}{}_{}.png".format(
                                voucher_image_prefix,
                                _category,
                                voucher_type_id
                            )

                if image_type == self.Image_Type_Voucher_Restriction:
                    image_url_prefix = self.get_image_url_prefix(company, image_type, category)
                    image_url = "{}{}_{}.png".format(
                        image_url_prefix,
                        _category,
                        voucher_restriction_id
                    )

                if image_type == self.Image_Type_Party_Size:
                    image_url_prefix = self.get_image_url_prefix(company, image_type, category)
                    image_url = "{}{}{}.png".format(
                        image_url_prefix,
                        "party_size_",
                        _category
                    )
        return image_url

    def get_image_url_prefix(self, company, image_type, category=''):
        """
        Gets image url prefix
        :param str company: Company
        :param str image_type: Image Type
        :rtype: str
        """
        image_url_prefix = ""
        if image_type == self.Image_Type_Voucher_Type:
            return OfferWlRepository.Voucher_Type_Image_URL_Prefix
        if image_type == self.Image_Type_Voucher_Restriction:
            image_url_prefix = OfferWlRepository.Voucher_Restriction_Image_URL_Prefix
            if company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
                image_url_prefix = OfferWlRepository.Voucher_Restriction_Image_URL_Prefix_GEMS
        if image_type == self.Image_Type_Party_Size:
            image_url_prefix = OfferWlRepository.Party_Size_Image_URL_Prefix
            if company == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
                image_url_prefix = OfferWlRepository.Party_Size_Image_URL_Prefix_GEMS
        return image_url_prefix

    def get_voucher_types(self):
        """
        Gets voucher types
        :rtype: dict
        """
        voucher_types = {
            '1': 'Buy One Get One',
            '2': 'PERCENTAGE OFF',
            '3': 'GIFT',
            '4': 'PACKAGE',
            '6': 'SPEND THIS GET THIS'
        }
        return voucher_types

    def get_voucher_type_details(
            self, voucher_type, offer_category, locale='en', replace_241_type_with_141=False,
            is_monthly=False, company=''
    ):
        """
        Returns voucher type details
        :param int|str voucher_type: Voucher type
        :param str offer_category: Offer Category
        :param str locale: Locale
        :param bool replace_241_type_with_141: Flag to replace 2 for 1 offers with 1 for 1
        :param bool is_monthly: Flag for monthly offers
        :rtype: dict
        """
        if company.lower() == WLCompany.COMPANY_CODE_HCS_Singapure:
            replace_241_type_with_141 = True
        voucher_types = self.get_voucher_types()
        voucher_type_key = ''
        translation_repo = TranslationManager()

        if voucher_types.get(str(voucher_type)):
            if voucher_type == 1:
                if replace_241_type_with_141:
                    voucher_type_key = translation_repo.voucher_type_141
                else:
                    voucher_type_key = translation_repo.voucher_type_1
            elif voucher_type == 2:
                voucher_type_key = translation_repo.voucher_type_2
            elif voucher_type == 3:
                voucher_type_key = translation_repo.voucher_type_3
            elif voucher_type == 4:
                voucher_type_key = translation_repo.voucher_type_4
            elif voucher_type == 5:
                voucher_type_key = translation_repo.voucher_type_5
            elif voucher_type == 6:
                voucher_type_key = translation_repo.voucher_type_6

            voucher_type_title = translation_repo.get_translation(voucher_type_key, locale)
            if voucher_type_title:
                return self.get_offer_sub_detail_object(
                    voucher_type,
                    self.get_image_url(
                        self.Image_Type_Voucher_Type,
                        offer_category,
                        voucher_type,
                        replace_241_type_with_141,
                        '',
                        is_monthly,
                        company
                    ),
                    voucher_type_title,
                    ''
                )

    def get_message_for_offer_type(self, locale='en', offer_type=0, spend=0, reward=0,
                                   discount_off_or_percentage_off=0):
        """
        Gets the offer message for the offer type
        :param str locale: locality of the user
        :param str offer_type: type of the offer
        :param str spend: spends of the user
        :param str reward: rewards of the user till now
        :param str discount_off_or_percentage_off: discount of the user availed
        :rtype: str
        """
        if not offer_type or not offer_type > 0:
            offer_type = OfferWlRepository.OFFER_TYPE_VALUE_DEFAULT

        offer_type = int(offer_type)
        message = ""
        self.translation_manager = TranslationManager()
        if offer_type == OfferWlRepository.OFFER_TYPE_VALUE_DEFAULT:
            message = self.translation_manager.get_translation(
                self.translation_manager.voucher_type_1,
                locale
            )
        if offer_type == OfferWlRepository.OFFER_TYPE_VALUE_Buy_One_Get_One_Free:
            message = self.translation_manager.get_translation(
                self.translation_manager.voucher_type_1,
                locale
            )
        if offer_type == OfferWlRepository.OFFER_TYPE_VALUE_PERCENTAGE_OFF:
            message = self.translation_manager.get_translation(
                self.translation_manager.voucher_type_2,
                locale
            )
            message = message.replace('_percentage_value_', str(discount_off_or_percentage_off))
        if offer_type == OfferWlRepository.OFFER_TYPE_VALUE_GIFT:
            message = self.translation_manager.get_translation(
                self.translation_manager.voucher_type_3,
                locale
            )
        if offer_type == OfferWlRepository.OFFER_TYPE_VALUE_PACKAGE:
            message = self.translation_manager.get_translation(
                self.translation_manager.voucher_type_4,
                locale
            )
        if offer_type == OfferWlRepository.OFFER_TYPE_VALUE_FIX_PRICE_OFF:
            message = self.translation_manager.get_translation(
                self.translation_manager.voucher_type_5,
                locale
            )
            message = message.replace('_discount_value_', str(discount_off_or_percentage_off))
        if offer_type == OfferWlRepository.OFFER_TYPE_VALUE_SPEND_THIS_GET_THIS:
            message = self.translation_manager.get_translation(
                self.translation_manager.voucher_type_6,
                locale
            )
            message = message.replace('_spend_value_', str(spend))
            message = message.replace('_reward_value_', str(reward))
        return message

    def get_category_color_code(self, category, categories):
        """
        Gets category color code
        :param str category: Category
        :param list categories: Categories
        :rtype: list
        """
        for cat in categories:
            if category == cat['api_name']:
                return cat['color_code']
        return ''

    def sort_categories(self, categories):
        """
        Sorts categories
        :param list categories: Categories
        :rtype: list
        """
        Categories = CategoriesRepositoryWl()
        categories_array = []

        if Categories.category_API_Name_Restaurants_and_Bars in categories:
            categories_array.append(Categories.category_API_Name_Restaurants_and_Bars)

        if Categories.category_API_Name_Body in categories:
            categories_array.append(Categories.category_API_Name_Body)

        if Categories.category_API_Name_Leisure in categories:
            categories_array.append(Categories.category_API_Name_Leisure)

        if Categories.category_API_Name_Retail in categories:
            categories_array.append(Categories.category_API_Name_Retail)

        if Categories.category_API_Name_Services in categories:
            categories_array.append(Categories.category_API_Name_Services)

        if Categories.category_API_Name_Travel in categories:
            categories_array.append(Categories.category_API_Name_Travel)

        return categories_array

    def get_category_codes_for_analytics(self, categories):
        """
        Gets category codes for analytics
        :param list categories: Categories
        :rtype: str
        """
        categories_analytics = []
        if not categories:
            return categories_analytics
        for category in categories:
            analytics_category_code = OfferManager().get_analytics_category_code(category)
            if analytics_category_code:
                categories_analytics.append(analytics_category_code)
        return ",".join(categories_analytics)

    def parse_cuisines(self, cuisines):
        """
        Parse cuisines
        :param str cuisines: cuisines
        :rtype: list
        """
        cuisines_processed = []
        try:
            cuisines = cuisines.split(';')
            for cuisine in cuisines:
                if cuisine:
                    cuisines_processed.append(cuisine)
        except AttributeError:
            pass
        return cuisines_processed

    def process_categories(self, categories):
        """
        Processes Categories
        :param str categories: Categories
        :rtype: list
        """
        categories_processed = []
        try:
            categories = categories.split(';')
            for category in categories:
                if category:
                    categories_processed.append(category)
        except AttributeError:
            pass
        categories_processed = self.sort_categories(categories_processed)
        return categories_processed

    def parse_categories(self, categories):
        return self.process_categories(categories)
