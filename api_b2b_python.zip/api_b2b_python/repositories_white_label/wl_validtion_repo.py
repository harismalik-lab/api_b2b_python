"""
WL Validation Repository
"""
from collections import OrderedDict
from itertools import repeat

from common_white_label.common_helpers import get_current_date_time
from repositories_white_label.base_repo import BaseRepository
from repositories_white_label.wl_company_repo import WLCompany
from wrapper_white_labels.sql_dal import SqlDal


class WlValidationRepository(BaseRepository):
    INVALID_KEY_CUSTOMER_DOES_NOT_EXISTS = "00"
    INVALID_KEY_CUSTOMER_EXISTS = "01"
    VALID_KEY_CUSTOMER_DOES_NOT_EXISTS = "10"
    VALID_KEY_CUSTOMER_EXISTS = "11"
    FAQS_WEB_URL = "https://www.theentertainerme.com/{company}-FAQs"

    INACTIVE_KEY = -1
    INVALID_KEY = 0
    UNUSED_VALID_KEY = 1
    ALREADY_ACTIVATED_VALID_KEY = 2
    KEY_NOT_EXISTS = 3
    VALID_KEY = 4

    SECOND_GROUP = 2

    def get_user_groups(self, company, customer_id):
        """
        Gets the user Groups
        :param str company: Company
        :param int customer_id: Customer ID
        :rtype: list
        """
        sql_dal = SqlDal()
        sql_dal.select(['user_group', 'COUNT(user_group) as quantity'])
        sql_dal.from_(['wlvalidation'])
        ordered_where_clause = OrderedDict()
        ordered_where_clause['customer_id'] = customer_id
        ordered_where_clause['wl_company'] = company
        ordered_where_clause['active'] = True
        sql_dal.where(ordered_where_clause)
        sql_dal.group_by(['user_group'])
        results = sql_dal.get(default=[])
        user_groups = []
        for result in results:
            # append user_group in user_groups list
            user_groups.extend(repeat(result.get('user_group'), result.get('quantity', 0)))
        return user_groups

    def is_key_exists(self, company, wl_key):
        """
        Checks if key exists
        :param str company: Company name.
        :param str wl_key: key.
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select(['*'])
        sql_dal.from_(['wlvalidation'])
        sql_dal.where({'wl_key': wl_key, 'wl_company': company})
        return sql_dal.get_one(default={})

    def is_key_valid(self, wl_key, company):
        """
        Checks if key is valid.
        :param str wl_key: Key.
        :param str company: Company name.
        :rtype: bool
        """
        sql_dal = SqlDal()
        sql_dal.select(['id'])
        sql_dal.from_(['wlvalidation'])
        sql_dal.where({'wl_key': wl_key, 'wl_company': company, 'active': True})
        result = sql_dal.get_one(default={})
        return True if result else False

    def get_validation_info_mce(self, company, email, wl_key):
        """
        Gets the validation info of master card entertainer
        :param str company: Company name.
        :param str email: Email.
        :param str wl_key: key
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select(["CASE WHEN active <> 0 THEN 'true' ELSE 'false' END active", "wl_key"])
        sql_dal.from_(['wlvalidation'])
        sql_dal.where({'email': email, 'wl_company': company, 'wl_key': wl_key})
        return sql_dal.get_one(default={})

    def update_customer_validation(self, company, email, customer_id):
        """
        Updates the validation for customer.
        :param str company: Company
        :param str email: Email
        :param int customer_id: Customer ID
        :rtype: bool
        """
        try:
            sql_dal = SqlDal()
            sql_dal.where({'email': email, 'wl_company': company})
            sql_dal.update('wlvalidation', changes={'customer_id': customer_id})
            return True
        except:
            return False

    def get_user_group(self, company, customer_id):
        """
        Gets the user group
        :param str company: Company
        :param int customer_id: Customer ID
        :rtype: int
        """
        user_group = 1
        user_groups = self.get_user_groups(company, customer_id)
        if user_groups:
            user_group = user_groups[len(user_groups) - 1]
        return user_group

    def add_new_key(self, wl_key, company, customer_id, email, user_group_id, is_existing_user=0):
        """
        Adds a new key.
        :param str wl_key: Key
        :param str company: Company
        :param int customer_id: Customer ID
        :param str email: Email
        :param int user_group_id: User Group ID
        :param int is_existing_user: User exists or not
        :rtype: int|bool
        """
        sql_dal = SqlDal()
        columns = [
            'wl_key', 'wl_company', 'email', 'customer_id', 'activation_date',
            'isused', 'active', 'existing', 'user_group'
        ]
        values = [
            wl_key, company, email, customer_id, get_current_date_time(), 1, 1, 0, user_group_id
        ]
        try:
            last_row_id = sql_dal.insert(
                'wlvalidation',
                columns=columns,
                values=values,
                last_row_id=True
            )
            return last_row_id
        except Exception:
            return False

    def validate_key(self, wl_key, company='', email=''):
        """
        Checks the validation of key.
        :param str | int wl_key: Key
        :param str company: Company
        :param str email: Email
        :rtype: int
        """
        sql_dal = SqlDal()
        validation_result = self.INVALID_KEY
        sql_dal.select(['isused', 'email'])
        sql_dal.from_(['wlvalidation'])
        sql_dal.where({'wl_key': wl_key, 'wl_company': company, 'active': True})
        result = sql_dal.get_one(default={})
        if result:
            if not result.get('isused', False):
                validation_result = self.UNUSED_VALID_KEY
            elif result.get('email').lower() == email.lower():
                validation_result = self.ALREADY_ACTIVATED_VALID_KEY
        return validation_result

    def assign_key_to_customer(self, wl_key, company, email, is_customer_exists, customer_id):
        """
        Assigns a key to customer.
        :param str | int wl_key: Key
        :param str company: Company
        :param int customer_id: Customer id
        :param str email: Email
        :param int is_customer_exists: User exists or not
        :rtype: int
        """
        try:
            sql_dal = SqlDal()
            changes = {
                'email': email,
                'isused': True,
                'activation_date': get_current_date_time(),
                'existing': is_customer_exists,
                'customer_id': customer_id if is_customer_exists else None
            }
            sql_dal.where({'wl_key': wl_key, 'wl_company': company})
            sql_dal.update('wlvalidation', changes=changes)
            return True
        except Exception:
            return False

    def get_user_group_id_by_key(self, wl_key, company=''):
        """
        Gets the user's group id by key.
        :param str | int wl_key: Key
        :param str company: Company
        :rtype: int
        """
        sql_dal = SqlDal()
        sql_dal.select(['user_group'])
        sql_dal.from_(['wlvalidation'])
        sql_dal.where({'wl_key': wl_key, 'wl_company': company})
        return sql_dal.get_one(default={}).get('user_group', 1)

    def is_key_valid_and_not_used(self, wl_key, company='', email=''):
        """
        Checks if key is a valid not previously used.
        :param str wl_key: Key
        :param str company: Company
        :param str email: Email
        :rtype: bool
        """
        sql_dal = SqlDal()
        sql_dal.select(['id'])
        sql_dal.from_(['wlvalidation'])
        sql_dal.where({
            'wl_key': wl_key,
            'wl_company': company,
            'active': True,
            'email': email
        })
        result = sql_dal.get_one(default={})
        return True if result else False

    def get_number_of_valid_keys(self, company, email):
        """
        Gets the number of valid keys.
        :param str company: Company
        :param str email: Email
        :rtype: int
        """
        sql_dal = SqlDal()
        sql_dal.select(['count(wl_key) as number_of_keys'])
        sql_dal.from_(['wlvalidation'])
        sql_dal.where({
            'email': email,
            'wl_company': company,
            'active': True,
            'isused': True
        })
        result = sql_dal.get_one(default={})
        return int(result.get('number_of_keys', 0))

    def validate_key_mce(self, wl_key, email):
        """
        Validates a mce key.
        :param str wl_key: Key
        :param str email: Email
        :rtype: int
        """
        sql_dal = SqlDal()
        sql_dal.select(['active'])
        sql_dal.from_(['wlvalidation'])
        sql_dal.where({
            'wl_key': wl_key,
            'wl_company': WLCompany.COMPANY_CODE_MASTER_CARDS,
            'email': email,
            'active': True
        })
        result = sql_dal.get_one(default={})
        if result:
            return self.ALREADY_ACTIVATED_VALID_KEY
        return self.KEY_NOT_EXISTS

    def get_number_of_valid_keys_mce(self, email):
        """
        Gets the valid mce keys.
        :param str email: Email
        :rtype: int
        """
        sql_dal = SqlDal()
        sql_dal.select(['count(wl_key) as number_of_keys'])
        sql_dal.from_(['wlvalidation'])
        sql_dal.where({
            'wl_company': WLCompany.COMPANY_CODE_MASTER_CARDS,
            'email': email,
            'active': True
        })
        return sql_dal.get_one(default={}).get('number_of_keys', 0)

    def get_validation_object_mce(self, email):
        """
        Gets the mce validation.
        :param str email: Email
        :rtype: dict
        """
        sql_dal = SqlDal()
        sql_dal.select(['*'])
        sql_dal.from_(['wlvalidation'])
        sql_dal.where({
            'wl_company': WLCompany.COMPANY_CODE_MASTER_CARDS,
            'email': email,
            'active': True
        })
        return sql_dal.get_one(default={})

    def get_user_group_mce(self, _bin):
        """
        Gets mce user group.
        :param str _bin: Bin
        :rtype: int
        """
        sql_dal = SqlDal()
        sql_dal.select(['user_group'])
        sql_dal.from_(['wl_bin_codes'])
        sql_dal.where({'wl_company': WLCompany.COMPANY_CODE_MASTER_CARDS, 'bin': _bin})
        return sql_dal.get_one(default={}).get('user_group', False)

    def assign_key_to_customer_pre_activated(self, wl_key, company, email, is_customer_exists, customer_id):
        """
        Assigns a pre activated key to customer.
        :param str wl_key: Key
        :param str company: Company
        :param int customer_id: Id of customer
        :param str email: Email
        :param int is_customer_exists: User exists or not
        :rtype bool
        """
        try:
            sql_dal = SqlDal()
            changes = {
                'email': email,
                'isused': True,
                'activation_date': get_current_date_time(),
                'existing': is_customer_exists,
                'customer_id': customer_id if is_customer_exists else None,
            }
            sql_dal.where({'wl_key': wl_key, 'wl_company': company})
            sql_dal.update('wlvalidation', changes)
            return True
        except Exception:
            return False

    def validate_key_pre_activated(self, wl_key, company):
        """
        Validates a pre activated key.
        :param str wl_key: Key
        :param str company: Company
        :rtype: int
        """
        sql_dal = SqlDal()
        sql_dal.select(['isused', 'email'])
        sql_dal.from_(['wlvalidation'])
        sql_dal.where({
            'wl_key': wl_key,
            'wl_company': company,
            'active': True
        })
        result = sql_dal.get_one(default={})
        if result:
            return self.VALID_KEY
        return self.INVALID_KEY

    def expire_old_keys(self, company, email, wl_key):
        """
        Expires old keys.
        :param str company: Company
        :param str email: Email
        :param str wl_key: Key
        """
        try:
            sql_dal = SqlDal()
            changes = {
                'active': False,
                'deactivation_date': get_current_date_time(),
            }
            sql_dal.where({'wl_company': company, 'email': email})
            sql_dal.where_ne({'wl_key': wl_key})
            sql_dal.update('wlvalidation', changes)
        except Exception:
            return False

    def new_wl_validation_record(self, changes):
        """
        Inserts new entry in Db.
        :param changes: dictionary key value pair changes
        """
        if changes:
            try:
                sql_dal = SqlDal()
                columns = list(changes.keys())
                data = list(changes.values())
                sql_dal.insert('wlvalidation', columns=columns, values=data)
            except Exception:
                return False

    def get_number_of_valid_keys_old_user_groups_du(self, company, email):
        sql_dal = SqlDal()
        sql_dal.select(["count(wl_key) as number_of_keys"])
        sql_dal.from_('wlvalidation')
        sql_dal.where({'email': email, 'wl_company': company, 'active': True, 'isused': True})
        sql_dal.where_lt('user_group', 6, sql_safe=True)
        result = sql_dal.get_one(default={})
        number_of_keys = int(result.get('number_of_keys', 0))
        return number_of_keys

    def update_user_group(self, wl_key, company, email, user_group):
        sql_dal = SqlDal()
        sql_dal.where({'user_group': user_group, 'wl_key': wl_key, 'wl_company': company, 'email': email})
        changes = {'user_group': user_group}
        sql_dal.update('wlvalidation', changes)
        return True
