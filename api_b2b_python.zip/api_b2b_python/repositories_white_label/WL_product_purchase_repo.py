"""
WL Product Purchase Repository
"""
from common_white_label.common_helpers import get_current_date_time
from common_white_label.db import DEFAULT as ENTERTAINER_WEB
from repositories_white_label.base_repo import BaseRepository
from wrapper_white_labels.sql_dal import SqlDal


class WLProductPurchaseRepository(BaseRepository):
    """
    WL Product Purchase Repository
    """
    def add_product_purchase(
            self, company, msisdn, platform, key, user_id, custom_product_id, du_product_id, du_response_code,
            transaction_id, purchase_id, billed_price_aed=0
    ):
        """
        Add product purchase in db
        :param company: White label Company name
        :param msisdn: msisdn
        :param platform: platform os
        :param key: wl key
        :param user_id: id of the user
        :param custom_product_id: custom product id
        :param du_product_id: du product id
        :param du_response_code: response code of du
        :param transaction_id: transaction id
        :param purchase_id: purchase id
        :param billed_price_aed: billed price in aed
        :return: product_purchase_id that are inserted
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        current_date = get_current_date_time()
        product_purchase = {
            'user_id': user_id,
            'company': company,
            'msisdn': msisdn,
            'platform': platform,
            'wl_key': key,
            'custom_product_id': custom_product_id,
            'du_product_id': du_product_id,
            'du_response_code': du_response_code,
            'billed_price_aed': billed_price_aed,
            'transaction_id': transaction_id,
            'transaction_date': current_date,
            'purchase_id': purchase_id
        }

        try:
            product_purchase_id = sql_dal.insert(
                "purchase",
                "wl_product_purchases",
                columns=list(product_purchase.keys()),
                values=list(product_purchase.values()),
                last_row_id=True
            )
            return product_purchase_id
        except Exception:
            return False

    def add_product_purchase_log(
            self, company, msisdn, platform, key, user_id, custom_product_id, du_product_id, du_response_code,
            is_succeeded, msdp_response, purchase_cycle_state, purchase_cycle_message, billed_price_aed=0
    ):
        """
        Adding product purchase log in db
        :param company: Wl Company name
        :param msisdn: msisdn
        :param platform: platform os
        :param key: Wl key
        :param user_id: id of the user
        :param custom_product_id: custom product id
        :param du_product_id: du product id
        :param du_response_code: response code of du
        :param is_succeeded: is_succeeded flag
        :param msdp_response: msdp response
        :param purchase_cycle_state: purchase cycle state
        :param purchase_cycle_message: purchase cycle message
        :param billed_price_aed: billed price in aed
        :return: product_purchase_log_id
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        current_date = get_current_date_time()
        product_purchase_log = {
            'user_id': user_id,
            'company': company,
            'msisdn': msisdn,
            'platform': platform,
            'wl_key': key,
            'custom_product_id': custom_product_id,
            'du_product_id': du_product_id,
            'du_response_code': du_response_code,
            'billed_price_aed': billed_price_aed,
            'transaction_date': current_date,
            'is_succeeded': is_succeeded,
            'msdp_response': msdp_response,
            'purchase_cycle_state': purchase_cycle_state,
            'purchase_cycle_message': purchase_cycle_message
        }

        try:
            product_purchase_log_id = sql_dal.insert(
                "purchase",
                "wl_product_purchases_log",
                columns=list(product_purchase_log.keys()),
                values=list(product_purchase_log.values()),
                last_row_id=True
            )
            return product_purchase_log_id
        except Exception:
            return False

    def update_purchase_log(
            self, log_id, is_succeeded, key, du_response_code, msdp_response, transaction_id, purchase_id,
            purchase_cycle_state, purchase_cycle_message, product_purchase_id=0
    ):
        """
        Update product purchase log in db
        :param log_id: Log id
        :param is_succeeded: is succeeded flag
        :param key: wl key
        :param du_response_code: response code of du
        :param msdp_response: msdp response
        :param transaction_id: transaction id
        :param purchase_id: purchase id
        :param purchase_cycle_state: purchase cycle state
        :param purchase_cycle_message: purchase cycle message
        :param product_purchase_id: product purchase id
        :return: Boolean
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        changes = {
            'msdp_response': msdp_response,
            'is_succeeded': is_succeeded,
            'wl_key': key,
            'du_response_code': du_response_code,
            'transaction_id': transaction_id,
            'purchase_id': purchase_id,
            'purchase_cycle_state': purchase_cycle_state,
            'purchase_cycle_message': purchase_cycle_message,
            'product_purchase_id': product_purchase_id
        }
        sql_dal.where({'id': log_id})
        update = sql_dal.update("wl_product_purchase_log", changes=changes)
        return update
