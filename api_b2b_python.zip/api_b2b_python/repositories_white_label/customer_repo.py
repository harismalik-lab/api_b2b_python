"""
Customer Repository
"""
import datetime
import json
from collections import OrderedDict
from math import floor

from dateutil.parser import parse
from flask import current_app

from common_white_label.common_helpers import AwsS3Manager, CommonHelpers, get_current_date_time
from common_white_label.db import CONSOLIDATION
from common_white_label.db import DEFAULT as ENTERTAINER_WEB
from common_white_label.db import get_db_settings_from_app
from common_white_label.security import Security
from repositories_white_label.base_repo import BaseRepository
from repositories_white_label.exchange_rates_repo import ExchangeRatesRepositoryWL
from repositories_white_label.redemption_repo import RedemptionRepositoryWhiteLabel
from repositories_white_label.session_repo import SessionRepositoryWhiteLabel
from repositories_white_label.wl_company_repo import WLCompany
from repositories_white_label.wl_product_repo import WLProductRepository
from repositories_white_label.wl_send_email_repository import WlSendEmailsRepository
from repositories_white_label.wl_user_group_repo import WlUserGroup
from repositories_white_label.wl_validtion_repo import WlValidationRepository
from wrapper_white_labels.sql_dal import SqlDal


class CustomerProfileWhiteLabel(BaseRepository):
    DUMMY_PASSWORD_STRING = 'e@1r#p!u2.i'
    TRIAL = 1
    MEMBER = 2

    ONBOARDING_NOT_STARTED = 0
    ONBOARDING_INPROGRESS = 1
    ONBOARDING_FINISHED = 2

    MEMBERSTATUS_PROSPTECT = 1  # New-user from app might be from web and does not own any digital products.
    MEMBERSTATUS_MEMBER = 2  # If user own products.
    MEMBERSTATUS_ONBOARDING = 3  # New-user start using mobile apps.
    MEMBERSTATUS_REPROSPECT = 4  # When user's membership ends and its ready to target again.

    Token_Expiry_In_Hours = 72

    USER_NOT_EXIST = "User does not exist with this customer id"
    CAN_NOT_APPLY_KEY = "Sorry! You can’t extend your trial any further."
    USER_ALREADY_EXIST = "A customer with this email address exists."
    EMAIL_AVAILABLE = "Email available."
    EMAIL_VERIFIED = "Email verified."
    PENDING_VERIFICATION = "Looks like your Email verification is still pending. Please Verify to continue."
    NO_PASSWORD_FOUND = "no password available"
    PASSWORD_AVAILABLE = 'password available'
    NO_VALID_OPTION = 'no valid option passed'
    INVALID_EMAIL = 'Invalid email.'
    VERIFY_YOUR_EMAIL = "Verify your email"

    Status_Frozen = 11
    Status_Blacklisted = 12
    Status_Temporarily_Whitelisted = 13

    TRAIL_REDEMPTIONS_LIMIT = 1
    ONBOARDING_LIMIT = 1

    TRIAL_GROUP_ID = 1
    MEMBER_GROUP_ID = 2
    TRIAL_DAYS = 14

    CURRENCY_ID = 45
    CURRENCY = 'USD'

    MEMBERSHIP_EXPIRAION_DATE_MAX = '02 JAN {year}'.format(year=datetime.datetime.now().year + 1)
    ALLOWED_NUMBER_OF_DEVICES = 20
    MAX_OUTLETS = 60

    DIGITAL_TRAVEL_COMPLEMENTARY_PRODUCT = ""

    CUSTOMER_ORDER_SUCCESS = 2

    VERIFICATION_STATE_NOT_STARTED = 0
    VERIFICATION_STATE_STARTED = 1
    VERIFICATION_STATE_PHONE_VERIFIED = 2
    VERIFICATION_STATE_PHONE_NOT_VERIFIED_BUT_DEMOGRAPHIC_UPDATED = 3
    VERIFICATION_STATE_VERIFICATION_COMPLETED = 4

    STATUS_FROZEN = 11
    STATUS_BLACKLISTED = 12
    STATUS_TEMPORARILY_WHITELISTED = 13

    TABS_ALL_OFFERS_EN = "ALL OFFERS"
    TABS_ALL_OFFERS_AR = " كافة العروض"
    TABS_ALL_OFFERS_EL = "ΟΛΕΣ ΟΙ ΠΡΟΣΦΟΡΕΣ"

    TABS_MONTHLY_EN = "MONTHLY"
    TABS_MONTHLY_AR = " العروض الشهرية"
    TABS_MONTHLY_EL = "Μηνιαίες"

    TABS_NEW_EN = "NEW"
    TABS_NEW_AR = " العروض الجديدة"
    TABS_NEW_EL = "ΝΕΕΣ ΠΡΟΣΦΟΡΕΣ"

    TABS_ALL_OFFERS_REDEEMABILITY = "redeemable_reusable"
    TABS_MONTHLY_REDEEMABILITY = "reusable"
    TABS_NEW_REDEEMABILITY = "redeemable_reusable"

    TABS_ALL_OFFERS_FILTER_BY_TYPE = "NIL"
    TABS_MONTHLY_FILTER_BY_TYPE = "2"
    TABS_NEW_FILTER_BY_TYPE = "4"

    HAPPY_BIRTHDAY_START_RANGE_DAYS = -8
    HAPPY_BIRTHDAY_END_RANGE_DAYS = 21

    EGO_NOT_ELIGIBLE = '0'
    EGO_ELIGIBLE = '1'
    EGO_AVAILED = '2'
    EGO_NOT_AVAILED = '3'

    customer_group = 1

    def is_demographics_updated(self, customer_id):
        sql_dal = SqlDal(connection=CONSOLIDATION)
        sql_dal.select(["gender", "nationality", "birthdate"])
        sql_dal.from_(['ent_customer_profile'])
        sql_dal.where({"user_id": customer_id})
        result = sql_dal.get_one(default={})
        if result:
            gender = result.get('gender')
            nationality = result.get('nationality')
            birthdate = result.get('birthdate')
            if gender and nationality and birthdate:
                return 1
        return 0

    def insert_customer_language(self, customer_id, session_id, language, company):
        """
        Inserts the customer language in database
        :param customer_id: customer id
        :param session_id: session id
        :param language: language
        :param company: company name
        """
        try:
            sql_dal = SqlDal(connection=ENTERTAINER_WEB)
            columns = [
                'customer_id', 'session_id',
                'language', 'company', 'create_date',
            ]
            data = [
                customer_id, session_id, language, company,
                get_current_date_time()
            ]
            sql_dal.insert('customer_language', columns=columns, values=data)
        except Exception:
            return False

    def load_customer_profile_by_id(self, customer_id, hash_key='id'):
        """
        Load customer profile against provided customer id
        """
        customer_profile = {}
        if customer_id:
            sql_dal = SqlDal(connection=CONSOLIDATION)
            sql_dal.from_(['ent_customer_profile'])
            if isinstance(customer_id, list):
                sql_dal.where_in('user_id', customer_id)
                customer_profile = sql_dal.get(default=[])
                customer_profile = {profile[hash_key]: profile for profile in customer_profile}
            else:
                sql_dal.where('user_id', customer_id)
                customer_profile = sql_dal.get_one(default={})
        return customer_profile

    def get_user_profile_by_user_id(self, user_id, company):
        """
        Load customer profile by id
        :param customer_id: customer id
        :param company: white label client
        :return: customer profile
        """
        consolidation_db = get_db_settings_from_app(connection_name=CONSOLIDATION)['database']
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select([
            'c.user_id', 'us.email', 'c.firstname as first_name', 'c.lastname as last_name',
            'c.company as company', 'c.gender as gender', 'c.country_of_residence as country',
            'c.create_time as creation_date',
        ])
        sql_dal.from_(['{}.wl_user_custom_info as c'.format(consolidation_db)])
        sql_dal.inner_join('{}.user as us'.format(consolidation_db), 'c.user_id', 'us.id')
        sql_dal.where({'c.user_id': user_id})
        user = sql_dal.get_one(default={})
        if isinstance(user.get('creation_date'), datetime.datetime):
            user['creation_date'] = str(user.get('creation_date'))
        # redemption_repo = RedemptionRepositoryWhiteLabel()
        # user['redemptions_count'] = redemption_repo.find_redemptions_count_by_customer(
        #     customer_id=user_id,
        #     company=company
        # )
        return user

    def is_email_verified(self, user_id):
        """
        Returns True if users email is verified else False
        :param int user_id: User Id
        :rtype: bool
        """
        if user_id:
            sql_dal = SqlDal(connection=CONSOLIDATION)
            user = sql_dal.select().from_(['user AS u']).where({
                'u.id': user_id,
                'u.is_email_verified': 1
            }).get_count(default=0)
            if user:
                return True
        return False

    def get_customer_profile(self, customer_id):
        """
        Returns selected customer profile fields
        """
        if customer_id:
            sql_dal = SqlDal(connection=CONSOLIDATION)
            sql_dal.select(
                [
                    'cp.user_id as entity_id', 'cp.email', 'cp.member_group as group_id',
                    'cp.accepted_terms', 'cp.receive_email as do_not_email',
                    'COALESCE(cp.third_email_opt_out, "0") as third_do_not_email',
                    'cp.onboarding_status as using_trial', 'cp.is_used_trial as used_trial_membership',
                    'c.is_active as is_active', 'cp.membership_code', 'cp.age_bracket', 'cp.marital_status',
                    'cp.income_bracket', 'cp.mobile_phone', 'COALESCE(cp.nationality, "") as nationality',
                    'cp.city_of_residence', 'cp.country_of_residence', 'cp.education_level',
                    'cp.occupation_level', 'cp.currency', 'cp.lifestyle_preference',
                    'cp.firstname', 'cp.lastname', 'COALESCE(cp.gender, "") as gender',
                    'cp.membership_expiry as membership_expiration_date',
                    'cp.onboarding_startdate', 'cp.create_time as created_at', 'cp.update_time as updated_at',
                    'cp.new_member_group  as member_type', 'cp.onboarding_status',
                    'cp.onboarding_redemptions_count',
                    'COALESCE(cp.birthdate, "") as date_of_birth',
                    'COALESCE(cp.home_address, "") as home_address',
                    'COALESCE(cp.work_address, "") as work_address',
                    'COALESCE(cp.push_notifications, "1") as push_notifications',
                    'cp.is_phone_verified', 'cp.verification_state', '1 as is_demographics_updated',
                    'COALESCE(cp.affiliate_code, "") as affiliate_code'
                ]
            )
            sql_dal.from_('ent_customer_profile AS cp')
            sql_dal.inner_join('user AS c', 'cp.user_id', 'c.id')
            sql_dal.where({'cp.user_id': customer_id})
            result = sql_dal.get_one(default={})
            if result:
                result['is_demographics_updated'] = 0
                if all([result.get('gender'), result.get('nationality'), result.get('date_of_birth')]):
                    result['is_demographics_updated'] = 1
                date_of_birth = result.get('date_of_birth')
                if date_of_birth:
                    result['date_of_birth'] = parse(date_of_birth).strftime('%d/%m/%Y')
            else:
                return False
            if not result['currency']:
                result['currency'] = "USD"
            if result.get('using_trial') and result.get('using_trial') != 1:
                result['using_trial'] = False
            result['push_notifications'] = int(result['push_notifications'])
            result['default_currency'] = result['currency'].upper()
            result['created_at'] = str(result.get('created_at'))
            if result['membership_expiration_date']:
                result['membership_expiration_date'] = str(result.get('membership_expiration_date'))
            result['onboarding_startdate'] = str(result.get('onboarding_startdate'))
            result['updated_at'] = str(result.get('updated_at'))
            result['accepted_terms'] = str(result.get('accepted_terms'))
            result['do_not_email'] = str(result.get('do_not_email'))
            return result
        return False

    def get_customer_products(self, **kwargs):
        """
        Gets the customer products in the base of the user id. Also filter the purchased skus.
        :param user_id: user's id
        :param company: company of the user
        :rtype: list
        """
        company = kwargs.get('company', '')
        user_id = kwargs.get('user_id')

        wl_products_repo_instance = WLProductRepository()
        wl_validation_repo_instance = WlValidationRepository()

        user_groups = wl_validation_repo_instance.get_user_groups(company, user_id)
        if not user_groups:
            user_groups = [WlUserGroup.DEFAULT_USER_GROUP]

        configured_product_ids = wl_products_repo_instance.get_configured_products(company, user_groups)
        product_ids = configured_product_ids

        if isinstance(product_ids, str):
            return ','.join(product_ids)
        elif isinstance(product_ids, list):
            return ','.join(map(str, product_ids))
        else:
            return ''

    def login_customer(self, email, password, _hash='', company='entertainer'):
        """
        Login user info
        :param str email: email
        :param str password: password
        :param str _hash: hash
        :param str company: company
        :rtype dict
        """
        security = Security()
        record = {}
        if security.validate_password(password, _hash) or security.validate_hash_magento(password, _hash):
            lookup_based_company = WLCompany().is_lookup_based_company(company)
            if lookup_based_company:
                sql_dal = SqlDal(connection=CONSOLIDATION)
                sql_dal.select(['*'])
                sql_dal.from_(['user'], ['c'])
                sql_dal.inner_join('wl_user_custom_info as uci', 'c.id', 'uci.user_id')
                ordered_where_clause = OrderedDict()
                ordered_where_clause['c.email'] = email
                ordered_where_clause['c.is_active'] = True
                ordered_where_clause['uci.company'] = company
                ordered_where_clause['uci.password_hash'] = _hash
                sql_dal.where(ordered_where_clause)
            else:
                sql_dal = SqlDal(connection=CONSOLIDATION)
                sql_dal.select(['*'])
                sql_dal.from_(['user as u'])
                sql_dal.inner_join('wl_user_custom_info as wuci', 'u.id', 'wuci.user_id')
                sql_dal.where({
                    'u.email': email,
                    'u.is_active': True,
                    'wuci.password_hash': _hash,
                    'wuci.company': company
                })
            record = sql_dal.get_one(default={})
        return record

    def put_customer_in_trial_membership_if_qualifies(self, customer_profile=None):
        """
        Gives customer n-day Trial Membership if they qualify
        Also, remove trial membership if expired.
        :param: dict customer
        :rtype dict
        """
        if (customer_profile.get('new_member_group') == self.MEMBERSTATUS_ONBOARDING or
                customer_profile.get('onboarding_status') != self.ONBOARDING_FINISHED):

            if customer_profile.get('new_member_group') == self.MEMBERSTATUS_ONBOARDING:
                customer_profile['new_member_group'] = self.MEMBERSTATUS_PROSPTECT

            customer_profile['onboarding_status'] = self.ONBOARDING_FINISHED
            customer_profile['onboarding_enddate'] = get_current_date_time()
            customer_profile['update_time'] = get_current_date_time()
            if customer_profile:
                sql_dal = SqlDal(connection=CONSOLIDATION)
                sql_dal.where({'user_id': customer_profile.get('user_id')})
                sql_dal.update('ent_customer_profile', changes=customer_profile)
            customer_profile.update(customer_profile)
        return customer_profile

    def update_password_reset_token(self, customer_id, token):
        """
        Updates the password reset token
        :param int customer_id: id of the customer
        :param str token: token that is passed by the customer
        :rtype bool
        """
        try:
            token_expiry_date = datetime.datetime.now() + datetime.timedelta(hours=self.Token_Expiry_In_Hours)
            sql_dal = SqlDal(connection=CONSOLIDATION)
            changes = {
                'password_reset_token': token,
                'token_exp_date': token_expiry_date
            }
            sql_dal.where({'id': customer_id})
            sql_dal.update('user', changes=changes)
            return True
        except Exception:
            return False

    def get_password_hash(self, *args, **kwargs):
        """
        Gets the password hash of the user
        :param email: email of the user.
        :param company: company of the user.
        :rtype hash
        """
        sql_dal = SqlDal(connection=CONSOLIDATION)
        sql_dal.select(['wuci.password_hash'])
        sql_dal.from_(['user as u'])
        sql_dal.inner_join('wl_user_custom_info as wuci', 'u.id', 'wuci.user_id')
        sql_dal.where({
            'u.email': kwargs.get('email'),
            'u.is_active': True,
            'is_customer': True
        })
        result = sql_dal.get_one(default={})
        return result.get('password_hash')

    def get_customer_purchased_products(self, user_id, company):
        """
        Retreive customer product purchase ids
        :param user_id: user id
        :param company: company
        :rtype list
        """
        purchased_ids = []
        purchased_skus = []

        web_db = current_app.config['SQL_DB_CONFIG']['database']
        sql_dal = SqlDal(connection=CONSOLIDATION)
        sql_dal.select(['i.id', 'i.product_sku', 'i.quantity', 'p.bundled_product_sku'])
        sql_dal.from_(['ent_order'], ['co'])
        sql_dal.inner_join('ent_order_item as i', 'co.id', 'i.order_id')
        sql_dal.inner_join('{}.product as p'.format(web_db), 'p.id', 'i.product_id')
        sql_dal.where({
            'co.user_id': user_id,
            'co.company': company,
            'COALESCE(i.inactive, 0)': 0
        })

        results = sql_dal.get(default=[])
        # TODO nested loop prevention
        for result in results:
            for index in range(len(result.get('quantity'))):
                purchased_skus.append(result.get('product_sku'))
                if result.get('bundled_product_sku'):
                    bundled_product_skus = result.get('bundled_product_sku').split(',')
                    if bundled_product_skus:
                        purchased_skus = CommonHelpers.array_merge(purchased_skus, bundled_product_skus)
        sql_dal.clear()
        if purchased_skus:
            sql_dal.select(['id as product_id, COUNT(id) quantity'])
            sql_dal.from_(['product'])
            sql_dal.where({'sf_id': purchased_skus})
            sql_dal.group_by(['id'])
            results = sql_dal.get(default=[])
            # TODO nested
            for result in results:
                for index in range(len(result.get('quantity'))):
                    purchased_ids.append(result.get('product_id'))

        return purchased_ids

    def set_currency_and_default_currency(self, changes):
        """
        Sets the currency and the default currency for COMPANY_CODE_ENTERTAINER_CHANGI_REWARDS_ENTERTAINER
        """
        changes['currency'] = "SGD"
        changes['default_currency'] = 44
        return changes

    def create_new_customer(self, *args, **kwargs):
        """
        Creates new customer

        :param args: customer data
        :param kwargs:  customer data
        :rtype bool | int
        """
        from common_white_label.security import Security
        security_instance = Security()
        password_hash = security_instance.generate_password_hash(kwargs.get('password'))
        auth_key = security_instance.generate_random_key()
        email = kwargs.get('email')
        created_time = get_current_date_time()
        updated_time = get_current_date_time()

        if not kwargs.get('customer_profile_info'):
            try:
                sql_dal = SqlDal(connection=CONSOLIDATION)
                changes = {
                    'auth_key': auth_key,
                    'password_hash': password_hash,
                    'status': 10,
                    'is_customer': 1,
                    'create_time': created_time,
                    'update_time': updated_time,
                    'is_active': 1,
                    'email': email
                }
                if kwargs.get('email'):
                    changes.update({'username': kwargs.get('email')})
                if kwargs.get('firstname'):
                    changes.update({'first_name': kwargs.get('firstname')})
                if kwargs.get('lastname'):
                    changes.update({'last_name': kwargs.get('lastname')})
                columns = list(changes.keys())
                data = list(changes.values())

                # making entry in the user table
                new_customer_id = sql_dal.insert(
                    'user',
                    columns=columns,
                    values=data,
                    last_row_id=True
                )
            except Exception:
                return False

            country_of_residence = kwargs.get('country_of_residence')
            membership_code = self.generate_member_code(country_of_residence, new_customer_id)
            currency = kwargs.get('currency') if kwargs.get('currency') else self.CURRENCY
            default_currency = kwargs.get('default_currency') if kwargs.get('default_currency') else self.CURRENCY_ID
            customer_group = self.TRIAL
            try:
                changes = {
                    'user_id': new_customer_id,
                    'email': email,
                    'new_member_group': self.MEMBERSTATUS_PROSPTECT,
                    'default_currency': default_currency,
                    'currency': currency,
                    'third_email_opt_out': '0',
                    'member_group': customer_group,
                    'membership_status': 1,
                    'membership_code': membership_code,
                    'is_using_trial': 0,
                    'create_time': created_time,
                    'update_time': updated_time,
                    'onboarding_status': self.ONBOARDING_FINISHED,
                    'onboarding_enddate': created_time,
                    'onboarding_startdate': created_time,
                    'push_notifications': 1,
                    'is_used_trial': 0
                }

                if kwargs.get('language'):
                    changes.update({'language': kwargs.get('language')})
                if kwargs.get('firstname'):
                    changes.update({'firstname': kwargs.get('firstname')})
                if kwargs.get('lastname'):
                    changes.update({'lastname': kwargs.get('lastname')})
                if kwargs.get('gender'):
                    changes.update({'gender': kwargs.get('gender')})
                if kwargs.get('mobile_phone'):
                    changes.update({'mobile_phone': kwargs.get('mobile_phone')})
                if kwargs.get('nationality'):
                    changes.update({'nationality': kwargs.get('nationality')})
                if kwargs.get('affiliate_code'):
                    changes.update({'affiliate_code': kwargs.get('affiliate_code')})
                if kwargs.get('country_of_residence'):
                    changes.update({'country_of_residence': kwargs.get('country_of_residence')})
                if kwargs.get('terms_acceptance'):
                    changes.update({'accepted_terms': kwargs.get('terms_acceptance')})
                if kwargs.get('do_not_email'):
                    changes.update({'receive_email': kwargs.get('do_not_email')})

                # Function is over ride in multiple files for multiple companies.
                # Must ask Muhammad Saqib before using this function
                # self.set_currency_and_default_currency(changes)

                if kwargs.get('company').lower() == WLCompany.company_code_ENTERTAINER_VDF:
                    changes['currency'] = "QAR"
                    changes['default_currency'] = 45

                if kwargs.get('company') == WLCompany.COMPANY_CODE_ENTERTAINER_MTN:
                    changes['currency'] = "EUR"
                    changes['default_currency'] = 34

                if kwargs.get('company') == WLCompany.COMPANY_CODE_ENTERTAINER_QGIRCO:
                    changes['currency'] = "QAR"
                    changes['default_currency'] = 42

                if kwargs.get('company') == WLCompany.COMPANY_CODE_ENTERTAINER_HUT:
                    changes['currency'] = "HKD"
                    changes['default_currency'] = 36
                    changes['receive_email'] = 1

                if kwargs.get('company') == WLCompany.COMPANY_CODE_ALBILAD:
                    changes['currency'] = "SAR"
                    changes['default_currency'] = 43
                if (
                    kwargs.get('company') == WLCompany.COMPANY_CODE_ENTERTAINER_CHANGI_REWARDS_ENTERTAINER or
                    kwargs.get('company') == WLCompany.COMPANY_CODE_AAG
                ):
                    changes['currency'] = "SGD"
                    changes['default_currency'] = 44

                if kwargs.get('company') == WLCompany.COMPANY_CODE_ENTERTAINER_NAAMA:
                    changes['currency'] = "OMR"
                    changes['default_currency'] = 41

                if kwargs.get('company') == WLCompany.COMPANY_CODE_ENTERTAINER_EMAX:
                    changes['currency'] = "AED"
                    changes['default_currency'] = 31

                if kwargs.get('company') == WLCompany.COMPANY_CODE_DUBAI_ENTERTAINMENTS:
                    changes['currency'] = "AED"
                    changes['default_currency'] = 31

                if kwargs.get('company') == WLCompany.company_code_SOLIDATIRy:
                    changes['currency'] = "BHD"
                    changes['default_currency'] = 32
                    changes['country_of_residence'] = "BH"

                # gems default currency is changed on Rauf's request
                if kwargs.get('company') == WLCompany.COMPANY_CODE_ENTERTAINER_GEMS:
                    changes['currency'] = "AED"
                    changes['default_currency'] = 31

                if kwargs.get('company') == WLCompany.COMPANY_CODE_DU:
                    changes['currency'] = "AED"
                    changes['default_currency'] = 31

                if kwargs.get('date_of_birth'):
                    date_of_birth = kwargs.get('date_of_birth')
                    date_of_birth = date_of_birth.replace('/', '-')
                    date_of_birth = datetime.datetime.strptime(date_of_birth, '%Y-%m-%d')
                    changes.update({'birthdate': date_of_birth})

                columns = list(changes.keys())
                data = list(changes.values())
                sql_dal.insert(
                    'ent_customer_profile',
                    columns=columns,
                    values=data
                )
            except Exception:
                return False

        if kwargs.get('profile_customer_id'):
            new_customer_id = kwargs.get('profile_customer_id')
        try:
            sql_dal = SqlDal(connection=CONSOLIDATION)
            changes = {
                'company': 'EXPRS',
                'user_id': new_customer_id,
                'password_hash': password_hash,
                'status': 1,
                'create_time': created_time,
                'update_time': updated_time,
            }
            if kwargs.get('firstname'):
                changes.update({'firstname': kwargs.get('firstname')})
            if kwargs.get('lastname'):
                changes.update({'lastname': kwargs.get('lastname')})
            if kwargs.get('gender'):
                changes.update({'gender': kwargs.get('gender')})
            if kwargs.get('country_of_residence'):
                changes.update({'country_of_residence': kwargs.get('country_of_residence')})

            columns = list(changes.keys())
            data = list(changes.values())

            # making entry in the user table
            sql_dal.insert(
                'wl_user_custom_info',
                columns=columns,
                values=data
            )
        except Exception:
            return False
        return new_customer_id if new_customer_id else False

    def generate_member_code(self, country, user_id):
        """
        Generates Member code
        :param country:  Country
        :param user_id:  User id
        :rtype str
        """
        membership_code = 'M'
        year = datetime.datetime.now().year
        location_code = country
        if not location_code:
            location_code = "XX"
        user_id = str(user_id)
        user_id = user_id.rjust(8, '0')
        card_number = 1
        membership_code = "{membership_code}{year}{location_code}{user_id}{card_number}".format(
            membership_code=membership_code,
            year=year,
            location_code=location_code,
            user_id=user_id,
            card_number=str(card_number)
        )
        return membership_code

        # membership_code = 'M'
        # date = datetime.datetime.now()
        # year = datetime.datetime.strftime(date, '%y')
        # location_code = country
        # if not location_code:
        #     location_code = "XX"
        # user_id = str(user_id)
        # user_id = user_id.rjust(8, '0')
        # card_number = 1
        # membership_code = "{membership_code}{year}{location_code}{user_id}{card_number}".format(
        #     membership_code=membership_code,
        #     year=year,
        #     location_code=location_code,
        #     user_id=user_id,
        #     card_number=str(card_number)
        # )
        # return membership_code

    def set_savings(self, yearly_savings={}):
        """
        Override for company GEM
        """
        pass

    def calculate_aging(self, days):
        if days < 30:
            if days > 1:
                return '{} Days'.format(days)
            else:
                return '1 Day'
        else:
            months = floor(days / 30)
            remaining_days = days % 30
        if months < 12:
            if remaining_days >= 15:
                return str(months) + '.5 Months'
            else:
                if months > 1:
                    return str(months) + ' Months'
                else:
                    return str(months) + ' Month'
        else:
            years = floor(months / 12)
            remaining_months = months % 12
            if remaining_months >= 6:
                return str(years) + '.5 Years'
            else:
                if years > 1:
                    return str(years) + ' Years'
                else:
                    return str(years) + ' Year'

    def get_user_yearly_savings(
            self,
            user_id,
            currency,
            locale='en',
            message_to_append_with_this_year_savings='Saved this year',
            company='entertainer'
    ):
        """
        The method gets user's yearly savings
        :param int user_id: User Id
        :param str currency: Currency
        :param str locale: Locale
        :param str message_to_append_with_this_year_savings: Message you want to append
        :param str company: User's company name
        :rtype: dict
        """
        savings_response = {
            'offers_used': 0,
            'savings_this_year': 0,
            'savings_this_year_aed': 0
        }
        if locale == 'cn':
            savings_response['savings_this_year_label'] = message_to_append_with_this_year_savings
        else:
            savings_response['savings_this_year_label'] = '{currency} {message}'.format(
                currency=currency,
                message=message_to_append_with_this_year_savings)
        if user_id == 0:
            return savings_response
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select([
            "COALESCE(us.current_year_redemptions, 0) as offers_used",
            "COALESCE(us.current_year_savings, 0) as savings_this_year",
            "COALESCE(us.current_year_savings, 0) as savings_this_year_aed",
            "'' as savings_this_year_label"
        ])
        sql_dal.from_(['user_savings'], ['us'])
        sql_dal.where({'us.user_id': user_id, 'us.company': company})

        yearly_savings = sql_dal.get_one(default={})
        if yearly_savings:
            yearly_savings['offers_used'] = int(yearly_savings.get('offers_used', 0))
            yearly_savings['savings_this_year_aed'] = int(yearly_savings.get('savings_this_year', 0))
            yearly_savings['total_points'] = int(yearly_savings.get('total_points', 0))
            yearly_savings['gems_savings'] = int(yearly_savings.get('gems_savings', 0))

            # Function is override for GEM
            self.set_savings(yearly_savings)

            if locale == 'cn':
                yearly_savings['savings_this_year_label'] = message_to_append_with_this_year_savings
            else:
                yearly_savings['savings_this_year_label'] = '{currency} {message}'.format(
                    currency=currency,
                    message=message_to_append_with_this_year_savings)
            exchange_repo = ExchangeRatesRepositoryWL(
                single_connection=self.single_connection,
                connection=self.db_connection
            )
            yearly_savings['savings_this_year'] = round(exchange_repo.get_conversion_rate(
                yearly_savings['savings_this_year'], 'AED', currency
            ))
            return yearly_savings
        return savings_response

    def refresh_customer_sessions(self, *args, **kwargs):
        """
        Refreshes all Customer Sessions Against specific company
        :param int customer_id: id of customer
        :param str company: compnay of customer
        """
        customer_id = kwargs.get('customer_id')
        company = kwargs.get('company')
        product_ids = self.get_customer_products(user_id=customer_id, company=company)
        session_repo_instance = SessionRepositoryWhiteLabel()
        session_repo_instance.update_all_sessions_for_customer(customer_id, product_ids, company)

    def update_password_for_lookup_based_company(self, token, _password, customer_id, company=None):
        """
        Updates the password for lookup based companies.
        :param str token: token of the user
        :param str _password: password of the user
        :param int customer_id: id of the customer
        :param str company: company of the user
        :rtype: bool
        """
        try:
            security_instance = Security()
            sql_dal = SqlDal(connection=CONSOLIDATION)
            password = security_instance.generate_password_hash(_password)
            changes = {
                'password_reset_token': None,
                'token_exp_date': None
            }
            sql_dal.where({'password_reset_token': token})
            sql_dal.update('user', changes)

            sql_dal.clear()
            changes = {'password_hash': password}
            sql_dal.where({
                'user_id': customer_id,
                'company': company
            })
            sql_dal.update('wl_user_custom_info', changes=changes)
            return True
        except Exception:
            return False

    def check_customer_by_password_token(self, password_token):
        """
        Checks the customer on the base of the password token
        :param str password_token: password token of the user
        :rtype: int| bool
        """
        sql_dal = SqlDal(connection=CONSOLIDATION)
        sql_dal.select(['*'])
        sql_dal.from_(['user'])
        sql_dal.where({
            'password_reset_token': password_token,
            'is_active': True
        })
        result = sql_dal.get_one(default={})
        return result.get('id')

    def set_user_savings(self, user_savings):
        """
        function is override for gems
        """
        pass

    def get_user_savings_online(self, user_id, current_year, currency, locale='en', company='entertainer'):
        """
        Gets the user savings
        :param user_id:
        :param current_year:
        :param currency:
        :param locale:
        :param company:
        :rtype dict
        """
        user_savings_response = {
            'current_year': current_year,
            'savings': 0,
            'yearly_savings': 0
        }
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select([
            'current_year_savings', 'total_savings',
            "COALESCE(total_points, 0) as points, COALESCE(gems_savings, 0) as gems_savings"
        ])
        sql_dal.from_(['user_savings'])
        sql_dal.where({'user_id': user_id, 'company': company})
        user_savings = sql_dal.get(default=[])

        if len(user_savings) > 0:
            user_savings = user_savings[0]

            # function is used over here for hte purpose of multiple companies.
            self.set_user_savings(user_savings)

            exchange_repo_instance = ExchangeRatesRepositoryWL(
                single_connection=self.single_connection,
                connection=self.db_connection
            )
            savings = exchange_repo_instance.get_conversion_rate(
                float(user_savings.get('total_savings')),
                'AED',
                currency
            )
            yearly_savings = exchange_repo_instance.get_conversion_rate(
                float(user_savings.get('current_year_savings')),
                'AED',
                currency
            )
            if 1 > savings > 0:
                savings = 1
            if 1 > yearly_savings > 0:
                yearly_savings = 1

            user_savings_response['savings'] = round(savings)
            user_savings_response['yearly_savings'] = round(yearly_savings)
            user_savings_response['points'] = user_savings['points']
            return user_savings_response
        return user_savings_response

    def get_customer_purchased_skus_profile(self, user_id, company, locale):
        """
        Gets the customer purchased sku
        :param int user_id: id of the user
        :param str company: company of the user
        :param str locale: locale of customer
        :rtype: dict
        """
        web_db = current_app.config['SQL_DB_CONFIG']['database']
        sql_dal = SqlDal(connection=CONSOLIDATION)
        sql_dal.select([
            "DISTINCT pd.id", "pd.sf_id as sfId", "pt.name", "pd.valid_to as expiry_date",
            " '' as product_validity_message"
        ])
        sql_dal.from_(['ent_order as co'])
        sql_dal.inner_join('ent_order_item as i', 'co.id', 'i.order_id')
        sql_dal.inner_join('{web_db}.product AS pd'.format(web_db=web_db), 'pd.sf_id', 'i.product_sku')
        sql_dal.inner_join('{web_db}.product_translation AS pt'.format(web_db=web_db), 'pd.id', 'pt.product_id')
        sql_dal.where({
            'co.user_id': user_id,
            'co.company': company,
            'COALESCE(i.inactive, 0)': 0,
            'pt.locale': locale
        })
        results = sql_dal.get(default=[])
        if results:
            valid_until_text = 'valid until'
            if locale == 'ar':
                valid_until_text = 'صالح لغاية'
            elif locale == 'cn':
                valid_until_text = "有效期至"
            elif locale == 'el':
                valid_until_text = "Ισχύει έως"
            for result in results:
                if result.get('expiry_date'):
                    result['product_validity_message'] = "{} {}".format(
                        valid_until_text, result['expiry_date'].strftime('%d %B %Y')
                    )
                    result['expiry_date'] = str(result['expiry_date'])
        return results

    def get_customer_digital_orders_purchase_history(self, *args, **kwargs):
        """
        Customer digital order purchase history

        :rtype list
        """
        user_id = kwargs.get('user_id')
        locale = kwargs.get("locale")
        currency = kwargs.get("currency")
        company = kwargs.get("company")
        consolidation_db = get_db_settings_from_app(connection_name=CONSOLIDATION)['database']
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select([
            'p.id', 'i.product_sku as sku', 'COALESCE(pt.name, "") as name',
            'co.local_currency as base_currency', 'co.create_date as date', 'co.order_currency as currency',
            'i.total_price as price_local', 'i.total_discount as discount_local',
            'i.base_row_total as price_aed', 'i.base_discount_amount as discount_aed', 'i.is_gift'
        ])
        sql_dal.from_(['{co_db}.user'.format(co_db=consolidation_db)], aliases=['c'])
        sql_dal.inner_join('{co_db}.ent_order as co'.format(co_db=consolidation_db), 'co.user_id', 'c.id')
        sql_dal.inner_join('{co_db}.ent_order_item as i'.format(co_db=consolidation_db), 'co.id', 'i.order_id')
        sql_dal.inner_join('product as p', 'p.sf_id', 'i.product_sku')
        sql_dal.inner_join('product_translation as pt', 'p.id', 'pt.product_id')
        sql_dal.where({
            'c.id': user_id,
            'co.company': company,
            'COALESCE(i.inactive, 0)': 0,
            'pt.locale': locale
        })
        purchases = sql_dal.get(default=[])
        exchange_repo_instance = ExchangeRatesRepositoryWL(
            single_connection=self.single_connection,
            connection=self.db_connection
        )
        for purchase in purchases:
            if currency == purchase['currency']:
                price_total = purchase['price_local']
                price_discount = purchase['discount_local']
            else:
                price_total = exchange_repo_instance.get_conversion_rate(purchase['price_aed'], 'AED', currency)
                price_discount = exchange_repo_instance.get_conversion_rate(
                    purchase['discount_aed'] if purchase['discount_aed'] else 0, 'AED', currency)
            purchase['price'] = round(price_total - price_discount)
        return purchases

    def get_user_membership_card(self, user_id, company):
        """
        Get the user member ship card
        :param int user_id: id of the user
        :param str company: company of the user
        :rtype: dict
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        sql_dal.select(['*'])
        sql_dal.from_(['wl_membership_cards'])
        sql_dal.where({
            'user_id': user_id,
            'company': company
        })
        sql_dal.order_by({'created_date': 'DESC'})
        return sql_dal.get_one(default={})

    def set_primary_device(self, customer_id, device_install_token=None):
        """
        Sets primary device
        :param int customer_id: customer id
        :param str device_install_token: device install token
        :rtype: dict
        """
        sql_dal = SqlDal(connection=ENTERTAINER_WEB)
        changes = {
            'primary_device': 0
        }
        sql_dal.where({'customer_id': customer_id})
        sql_dal.update('customer_devices', changes=changes)
        sql_dal.clear()

        changes = {
            'primary_device': 1
        }
        sql_dal.where({
            'customer_id': customer_id,
            'device_install_token': device_install_token
        })
        sql_dal.update('customer_devices', changes=changes)
        return True

    def get_currency_for_country_name(self):
        # To be implemented
        pass

    def format_number(self, mobile_number):
        """
        Format the mobile number
        :param str mobile_number: mobile number of the user.
        """
        if len(mobile_number) > 2:
            if mobile_number[0] == "+":
                mobile_number = mobile_number[1:]  # substr(mobile_number, 1)
            elif mobile_number[0:2] == "00":
                mobile_number = mobile_number[2:]  # substr(mobile_number, 2)
            elif mobile_number[0] == "0":
                mobile_number = mobile_number[1:]  # substr(mobile_number, 1)
        return mobile_number

    def update_customer_user_table_info(self, customer_id=0, company='entertainer', data={}):
        """
        Updates the user table information of the user.

        :param int customer_id: customer id
        :param str company: company
        :param dict data: data
        """
        if customer_id and data:
            sql_dal = SqlDal(connection=CONSOLIDATION)
            sql_dal.where({'id': customer_id, 'company': company})
            sql_dal.update('user', changes=data)

    def update_mobile_phone_number(self, customer_id, mobile_phone):
        """
        update customer's phone number

        :param customer_id: customer id
        :param mobile_phone: user phone number
        :rtype dict
        """
        sql_dal = SqlDal(connection=CONSOLIDATION)
        customer_phone_number_update = {
            'mobilePhone': mobile_phone
        }
        sql_dal.where('user_id', customer_id)
        sql_dal.update('ent_customer_profile', changes=customer_phone_number_update)
        return sql_dal.get_one(default={})

    def get_member_type(self, group_id):
        """
        Gets the member type
        :param int group_id: group id
        :rtype: str
        """
        member_types = {
            2: 'member',
            3: 'onboarding',
            4: 'reprospect'
        }
        return member_types.get(group_id, 'prospect')

    def load_customer_by_email(self, email, single=True):
        """
        Loads the customer_profile on the base of email
        :param str email: email of the user
        :param bool single: load single user
        :rtype dict
        """
        sql_dal = SqlDal(connection=CONSOLIDATION)
        sql_dal.from_(['user as u'])
        sql_dal.inner_join('wl_user_custom_info as wuci', 'u.id', 'wuci.user_id')
        sql_dal.where({'email': email, 'u.is_active': 1})
        if single:
            customer_profile = sql_dal.get_one(default={})
        else:
            sql_dal.order_by({'id': 'DESC'})
            customer_profile = sql_dal.get(default=[])
        return customer_profile

    def load_customer_by_email_and_custom_info(self, email, company, single=True):
        """
        Loads the customer_profile on the base of email
        :param str email: email of the user
        :param bool single: load single user
        :rtype dict
        """
        sql_dal = SqlDal(connection=CONSOLIDATION)
        sql_dal.select(['u.email', 'wuci.password_hash', 'u.is_email_verified'])
        sql_dal.from_(['user as u'])
        sql_dal.where({'u.email': email, 'u.is_active': 1, 'wuci.company': company})
        sql_dal.inner_join('wl_user_custom_info as wuci', 'u.id', 'wuci.user_id')
        if single:
            customer_profile = sql_dal.get_one(default={})
        else:
            sql_dal.order_by({'id': 'DESC'})
            customer_profile = sql_dal.get(default=[])
        return customer_profile

    def update_demographic_state(self, user_id, locale='en'):
        """
        This method updates verification state of a user.
        :param int user_id: Customer Id
        :param str locale: Locale
        :rtype: bool
        """
        customer_profile = self.load_customer_profile_by_user_id(user_id)
        if customer_profile:
            verification_state = customer_profile.get('verification_state')
            if verification_state == CustomerProfileWhiteLabel.VERIFICATION_STATE_NOT_STARTED:
                verification_state = CustomerProfileWhiteLabel.VERIFICATION_STATE_STARTED
            elif verification_state == CustomerProfileWhiteLabel.VERIFICATION_STATE_STARTED:
                verification_state = CustomerProfileWhiteLabel.VERIFICATION_STATE_PHONE_NOT_VERIFIED_BUT_DEMOGRAPHIC_UPDATED  # noqa E501
            elif verification_state == CustomerProfileWhiteLabel.VERIFICATION_STATE_PHONE_VERIFIED:
                verification_state = CustomerProfileWhiteLabel.VERIFICATION_STATE_VERIFICATION_COMPLETED
            if customer_profile.get('verification_state') == verification_state:
                return True
            changes = {'verification_state': verification_state}
            sql_dal = SqlDal(connection=CONSOLIDATION)
            sql_dal.where({'user_id': user_id})
            sql_dal.update('ent_customer_profile', changes=changes)
            return True
        return False

    def update_customer_profile(self, customer_id, fields):
        """
        Update customer profile
        :param customer_id:
        :param fields:
        :rtype: Boolean
        """
        if customer_id:
            changes = {}
            if fields.get('gender'):
                changes.update({'gender': fields.get('gender')})
            if fields.get('third_do_not_email'):
                changes.update({'third_email_opt_out': fields.get('third_do_not_email')})
            if fields.get('work_address'):
                changes.update({'work_address': fields.get('work_address')})
            if fields.get('home_address'):
                changes.update({'home_address': fields.get('home_address')})
            if fields.get('push_notifications'):
                changes.update({'push_notifications': fields.get('push_notifications')})
            if fields.get('affiliate_code'):
                changes.update({'affiliate_code': fields.get('affiliate_code')})
            if fields.get('do_not_email'):
                changes.update({'receive_email': fields.get('do_not_email')})
            if fields.get('mobile_phone'):
                changes.update({'mobile_phone': fields.get('mobile_phone')})
            if fields.get('marital_status'):
                changes.update({'marital_status': fields.get('marital_status')})
            if fields.get('nationality'):
                changes.update({'nationality': fields.get('nationality')})
            if fields.get('country_of_residence'):
                changes.update({'country_of_residence': fields.get('country_of_residence')})
            try:
                if fields.get('date_of_birth'):
                    date_of_birth = fields.get('date_of_birth').replace('/', '-')
                    date_of_birth = parse(date_of_birth).strftime('%Y-%m-%d')
                    changes.update({'birthdate': date_of_birth})
            except Exception:
                return False
            current_date = datetime.datetime.now()
            current_date = datetime.datetime.strftime(current_date, '%Y-%m-%d %H:%M:%S')
            changes.update({'update_time': current_date})
            if not fields.get('language_preference'):
                fields['language_preference'] = "en"
            from repositories_white_label.currency_repo import CurrencyRepositoryWL
            currency_repo_instance = CurrencyRepositoryWL()
            if fields.get('currency'):
                fields['default_currency'] = fields.get('currency')

            currency_info = currency_repo_instance.get_currency_by_code(
                fields.get('language_preference'),
                fields.get('default_currency').upper()
            )
            fields['currency'] = fields.get('default_currency').upper()
            if currency_info:
                fields['default_currency'] = currency_info['currency_id']

            changes.update({'currency': fields.get('currency')})
            changes.update({'default_currency': fields.get('default_currency')})
            self.update_demographic_state(customer_id)
            sql_dal = SqlDal(connection=CONSOLIDATION)
            sql_dal.where('user_id', customer_id)
            sql_dal.update('ent_customer_profile', changes=changes)
            return True
        return False

    def get_customer_credit_card_details(self, user_id):
        """
        Gets customer credit card details
        :param int user_id: id of the user
        :rtype: dict
        """
        sql_dal = SqlDal(connection=CONSOLIDATION)
        sql_dal.select(['c_id', 'c_4', 'c_type'])
        sql_dal.from_(['ent_customer_cc_holder_wl'])
        sql_dal.where({'id': user_id, 'is_deleted': 0, 'is_primary': 1})
        result = sql_dal.get_one(default={})
        return result

    def send_email(self, email_type_id, email, language='en', priority=WlSendEmailsRepository.Priority_Medium,
                   email_data={}, optional_data={}, dump=True):
        """
        Create email database entry for automated generated email notification
        :param str | int email_type_id: email type id
        :param str email: email
        :param str language: language
        :param int priority: email notification priority
        :param str | dict email_data: email data
        :param str | null optional_data: optional data
        :param bool dump: dump
        :rtype bool
        """
        sql_dal = SqlDal(connection=CONSOLIDATION)
        try:
            columns = [
                'email_to',
                'email_template_data',
                'optional_data',
                'language',
                'priority',
                'created_date'
            ]
            data = [
                email,
                json.dumps(email_data) if dump else email_data,
                json.dumps(optional_data) if dump else optional_data,
                language,
                priority,
                get_current_date_time()
            ]
            if email_type_id:
                columns.append('email_template_type_id')
                data.append(email_type_id)
            sql_dal.insert('ent_send_emails', columns=columns, values=data)
        except Exception:
            return False
        return True

    def update_customer_profile_by_id(self, customer_id, data={}):
        """
        Updates customer informations
        :param int customer_id: Customer id
        :param dict data:  Data
        """
        if customer_id:
            sql_dal = SqlDal(connection=CONSOLIDATION)
            sql_dal.where({"user_id": customer_id})
            sql_dal.update('ent_customer_profile', changes=data)
        return data

    def load_customer_profile_by_user_id(self, user_id):
        """
        Load customer profile by id
        :param int user_id: user id
        :rtype dict
        """
        customer_profile = {}
        if user_id:
            sql_dal = SqlDal(connection=CONSOLIDATION)
            sql_dal.from_(['ent_customer_profile'])
            if isinstance(user_id, list):
                sql_dal.where_in('user_id', user_id)
                customer_profile = sql_dal.get(default=[])
                customer_profile = {profile['user_id']: profile for profile in customer_profile}
            else:
                sql_dal.where('user_id', user_id)
                customer_profile = sql_dal.get_one(default={})
        return customer_profile

    def upload_profile_image(self, user_file, user_id):
        """
        Upload user profile image
        :param str user_file: location for profile image file
        :param int user_id: user id
        :rtype dict
        """
        response_message = {}
        if user_file and user_id:
            response_message['code'] = AwsS3Manager.RESPONSE_CODE_BAD_REQUEST
            try:
                ext = user_file.filename.split(".")
                image_name = "{user_id}_{md5}.{digit}".format(
                    user_id=user_id,
                    md5=Security.generate_random_string(),
                    digit=ext[-1]
                )
                response_message = AwsS3Manager()._put_object(
                    file=user_file,
                    image_name=image_name,
                )
            except:
                pass
        return response_message

    def save_user_profile(self, user_id, about_me, profile_image, country=""):
        """
        Save user profile on th basis of user id
        :param int user_id: user id
        :param str about_me: about me
        :param str profile_image: location for profile image
        :param str country: country of residence
        :rtype bool
        """
        if not user_id:
            return False
        else:
            changes = {}
            if about_me:
                changes['about_me'] = about_me
            if profile_image:
                changes['profile_image'] = profile_image
            if country:
                changes['country_of_residence'] = country
            sql_dal = SqlDal(connection=CONSOLIDATION)
            sql_dal.where('user_id', user_id)
            if changes:
                sql_dal.update('ent_customer_profile', changes=changes)
            return True

    def get_user_from_custom_table(self, user_id, company):
        """
        Gets the customer from custom table of company
        :param int user_id: id of user
        :param str company: company of the user
        :rtype: dict
        """
        sql_dal = SqlDal(connection=CONSOLIDATION)
        sql_dal.select(['user_id'])
        sql_dal.from_('wl_user_custom_info')
        sql_dal.where({'user_id': user_id, 'company': company})
        return sql_dal.get_one(default={})
