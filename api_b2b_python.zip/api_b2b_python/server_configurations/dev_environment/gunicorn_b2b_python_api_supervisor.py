import multiprocessing
import os

parent_directory = os.getcwd()
chdir = parent_directory
pythonpath = '{path}/envname'.format(path=parent_directory)
accesslog = '{path}/logs/b2b-python-api-access.log'.format(path=parent_directory)
errorlog = '{path}/logs/b2b-python-api-error.log'.format(path=parent_directory)
capture_output = True
raw_env = 'APPLICATION_SETTINGS={path}/instance/dev_settings.py'.format(path=parent_directory)

bind = '127.0.0.1:8061'.format(path=parent_directory)
timeout = 120
workers = multiprocessing.cpu_count() * 2 + 1
preload_app = True
proc_name = 'b2b_python_api'

files_to_create = [accesslog, errorlog]
for log_file in files_to_create:
    open(log_file, "wb").close()
