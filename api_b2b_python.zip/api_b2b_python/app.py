#!/usr/bin/env python
import optparse
import os
import sys

from celery import Celery
from elasticapm.contrib.flask import ElasticAPM
from flask import Flask, g
from flask_apidoc import ApiDoc
from flask_caching import Cache
from flask_compress import Compress
from flask_jwt_extended import JWTManager
from flask_mongoengine import MongoEngine
from flask_profiler import Profiler

from app_configurations_white_label.app_environments import DevelopmentConfig
from app_configurations_white_label.settings import api_prefix

app = None
celery = None
compress = Compress()
profiler = Profiler()


def make_celery(app, backup_broker=False):
    """
    Configure celery module.
    :param backup_broker: boolean for backup_broker
    :param app:
    :return: celery instance
    """
    def create_celery_backup_db():
        if app.config.get('CELERY_BROKER_FOLDER', ''):
            if not os.path.exists(app.config.get('CELERY_BROKER_FOLDER')):
                os.mkdir(app.config.get('CELERY_BROKER_FOLDER'))
        app.config['CELERY_BACKUP_DB'] = '{folder}/{file}'.format(
            folder=app.config.get('CELERY_BROKER_FOLDER', os.getcwd()),
            file=app.config['CELERY_BACKUP_DB']
        )

    def broker_settings(broker_key='', broker_transport_options_key=''):
        broker = app.config.get(broker_key, '')
        if 'filesystem' in broker:
            for folder_key, folder in app.config.get(broker_transport_options_key, {}).items():
                folder_path = os.path.join(app.config.get('CELERY_BROKER_FOLDER'), folder)
                app.config[broker_transport_options_key][folder_key] = folder_path
                if not os.path.exists(folder_path):
                    os.mkdir(folder_path)
        elif 'sqlite' in broker:
            if '.sqlite' in broker:
                app.config[broker_key] = app.config[broker_key].replace(
                    '///',
                    '///{folder}/'.format(folder=app.config.get('CELERY_BROKER_FOLDER'))
                )

    def backend_settings(backend_key=''):
        backend = app.config.get(backend_key, '')
        if backend:
            if 'sqlite' in backend:
                if '.sqlite' in backend:
                    app.config[backend_key] = app.config[backend_key].replace(
                        '///',
                        '///{folder}/'.format(folder=app.config.get('CELERY_BROKER_FOLDER'))
                    )

    create_celery_backup_db()
    broker_key = 'CELERY_BROKER_URL'
    broker_transport_options_key = 'BROKER_TRANSPORT_OPTIONS'
    if backup_broker:
        broker_key = 'CELERY_BACKUP_BROKER_URL'
        broker_transport_options_key = 'BACKUP_BROKER_TRANSPORT_OPTIONS'
        app.config['BROKER_TRANSPORT_OPTIONS'] = app.config.get(broker_transport_options_key, {})
    broker_settings(broker_key=broker_key, broker_transport_options_key=broker_transport_options_key)
    backend_settings(backend_key='CELERY_RESULT_BACKEND')
    celery = Celery(
        app.import_name,
        backend=app.config['CELERY_RESULT_BACKEND'],
        broker=app.config[broker_key]
    )
    celery.conf.update(app.config)
    TaskBase = celery.Task

    class ContextTask(TaskBase):
        abstract = True

        def __call__(self, *args, **kwargs):
            with app.app_context():
                return TaskBase.__call__(self, *args, **kwargs)
    celery.Task = ContextTask
    return celery


def post_app_signals():
    pass


def make_log_folders(app):
    """
    Makes the log folders
    :param app: current app
    """
    if app.config.get('LOGS_PATH', ''):
        parent_log_folder = app.config.get('LOGS_PATH')
        if not os.path.exists(parent_log_folder):
            os.makedirs(parent_log_folder)
            if app.config.get('ALL_SUBS_LOGS_FOLDERS', ''):
                sub_folder_names = app.config.get('ALL_SUBS_LOGS_FOLDERS', [])
            else:
                from app_configurations_white_label.settings import all_sub_logs_folders
                sub_folder_names = all_sub_logs_folders
            for sub_folder_name in sub_folder_names:  # creating sub folders
                if not os.path.exists(os.path.join(parent_log_folder, sub_folder_name)):
                    os.makedirs(os.path.join(parent_log_folder, sub_folder_name))


def create_app(config_settings=DevelopmentConfig, post_signals=True, backup_broker=False):
    """
    Configure the flask-app.
    :param config_settings: config_settings
    :param post_signals: call post_signals or not
    :param backup_broker: boolean
    :return flask-app
    """
    global app
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_settings)
    cache = Cache(config=app.config)
    try:
        app.config.from_envvar('APPLICATION_SETTINGS')
        if app.config.get("IS_PROD"):
            os.environ["FLASK_ENV"] = "production"
        elif app.config.get("IS_STAGING"):
            os.environ["FLASK_ENV"] = "staging"
        else:
            os.environ["FLASK_ENV"] = "development"
    except RuntimeError:
        pass

    app.url_map.strict_slashes = False
    make_log_folders(app)
    global celery
    celery = make_celery(app, backup_broker=backup_broker)
    compress.init_app(app)
    profiler.init_app(app)
    jwt = JWTManager(app)
    mongo_db = MongoEngine(app)
    cache.init_app(app)
    ApiDoc(app=app, url_path='{api_prefix}/docs/'.format(api_prefix=api_prefix))

    with app.app_context():
        cache.clear()
        g.app = app
        g.celery = celery
        g.mongo_db = mongo_db
        g.jwt = jwt
        g.cache = cache
        # initializing limiter within app_context after cache to avoid issues
        from common_white_label.custom_limiter import CustomLimiter
        limiter = CustomLimiter()
        limiter.init_app(app)
        g.limiter = limiter

        if app.config.get('TOKEN_DECORATOR'):
            from common_white_label.common_helpers import get_function_from_string
            setattr(app, 'token_decorator', get_function_from_string(app.config.get('TOKEN_DECORATOR')).get('func'))
        if app.config.get('API_URL_INIT'):
            from common_white_label.common_helpers import get_function_from_string
            api_urls = get_function_from_string(app.config.get('API_URL_INIT', '')).get('func')
        else:
            from app_configurations_white_label.api_settings import api_urls
            api_urls = api_urls
        api_urls()  # routing initialization
        if post_signals:
            post_app_signals()
    if app.config.get('GENERATE_ALL_APM_LOGS', False):
        ElasticAPM(app)
    return {'app': app, 'celery': celery}


def flask_run(app, default_host="127.0.0.1", default_port="5000"):
    """
    Takes a flask instance and runs it. Parses command-line flags to configure the app.
    """

    # Set up the command-line options
    parser = optparse.OptionParser()
    parser.add_option(
        "-H",
        "--host",
        help="Host of the Flask-app default: {host}".format(host=default_host),
        default=default_host
    )
    parser.add_option(
        "-P",
        "--port",
        help="Port for the Flask-app default: {port}".format(port=default_port),
        default=default_port
    )
    parser.add_option(
        "--nd",
        "--nodebug",
        action="store_false",
        dest="debug",
        help="Disable debug-mode for Flask-app",
        default=app.config['DEBUG']
    )
    options, _ = parser.parse_args()
    app.run(
        debug=options.debug,
        host=options.host,
        port=int(options.port)
    )


if __name__ == '__main__':
    app = create_app()['app']
    flask_run(app)
elif __name__ == 'app':
    if 'celery' in sys.argv[0]:
        if 'backup_broker' in sys.argv:
            app = create_app(post_signals=False, backup_broker=True)['app']
            sys.argv.remove('backup_broker')
        else:
            app = create_app(post_signals=False)['app']
