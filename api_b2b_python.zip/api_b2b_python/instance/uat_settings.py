import os

SECRET_KEY = '8msj459sjs02ns0sks02kks02mskkxncvkdujh'
JWT_SECRET_KEY = 'gtysjwn8d8s92hdfbfutjsjsussh2h2usjsh'
MONGODB_SETTINGS = {'host': 'mongodb://mongostuser:edawoletYrI1M6QM1V@134.213.252.56:22222/entertainer'}

sql_user = 'uat_api_qpf_jsc'
sql_password = 'nuonDymQ0U3SdoIySrWB'
sql_host = 'te-uat-rds.cluster-cs6ndhrqo5f6.eu-west-1.rds.amazonaws.com'
sql_port = '3306'

default_db_name = 'entertainer_web'
consolidation_db_name = 'consolidation'
informatica_db_name = 'informatica'
IS_SWAGGER_ON = False

DB_CONFIG = {
    "database": default_db_name,
    "user": sql_user,
    "host": sql_host,
    "password": sql_password,
    "port": sql_port
}
BACKUP_DB_CONFIG = {
    "database": default_db_name,
    "user": 'etainer_clone',
    "host": '52.5.167.245',
    "password": '3jCa#NY6g$jHJ'
}
CONSOLIDATION_DB_CONFIG = {
    "database": consolidation_db_name,
    "user": sql_user,
    "host": sql_host,
    "password": sql_password,
    "port": sql_port
}

INFORMATICA_DB_CONFIG = {
    "database": informatica_db_name,
    "user": sql_user,
    "host": sql_host,
    "password": sql_password,
    "port": sql_port
}

GAMIFICATION_CONFIG = {
    'user': 'creativity',
    'password': 'HwJnm5_QP29ww_v6F7W'
}

SQL_DB_CONFIG = DB_CONFIG
SQL_BACKUP_DB_CONFIG = BACKUP_DB_CONFIG
SQL_CONSOLIDATION_DB_CONFIG = CONSOLIDATION_DB_CONFIG
SQL_INFORMATICA_DB_CONFIG = INFORMATICA_DB_CONFIG

NEW_CART_URL = "https://entcartut.theentertainerme.com/products2019?et=1&utm_source=app&utm_medium=cart-icon&utm_campaign=cart_icon_app_gbl"  # noqa: E501
KALIGO_SIGN_IN_API_ENDPOINT = "https://theentertainer.kaligo.com/whitelabel/entertainer/sign_in"
KALIGO_ENCRYPTION_KEY = "7tgb4mv5d4yll0c6"
ENTERTAINER_GAMIFICATION_URL = "https://api.theentertainerme.com/gamify/web/v2/"

DEBUG = False
ENCRYPT_RESPONSE = False
IS_STAGING = True
FLASK_PROFILER_ENABLED = False

GAMIFICATION_URL = "https://api.theentertainerme.com/gamify/web/v2/"

MONGO_ERROR_LOG_URL = "https://api.theentertainerme.com/api_analytics/web/v1/error/api/log"
REFERRAL_URL = "https://entcartut.theentertainerme.com/site/connectreferralsignupnew/?_t=r&_i="
CONNECT_URL = "https://entcartut.theentertainerme.com/site/connectreferral/?_t=c&_i="
ENTERTAINER_GAMIFICATION_ENVIRONMENT = "Production"

APP_BOY_FEEDER_URL = "http://api.theentertainerme.com/appboy_feeder/Main/process_info"

REDEMPTION_ENDPOINT = "https://api.theentertainerme.com/api_entertainer/web/v64/redemptions"
REDEMPTION_ENDPOINT_URL = 'https://api.theentertainerme.com/api_entertainer/web/v{version}/{end_point}'

REDEMPTION_ENDPOINT_V51 = "https://api.theentertainerme.com/api_consolidation/web/v51/redemptions"
REDEMPTION_ENDPOINT_V22 = "https://api.theentertainerme.com/api_consolidation/web/v22/redemptions"

API_ENDPOINT = "https://api.theentertainerme.com/api_entertainer/web/{version}/{controller}"
PASSWORD_RESET_URL = "https://entcartut.theentertainerme.com/resetpassword?token="
EMAIL_VERIFICATION_URL = "https://entcartut.theentertainerme.com/verify-email?__e="
BUY_PAGE_URL = 'https://entcartut.theentertainerme.com/buy/checkout'
BASIC_AUTH_ENABLED = True
FLASK_PROFILER = {
    "enabled": FLASK_PROFILER_ENABLED,
    "storage": {
        "engine": "mongodb",
        "MONGO_URL": MONGODB_SETTINGS['host'].replace('entertainer', 'admin'),
        "DATABASE": "entanalytics",
        "COLLECTION": "flask_profiler_python_api"
    },
    "basicAuth": {
        "enabled": FLASK_PROFILER_ENABLED,
        "username": 'prototype',
        "password": 'prototype'

    },
    "ignore": [
        "^/static/.*"
    ]
}

REDEMPTION_ENDPOINT_FOR_OFFLINE = "https://api.theentertainerme.com/api_entertainer/web/vo64/redemptions"
IS_DEV = False
rabbit_mq_broker_url = 'amqp://guest:guest@127.0.0.1:5672/'

CACHE_REDIS_URL = 'redis://te-st-redis.7e8iah.ng.0001.euw1.cache.amazonaws.com:6379'
CELERY_BROKER_URL = CACHE_REDIS_URL
# CELERY_BACKUP_BROKER_URL = filesystem from app_environments
CELERY_RETRY_TIME = 300
# Flask Cache attributes
CACHE_KEY_PREFIX = 'STAGE'
CACHE_TYPE = 'filesystem'
present_directory = os.getcwd()
CACHE_DIR = '{present_directory}/.entertainer_cache'.format(present_directory=present_directory)
# CACHE_REDIS_HOST = '134.213.138.68'
# CACHE_REDIS_PORT = 6379
# CACHE_REDIS_PASSWORD = 'wxE0vr626XXL4NQvuOEU'

D_CART_URL = "https://entcartut.theentertainerme.com/delivery"

ELASTIC_SEARCH_URL = "https://fuzzy.theentertainerme.com/entertainer_en/data_en/_search"
ELASTIC_SEARCH_BASE_URL = "http://127.0.0.1:9222"
ELASTIC_SEARCH_IS_ON = True

# TODO need to add this param in prod instance
FAQS_WEB_URL = "https://www.theentertainerme.com/{company}-FAQs"

GENERATE_APM_ERROR_LOGS = True
GENERATE_ALL_APM_LOGS = True
ELASTIC_APM = {
    'SERVICE_NAME': 'Public Api UAT Node',
    'SECRET_TOKEN': '',
    'SERVER_URL': 'http://10.1.12.53:8200',
    'AUTO_LOG_STACKS': False,
    'SERVER_TIMEOUT': 1,
    "METRICS_INTERVAL": "0s",
    "METRICS_SETS": [],
    'PROCESSORS': (
        'common_white_label.flask_elastic_apm.apm_cutom_span_filter_processor',
        'elasticapm.processors.sanitize_stacktrace_locals',
        'elasticapm.processors.sanitize_http_request_cookies',
        'elasticapm.processors.sanitize_http_headers',
        'elasticapm.processors.sanitize_http_wsgi_env',
        'elasticapm.processors.sanitize_http_request_querystring',
        'elasticapm.processors.sanitize_http_request_body'
    )
}

LIMIT_SCOPE = 'public_api_uat_node'
RATELIMIT_STORAGE_URL = CACHE_REDIS_URL
RATELIMIT_STRATEGY = 'moving-window'

PHP_WL_BASE_URL = 'https://entutapi.theentertainerme.com'
