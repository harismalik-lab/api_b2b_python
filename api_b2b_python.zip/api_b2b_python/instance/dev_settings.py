import os

SECRET_KEY = '8msj459sjs02ns0sks02kks02mskkxncvkdujh'
JWT_SECRET_KEY = 'gtysjwn8d8s92hdfbfutjsjsussh2h2usjsh'
MONGODB_SETTINGS = {'host': 'mongodb://mongostuser:edawoletYrI1M6QM1V@134.213.252.56:22222/entertainer'}
sql_user = 'gen_dv_api_rgc'
sql_password = 'F7xnPVIRJlip8VWnb3'
sql_host = os.environ.get('STAGING_LOCAL_HOST', 'te-dev-rds.cluster-cx9bkl0httv4.eu-west-1.rds.amazonaws.com')
sql_port = os.environ.get('STAGING_LOCAL_PORT', '3306')

default_db_name = 'entertainer_web'
consolidation_db_name = 'consolidation'
informatica_db_name = 'informatica'
IS_SWAGGER_ON = False

DB_CONFIG = {
    "database": default_db_name,
    "user": sql_user,
    "host": sql_host,
    "password": sql_password,
    "port": sql_port
}
BACKUP_DB_CONFIG = {
    "database": default_db_name,
    "user": 'etainer_clone',
    "host": '52.5.167.245',
    "password": '3jCa#NY6g$jHJ'
}
CONSOLIDATION_DB_CONFIG = {
    "database": consolidation_db_name,
    "user": sql_user,
    "host": sql_host,
    "password": sql_password,
    "port": sql_port
}

INFORMATICA_DB_CONFIG = {
    "database": informatica_db_name,
    "user": sql_user,
    "host": sql_host,
    "password": sql_password,
    "port": sql_port
}

GAMIFICATION_CONFIG = {
    'user': 'creativity',
    'password': 'HwJnm5_QP29ww_v6F7W'
}

SQL_DB_CONFIG = DB_CONFIG
SQL_BACKUP_DB_CONFIG = BACKUP_DB_CONFIG
SQL_CONSOLIDATION_DB_CONFIG = CONSOLIDATION_DB_CONFIG
SQL_INFORMATICA_DB_CONFIG = INFORMATICA_DB_CONFIG
NEW_CART_URL = "https://dventawsm.etenvbiz.com/products2019?et=1&utm_source=app&utm_medium=cart-icon&utm_campaign=cart_icon_app_gbl"  # noqa
KALIGO_SIGN_IN_API_ENDPOINT = "https://entertainer.kaligo-staging.xyz/whitelabel/entertainer/sign_in"
KALIGO_ENCRYPTION_KEY = "89d20b535d8afa50"
ENTERTAINER_GAMIFICATION_URL = "https://dventawsm.etenvbiz.com/gamify/web/v2/"
DEBUG = False
ENCRYPT_RESPONSE = False
IS_STAGING = True
FLASK_PROFILER_ENABLED = False
ELASTIC_SEARCH_URL = "http://fuzzy.theentertainerme.com:9222/entertainer_en/data_en/_search"
GAMIFICATION_URL = "https://entqaapi.etenvbiz.com/gamify/web/v2/"
ELASTIC_SEARCH_IS_ON = False
MONGO_ERROR_LOG_URL = "http://apistaging.theentertainerme.com/api_analytics/web/public_api/error/api/log"
REFERRAL_URL = "https://entqacart.etenvbiz.com/site/connectreferralsignupnew/?_t=r&_i="
CONNECT_URL = "https://entqacart.etenvbiz.com/site/connectreferral/?_t=c&_i="
ENTERTAINER_GAMIFICATION_ENVIRONMENT = "Staging"
APP_BOY_FEEDER_URL = "http://api.theentertainerme.com/appboy_feeder/Main/process_info"
REDEMPTION_ENDPOINT_V51 = "http://apistaging.theentertainerme.com/api_consolidation/web/v51/redemptions"
REDEMPTION_ENDPOINT_V22 = "http://apistaging.theentertainerme.com/api_consolidation/web/v22/redemptions"
REDEMPTION_ENDPOINT = "http://apistaging.theentertainerme.com/api_consolidation/web/v20/redemptions"
API_ENDPOINT = "http://pyapi.theentertainerme.com:8086/api_consolidation/web/{version}/{controller}"
PASSWORD_RESET_URL = "https://dventawsm.etenvbiz.com/resetpassword?token="
EMAIL_VERIFICATION_URL = "https://dventawsm.etenvbiz.com/verify-email?__e="
BUY_PAGE_URL = 'https://dventawsm.etenvbiz.com/buy/checkout'
BASIC_AUTH_ENABLED = True
FLASK_PROFILER = {
    "enabled": FLASK_PROFILER_ENABLED,
    "storage": {
        "engine": "mongodb",
        "MONGO_URL": MONGODB_SETTINGS['host'].replace('entertainer', 'admin'),
        "DATABASE": "entanalytics",
        "COLLECTION": "flask_profiler_python_api"
    },
    "basicAuth": {
        "enabled": FLASK_PROFILER_ENABLED,
        "username": 'prototype',
        "password": 'prototype'

    },
    "ignore": [
        "^/static/.*"
    ]
}
REDEMPTION_ENDPOINT_FOR_OFFLINE = "http://54.224.103.36:8086/api_consolidation/web/vo59/redemptions"
IS_DEV = False
rabbit_mq_broker_url = 'amqp://guest:guest@127.0.0.1:5672/'
redis_broker_url = 'redis://te-dev-redis.hdd3kc.0001.euw1.cache.amazonaws.com:6379'
CELERY_BROKER_URL = redis_broker_url
# CELERY_BACKUP_BROKER_URL = filesystem from app_environments
CELERY_RETRY_TIME = 300
# Flask Cache attributes
CACHE_KEY_PREFIX = 'STAGE'
CACHE_TYPE = 'filesystem'
present_directory = os.getcwd()
CACHE_DIR = '{present_directory}/.public_api_cache'.format(present_directory=present_directory)
# CACHE_REDIS_HOST = '134.213.138.68'
# CACHE_REDIS_PORT = 6379
# CACHE_REDIS_PASSWORD = 'wxE0vr626XXL4NQvuOEU'
D_CART_URL = "https://dventawsm.etenvbiz.com/delivery"
ELASTIC_SEARCH_BASE_URL = "http://127.0.0.1:9222"
# TODO need to add this param in prod instance
FAQS_WEB_URL = "https://dventawsm.etenvbiz.com/{company}-FAQs"

GENERATE_APM_ERROR_LOGS = False
GENERATE_ALL_APM_LOGS = False
ELASTIC_APM = {
    'SERVICE_NAME': 'Public Api Dev Node',
    'SECRET_TOKEN': '',
    'SERVER_URL': 'http://10.1.12.53:8200',
    'AUTO_LOG_STACKS': False,
    'SERVER_TIMEOUT': 1,
    "METRICS_INTERVAL": "0s",
    "METRICS_SETS": [],
    'PROCESSORS': (
        'common_white_label.flask_elastic_apm.apm_cutom_span_filter_processor',
        'elasticapm.processors.sanitize_stacktrace_locals',
        'elasticapm.processors.sanitize_http_request_cookies',
        'elasticapm.processors.sanitize_http_headers',
        'elasticapm.processors.sanitize_http_wsgi_env',
        'elasticapm.processors.sanitize_http_request_querystring',
        'elasticapm.processors.sanitize_http_request_body'
    )
}

LIMIT_SCOPE = 'public_api_dev_node'
RATELIMIT_STORAGE_URL = redis_broker_url
RATELIMIT_STRATEGY = 'moving-window'

PHP_WL_BASE_URL = 'https://dventapi.etenvbiz.com'
