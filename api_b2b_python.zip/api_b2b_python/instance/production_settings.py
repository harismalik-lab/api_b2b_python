BUY_PAGE_URL = 'https://www.theentertainerme.com/buy/checkout'
APP_BOY_FEEDER_URL = "http://api.theentertainerme.com/appboy_feeder/Main/process_info"
PHP_WL_BASE_URL = 'https://api.theentertainerme.com'
