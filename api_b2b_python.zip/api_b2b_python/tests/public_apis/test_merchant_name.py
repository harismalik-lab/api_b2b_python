"""
Test merchant name Api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestMerchantNameApi(object):
    """
    Test merchant name Api.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            '__i': 5394674,
            '__platform': 'ios',
            '__sid': 20171657,
            'app_version': 2.0,
            'language': 'en',
            'location_id': 2,
            'session_token': '12778574965c2482724673e8.15855751',
            'wlcompany': 'maf',
            'merchant_id': 7585,
            'offer_id': 68141
        }

    @pytest.mark.order1
    def test_get_merchant_name_with_valid_response(self, client, request_data):
        """
        Test the merchant name endpoint with for 200 response.
        """
        response = client.get(url_for_api_version(endpoint='merchant-name', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert len(response_data['data']) > 0
        assert response_data['data']['merchant_name']['name'] == 'Dai Pai Dong'
        assert response_data['data']['offer_name']['name'] == "Main Course"

    @pytest.mark.order2
    def test_get_merchant_name_endpoint_validation_error(self, client, request_data):
        """
        Test the merchant name api with missing merchant_id param.
        """
        del request_data['merchant_id']
        response = client.get(url_for_api_version(endpoint='merchant-name', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "merchant_id: missing required parameter"
