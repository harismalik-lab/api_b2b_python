"""
Test Login Message Api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestLoginMessageApi(object):
    """
    Test Login Message Api working will valid and invalid parameters.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {'language': 'en', 'wlcompany': 'kel'}

    @pytest.mark.order1
    def get_login_message_with_valid_response(self, client, request_data):
        """
        Test the login_message endpoint with for 200 response.
        """
        response = client.get(
            url_for_api_version(
                endpoint='login-message-api',
                version=self.version
            ),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['message'] == 'Please go to http://kelloggsentertainer.com/ to register your Kelloggs key.'

    @pytest.mark.order2
    def get_login_message_with_validation_error(self, client, request_data):
        """
        Test the login_message endpoint with no company parameter.
        """
        del request_data['wlcompany']
        response = client.get(
            url_for_api_version(
                endpoint='login-message-api',
                version=self.version
            ),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "wlcompany: missing required parameter"
