"""
Test Feed AppBoy Api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestFeedAppBoyApi(object):
    """
    Test Feed AppBoy Api.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'user_id': '172451',
            '__platform': 'ios',
            'wlcompany': 'maf'
        }

    @pytest.mark.order1
    def test_feed_appboy_with_valid_response(self, client, request_data):
        """
        Test feed appboy endpoint with for 200 response.
        """
        response = client.post(url_for_api_version(endpoint='feed-app-boy', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert len(response_data['data']) > 0
        assert response_data['data']['is_fed_successfully']

    @pytest.mark.order2
    def test_feed_appboy_endpoint_validation_error(self, client, request_data):
        """
        Test feed appboy missing user_id param.
        """
        del request_data['user_id']
        response = client.post(url_for_api_version(endpoint='feed-app-boy', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "user_id: missing required parameter"
