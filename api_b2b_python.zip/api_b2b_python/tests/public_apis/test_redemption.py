"""
Test redemption Api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestRedemptionApi(object):
    """
    Unit Test for redemption Api
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'language': 'en',
            '__lat': '31.484112',
            'wlcompany': 'maf',
            'transaction_id': 'ios-1545896100-5745628-266839-61780',
            'app_version': 2.0,
            'offer_id': 729061,
            'merchant_pin': 9999,
            'lng': 74.39314716502501,
            '__platform': 'ios',
            'currency': 'USD',
            'session_token': '12778574965c2482724673e8.15855751',
            'location_id': 2,
            'quantity': 1,
            'is_reattempt': 0,
            'product_id': 7415,
            'is_shared': 0,
            'os_version': '11.1.1',
            'is_delivery': True,
            'lat': '31.484112152859087',
            '__lng': 74.393147,
            'outlet_id': 26977,
            'time_zone': 'Asia/Karachi',
            'device_model': 'iPhone6S'
        }

    @pytest.mark.order1
    def test_post_redemption_with_valid_response(self, client, request_data):
        """
        Test the redemption endpoint with for 200 response.
        """
        response = client.post(url_for_api_version(endpoint='redemption', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['message'] == 'success'
        assert response_data['data']
        assert response_data['data'].get('referenceNo')
        assert response_data['data'].get('referenceNo').get('redemption_code') == response_data['code']

    @pytest.mark.order2
    def test_post_redemption_with_invalid_pin(self, client, request_data):
        """
        Test redemption endpoint with wrong merchant param.
        """
        request_data['merchant_pin'] = 1234
        response = client.post(url_for_api_version(endpoint='redemption', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 422
        assert response_data['message'] == "Invalid merchant PIN"
