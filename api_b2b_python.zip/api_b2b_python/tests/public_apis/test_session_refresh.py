"""
Test Session Refresh Api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestSessionRefreshApi(object):
    """
    Tests class for session refresh api to validate 200 and 400 responses.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'wlcompany': 'HS',
            'customer_id': '5757903'
        }

    @pytest.mark.order1
    def test_get_session_refresh_with_valid_response(self, client, request_data):
        """
        Test the session refresh endpoint with for 200 response.
        """
        response = client.get(url_for_api_version(
            endpoint='user-session-refresh',
            version=self.version),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert response_data['data'] == []

    @pytest.mark.order2
    def test_get_session_refresh_endpoint_validation_error(self, client, request_data):
        """
        Test the session refresh missing app_version param.
        """
        del request_data['wlcompany']
        response = client.get(url_for_api_version(
            endpoint='user-session-refresh',
            version=self.version),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "wlcompany: missing required parameter"
