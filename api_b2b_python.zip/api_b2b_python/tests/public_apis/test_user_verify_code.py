"""
Test User Verify Code Api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestUserVerifyCodeApi(object):
    """
    Test User Verify Code Api.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'user_id': 1549860,
            'email': 'naeem@duotpqa.com',
            'phone_number': '971528657430',
            'verification_code': 99999,
            'wlcompany': 'DUE'
        }

    @pytest.mark.order1
    def test_post_user_verify_code_with_valid_response(self, client, request_data):
        """
        Test the user verify code endpoint with for 200 response.
        """
        response = client.post(url_for_api_version(endpoint='verify-code-api', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert len(response_data['data']) > 0
        response_data['data'] = response_data['data']
        assert response_data['data']['is_code_verified'] == False  # noqa: E712
        assert response_data['data']['response_code_for_code_verification'] == 3
        assert response_data['data']['message'] == "Invalid code entered"

    @pytest.mark.order2
    def test_post_user_verify_code_endpoint_validation_error(self, client, request_data):
        """
        Test the user verify code api with missing wl_company param.
        """
        del request_data['wlcompany']
        response = client.post(url_for_api_version(endpoint='verify-code-api', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "wlcompany: missing required parameter"
