"""
Test cheers configs Api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestCheersConfigsApi(object):
    """
    Test cheers config Api.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            '__platform': 'ios',
            'app_version': '2.0',
            'language': 'en',
            'wlcompany': 'maf'
        }

    @pytest.mark.order1
    def test_get_cheers_configs_with_valid_response(self, client, request_data):
        """
        Test the cheers config endpoint with for 200 response.
        """
        response = client.get(url_for_api_version(endpoint='cheers_configs', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert len(response_data['data']) > 0
        response_data['data']['cheers_rules'] = response_data['data']['cheers_rules'][0]
        assert response_data['data']['cheers_rules']['id'] == 4
        assert response_data['data']['cheers_rules']['location_id'] == 1
        assert response_data['data']['cheers_rules']['product_id'] == 1970
        assert response_data['data']['cheers_rules']['product_sku'] == "D17DBCH"
        assert response_data['data']['cheers_rules']['category_id'] == 1
        assert response_data['data']['cheers_rules']['category'] == "Food & Drink"
        assert response_data['data']['cheers_rules']['api_name'] == "Restaurants and Bars"
        assert response_data['data']['cheers_rules']['age_limit'] == 21

    @pytest.mark.order2
    def test_get_cheers_configs_endpoint_validation_error(self, client, request_data):
        """
        Test the cheers configs missing wl_company.
        """
        del request_data['wlcompany']
        response = client.get(url_for_api_version(endpoint='cheers_configs', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "wlcompany: missing required parameter"
