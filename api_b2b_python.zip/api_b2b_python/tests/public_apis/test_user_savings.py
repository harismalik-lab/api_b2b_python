"""
Test User Savings Api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestUserSavingsApi(object):
    """
    Unit Test for User Savings Api.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'wlcompany': 'hs',
            '__platform': 'ios',
            'app_version': '1.2',
            'session_token': '10630945455bed7c84f39460.31284469',
            'location_id': '1'
        }

    @pytest.mark.order1
    def test_get_user_savings_with_valid_response(self, client, request_data):
        """
        Test the user savings endpoint with for 200 response.
        """
        response = client.get(
            url_for_api_version(endpoint='users-savings', version=self.version, user_id=5746457),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert response_data['data']['current_year'] == "2019"
        assert response_data['data']['yearly_savings'] == 0
        assert response_data['data']['savings'] == 0

    @pytest.mark.order2
    def test_get_user_savings_endpoint_validation_error(self, client, request_data):
        """
        Test the user savings api with missing wl_company param.
        """
        del request_data['__platform']
        response = client.get(
            url_for_api_version(endpoint='users-savings', version=self.version, user_id=5746457),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "__platform: missing required parameter"
