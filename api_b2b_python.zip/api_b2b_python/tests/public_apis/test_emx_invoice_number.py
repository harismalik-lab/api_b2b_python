"""
Test Emax invoice number
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestEmaxInvoiceApi(object):
    """
    Test emx invoice number api for 200 response and a validation error check.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'wlcompany': 'emx',
            'invoice_number': 'CCINV-2800541861',
            '__platform': 'ios',
            'app_version': 2.0,
            'language': 'en',
            'session_token': '59109081125c6176cf9fae98.61347769'
        }

    @pytest.mark.order1
    def test_get_emx_invoice_number_with_valid_response(self, client, request_data):
        """
        Test the emx invoice number endpoint with for 200 response.
        """
        response = client.post(url_for_api_version(endpoint='emx-invoice-number', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert response_data['message'] == "Uh oh!\n\n This Emax Code is already used!"
        assert not response_data['data']['validation_status']
        assert response_data["cmd"] == "/et_rs_prd/wl/v1/invoice_number?"

    @pytest.mark.order2
    def test_get_emx_invoice_endpoint_validation_error(self, client, request_data):
        """
        Test the emx endpoint with missing invoice number param
        """
        del request_data['invoice_number']
        response = client.post(url_for_api_version(endpoint='emx-invoice-number', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "invoice_number: missing required parameter"
