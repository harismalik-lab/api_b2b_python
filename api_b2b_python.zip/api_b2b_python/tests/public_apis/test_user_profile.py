"""
Test User Profile Api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestUserProfileApi(object):
    """
    Test user profile Api with valid and missing params.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'language': 'en',
            '__platform': 'ios',
            'app_version': '2.1',
            'location_id': '1',
            'wlcompany': 'HS',
            'session_token': '12149175335c540fed728560.73397043',
        }

    @pytest.mark.order1
    def test_get_user_profile_with_valid_response(self, client, request_data):
        """
        Test the user profile endpoint with for 200 response.
        """
        response = client.get(url_for_api_version(endpoint='user-profile', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert len(response_data['data']) > 0
        assert response_data['data']['first_name'] == 'Adeel'
        assert response_data['data']['last_name'] == 'Saeed'
        assert response_data['data']['savings_lifetime_int'] == 0
        assert response_data['data']['user_id'] == 5757903
        assert response_data['data']['currency'] == 'AED'
        assert response_data['data']['email'] == 'testqaadeel89+voda2@gmail.com'
        assert response_data['data']['about_me'] == ""

    @pytest.mark.order2
    def test_get_user_profile_endpoint_validation_error(self, client, request_data):
        """
        Test the user profile missing wlcompany param.
        """
        del request_data['wlcompany']
        response = client.get(url_for_api_version(endpoint='user-profile', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "wlcompany: missing required parameter"
