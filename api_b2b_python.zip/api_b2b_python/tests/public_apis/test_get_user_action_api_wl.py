"""
Test Get User action Api.
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestGetUserActionApiWl(object):
    """
    Unit Test for Get User Action API.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'wlcompany': 'hs',
            'session_token': 'f4701d9a-b3dd-444f-b147-149ca04d1034',
            '__platform': 'ios',
            'location_id': 1,
            'language': 'en',
            'app_version': '2.0',
        }

    @pytest.mark.order1
    def test_get_user_action_with_valid_response(self, client, request_data):
        """
        Test the get user action endpoint for 200 response.
        """
        response = client.get(url_for_api_version(
            endpoint='get-user-action',
            version=self.version,
            user_id=6747612),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert response_data['data']['membership_code'] == "M19PK067476121"

    @pytest.mark.order2
    def test_get_user_action_with_invalid_response(self, client, request_data):
        """
        Test the get user action endpoint for 400 response.
        """
        del request_data['app_version']
        response = client.get(url_for_api_version(
            endpoint='get-user-action',
            version=self.version,
            user_id=6747612),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == 'app_version: missing required parameter'
