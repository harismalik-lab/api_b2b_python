"""
Test Country Api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestCountryApi(object):
    """
    Test Country Api.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            '__i': 1312170,
            'language': 'en',
            'session_token': '6573971705bfbf8a09575d9.67949037',
            'wlcompany': 'hkl',
            'istravel': False
        }

    @pytest.mark.order1
    def test_get_country_with_valid_response(self, client, request_data):
        """
        Test the country endpoint with for 200 response.
        """
        response = client.get(url_for_api_version(endpoint='country', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert len(response_data['data']) > 0
        response_data['data']['countries'] = response_data['data']['countries'][0]
        assert response_data['data']['countries']['id'] == 18
        assert response_data['data']['countries']['shortname'] == "BH"
        assert response_data['data']['countries']['name'] == "Bahrain"
        assert response_data['data']['countries']['position'] == 1

    @pytest.mark.order2
    def test_get_country_enpoint_validation_error(self, client, request_data):
        """
        Test the country api with missing wl_company param.
        """
        del request_data['wlcompany']
        response = client.get(url_for_api_version(endpoint='country', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "wlcompany: missing required parameter"
