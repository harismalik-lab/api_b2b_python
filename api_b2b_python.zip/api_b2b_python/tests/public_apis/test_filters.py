"""
Test Filters Api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestFiltersApi(object):
    """
    Test Filters Api.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            '__platform': 'ios',
            'app_version': '2.0',
            'language': 'en',
            'wlcompany': 'maf'
        }

    @pytest.mark.order1
    def test_get_filters_with_valid_response(self, client, request_data):
        """
        Test the filters endpoint with for 200 response.
        """
        response = client.get(url_for_api_version(endpoint='filters', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert len(response_data['data']) > 0
        response_data['data'] = response_data['data'][0]
        response_data['data']['filter_sections'] = response_data['data']['filter_sections'][0]
        response_data['data']['filter_sections']['options'] = response_data['data']['filter_sections']['options'][0]
        assert response_data['data']['filter_sections']['options']['uid'] == "0_Body_All"
        assert response_data['data']['filter_sections']['options']['key'] == "All"
        assert response_data['data']['filter_sections']['options']['name'] == "All"
        assert not response_data['data']['filter_sections']['has_icons']
        assert not response_data['data']['filter_sections']['collapsible']
        assert response_data['data']['filter_sections']['category_id'] == 1
        assert response_data['data']['filter_sections']['selection_type'] == 1
        assert response_data['data']['filter_sections']['section_order_id'] == 1
        assert response_data['data']['filter_sections']['section_name'] == 'Type'

    @pytest.mark.order2
    def test_get_filters_endpoint_validation_error(self, client, request_data):
        """
        Test the filters missing app_version param.
        """
        del request_data['app_version']
        response = client.get(url_for_api_version(endpoint='filters', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "app_version: missing required parameter"
