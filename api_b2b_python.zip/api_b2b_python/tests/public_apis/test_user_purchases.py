"""
Test Get User Purchases Api.
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestGetUserPurchasesWl(object):
    """
    Test Get User Purchases Api.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'wlcompany': 'hs',
            'session_token': '788903125bdaaa50c00370.31917650',
            '__platform': 'ios',
            'location_id': 1,
            'app_version': '2.0',
        }

    @pytest.mark.order1
    def test_get_user_purchases_with_valid_response(self, client, request_data):
        """
        Test user purchases endpoint for 200 response.
        """

        response = client.get(url_for_api_version(
            endpoint='user-purchases',
            version=self.version,
            user_id=220364),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']

    @pytest.mark.order2
    def test_get_user_purchases_with_invalid_response(self, client, request_data):
        """
        Test user purchases endpoint for 400 response.
        """
        del request_data['app_version']
        response = client.get(url_for_api_version(
            endpoint='user-purchases',
            version=self.version,
            user_id=220364),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == 'app_version: missing required parameter'
