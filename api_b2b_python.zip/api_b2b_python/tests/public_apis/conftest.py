import pytest


@pytest.fixture(scope='session')
def app(request):
    from app import create_app
    app = create_app(config_settings='app_configurations_white_label.app_environments.TestingConfig')['app']
    ctx = app.app_context()
    ctx.push()

    def teardown():
        ctx.pop()

    request.addfinalizer(teardown)
    return app


@pytest.fixture(scope='session')
def client(app):
    return app.test_client()

#
# @pytest.fixture(scope='session')
# def logged_in_customer(client):
#     data = {
#         "email": "testqamsd+h01@gmail.com",
#         "device_model": "OPPO F1s",
#         "__platform": "android",
#         "password": "123456",
#         "device_os": "nokia"
#     }
#     from common.common_helpers import url_for_api_version
#     response = client.post(url_for_api_version(endpoint='sessions', version=59), data=data)
#     response_data = json.loads(response.get_data().decode('utf8'))
#     session_id = response_data["data"]["validation_params"]["__sid"]
#     session_token = response_data["data"]["validation_params"]["session_token"]
#     __i = response_data["data"]["validation_params"]["__i"]
#     data = {
#         "__sid": session_id,
#         "__i": __i,
#         'user_id': __i,
#         'session_token': session_token,
#         'currency': "AED",
#         'app_version': '5.9.02',
#         'category': 'Restaurants and Bars',
#         'company': 'entertainer',
#         'device_key': 'ios-' + str(uuid.uuid4()),
#         'device_model': 'Simulator',
#         'include_featured': 1,
#         'language': 'en',
#         'location_id': 1,
#         'offset': 0,
#         'outlet_limit': 60,
#         'redeemability': 'redeemable_reusable',
#         'sort': 'default',
#         'query': 'lake',
#         '__platform': 'ios',
#         'os': 'ios',
#         'new_cart_url': 'abc@theentertainerme.com',
#         'entry_id': '10015383658cfe39d031688.59103990',
#         'status': 0,
#         'offer_id[]': '2042',
#         'email': 'this@gmail.com',
#         "app_action_id": 137,
#         "key": "key",
#         "points": 10
#     }
#     return data
