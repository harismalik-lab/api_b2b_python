"""
Test user gem points summary api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestUserGemPointSummaryApi(object):
    """
    Test Cases for validation of User gems points summary api.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'language': 'en',
            '__platform': 'ios',
            'session_token': 'a1c9db72-88e2-499e-9c6d-cc1d83769648',
            'wlcompany': 'hs',
            'istravel': True,
            'location_id': 1,
            'app_version': 1.2,
            'currency': '',
            'build_no': 1,
            'summary_type': 'by_month'
        }

    @pytest.mark.order1
    def test_user_gem_point_summary_with_valid_response_by_month(self, client, request_data):
        """
        Test the user gem point summary endpoint by month with for 200 response.
        """
        response = client.get(
            url_for_api_version(endpoint='user_gems_points_summary_api', version=self.version),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert response_data["cmd"] == '/et_rs_prd/wl/v1/user/gemspoints/summary?language=%20en&__platform=%20ios&session_token=%20a1c9db72-88e2-499e-9c6d-cc1d83769648&wlcompany=%20hs&location_id=%201&app_version=%201.2&currency=%20%27%27&build_no=%201&summary_type=%20by_month'  # noqa:E501

    @pytest.mark.order2
    def test_user_gem_point_summary_with_valid_response_by_year(self, client, request_data):
        """
        Test the user gem point summary endpoint by year with for 200 response.
        """
        request_data['summary_type'] = 'by_year'
        response = client.get(
            url_for_api_version(endpoint='user_gems_points_summary_api', version=self.version),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert response_data["cmd"] == '/et_rs_prd/wl/v1/user/gemspoints/summary?language=%20en&__platform=%20ios&session_token=%20a1c9db72-88e2-499e-9c6d-cc1d83769648&wlcompany=%20hs&location_id=%201&app_version=%201.2&currency=%20%27%27&build_no=%201&summary_type=%20by_year'  # noqa:E501

    @pytest.mark.order3
    def test_user_gem_point_history_with_invalid_response(self, client, request_data):
        """
        Test the user gem point summary endpoint with missing required param.
        """
        del request_data['wlcompany']
        response = client.get(
            url_for_api_version(endpoint='user-gems-points-summary-api', version=self.version),
            data=request_data
        )
        assert response.status_code == 400
