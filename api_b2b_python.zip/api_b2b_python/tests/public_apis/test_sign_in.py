"""
Test Sign in  Api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestSignInApi(object):
    """
    Sign_in api test cases
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'wlcompany': 'emx',
            'app_version': 1.0,
            'email': 'testqatahir+hspy5@gmail.com',
            '__platform': 'ios',
            'wl_key': 'HSEMX0099',
            'password': 123456,
            'device_model': 'svbjasv',
            'invoice_number': 'C3790724005',
            'invoice_date': '2019-02-13 00:00:00'
        }

    @pytest.mark.order1
    def test_post_sign_in_invoice_number_valid_response(self, client, request_data):
        """
        Test the sign in endpoint with for 200 response.
        """
        response = client.post(url_for_api_version(endpoint='sign-in', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response_data['message'] == 'success'
        assert response.status_code == 200
        assert response_data['success']

    @pytest.mark.order2
    def test_post_sign_in_branch_io_valid_response(self, client, request_data):
        """
        Test the sign in endpoint with for 200 response.
        """
        request_data['wlcompany'] = 'hs'
        del request_data['invoice_number']
        del request_data['invoice_date']
        response = client.post(url_for_api_version(endpoint='sign-in', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response_data['message'] == 'success'
        assert response.status_code == 200
        assert response_data['success']

    @pytest.mark.order3
    def test_post_sign_in_with_valid_response(self, client, request_data):
        """
        Test the sign in endpoint with for 200 response.
        """
        request_data['wlcompany'] = 'hs'
        request_data['using_branch_activation'] = True
        del request_data['invoice_number']
        del request_data['invoice_date']
        response = client.post(url_for_api_version(endpoint='sign-in', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert response_data['message'] == "success"

    @pytest.mark.order4
    def test_post_sign_in_valid_response(self, client, request_data):
        """
        Test the sign in endpoint with for 200 response.
        """
        request_data['wlcompany'] = 'hs'
        request_data['using_branch_activation'] = False
        del request_data['invoice_number']
        del request_data['invoice_date']
        response = client.post(url_for_api_version(endpoint='sign-in', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert response_data['message'] == "success"

    @pytest.mark.order5
    def test_post_validates_endpoint_validation_error(self, client, request_data):
        """
        Test the validates missing wlcompany param.
        """
        del request_data['wlcompany']
        response = client.post(url_for_api_version(endpoint='sign-in', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "wlcompany: missing required parameter"
