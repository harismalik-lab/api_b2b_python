"""
Test for user spend summary api
"""
import json
from datetime import date

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestUserSpendSummaryApi(object):
    """
    Test Cases for validation of User spend summary api.
    """
    version = "1"
    @pytest.fixture()
    def request_data(self):
        return {
            'session_token': '48363016805c6d2fe860be91.39208628',
            '__platform': 'ios',
            'app_version': 2.0,
            'summary_type': 'by_year',
            'currency': 'USD',
            'language': 'en',
            'location_id': 1,
            'wlcompany': 'emx'
        }

    @pytest.mark.order1
    def test_get_user_spend_summary_by_year(self, client, request_data):
        """
        Test user spend summary by year with 200 response
        """
        current_date = date.today()
        response = client.get(url_for_api_version(endpoint='user-spend-summary', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert len(response_data['data']) > 0
        assert set(set(response_data.get('data').keys())) == {
            'currency',
            'current_month',
            'current_month_saving',
            'current_year',
            'graph_data',
            'life_time_saving',
            'progress_data'
        }
        assert response_data['data']['current_year'] == current_date.year
        assert response_data['data']['current_month'] == current_date.strftime("%B")

    @pytest.mark.order2
    def test_unauthorizer_user(self, client, request_data):
        """
        Test user spend summary with unauthorized user and with 403 response
        """
        del request_data['session_token']
        response = client.get(url_for_api_version(endpoint='user-spend-summary', version=self.version), data=request_data)
        assert response.status_code == 403
