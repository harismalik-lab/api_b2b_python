
"""
Test merchant id api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestMerchantIdApiWl(object):
    """
    Unit tests for merchant api for 200 response and validation check
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'wlcompany': 'maf',
            'session_token': '12778574965c2482724673e8.15855751',
            '__platform': 'ios',
            'location_id': 1,
            'app_version': 2,
            'language': 'en',
            'sort': 'default',
            'first_sort_by_redeemability': 0,
            'radius': 0,
            'query': 'Al+Safeer',
            'query_type': 'name',
            'category': 'All',
            'cuisine': 'All',
            'redeemability': 'redeemable_reusable',
            'offset': 0,
            'limit': 60,
            'outlet_limit': 60,
            'currency': 'USD',
            'outlet_id': 0,
            'merchant_id': 16604
        }

    @pytest.mark.order1
    def test_merchant_id_with_valid_response(self, client, request_data):
        """
        Test merchants api for 200 response.
        """
        response = client.get(url_for_api_version(
            endpoint='merchant-id',
            version=self.version,
            merchant_id=request_data.get('merchant_id')),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert response_data['data']['id'] == 16604
        assert response_data['data']['merchant_pin'] == "fa246d0262c3925617b0c72bb20eeb1d"

    @pytest.mark.order2
    def test_merchant_api_with_invalid_response(self, client, request_data):
        """
        Test the merchant endpoint for 400 response.
        """
        del request_data['app_version']
        response = client.get(url_for_api_version(
            endpoint='merchant-id',
            version=self.version,
            merchant_id=request_data.get('merchant_id')),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == 'app_version: missing required parameter'
