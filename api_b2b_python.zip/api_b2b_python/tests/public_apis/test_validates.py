"""
Test Validates Api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestValidatesApi(object):
    """
    Test Validates Api.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'wlcompany': 'HS',
            'language': 'en',
            'email': 'testqasajeel+5dec1@gmail.com',
            'key': '423C23EFF',
            'is_secondary_key': True,
            'afterlogin': False,
            'using_branch_activation': False
        }

    @pytest.mark.order1
    def test_get_validates_with_valid_response(self, client, request_data):
        """
        Test the validates endpoint with for 200 response.
        """
        response = client.post(url_for_api_version(endpoint='validates', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert len(response_data['data']) > 0
        assert response_data['message'] == "you have already activated this key"
        assert response_data['data']['customer_id'] == 0
        assert not response_data['data']['is_customer_exists']
        assert not response_data['data']['validation_status']
        assert not response_data['data']['product_to_purchase']

    @pytest.mark.order2
    def test_get_validates_enpoint_validation_error(self, client, request_data):
        """
        Test the validates missing app_version param.
        """
        del request_data['wlcompany']
        response = client.post(url_for_api_version(endpoint='validates', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "wlcompany: missing required parameter"
