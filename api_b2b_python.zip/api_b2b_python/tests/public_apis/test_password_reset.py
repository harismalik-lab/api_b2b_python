"""
Tests for reset password api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestRestPasswordApi(object):
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            '__platform': 'ios',
            'app_version': '2',
            'language': 'en',
            'wlcompany': 'maf',
            'session_token': '12778574965c2482724673e8.15855751'
        }

    @pytest.mark.order1
    def test_reset_password_with_no_email_argument(self, client, request_data):
        """
        Test having no email in the request
        """
        request_data['email'] = ''
        response = client.post(url_for_api_version(endpoint='password-reset', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 422
        assert response_data == {
            "cmd": "/et_rs_prd/wl/v1/passwords?",
            "success": False,
            "message": "Email address not found.",
            "http_response": 422,
            "code": 55,
            "data": []
        }

    @pytest.mark.order2
    def test_reset_password_with_invalid_email(self, client, request_data):
        """
        Test having invalid email address in the request
        """
        request_data['email'] = "nananana@gail.com"
        response = client.post(url_for_api_version(endpoint='password-reset', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 422
        assert response_data == {
            "cmd": "/et_rs_prd/wl/v1/passwords?",
            "success": False,
            "message": "Email address not found.",
            "http_response": 422,
            "code": 55,
            "data": []
        }

    @pytest.mark.order3
    def test_reset_password_with_valid_email(self, client, request_data):
        """
        Test with valid email address and the language and authenticates the response code
        """
        request_data['email'] = "testhassan3013@gmail.com"
        response = client.post(url_for_api_version(endpoint='password-reset', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 201
        assert response_data == {
            "message": "success",
            "success": True,
            "data": {
                "message": "Password reset link sent to your email address.",
                "is_sent": True
            },
            "code": 0,
            "http_response": 201,
            "cmd": "/et_rs_prd/wl/v1/passwords?"
        }
        assert response_data['message'] == 'success'
