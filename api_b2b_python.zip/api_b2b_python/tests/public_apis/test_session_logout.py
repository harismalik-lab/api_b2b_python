"""
Test Session Logout Api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestSessionLogoutApi(object):
    """
    Test User Session Logout api with valid and invalid parameters.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'language': 'en',
            '__platform': 'ios',
            'app_version': '2.1',
            'location_id': '1',
            'wlcompany': 'hs',
            'session_token': 'a1c9db72-88e2-499e-9c6d-cc1d83769648',
            'build_no': 1,
            'istravel': True
        }

    @pytest.mark.order1
    def test_session_logout_with_valid_response(self, client, request_data):
        """
        Test the session logout endpoint with for 200 response.
        """
        response = client.get(url_for_api_version(
            endpoint='session_logout_api',
            version=self.version),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert response_data["cmd"] == "/et_rs_prd/wl/v1/session/logout?language=en&__platform=ios&location_id=1&wlcompany=hs&app_version=1.2&istravel=True&build_no=1"  # noqa:E501

    @pytest.mark.order2
    def test_session_logout_with_invalid_response(self, client, request_data):
        """
        Test the session logout endpoint with missing params session token and session id response.
        """
        del request_data['session_token']
        response = client.get(url_for_api_version(
            endpoint='session_logout_api',
            version=self.version),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 403
        assert not response_data['success']
        assert response_data["cmd"] == "/et_rs_prd/wl/v1/session/logout?language=en&__platform=ios&location_id=1&wlcompany=hs&app_version=1.2&istravel=True&build_no=1"  # noqa:E501
