"""
Test user profile update Api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestPostUserProfileApi(object):
    """
    Test user profile update Api.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'user_id': 5745248,
            '__platform': 'ios',
            'app_version': '2.0',
            'language': 'ar',
            'session_token': '0733eec3-e3b4-47e8-ae33-0647e4db9600',
            'wlcompany': 'entertainer-v67'
        }

    @pytest.mark.order1
    def test_get_merchant_name_with_valid_response(self, client, request_data):
        """
        Test the post user profile update endpoint with for 200 response.
        """
        response = client.post(url_for_api_version(endpoint='post-user-profile', version=self.version),
                               data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert len(response_data['data']) > 0
        assert response_data['data']['user_id'] == request_data.get('user_id')
        assert response_data['data']['country'] == "Bahrain"

    @pytest.mark.order2
    def test_get_merchant_name_endpoint_validation_error(self, client, request_data):
        """
        Test the post user profile update api with missing __platform param.
        """
        del request_data['__platform']
        response = client.post(url_for_api_version(endpoint='post-user-profile', version=self.version),
                               data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "__platform: missing required parameter"
