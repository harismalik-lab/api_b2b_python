"""
Test get kaligo deeplink api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestGetKaligoDeeplinkApi(object):
    """
    Test get kaligo deeplink api with valid and missing params.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'language': 'en',
            '__platform': 'ios',
            'session_token': 'a1c9db72-88e2-499e-9c6d-cc1d83769648',
            'wlcompany': 'hs',
            'istravel': False,
            'location_id': 1,
            'app_version': 1.2,
            'build_no': 1,
            'kaligo_location_identifier': 'Loren Ipsum - Web Link',
        }

    @pytest.mark.order1
    def test_get_kaligo_deeplink_with_valid_params(self, client, request_data):
        """
        Test the get kaligo deeplink endpoint with for 200 response.
        """
        response = client.get(
            url_for_api_version(
                endpoint='kaligo_deeplink_api',
                version=self.version
            ),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert response_data['cmd'] == "/et_rs_prd/wl/v1/kaligo/deeplink?language=%20en&__platform=%20ios&session_token=%20a1c9db72-88e2-499e-9c6d-cc1d83769648&wlcompany=%20hs&location_id=%201&app_version=%201.2&currency=%20%27%27&build_no=%201&kaligo_location_identifier=%20Loren%20Ipsum%20-%20Web%20Link"  # noqa:E501

    @pytest.mark.order2
    def test_get_kaligo_deeplink_with_missing_param(self, client, request_data):
        """
        Test the get kaligo deeplink endpoint with missing param.
        """
        del request_data['wlcompany']
        response = client.get(
            url_for_api_version(
                endpoint='kaligo_deeplink_api',
                version=self.version
            ),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert not response_data['success']
