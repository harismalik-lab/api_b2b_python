"""
Test User Languages Api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestUserLanguagesApi(object):
    """
    Test User Languages Api
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            '__platform': 'ios',
            'app_version': 2.0,
            'language': 'en',
            'location_id': 1,
            'session_token': '12778574965c2482724673e8.15855751',
            'wlcompany': 'maf'
        }

    @pytest.mark.order1
    def test_post_user_language_with_valid_response(self, client, request_data):
        """
        Test the user language endpoint with for 200 response.
        """
        response = client.post(url_for_api_version(endpoint='user-languages', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert response_data['message'] == "success"
        assert response_data['data'] == []

    @pytest.mark.order2
    def test_post_user_language_endpoint_validation_error(self, client, request_data):
        """
        Test the user language with missing __platform param.
        """
        del request_data['__platform']
        response = client.post(url_for_api_version(endpoint='user-languages', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "__platform: missing required parameter"
