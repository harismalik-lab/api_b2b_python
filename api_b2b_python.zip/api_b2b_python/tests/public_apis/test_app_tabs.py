"""
Test App Tabs Api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestAppTabsApi(object):
    """
    Test App Tabs Api.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            '__platform': 'ios',
            'app_version': '2',
            'language': 'en',
            'wlcompany': 'maf',
            'session_token': '12778574965c2482724673e8.15855751'
        }

    @pytest.mark.order1
    def test_app_tabs_with_valid_response(self, client, request_data):
        """
        Test the App Tabs endpoint with for 200 response.
        """
        response = client.get(url_for_api_version(endpoint='app-tabs', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert len(response_data['data']) > 0
        assert response_data['data']['limit'] == 60
        assert response_data['data']['tabs'] == [
            {
                "section_type": 1,
                "order": 1,
                "uid": "all_offers",
                "name": "ALL OFFERS",
                "params": {
                    "redeemability": "redeemable_reusable"
                }
            }
        ]

    @pytest.mark.order2
    def test_app_tabs_endpoint_validation_error(self, client, request_data):
        """
        Test the App Tabs missing app_version param.
        """
        del request_data['app_version']
        response = client.get(url_for_api_version(endpoint='app-tabs', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "app_version: missing required parameter"

    @pytest.mark.order3
    def test_app_tabs_endpoint_validation_error_with_session_token(self, client, request_data):
        """
        Test the App Tabs missing session_token param.
        """
        del request_data['session_token']
        response = client.get(url_for_api_version(endpoint='app-tabs', version=self.version), data=request_data)
        assert response.status_code == 403
