"""
Test validate imie api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestValidateImieApi(object):
    """
    Test validate imie api
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'key': 'HSKEYACE1',
            'wlcompany': 'HS',
            'language': 'en'
        }

    @pytest.mark.order1
    def test_post_validate_imie_with_valid_response(self, client, request_data):
        """
        Test the validate imie endpoint with for 200 response.
        """
        response = client.post(url_for_api_version(endpoint='validate-imie', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert len(response_data['data']) > 0
        assert response_data['data']['validation_status']
        assert response_data['data']['session_token'] == "privileged"
        assert response_data['data']['allowed_key_validation']

    @pytest.mark.order2
    def test_post_validate_imie_endpoint_validation_error(self, client, request_data):
        """
        Test the validate imie api with missing wl_company param.
        """
        del request_data['wlcompany']
        response = client.post(url_for_api_version(endpoint='validate-imie', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "wlcompany: missing required parameter"
