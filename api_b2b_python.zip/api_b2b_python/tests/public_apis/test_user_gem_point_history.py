"""
Test user gem points history api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestUserGemPointHistoryApi(object):
    """
    Test user gem history api for 200 response and parameters validation check.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'language': 'en',
            '__platform': 'ios',
            'session_token': 'a1c9db72-88e2-499e-9c6d-cc1d83769648',
            'wlcompany': 'hs',
            'location_id': 1,
            'app_version': 1.2,
            'currency': '',
            'build_no': 1
        }

    @pytest.mark.order1
    def test_user_gem_point_history_with_valid_response(self, client, request_data):
        """
        Test the user gem point history endpoint with for 200 response.
        """
        response = client.get(
            url_for_api_version(
                endpoint='user-gems-points-history-api',
                version=self.version
            ),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert response.cmd == "/et_rs_prd/wl/v1/user/gemspoints/history?language=%20en&__platform=%20ios&session_token=%20a1c9db72-88e2-499e-9c6d-cc1d83769648&wlcompany=%20hs&location_id=%201&app_version=%201.2&currency=%20%27%27&build_no=%201"  # noqa:E501

    @pytest.mark.order2
    def test_user_gem_point_history_with_missing_param(self, client, request_data):
        """
        Test the user gem point history endpoint with missing required param.
        """
        del request_data['wlcompany']
        response = client.get(
            url_for_api_version(
                endpoint='user-gems-points-history-api',
                version=self.version
            ),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['success']
