"""
Test User Sign Up Api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestSignUpApi(object):
    """
    Test User Sign Up Api
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'date_of_birth': '1992-12-06',
            'nationality': 'pakistan',
            'gender': 'male',
            'wlcompany': 'nma',
            '__platform': 'android',
            'firstname': 'zaheer',
            'lastname': 'look_up_cmpny',
            'mobile_phone': '0334',
            'country_of_residence': 'PK',
            'email': 'user_testsignup3@gmail.com',
            'password': '123123',
            'confirm_password': '123123',
            'app_version': '1'
        }

    @pytest.mark.order1
    def test_post_user_signup_with_valid_response(self, client, request_data):
        """
        Test the user sign up endpoint with for 200 response.
        """
        response = client.post(url_for_api_version(endpoint='user-signup', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert response_data['message'] == "success"
        assert type(response_data['data']) is dict

    @pytest.mark.order2
    def test_post_user_signup_with_invalid_response(self, client, request_data):
        """
        Test the user sign up endpoint with for 400 response.
        """
        del request_data['wlcompany']
        response = client.post(url_for_api_version(endpoint='user-signup', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == 'wlcompany: missing required parameter'
