"""
Test User Password Token Api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestUserPasswordTokenApi(object):
    """
    Test User Password Token Api.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {'wlcompany': 'DU GO', 'password_token': 'kl9078adbnc90pasdS04'}

    @pytest.mark.order1
    def test_post_user_password_token_with_valid_response(self, client, request_data):
        """
        Test the user password token endpoint with for 200 response.
        """
        response = client.post(
            url_for_api_version(endpoint='user-password-token', version=self.version),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert len(response_data['data']) > 0
        assert response_data['data']['is_valid_member']

    @pytest.mark.order2
    def test_post_user_password_token_endpoint_validation_error(self, client, request_data):
        """
        Test the user password token api with missing wlcompany param.
        """
        del request_data['wlcompany']
        response = client.post(
            url_for_api_version(endpoint='user-password-token', version=self.version),
            data=request_data
        )
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "wlcompany: missing required parameter"
