"""
Test outlets api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestOutletsApi(object):
    """
    Test outlets api
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            "language": "en",
            "wlcompany": "hs",
            "app_version": "1.0",
            "__i": 220364,
            "__platform": "ios",
            "session_token": "788903125bdaaa50c00370.31917650",
            "location_id": 1,
            "locale": "en",
            "is_cheers": "True",
            "is_cuckoo": "True",
            "is_company_specific": "True"
        }

    @pytest.mark.order1
    def test_get_outlet_api_with_valid_response(self, client, request_data):
        """
        Test outlet api for 200 response.
        """
        response = client.get(url_for_api_version(endpoint='outlet', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert len(response_data['data']) > 0
        assert 107 in [x.get('id') for x in response_data['data']['outlets']]
        assert "O043362" in [x.get('sfId') for x in response_data['data']['outlets']]

    @pytest.mark.order2
    def test_get_outlet_endpoint_validation_error(self, client, request_data):
        """
        Test the outlet api with missing merchant_id param.
        """
        del request_data['__platform']
        response = client.get(url_for_api_version(endpoint='outlet', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "__platform: missing required parameter"
