"""
Test merchant api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestMerchantApi(object):
    """
    Test all merchants 200 response and validation check and filtered merchants by location
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'wlcompany': 'maf',
            'session_token': '12778574965c2482724673e8.15855751',
            '__platform': 'ios',
            'location_id': 1,
            'app_version': 2,
            'language': 'en',
            'sort': 'default',
            'offset': 0,
            'outlet_limit': 60,
            'currency': 'USD'
        }

    @pytest.mark.order1
    def test_get_merchant_api_with_valid_response(self, client, request_data):
        """
        Test the merchant api endpoint with for 200 response.
        """
        response = client.get(url_for_api_version(endpoint='merchant', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert len(response_data['data']) > 0
        assert response_data['message'] == "success"

    @pytest.mark.order2
    def test_get_merchant_api_endpoint_validation_error(self, client, request_data):
        """
        Test the merchant api with missing session_token
        """
        del request_data['app_version']
        response = client.get(url_for_api_version(endpoint='merchant', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "app_version: missing required parameter"
