"""
Test currencies Api
"""
import json

import pytest

from common_white_label.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestcurrenciesApi(object):
    """
    Test Currencies Api.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            '__platform': 'ios',
            'app_version': '2.0',
            'language': 'en',
            'wlcompany': 'maf'
        }

    @pytest.mark.order1
    def test_get_currencies_with_valid_response(self, client, request_data):
        """
        Test the currencies endpoint with for 200 response.
        """
        response = client.get(url_for_api_version(endpoint='currencies', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert len(response_data['data']) > 0
        response_data['data']['currencies'] = response_data['data']['currencies'][0]
        assert response_data['data']['currencies']['name'] == 'UAE Dirham'
        assert response_data['data']['currencies']['id'] == 'AED'
        assert response_data['data']['currencies']['translated_currency'] == 'AED'

    @pytest.mark.order2
    def test_get_currencies_enpoint_validation_error(self, client, request_data):
        """
        Test the currencies missing app_version param.
        """
        del request_data['app_version']
        response = client.get(url_for_api_version(endpoint='currencies', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "app_version: missing required parameter"
