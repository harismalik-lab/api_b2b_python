"""
Public Api V1 routing
"""
from routing.base_routing import BaseRouting
from white_labels_api.v1.app_key_validation_config.api import AppKeyValidationConfigApi
from white_labels_api.v1.app_tabs.api import AppTabsApi
from white_labels_api.v1.app_tutorial_api.api import AppTutorialApi
from white_labels_api.v1.cheers_config.api import CheersConfigsApiWL
from white_labels_api.v1.config.api import ConfigsApiWL
from white_labels_api.v1.config_connectivity.api import ConfigConnectivityApiWL
from white_labels_api.v1.country.api import CountryApiWl
from white_labels_api.v1.currencies.api import CurrenciesApi
from white_labels_api.v1.express_home_api.api import ExpressHomeApi
from white_labels_api.v1.feed_app_boy_api.api import FeedAppBoyApi
from white_labels_api.v1.filters.api import FiltersApiWL
from white_labels_api.v1.get_jwt_token.api import GetJwtToken
from white_labels_api.v1.get_kaligo_deeplink.api import GetKaligoDeeplinkApiWl
from white_labels_api.v1.hotels.api import HotelsApi
from white_labels_api.v1.location_categories.api import LocationCategoriesApi
from white_labels_api.v1.locations.api import LocationsApiWL
from white_labels_api.v1.login_message.api import LoginMessageApiWL
from white_labels_api.v1.malls.api import MallsApi
from white_labels_api.v1.merchant.api import MerchantApi, MerchantsWL
from white_labels_api.v1.merchant_name.api import MerchantNameApiWl
from white_labels_api.v1.neighborhood.api import NeighborhoodApi
from white_labels_api.v1.outlet.api import OutletsApi
from white_labels_api.v1.passwords_api.api import UserPasswordResetApi
from white_labels_api.v1.redemption.api import RedemptionProcessWL
from white_labels_api.v1.redemption_history.api import RedemptionHistoryApi
from white_labels_api.v1.savings_history.api import SavingsHistoryApi
from white_labels_api.v1.session_logout.api import LogoutApi
from white_labels_api.v1.sign_in.api import SignInWLApi
from white_labels_api.v1.sign_up_api.api import SignUpWLApi
from white_labels_api.v1.user_gem_point_history.api import UserGemsPointsHistoryApiWL
from white_labels_api.v1.user_gems_points_summary.api import UserGemsPointsSummaryApiWL
from white_labels_api.v1.user_languages.api import UserLanguagesApiWl
from white_labels_api.v1.user_password_token.api import UserPasswordTokenApiWl
from white_labels_api.v1.user_profile_get_api.api import UserProfileWhiteLable
from white_labels_api.v1.user_profile_post_api.api import PostUserProfileApi
from white_labels_api.v1.user_savings_api.api import UserSavingsApi
from white_labels_api.v1.user_session_refresh_api.api import WlUserSessionRefreshApi
from white_labels_api.v1.user_spend_history_api.api import UserSpendHistoryApiWL
from white_labels_api.v1.user_spend_summary.api import UserSpendSummaryApiWl
from white_labels_api.v1.users_purchases.api import GetUserPurchasesWl
from white_labels_api.v1.users_user_id.api import GetUserActionApiWl, PostUserActionApiWl
from white_labels_api.v1.validate_imie.api import ValidateImieApiWl
from white_labels_api.v1.validates_api.api import PostValidatesActionApi
from white_labels_api.v1.verify_code.api import VerifyCodeApiWl
from white_labels_api.v1.verify_email.api import UserEmailVerificationApi
from white_labels_api.v1.verify_model_api.api import VerifyModelApi


class B2bPythonApiV1(BaseRouting):
    api_version = '1'

    def set_routing_collection(self):
        self.routing_collection['app-key-validation-config'] = {'view': AppKeyValidationConfigApi,
                                                                'url': '/app/key/validation/config'}
        self.routing_collection['app-tutorial'] = {'view': AppTutorialApi, 'url': '/app/tutorial'}
        self.routing_collection['app-tabs'] = {'view': AppTabsApi, 'url': '/app/tabs'}
        self.routing_collection['configs'] = {'view': ConfigsApiWL, 'url': '/configs'}
        self.routing_collection['configs-connectivity'] = {'view': ConfigConnectivityApiWL,
                                                           'url': '/configurations/connectivity'}
        self.routing_collection['cheers_configs'] = {'view': CheersConfigsApiWL, 'url': '/configurations/cheers'}
        self.routing_collection['country'] = {'view': CountryApiWl, 'url': '/country'}
        self.routing_collection['currencies'] = {'view': CurrenciesApi, 'url': '/currencies'}
        self.routing_collection['feed-app-boy'] = {'view': FeedAppBoyApi, 'url': '/feed/appboy'}
        self.routing_collection['filters'] = {'view': FiltersApiWL, 'url': '/filters'}
        self.routing_collection['get-user-action'] = {'view': GetUserActionApiWl, 'url': '/users/action'}
        self.routing_collection['get-user-profile'] = {'view': UserProfileWhiteLable, 'url': '/user/profile'}
        self.routing_collection['home_api'] = {'view': ExpressHomeApi, 'url': '/home'}
        self.routing_collection['kaligo_deeplink_api'] = {'view': GetKaligoDeeplinkApiWl, 'url': '/kaligo/deeplink'}
        self.routing_collection['locations'] = {'view': LocationsApiWL, 'url': '/locations'}
        self.routing_collection['location-categories'] = {'view': LocationCategoriesApi, 'url': '/location/categories'}
        self.routing_collection['login-message-api'] = {'view': LoginMessageApiWL, 'url': '/pre/login/message'}
        self.routing_collection['merchant'] = {'view': MerchantsWL, 'url': '/merchants'}
        self.routing_collection['merchant-name'] = {'view': MerchantNameApiWl, 'url': '/merchant/name'}
        self.routing_collection['merchant-id'] = {'view': MerchantApi, 'url': '/merchants/<int:merchant_id>'}
        self.routing_collection['outlet'] = {'view': OutletsApi, 'url': '/outlets'}
        self.routing_collection['password-reset'] = {'view': UserPasswordResetApi, 'url': '/passwords'}
        self.routing_collection['post-user-profile'] = {'view': PostUserProfileApi, 'url': '/user/profile'}
        self.routing_collection['post-user-action'] = {'view': PostUserActionApiWl, 'url': '/users/action'}
        self.routing_collection['redemption'] = {'view': RedemptionProcessWL, 'url': '/redemptions'}
        self.routing_collection['session_logout_api'] = {'view': LogoutApi, 'url': '/session/logout'}
        self.routing_collection['sign-in'] = {'view': SignInWLApi, 'url': '/sessions'}
        self.routing_collection['sign-up'] = {'view': SignUpWLApi, 'url': '/users'}
        self.routing_collection['user_gems_points_summary_api'] = {'view': UserGemsPointsSummaryApiWL,
                                                                   'url': '/user/gemspoints/summary'}
        self.routing_collection['user-gems-points-history-api'] = {'view': UserGemsPointsHistoryApiWL,
                                                                   'url': '/user/gemspoints/history'}
        self.routing_collection['user-languages'] = {'view': UserLanguagesApiWl, 'url': '/userlanguages'}
        self.routing_collection['user-password-token'] = {'view': UserPasswordTokenApiWl, 'url': '/user/password/token'}
        self.routing_collection['user-session-refresh'] = {'view': WlUserSessionRefreshApi, 'url': '/user/session/refresh'}
        self.routing_collection['user-spend-summary'] = {'view': UserSpendSummaryApiWl, 'url': '/user/spend/summary'}
        self.routing_collection['user-purchases'] = {'view': GetUserPurchasesWl,
                                                     'url': '/users/purchases'}
        self.routing_collection['user_spend_history_api'] = {'view': UserSpendHistoryApiWL,
                                                             'url': '/user/spend/history'}
        self.routing_collection['users-savings'] = {'view': UserSavingsApi, 'url': '/users/savings'}
        self.routing_collection['validates'] = {'view': PostValidatesActionApi, 'url': '/validates'}
        self.routing_collection['validate-imie'] = {'view': ValidateImieApiWl, 'url': '/validate/imie'}
        self.routing_collection['verify-code-api'] = {'view': VerifyCodeApiWl, 'url': '/user/verify/code'}
        self.routing_collection['verify-model-api'] = {'view': VerifyModelApi, 'url': '/verify/model'}
        self.routing_collection['get-jwt-token'] = {'view': GetJwtToken, 'url': '/get_jwt_token'}
        self.routing_collection['redemption-history-api'] = {'view': RedemptionHistoryApi, 'url': '/redemption/history'}
        self.routing_collection['savings-history-api'] = {'view': SavingsHistoryApi, 'url': '/savings/history'}
        self.routing_collection['malls'] = {'view': MallsApi, 'url': '/malls'}
        self.routing_collection['neighborhood'] = {'view': NeighborhoodApi, 'url': '/neighborhood'}
        self.routing_collection['hotels'] = {'view': HotelsApi, 'url': '/hotels'}
        self.routing_collection['email-verification'] = {'view': UserEmailVerificationApi, 'url': '/verify/email'}
