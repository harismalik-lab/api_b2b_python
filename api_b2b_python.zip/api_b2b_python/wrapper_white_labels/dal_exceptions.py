"""
This module contains DB Wrapper Exceptions
"""


class InvalidUsage(Exception):
    """
    This is an exception we raise on invalid usage
    """
    pass


class WhereConditionRequired(Exception):
    """
    This is an exception we raise when there's not where condition defined before insertion, deletion or updating
    """
    pass
