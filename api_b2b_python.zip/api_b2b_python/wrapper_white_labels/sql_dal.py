"""
This module contains Sql Data Abstraction class. It has following public methods:
 - execute_query()
 - from_()
 - get()
 - select()
 - where()
 - where_between()
 - where_between_ne()
 - where_gt()
 - where_gte()
 - where_in()
 - where_lt()
 - where_lte()
 - where_ne()
 - where_not_in()
 - like()
 - inner_join()
 - left_join()
 - right_join()
 - full_outer_join()
 - get_count()
 - get_distinct_count
 - insert()
 - batch_insert()
 - update()
"""
import time
import traceback
from contextlib import contextmanager

import elasticapm
from flask import current_app, request
from jinjasql import JinjaSql
from mysql.connector import errors

from app_configurations_white_label.settings import DAL_LOGS_PATH
from common_white_label.common_helpers import get_logger
from common_white_label.db import DEFAULT, get_connection_for_db, get_single_connection_for_db
from wrapper_white_labels.dal_exceptions import InvalidUsage, WhereConditionRequired

__author__ = 'kamal'


if current_app:
    logger = get_logger(
        filename='{log_path}{file_name}'.format(
            log_path=DAL_LOGS_PATH,
            file_name='dal.log',
        ),
        name='dal.log'
    )
else:
    logger = None


class SqlDal(object):
    """
    This is a class which handles sql query generation and execution
    """
    def __init__(self, connection=DEFAULT, track_tables=False, close_connection=True, single_connection=False):
        # Jinjasql related variables
        self._where_parameters = {}
        # Sql Wrapper variables
        self._select = '*'
        self._from = ''
        self._wheres = []
        self._wheres_ne = []
        self._in = []
        self._not_in = []
        self._gt = []
        self._gte = []
        self._lt = []
        self._lte = []
        self._btw = []
        self._btw_ne = []
        self._like = []
        self._join = []
        self.query_list = []
        self._is_set = {}
        self._group_by = []
        self._order_by = []
        self._limit = None
        self._raw_query = None
        self._offset = None
        self._parenthisised_where = []
        self._having_lte = ''
        if not connection:
            connection = DEFAULT
        self._connection = connection
        self.con = None
        self._close_connection = close_connection
        self.join_order = []
        self.tables = []
        self.track_tables = track_tables
        self.single_connection = True

    ###############################
    # PRIVATE METHODS
    ###############################

    @contextmanager
    def _get_context_cursor(self, connection):
        """
        The method handles opening and closing of cursor
        :param mysql.connector.pooling.PooledMySQLConnection con: Db Connection
        """
        self.get_dal_connection(connection)
        try:
            cursor = self.con.cursor(dictionary=True)
            yield cursor
            try:
                cursor.close()
            except (ReferenceError, RuntimeError):
                pass
        except errors.OperationalError:
            pass

    @classmethod
    def _connect(cls):
        """
        Creates and returns a connection
        :rtype: mysql.connector.pooling.PooledMySQLConnection
        """
        if cls.single_connection:
            connection = get_single_connection_for_db(DEFAULT)
        else:
            connection = get_connection_for_db(DEFAULT)
        return connection

    def _prepare_where_in(self):
        """
        This module prepare a where in query, e.g WHERE X IN (A, B, C)
        """
        if self._in:
            where_in = []
            for field, value, optional in self._in:
                if where_in or 'WHERE' in self.query_list:
                    where_in.append("OR" if optional else "AND")
                where_in.append("{} IN {}".format(field, value))
            if where_in:
                if 'WHERE' not in self.query_list:
                    self.query_list.append('WHERE')
                self.query_list.extend(where_in)

    def _prepare_where_not_in(self):
        """
        This module prepare a where not in query, e.g WHERE X NOT IN (A, B, C)
        """
        if self._not_in:
            where_not_in = []
            for field, value, optional in self._not_in:
                if where_not_in or 'WHERE' in self.query_list:
                    where_not_in.append("OR" if optional else "AND")
                where_not_in.append("{} NOT IN {}".format(field, value))
            if where_not_in:
                if 'WHERE' not in self.query_list:
                    self.query_list.append('WHERE')
                self.query_list.extend(where_not_in)

    def _prepare_where(self):
        """
        This module prepares WHERE sql query, e.g WHERE Field = Value
        """
        where_conditions = []
        if self._wheres and self.query_list:
            for key, value, optional in self._wheres:
                if where_conditions or 'WHERE' in self.query_list:
                    where_conditions.append("OR" if optional else "AND")
                where_conditions.append("{} = {}".format(key, value))
            if where_conditions:
                if 'WHERE' not in self.query_list:
                    self.query_list.append('WHERE')
                self.query_list.extend(where_conditions)

    def _prepare_where_ne(self):
        """
        This method prepares WHERE not equal sql query, e.g WHERE Field != value
        """
        where_conditions = []
        if self._wheres_ne and self.query_list:
            for key, value, optional in self._wheres_ne:
                if where_conditions or 'WHERE' in self.query_list:
                    where_conditions.append("OR" if optional else "AND")
                where_conditions.append("{} != {}".format(key, value))
            if where_conditions:
                if 'WHERE' not in self.query_list:
                    self.query_list.append('WHERE')
                self.query_list.extend(where_conditions)

    def _prepare_where_gte(self):
        """
        This method prepares WHERE greater or equal sql equivalent query
        """
        where_conditions = []
        if self._gte and self.query_list:
            for key, value, optional in self._gte:
                if where_conditions or 'WHERE' in self.query_list:
                    where_conditions.append("OR" if optional else "AND")
                where_conditions.append("{} >= {}".format(key, value))
            if where_conditions:
                if 'WHERE' not in self.query_list:
                    self.query_list.append('WHERE')
                self.query_list.extend(where_conditions)

    def _prepare_where_gt(self):
        """
        This method prepares WHERE greater than sql equivalent query
        """
        where_conditions = []
        if self._gt and self.query_list:
            for key, value, optional in self._gt:
                if where_conditions or 'WHERE' in self.query_list:
                    where_conditions.append("OR" if optional else "AND")
                where_conditions.append("{} > {}".format(key, value))
            if where_conditions:
                if 'WHERE' not in self.query_list:
                    self.query_list.append('WHERE')
                self.query_list.extend(where_conditions)

    def _prepare_where_lt(self):
        """
        This method prepares WHERE less than or equal sql equivalent query
        """
        where_conditions = []
        if self._lt and self.query_list:
            for key, value, optional in self._lt:
                if where_conditions or 'WHERE' in self.query_list:
                    where_conditions.append("OR" if optional else "AND")
                where_conditions.append("{} < {}".format(key, value))
            if where_conditions:
                if 'WHERE' not in self.query_list:
                    self.query_list.append('WHERE')
                self.query_list.extend(where_conditions)

    def _prepare_where_lte(self):
        """
        This method prepares WHERE less than or equal sql equivalent query
        """
        where_conditions = []
        if self._lte and self.query_list:
            for key, value, optional in self._lte:
                if where_conditions or 'WHERE' in self.query_list:
                    where_conditions.append("OR" if optional else "AND")
                where_conditions.append("{} <= {}".format(key, value))
            if where_conditions:
                if 'WHERE' not in self.query_list:
                    self.query_list.append('WHERE')
                self.query_list.extend(where_conditions)

    def _prepare_where_between(self):
        """
        This method prepares WHERE BETWEEN sql equivalent query
        """
        if self._btw:
            where_between = []
            for field, val_1, val_2, optional in self._btw:
                if where_between or 'WHERE' in self.query_list:
                    where_between.append("OR" if optional else "AND")
                where_between.append("{} BETWEEN {} AND {}".format(field, val_1, val_2))
            if where_between:
                if 'WHERE' not in self.query_list:
                    self.query_list.append('WHERE')
                self.query_list.extend(where_between)

    def _prepare_where_between_ne(self):
        """
        This method prepares WHERE NOT BETWEEN sql equivalent query
        :param list self.query_list: List of query tokens
        """
        if self._btw_ne:
            where_not_between = []
            for field, val_1, val_2, optional in self._btw_ne:
                if where_not_between or 'WHERE' in self.query_list:
                    where_not_between.append("OR" if optional else "AND")
                where_not_between.append("{} NOT BETWEEN {} AND {}".format(field, val_1, val_2))
            if where_not_between:
                if 'WHERE' not in self.query_list:
                    self.query_list.append('WHERE')
                self.query_list.extend(where_not_between)

    def _prepare_like_condition(self):
        """
        This method prepares LIKE equivalent sql query
        """
        if self._like:
            like_conditions = []
            for field, wildcard, optional in self._like:
                if like_conditions or 'WHERE' in self.query_list:
                    like_conditions.append("OR" if optional else "AND")
                like_conditions.append("{} LIKE {}".format(field, wildcard))
            if like_conditions:
                if 'WHERE' not in self.query_list:
                    self.query_list.append('WHERE')
                self.query_list.extend(like_conditions)

    def _prepare_joins(self):
        """
        This appends sql query for JOINS
        """
        for join_type, table, on_left, on_right in self._join:
            self.query_list.append('{} JOIN {} ON {}={}'.format(join_type, table, on_left, on_right))

    def _prepare_group_by(self):
        """
        Prepares group by
        """
        if self._group_by:
            self.query_list.append('GROUP BY {}'.format(",".join(self._group_by)))

    def _prepare_order_by(self):
        """
        Prepares order by clause
        """
        if self._order_by:
            columns = []
            for col, order in self._order_by:
                columns.append("{} {}".format(col, order))
            self.query_list.append("ORDER BY {}".format(",".join(columns)))

    def _prepare_raw_query(self):
        """
        Prepares raw order by clause
        """
        if self._raw_query:
            self.query_list.append(" {raw_query} ".format(raw_query=self._raw_query))

    def _prepare_limit(self):
        """
        Prepares Limit clause
        """
        if self._limit:
            self.query_list.append("LIMIT {}".format(self._limit))

    def _prepare_offset(self):
        """
        Prepares Offset clause
        """
        if self._offset:
            self.query_list.append("OFFSET {}".format(self._offset))

    def _prepare_parenthesised_where_clause(self):
        """
        This method sets where clause with parentheses
        """
        if self._parenthisised_where:
            if 'WHERE' in " ".join(self.query_list):
                self.query_list.extend(self._parenthisised_where)
            else:
                self._parenthisised_where[0] = self._parenthisised_where[0].lstrip(' AND')
                self.query_list.append('WHERE {}'.format(self._parenthisised_where[0]))

    def _prepare_having_lte(self):
        """
        This method sets having clause
        """
        if self._having_lte:
            self.query_list.append(self._having_lte)

    def _prepare_sql_query(self):
        """
        This method loads all the conditions into query list
        """
        self._prepare_joins()
        # Where
        self._prepare_where()
        # Where In
        self._prepare_where_in()
        # Where Not In
        self._prepare_where_not_in()
        # Where gt
        self._prepare_where_gt()
        # Where gte
        self._prepare_where_gte()
        # Where lt
        self._prepare_where_lt()
        # Where lte
        self._prepare_where_lte()
        # Where between
        self._prepare_where_between()
        # Where not between
        self._prepare_where_between_ne()
        # Where ne
        self._prepare_where_ne()
        # Like
        self._prepare_like_condition()
        # where parentheses
        self._prepare_parenthesised_where_clause()
        # Group by
        self._prepare_group_by()
        # Having
        self._prepare_having_lte()
        # Order by
        self._prepare_order_by()
        self._prepare_raw_query()
        # Limit
        self._prepare_limit()
        # Offset
        self._prepare_offset()
        return ' '.join(self.query_list)

    def _push_value_in_parameters_list(self, value, sql_safe=False):
        """
        Pushed value to params list which will be later used by jinjasql to prepare the query
        :param int|str|float|list value:
        :rtype: str
        """
        unique_param_name = 'pm_{}'.format(len(self._where_parameters) + 1)  # Generating a parameter name for jinjasql
        if isinstance(value, list):
            # Generating jinjasql pyformat param e.g {{user_id}}, '{{' means we are escaping '{'.
            if sql_safe:
                value = '({})'.format((str(value)).strip('[]'))
                _param_name = '{{{{{} | sqlsafe }}}}'.format(unique_param_name)
            else:
                _param_name = '{{{{{} | inclause}}}}'.format(unique_param_name)
        else:
            if sql_safe:
                _param_name = '{{{{{} | sqlsafe }}}}'.format(unique_param_name)
            else:
                # Generating jinjasql pyformat param e.g {{user_id}}, '{{' means we are escaping '{'.
                _param_name = '{{{{{}}}}}'.format(unique_param_name)
        self._where_parameters.update({unique_param_name: value})
        return _param_name

    ###############################
    # PUBLIC METHODS
    ###############################
    def clear(self):
        """
        This method clears the class attributes
        """
        # Jinjasql related variables
        self._where_parameters = {}
        # Sql Wrapper variables
        self._select = '*'
        self._from = ''
        self._wheres = []
        self._wheres_ne = []
        self._in = []
        self._not_in = []
        self._gt = []
        self._gte = []
        self._lt = []
        self._lte = []
        self._btw = []
        self._btw_ne = []
        self._like = []
        self._left = []
        self._right = []
        self.query_list = []
        self._is_set = {}
        self._group_by = []
        self._order_by = []
        self._limit = None
        self._offset = None
        self._parenthisised_where = []
        self._having_lte = ''
        self._join = []
        self.tables = []
        self.con = None
        self.track_tables = False
        self._raw_query = None

    def select(self, fields=list()):
        """
        This is an abstract SELECT method.
        :param list fields: Fields to fetch from table
        :return:
        """
        if isinstance(fields, list) and fields:
            self._select = '{}{}'.format('{},'.format(self._select) if self._select != '*' else '', ",".join(fields))
        elif isinstance(fields, str):
            self._select = fields
        return self

    def from_(self, _from=list(), aliases=list()):
        """
        This method is to specify targeted tables from we want data
        :param list aliases: Table aliases
        :param list|str _from: Table names to get data from
        """
        if aliases:
            assert len(aliases) <= len(_from) and isinstance(aliases, list) and isinstance(_from, list)
            for _index, _alias in enumerate(aliases):
                _from[_index] = '{} AS {}'.format(_from[_index], _alias)
                self._from = ",".join(_from)
        if isinstance(_from, list) and _from and not aliases:
            if self.track_tables:
                self.tables.extend([table if 'as' not in table.lower() else table.split(' ')[0] for table in _from])
            self._from = ",".join(_from)
        elif isinstance(_from, str) and not aliases:
            if self.track_tables:
                self.tables.append(_from.split(' ')[0])
            self._from = _from
        elif not _from:
            raise InvalidUsage("_from cannot be empty")
        return self

    def where(self, where, value=None, optional=False, sql_safe=False):
        """
        This method specifies Where conditions with equal operator
        :param dict|str where: Dictionary or a single field e.g if you want to add condition field=3
        you can specify as
        >>> self.where("field", 3)
        If you want multiple conditions use
        >>> self.where({"field": 3, "field2": 4})
        :param int|str|long|float|bool value: Value to compare with
        :param bool optional: Whether it is optional condition or not
        """
        if isinstance(where, dict):
            for key, value in where.items():
                value = self._push_value_in_parameters_list(value, sql_safe=sql_safe)
                self._wheres.append((key, value, optional))
        elif isinstance(where, str) and value is not None:
            value = self._push_value_in_parameters_list(value, sql_safe=sql_safe)
            self._wheres.append((where, value, optional))
        else:
            raise InvalidUsage("Specify conditions accurately.")
        self._is_set['where'] = True if self._wheres else False
        return self

    def where_ne(self, where, value=None, optional=False, sql_safe=False):
        """
        This method specifies Where conditions with not equal operator
        :param dict|str where: Dictionary or a single field e.g if you want to add condition field=3
        you can specify as
        >>> self.where("field", 3)
        If you want multiple conditions use
        >>> self.where({"field": 3, "field2": 4})
        :param int|str|long|float|bool value: Value to compare with
        :param bool optional: Whether it is optional condition or not
        """
        if isinstance(where, dict):
            for key, value in where.items():
                value = self._push_value_in_parameters_list(value, sql_safe=sql_safe)
                self._wheres_ne.append((key, value, optional))
        elif isinstance(where, str) and value is not None:
            value = self._push_value_in_parameters_list(value, sql_safe=sql_safe)
            self._wheres_ne.append((where, value, optional))
        else:
            raise InvalidUsage("Specify conditions accurately.")
        self._is_set['where'] = True if self._wheres_ne else False
        return self

    def where_gt(self, where, value=None, optional=False, sql_safe=False):
        """
        This method specifies Where conditions with greater than operator
        :param dict|str where: Dictionary or a single field e.g if you want to add condition field=3
        you can specify as
        >>> self.where("field", 3)
        If you want multiple conditions use
        >>> self.where({"field": 3, "field2": 4})
        :param int|str|long|float|bool value: Value to compare with
        :param bool optional: Whether it is optional condition or not
        """
        if isinstance(where, dict):
            for key, value in where.items():
                value = self._push_value_in_parameters_list(value, sql_safe=sql_safe)
                self._gt.append((key, value, optional))
        elif isinstance(where, str) and value is not None:
            value = self._push_value_in_parameters_list(value, sql_safe=sql_safe)
            self._gt.append((where, value, optional))
        else:
            raise InvalidUsage("Specify conditions accurately.")
        self._is_set['where'] = True if self._gt else False
        return self

    def where_lt(self, where, value=None, optional=False, sql_safe=False):
        """
        This method specifies Where conditions with less than operator
        :param dict|str where: Dictionary or a single field e.g if you want to add condition field=3
        you can specify as
        >>> self.where("field", 3)
        If you want multiple conditions use
        >>> self.where({"field": 3, "field2": 4})
        :param int|str|long|float|bool value: Value to compare with
        :param bool optional: Whether it is optional condition or not
        """
        if isinstance(where, dict):
            for key, value in where.items():
                value = self._push_value_in_parameters_list(value, sql_safe=sql_safe)
                self._lt.append((key, value, optional))
        elif isinstance(where, str) and value is not None:
            value = self._push_value_in_parameters_list(value, sql_safe=sql_safe)
            self._lt.append((where, value, optional))
        else:
            raise InvalidUsage("Specify conditions accurately.")
        self._is_set['where'] = True if self._lt else False
        return self

    def where_gte(self, where, value=None, optional=False, sql_safe=False):
        """
        This method specifies Where conditions with greater than or equal operator
        :param dict|str where: Dictionary or a single field e.g if you want to add condition field=3
        you can specify as
        >>> self.where("field", 3)
        If you want multiple conditions use
        >>> self.where({"field": 3, "field2": 4})
        :param int|str|long|float|bool|date value: Value to compare with
        :param bool optional: Whether it is optional condition or not
        """
        if isinstance(where, dict):
            for key, value in where.items():
                value = self._push_value_in_parameters_list(value, sql_safe=sql_safe)
                self._gte.append((key, value, optional))
        elif isinstance(where, str) and value is not None:
            value = self._push_value_in_parameters_list(value, sql_safe=sql_safe)
            self._gte.append((where, value, optional))
        else:
            raise InvalidUsage("Specify conditions accurately.")
        self._is_set['where'] = True if self._gte else False
        return self

    def where_lte(self, where, value=None, optional=False, sql_safe=False):
        """
        This method specifies Where conditions with less than or equal operator
        :param dict|str where: Dictionary or a single field e.g if you want to add condition field=3
        you can specify as
        >>> self.where("field", 3)
        If you want multiple conditions use
        >>> self.where({"field": 3, "field2": 4})
        :param int|str|long|float|bool value: Value to compare with
        :param bool optional: Whether it is optional condition or not
        """
        if isinstance(where, dict):
            for key, value in where.items():
                value = self._push_value_in_parameters_list(value, sql_safe=sql_safe)
                self._lte.append((key, value, optional))
        elif isinstance(where, str) and value is not None:
            value = self._push_value_in_parameters_list(value, sql_safe=sql_safe)
            self._lte.append((where, value, optional))
        else:
            raise InvalidUsage("Specify conditions accurately.")
        self._is_set['where'] = True if self._lte else False
        return self

    def where_in(self, field="", _in=list(), optional=False, sql_safe=False):
        """
        This method specify where in condition
        :param bool sql_safe: Flag for safe string (jinjasql related)
        :param str field: A Column which you wanna get checked
        :param list _in: List in which you wanna check column
        :param bool optional: Whether it is optional condition or not
        """
        if field and _in:
            value = self._push_value_in_parameters_list(_in, sql_safe=sql_safe)
            _tuple = (field, value, optional)
            self._in.append(_tuple)
            self._is_set['where'] = True
        else:
            raise InvalidUsage("Specify conditions accurately.")
        return self

    def where_between(self, field, val_1, val_2, optional=False):
        """
        This method specifies where between condition
        :param str field: Field you wanna check
        :param int|float|str val_1: Starting offset
        :param int|float|str val_2: Ending offset
        :param bool optional: Whether it is optional condition or not
        """
        if field and val_1 is not None and val_2 is not None:
            val_1 = self._push_value_in_parameters_list(val_1)
            val_2 = self._push_value_in_parameters_list(val_2)
            tup = (field, val_1, val_2, optional)
            self._btw.append(tup)
            self._is_set['where'] = True
        else:
            raise InvalidUsage("Specify conditions accurately.")
        return self

    def where_between_ne(self, field, val_1, val_2, optional=False):
        """
        This method specifies where not between condition
        :param str field: Field you wanna check
        :param int|long|float|str val_1: Starting offset
        :param int|long|float|str val_2: Ending offset
        :param bool optional: Whether it is optional condition or not
        """
        assert isinstance(field, str), 'Invalid field'
        assert isinstance(val_1, (int, float, str)), "Invalid value 1"
        assert isinstance(val_2, (int, float, str)), "Invalid value 2"
        if field and val_1 is not None and val_2 is not None:
            val_1 = self._push_value_in_parameters_list(val_1)
            val_2 = self._push_value_in_parameters_list(val_2)
            tup = (field, val_1, val_2, optional)
            self._btw_ne.append(tup)
            self._is_set['where'] = True
        else:
            raise InvalidUsage("Specify conditions accurately.")
        return self

    def where_not_in(self, field="", _in=list(), optional=False):
        """
        This method specify where not in condition
        :param str field: A Column which you wanna get checked
        :param list _in: List in which you wanna check column
        :param bool optional: Whether it is optional condition or not
        """
        if field and _in:
            value = self._push_value_in_parameters_list(_in)
            _tuple = (field, value, optional)
            self._not_in.append(_tuple)
            self._is_set['where'] = True
        else:
            raise InvalidUsage("Specify conditions accurately.")
        return self

    def like(self, field, string, enable_start_wild_card=True, enable_end_wildcard=True, optional=False):
        """
        This method adds a wild card search in sql query.
        :param str field: Desired table field
        :param str string: wildcard string
        :param bool enable_start_wild_card: A flag to add '%' on left of wildcard string
        :param bool enable_end_wildcard: A flag to add '%' on right of wildcard string
        :param bol optional: Whether it is optional condition or not
        """
        assert isinstance(field, str), 'Invalid field type'
        assert isinstance(string, str), 'Invalid search string type'
        if '%' in string:
            # Escaping manually added percent signs
            string = string.replace('%', '\%')
        string = '{}{}{}'.format('%' if enable_start_wild_card else '',
                                 string, '%' if enable_end_wildcard else '')
        string = self._push_value_in_parameters_list(string)
        self._like.append((field, string, optional))
        self._is_set['where'] = True
        return self

    def inner_join(self, table_name, on_left_field, on_right_field):
        """
        This method adds an INNER JOIN
        :param str table_name: Table name
        :param str on_left_field: Left column name
        :param str on_right_field: Right column name
        """
        assert isinstance(table_name, str), 'Invalid table_name type'
        assert isinstance(on_left_field, str), 'Invalid left field name type'
        assert isinstance(on_right_field, str), 'Invalid right field name type'
        if self.track_tables:
            self.tables.append(table_name.split(' ')[0])
        self._join.append(('INNER', table_name, on_left_field, on_right_field))
        return self

    def left_join(self, table_name, on_left_field, on_right_field):
        """
        This method adds an LEFT JOIN
        :param str table_name: Table name
        :param str on_left_field: Left column name
        :param str on_right_field: Right column name
        """
        assert isinstance(table_name, str), 'Invalid table_name type'
        assert isinstance(on_left_field, str), 'Invalid left field name type'
        assert isinstance(on_right_field, str), 'Invalid right field name type'
        if self.track_tables:
            self.tables.append(table_name.split(' ')[0])
        self._join.append(('LEFT', table_name, on_left_field, on_right_field))
        return self

    def right_join(self, table_name, on_left_field, on_right_field):
        """
        This method adds an RIGHT JOIN
        :param str table_name: Table name
        :param str on_left_field: Left column name
        :param str on_right_field: Right column name
        """
        assert isinstance(table_name, str), 'Invalid table_name type'
        assert isinstance(on_left_field, str), 'Invalid left field name type'
        assert isinstance(on_right_field, str), 'Invalid right field name type'
        if self.track_tables:
            self.tables.append(table_name.split(' ')[0])
        self._join.append(('RIGHT', table_name, on_left_field, on_right_field))
        return self

    def get_dal_connection(self, connection):
        from PyMysqlPool.mysql.connector.dpooling import PooledMySQLConnection
        if isinstance(self.con, PooledMySQLConnection):
            self.close_connection()

        if self._connection:
            if isinstance(self._connection, str):
                if self.single_connection:
                    self.con = get_single_connection_for_db(self._connection)
                else:
                    self.con = get_connection_for_db(self._connection)
            else:
                self.con = self._connection
        elif isinstance(connection, str):
            if self.single_connection:
                self.con = get_single_connection_for_db(connection)
            else:
                self.con = get_connection_for_db(connection)
        else:
            self.con = connection or self._connect()

    def close_connection(self):
        try:
            if self.con and self._close_connection:
                self.con.close()
        except errors.OperationalError:
            pass
        except Exception:
            pass
        self.con = None

    # Making it public so that if a query is too complex for sqlDal it can be executed directly
    @elasticapm.capture_span()
    def execute_query(self, sql, fetch_one=False, commit_changes=False, last_row_id=False, connection=None,
                      default=None, retries=0, get_row_count=False, retry_update=False):
        """
        This method executes sql query and returns the result
        :param bool retry_update: Flag for retrying update query
        :param str|int|list|None default: Value that we want in return as default
        :param mysql.connector.pooling.PooledMySQLConnection connection: Db Connection
        :param bool last_row_id: True if you want to get last row id
        :param bool commit_changes: True if you want changes to be commit
        :param str sql: Sql query
        :param bool fetch_one: Flag to get single row
        :param int retries: for recursion
        :rtype: list|dict|int|None
        """
        params = ''
        try:
            with self._get_context_cursor(connection) as cursor:
                if self._where_parameters:
                    jinja_sql = JinjaSql()
                    sql, params = jinja_sql.prepare_query(sql, self._where_parameters)
                    cursor.execute(sql, params=list(params))
                else:
                    cursor.execute(sql)
                if not commit_changes:
                    result = cursor.fetchall() if not fetch_one else cursor.fetchone()
                else:
                    self.con.commit()
                    result = True
                    if get_row_count:
                        result = cursor.rowcount
                    elif last_row_id:
                        result = cursor.lastrowid
                return result if result else default
        except errors.IntegrityError as exception_raised:
            self.con.rollback()
            if logger:  # No logging in tests
                logger.exception(
                    'Error occurred while executing sql query.\nquery: {query}\nparams:{params}\nurl: {url}\n'
                    'request_params: {request_params}\nTB: {traceback}'.format(
                        query=' '.join(self.query_list),
                        url=request.full_path if request else '',
                        request_params=request.form.to_dict() if request else '',
                        params=list(params),
                        traceback=traceback.format_exc()
                    ),
                    extra={'status_code': getattr(exception_raised, 'code', 500)}
                )
            raise
        except errors.InternalError:
            if retry_update:
                time.sleep(2)
                self.con.commit()
                return
            raise
        except Exception as exception_raised:
            if logger:  # No logging in tests
                logger.exception(
                    'Error occurred while executing sql query.\nquery: {query}\nparams:{params}\nurl: {url}\n'
                    'request_params: {request_params}\nTB: {traceback}'.format(
                        query=' '.join(self.query_list),
                        url=request.full_path if request else '',
                        request_params=request.form.to_dict() if request else '',
                        params=list(params),
                        traceback=traceback.format_exc()
                    ),
                    extra={'status_code': getattr(exception_raised, 'code', 500)}
                )
            raise
        finally:
            self.close_connection()
            self.clear()

    def get_count(self, connection=None, default=None):
        """
        This method returns count of records against built query
        :param mysql.connector.pooling.PooledMySQLConnection connection: Db Connection
        :param default: Default value
        :rtype: int
        """
        if self._from:
            self.query_list.append("SELECT COUNT({}) AS sql_dal_count FROM {}".format(self._select, self._from))
        else:
            raise InvalidUsage("Provide from")
        query = self._prepare_sql_query()
        result = self.execute_query(query, fetch_one=True, connection=connection, default=default)
        if result:
            return result['sql_dal_count']

    def get_distinct_count(self, connection=None, default=None):
        """
        This method returns distinct count of records against built query
        :param mysql.connector.pooling.PooledMySQLConnection connection: Db Connection
        :param default: Default value
        :rtype: int
        """
        self.query_list = []
        if self._from:
            self.query_list.append("SELECT COUNT(DISTINCT {}) AS sql_dal_count FROM {}".format(self._select,
                                                                                               self._from))
        else:
            raise InvalidUsage("Mention target tables using from() method")
        query = self._prepare_sql_query()
        result = self.execute_query(query, fetch_one=True, connection=connection, default=default)
        if result:
            return result['sql_dal_count']

    def get_distinct(self, connection=None, default=None):
        """
        This method returns distinct records against built query
        :param mysql.connector.pooling.PooledMySQLConnection connection: Db Connection
        :param default: Default value
        :rtype: list|dict
        """
        self.query_list = []
        if self._from:
            self.query_list.append("SELECT DISTINCT {} FROM {}".format(self._select, self._from))
        else:
            raise InvalidUsage("Mention target tables using from() method")
        query = self._prepare_sql_query()
        return self.execute_query(query, connection=connection, default=default)

    def get(self, connection=None, default=None):
        """
        This method calls all query preparing functions and execute than query and return result
        :param default: Default value
        :param mysql.connector.pooling.PooledMySQLConnection connection: Db Connection
        :rtype: list | type(default)
        """
        self.query_list = []
        if self._from:
            self.query_list.append("SELECT {} FROM {}".format(self._select, self._from))
        else:
            raise InvalidUsage("Mention target tables using from() method")
        query = self._prepare_sql_query()
        return self.execute_query(query, connection=connection, default=default)

    def get_one(self, connection=None, default=None):
        """
        This method calls all query preparing functions and execute than query and return one row or None
        :param default:
        :param str|None|mysql.connector.pooling.PooledMySQLConnection connection: Db Connection
        :rtype: dict | None
        """
        self.query_list = []
        if self._from:
            self.query_list.append("SELECT {} FROM {}".format(self._select, self._from))
        else:
            raise InvalidUsage("Mention target tables using from() method")
        self.limit(1)
        query = self._prepare_sql_query()
        return self.execute_query(query, connection=connection, fetch_one=True, default=default)

    def insert(self, table_name, columns=list(), values=list(), connection=None, last_row_id=False):
        """
        This method performs sql insertion
        :param last_row_id:
        :param str table_name: Name of table
        :param list columns: List of column names
        :param list values: List of values
        :param mysql.connector.pooling.PooledMySQLConnection connection: Db Connection
        """
        assert isinstance(values, list) and values
        if None in values:
            values = ['' if v is None else v for v in values]
        insert_query = "INSERT INTO {} ({}) VALUES{};" if columns else "INSERT INTO {} VALUES{};"
        values = self._push_value_in_parameters_list(values)
        args_tuple = (table_name, values)
        if columns:
            args_tuple = (table_name, ",".join(columns), values)
        insert_query = insert_query.format(*args_tuple)
        result = self.execute_query(insert_query, commit_changes=True, connection=connection, last_row_id=last_row_id)
        self.clear()
        return result

    def batch_insert(self, table_name, columns=list(), list_of_values=list(), connection=None):
        """
        This method performs batch data insertion
        :param str table_name: Table name
        :param list columns: List of column names
        :param list list_of_values: List of value lists
        :param mysql.connector.pooling.PooledMySQLConnection connection: Db Connection
        """
        assert isinstance(list_of_values, list) and list_of_values
        insert_query = "INSERT INTO {} ({})" if columns else "INSERT INTO {}"
        args_tuple = (table_name, ",".join(columns)) if columns else [table_name]
        insert_query = insert_query.format(*args_tuple)
        values_str_list = []
        for values in list_of_values:
            if None in values:
                values = ['' if v is None else v for v in values]
            values = self._push_value_in_parameters_list(values)
            values_str_list.append("{}".format(values))
        insert_query += " VALUES" + ",".join(values_str_list)
        self.execute_query(insert_query, commit_changes=True, connection=connection)
        self.clear()

    def update(self, table_name, changes, connection=None):
        """
        This method updates rows in db
        :param str table_name: Name of table
        :param dict changes: Dictionary where keys are column names and values are their new values.
        :param mysql.connector.pooling.PooledMySQLConnection connection: Db Connection
        """
        if not self._is_set.get('where'):
            raise WhereConditionRequired("No Where condition specified.")
        changes_list = []
        for key, value in changes.items():
            value = self._push_value_in_parameters_list(value)
            changes_list.append("{}={}".format(key, value))
        self.query_list.append("UPDATE {} SET {}".format(table_name, ",".join(changes_list)))
        query = self._prepare_sql_query()
        self.execute_query(query, commit_changes=True, connection=connection, retry_update=True)
        self.clear()

    def delete(self, table_name, connection=None, get_row_count=True):
        """
        This method deletes rows from specified table with specified where clauses
        :param str table_name: Table name
        :param bool get_row_count: getting the count of rows affected
        :param mysql.connector.pooling.PooledMySQLConnection connection: Db Connection
        """
        if not self._is_set.get('where'):
            raise WhereConditionRequired("No Where condition specified.")
        self.query_list.append("DELETE FROM {}".format(table_name))
        query = self._prepare_sql_query()
        result = self.execute_query(query, commit_changes=True, connection=connection, get_row_count=get_row_count)
        self.clear()
        return result

    def group_by(self, columns):
        """
        This method add group buy sql statement.
        :param list columns: Column names
        """
        self._group_by = columns

    def order_by(self, columns):
        """
        This adds order by clause, pass in the dict with columns as keys and asc or desc for ascending and descending
        :param dict columns: Dict of columns and order type
        """
        assert isinstance(columns, dict), 'Invalid columns dict'
        for key, value in columns.items():
            self._order_by.append((key, 'DESC' if value.lower() == 'desc' else 'ASC'))
        return self

    def raw_order_by(self, raw_query):
        """
        This adds order by clause, pass in the dict with columns as keys and asc or desc for ascending and descending
        :param dict columns: Dict of columns and order type
        """
        assert isinstance(raw_query, str), 'must be string'
        self._raw_query = raw_query

    def limit(self, rows):
        """
        This adds rows limit
        :param int rows: Number of rows you wanna get
        """
        assert isinstance(rows, int)
        self._limit = rows
        return self

    def offset(self, rows):
        """
        This adds offset in limit
        :param int rows: Number of rows you wanna skip
        """
        assert isinstance(rows, int)
        self._offset = rows

    def having(self, column, value, op=None):
        """
        This sets having clause with less than equal operator
        :param str column: Column name
        :param str|int|float|list value: Condition string
        """
        value = self._push_value_in_parameters_list(value)
        if op:
            self._having_lte = 'HAVING {} {} {}'.format(column, op, value)
        else:
            self._having_lte = 'HAVING {} <= {}'.format(column, value)
        return self

    def set_complex_select_clause(self, select_clause, params_dict=dict()):
        """
        This method inserts a complex select clause directly and validates it's params before formatting them into query
        :param str select_clause: Select clause
        :param params_dict:
        :return:
        """
        self._select = select_clause.format(**params_dict)
        return self

    def set_parenthesised_where_clause(self, where_clause, params_dict={}):
        """
        This method sets where clause with parentheses
        :param where_clause:
        :param params_dict:
        :return:
        """
        self._parenthisised_where.append(where_clause.format(**params_dict))
        return self
