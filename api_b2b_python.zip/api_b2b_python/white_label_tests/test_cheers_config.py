"""
Test Cheers Config Api
"""
import json

import pytest
from common.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestCheersConfigApi(object):
    """
    Test Cheers Config Api.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            '__platform': 'ios',
            'app_version': '2.0',
            'language': 'en',
            'wlcompany': 'maf',
        }

    @pytest.mark.order1
    def test_get_cheers_configs_with_valid_data(self, client, request_data):
        """
        Test the cheers config api with correct params.
        """
        response = client.get(url_for_api_version(endpoint='configurations/cheers', version=self.version),
                              data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert len(response_data['data']) > 0
        response_data['data']['cheers_rules'] = response_data['data']['cheers_rules'][0]
        assert response_data['data']['cheers_rules']['os'] == 'all'
        assert response_data['data']['cheers_rules']['value'] == 1
        assert response_data['data']['cheers_rules']['key'] == 'locations'

    @pytest.mark.order2
    def test_get_cheers_configs_with_missing_wl_company(self, client, request_data):
        """
        Test the cheers configs with correct params and missing wl company.
        """
        del request_data['wlcompany']
        response = client.get(url_for_api_version(endpoint='configurations/cheers', version=self.version),
                              data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "wlcompany: missing required parameter"
