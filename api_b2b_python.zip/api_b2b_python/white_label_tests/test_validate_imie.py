"""
Test Configs Api
"""
import json

import pytest
from common.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestConfigsApi(object):
    """
    Test Configs Api.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'key': 'HSKEYACE1',
            'wlcompany': 'HS',
            'language': 'en',
        }

    @pytest.mark.order1
    def test_get_validate_imie_with_valid_data(self, client, request_data):
        """
        Test the validate imie api with correct params.
        """
        response = client.get(url_for_api_version(endpoint='validate/imie', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert len(response_data['data']) > 0
        response_data['data']['validation_status'] = response_data['data']['validation_status'][0]
        assert response_data['data']['validation_status']['os'] == 'all'
        assert response_data['data']['validation_status']['value'] == 1
        assert response_data['data']['validation_status']['key'] == 'locations'

    @pytest.mark.order2
    def test_get_validate_imie_with_missing_wl_company(self, client, request_data):
        """
        Test the configs with correct params and missing wl company.
        """
        del request_data['wlcompany']
        response = client.get(url_for_api_version(endpoint='validate/imie', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "wlcompany: missing required parameter"

    @pytest.mark.order3
    def test_get_validate_imie_with_missing_key(self, client, request_data):
        """
        Test the validate imie with correct params and missing key.
        """
        del request_data['key']
        response = client.get(url_for_api_version(endpoint='validate/imie', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "key: missing required parameter"
