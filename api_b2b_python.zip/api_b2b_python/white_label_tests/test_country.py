"""
Test Country Api
"""
import json

import pytest
from common.common_helpers import url_for_api_version


@pytest.mark.usefixtures('client_class')
class TestCountryApi(object):
    """
    Test Country Api.
    """
    version = '1'

    @pytest.fixture()
    def request_data(self):
        return {
            'wlcompany': 'maf',
            '__i': '1312170',
            '__sid': '18022240',
            'istravel': 'true',
            'language': 'en',
            'session_token': '6573971705bfbf8a09575d9.67949037'
        }

    @pytest.mark.order1
    def test_get_country_with_valid_data(self, client, request_data):
        """
        Test the country with correct params.
        """
        response = client.get(url_for_api_version(endpoint='country', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 200
        assert response_data['success']
        assert len(response_data['data']) > 0
        response_data['data']['countries'] = response_data['data']['countries'][0]
        assert response_data['data']['countries']['os'] == 'all'
        assert response_data['data']['countries']['value'] == 1
        assert response_data['data']['countries']['key'] == 'locations'

    @pytest.mark.order2
    def test_get_country_with_missing_wl_company(self, client, request_data):
        """
        Test the country api with correct params and missing wl company.
        """
        del request_data['wlcompany']
        response = client.get(url_for_api_version(endpoint='country', version=self.version), data=request_data)
        response_data = json.loads(response.get_data().decode('utf8'))
        assert response.status_code == 400
        assert response_data['message'] == "wlcompany: missing required parameter"
